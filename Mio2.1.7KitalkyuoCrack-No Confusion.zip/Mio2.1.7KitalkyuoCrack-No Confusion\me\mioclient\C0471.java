package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.List;
import java.util.AbstractMap.SimpleEntry;
import java.util.Map.Entry;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public final class C0471 implements C0045, C0997 {
   public static int f1104 = w.a<"B">(8504033399850219006L, 257832362129977838L);

   public C0471() {
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
      w.a<"Û">(C0933.f1413, new C0454(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C1116(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0440(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C1049(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C1278(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0199(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0988(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0704(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0058(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0756(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0228(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C1254(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0213(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C1162(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0566(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0279(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0831(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C0531(), 126119458508482463L);
      w.a<"Û">(C0933.f1413, new C1274(), 126119458508482463L);
   }

   @C1027
   public void m2519(C0628 var1) {
      Iterator var2 = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         C1266 var3 = (C1266)w.a<"Û">(var2, 192468336863492695L);
         if (var3 instanceof C0601 var4) {
            var4.m3245(var4.m3243());
         }
      }
   }

   @Override
   public JsonElement toJson() {
      JsonObject var1 = new JsonObject();
      Iterator var2 = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         C1266 var3 = (C1266)w.a<"Û">(var2, 192468336863492695L);
         if (var3 instanceof C0601) {
            try {
               w.a<"Û">(var1, w.a<"Û">(var3, 123401924173496230L), w.a<"Û">(var3, 330994760695067988L), 130151082343781043L);
            } catch (Exception var5) {
               w.a<"Û">(var5, 277292852406578821L);
            }
         }
      }

      return var1;
   }

   @Override
   public void fromJson(JsonElement var1) {
      w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(
                  w.a<"Û">(w.a<"Û">(w.a<"Û">(var1, 322749330123725882L), 365019034879995407L), 218807454277778388L),
                  w.a<"B">(
                     (Function<Entry, Integer>)var0 -> {
                        try {
                           return w.a<"B">(
                              w.a<"Û">(
                                 w.a<"Û">(
                                    w.a<"Û">(w.a<"Û">((JsonElement)w.a<"Û">(var0, 196870340575900401L), 322749330123725882L), "hud", 216368726004279618L),
                                    "index",
                                    268791691692763549L
                                 ),
                                 113424266836384094L
                              ),
                              367942141483020029L
                           );
                        } catch (Throwable var2) {
                           return w.a<"B">((f1104 | 191681) + ~(f1104 & 191681) + 1 ^ -236529165, 367942141483020029L);
                        }
                     },
                     224107444354928270L
                  ),
                  267272267864878514L
               ),
               (Function<Entry, SimpleEntry<Object, Object>>)var0 -> new SimpleEntry<>(
                     (C1266)w.a<"Û">(
                        w.a<"Û">(
                           C0933.f1413,
                           (Predicate<C1266>)var1x -> w.a<"Û">(
                                 w.a<"Û">(var1x, 123401924173496230L), (String)w.a<"Û">(var0, 141740301999341859L), 307662238383225114L
                              ),
                           120632717548688135L
                        ),
                        null,
                        237682386832069967L
                     ),
                     (JsonElement)w.a<"Û">(var0, 196870340575900401L)
                  ),
               141209812120559377L
            ),
            (Predicate<SimpleEntry>)var0 -> w.a<"Û">(var0, 303837109762247205L) instanceof C0601,
            287370376266094532L
         ),
         (Consumer<SimpleEntry>)var0 -> {
            try {
               w.a<"Û">((C1266)w.a<"Û">(var0, 303837109762247205L), (JsonElement)w.a<"Û">(var0, 238411326873787083L), 221340337294098988L);
            } catch (Exception var2) {
               w.a<"Û">(var2, 277292852406578821L);
            }
         },
         363246113849499757L
      );
   }

   @Override
   public String getConfigName() {
      return "hud.json";
   }

   public static String _QJPKlaHFL4imDeom4k2vyYMx8uYvBMtmk91TmPEgnqTTiCw3Yz6044MS0HBAHweSCofejsaoVGHxAmPZvsXVcjI2PNCDM5I9xA8/* $VF was: 4QJPKlaHFL4imDeom4k2vyYMx8uYvBMtmk91TmPEgnqTTiCw3Yz6044MS0HBAHweSCofejsaoVGHxAmPZvsXVcjI2PNCDM5I9xA8*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
