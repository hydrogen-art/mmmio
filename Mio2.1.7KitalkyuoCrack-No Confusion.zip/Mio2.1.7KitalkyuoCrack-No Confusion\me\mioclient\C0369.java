package me.mioclient;

import java.util.function.Predicate;

public class C0369 implements Predicate {
   public C1362 f4450;

   public C0369(C1362 var1) {
      this.f4450 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4450.f3545, 254992554122318132L);
   }
}
