package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0347 implements C0196 {
   f1909 {
      @Override
      public String getName() {
         return "Strafe";
      }

      public static String aoUh0OvR8oFRvDcNcXBhc2fnGmkJ9j9utu8UtchHkm1WCx20OMzdoo7PaxvFuKd03fuIwHYeI0oICGU6AuCpwA3Q7U4nTDJGeGso(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   },
   f1910 {
      @Override
      public String getName() {
         return "StrafeStrict";
      }

      public static String _Brp6FwKiUqb0eF6sY91fCyx594LirzpTbWtPMT1SBuar8ScQP6bSPsllbo0wv0lBVpUS3zeTjnrRSJ96Fh1bBpxGGTxwJzZOuc4/* $VF was: 2Brp6FwKiUqb0eF6sY91fCyx594LirzpTbWtPMT1SBuar8ScQP6bSPsllbo0wv0lBVpUS3zeTjnrRSJ96Fh1bBpxGGTxwJzZOuc4*/(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   },
   f1911 {
      @Override
      public String getName() {
         return "Vanilla";
      }

      public static String ON07md83QnAfAqab3nZYy1G1hHN6U0D2YHRNqRMpzXHypoJ53U227Zm5BIQAa13ekheGZph4nmjZzMWCAE6dDWcPesUMfgENHySi(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   },
   f1912 {
      @Override
      public String getName() {
         return "OnGround";
      }

      public static String u15YWzzhGM9KE4NdEkAEWGjmswl6NLbsz5UocLpwCPqLodp0YLCG3DXHeHgdgoB7VS6lelKVh8Ue2iIap0SM9Nz9RDB2zR4zrQ4F(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   },
   f1913 {
      @Override
      public String getName() {
         return "Grim";
      }

      public static String qou16SVZJqTYbwh7i7YLKhpdShojVkBtkoT0QEmGRgDP8BukU2xLLJPFAexdGWPUlGjyzl4OxbQgXNZ2GoBJ0pugWcR6beIk9HoJ(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   },
   f1914 {
      @Override
      public String getName() {
         return "None";
      }

      public static String zy93pMEKQ9z3tZN9eaozjKUdyCzXbJlULc5w4nX298zOQr8XG5kWMWD6I8LGRfJVTCifK4ylpPw8poMO38yIgMt8vjLuCQPfX1hO(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   };

   public static String X7QTFO0pPb4QjjzmnQB6XKwzGUD2SJyaXX4pbdALIdePTLgH0U4riwtT1ees0GRCSdHdQ1NlHKL0esfJuOUUvWVVpO57k7rEIKSR(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
