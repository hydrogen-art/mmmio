package me.mioclient;

import java.util.function.Predicate;

public class C0242 implements Predicate {
   public C0931 f3891;

   public C0242(C0931 var1) {
      this.f3891 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3891.f2424, 254992554122318132L);
   }
}
