package me.mioclient;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;

public final class C0205 extends C1316<C0915> implements C0045 {
   public final List<CompletableFuture<?>> f3082 = new ArrayList<>();
   public int f3083;
   public static int f3084 = w.a<"B">(8432145267493482607L, 257832362129977838L);

   public C0205() {
      this.f3083 = (f3084 | 686921) + ~(f3084 & 686921) + 1 ^ 1315816471;
   }

   public void m3301(String var1, BiConsumer<String, ? super Throwable> var2) {
   }

   public boolean m3302() {
      Iterator var1 = w.a<"Û">(this.f3082, 341496865259068134L);

      while (w.a<"Û">(var1, 333900474771661065L)) {
         CompletableFuture var2 = (CompletableFuture)w.a<"Û">(var1, 192468336863492695L);
         if (!w.a<"Û">(var2, 370600344815678040L)) {
            return (boolean)((f3084 | 960849) + ~(f3084 & 960849) + 1 ^ 1315509775);
         }
      }

      return (boolean)((f3084 | 41778) + ~(f3084 & 41778) + 1 ^ 1315380333);
   }

   public boolean m3303() {
      Iterator var1 = w.a<"Û">(this.f3082, 341496865259068134L);

      while (w.a<"Û">(var1, 333900474771661065L)) {
         CompletableFuture var2 = (CompletableFuture)w.a<"Û">(var1, 192468336863492695L);
         if (w.a<"Û">(var2, 226898427649021788L)) {
            return (boolean)((f3084 | 328885) + ~(f3084 & 328885) + 1 ^ 1315093482);
         }
      }

      return (boolean)((f3084 | 724762) + ~(f3084 & 724762) + 1 ^ 1315745860);
   }

   public int m3304() {
      return this.f3083;
   }
}
