package me.mioclient;

import java.util.function.Supplier;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class C0469 extends C0711 {
   public final Runnable f0731;
   public static int f0732 = -2130065325;

   public C0469(C1244 var1, String var2, Runnable var3) {
      this(var1, () -> var2, var3);
   }

   public C0469(C1244 var1, Supplier<String> var2, Runnable var3) {
      super(var1, var2);
      this.f0731 = var3;
      this.m$$VFobpBmjYrLoHtlzhQjqArXF3GoygsgnFldYTU5ZJolRPOOIBp4QiLFYPQEEwA4rSmGtYToZsGR4J0pZcIqfKh1fui8thTzZj(
         (boolean)((f0732 | 557603) + ~(f0732 & 557603) + 1 ^ -2130621839)
      );
   }

   @Override
   public void m0001(class_332 var1, class_4587 var2, double var3, double var5) {
      if (this.m0352()) {
         C0438.m3962(
            var2,
            (float)(
               this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                  + ((f0732 | 138695) + ~(f0732 & 138695) + 1 ^ -2129930859)
            ),
            (float)(
                  this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                     + this.m$$hlCUpAMCB8w0fikXDazwCNyOBsPOGWgAm2lmO5tu7dGyqkbhliec158gzgZe9bnF3DuoOxLmXH5dfCU0wQDHsWXD8knX2Gis1
               )
               + Float.intBitsToFloat((f0732 | 844114) + ~(f0732 & 844114) + 1 ^ -1106958079),
            (float)(
               this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                  + this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.m0240()
                  - ((f0732 | 885087) + ~(f0732 & 885087) + 1 ^ -2130425587)
            ),
            (float)(
                  this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                     + this.m$$hlCUpAMCB8w0fikXDazwCNyOBsPOGWgAm2lmO5tu7dGyqkbhliec158gzgZe9bnF3DuoOxLmXH5dfCU0wQDHsWXD8knX2Gis1
                     + this.m$$xdvvw3zUfaxk5zyR1LuOyULP1ncsBH0Jp7Rg4gVMI1b0GhMBLMGdWDzO5FqEI2nDnNORyLVYlZg5A0VP0jSXwr08L1rXIE9mU()
               )
               - Float.intBitsToFloat((f0732 | 674349) + ~(f0732 & 674349) + 1 ^ -1107066242),
            this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3779.getValue()
         );
      }

      super.m0001(var1, var2, var3, var5);
   }

   public void m0351(double var1, double var3, int var5) {
      super.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(var1, var3, var5);
      if (this.m$$KS06f9f0NeLXQssz988RwWxLCd732LAhBiLrzA6AumbpOGfb45EuzpXjfSeTD0OkSNHYLtbwg5PkbT1fpFz6nDh4Qmr4NR48O(var1, var3) && var5 == 0) {
         this.f0731.run();
      }
   }

   public boolean m0352() {
      return (boolean)((f0732 | 264918) + ~(f0732 & 264918) + 1 ^ -2129804668);
   }

   static {
      long var10000 = 6583243360855786716L;
   }
}
