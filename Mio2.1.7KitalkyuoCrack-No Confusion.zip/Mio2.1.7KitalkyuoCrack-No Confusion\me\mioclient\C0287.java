package me.mioclient;

import net.minecraft.class_332;
import net.minecraft.class_4587;

public class C0287 extends C1180 {
   public static final C0287 f3644 = new C0287();
   public class_4587 f3645;
   public class_332 f3646;
   public float f3647;

   public static C0287 m1512(class_4587 var0, class_332 var1, float var2) {
      f3644.f3645 = var0;
      f3644.f3647 = var2;
      f3644.f3646 = var1;
      f3644.m$$PnImoBYt9TWIQWIZlu7x4PlhMDyByiNsAByNVyDskMUoK138NBsECzhidsQ4dW8jIrxRO1miiLIJHcgVioDyfs0PQSZvvw3Cx();
      return f3644;
   }

   public class_4587 m1513() {
      return this.f3645;
   }

   public float m1514() {
      return this.f3647;
   }

   public class_332 m1515() {
      return this.f3646;
   }
}
