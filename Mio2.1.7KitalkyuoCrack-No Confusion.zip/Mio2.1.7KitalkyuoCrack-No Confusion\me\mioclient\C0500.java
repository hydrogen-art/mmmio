package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2561;

public class C0500 extends C1266 {
   public final C0015<C0501> f2783;
   public final C0015<String> f2784;
   public static final String[] f2785;
   public static int f2786 = w.a<"B">(7958475758207513006L, 257832362129977838L);

   public C0500() {
      super("CustomDeathText", "Displays a custom message on your death screen.", C1045.f3173);
      w.a<"B">(this, 242859112966675773L);
      w.a<"Û">(this, (boolean)((f2786 | 554633) + ~(f2786 & 554633) + 1 ^ -1883451652), 135570431627433065L);
   }

   public class_2561 m1107() {
      return (class_2561)(w.a<"Û">(this.f2783, 174312564406604366L) == C0501.f2779
         ? w.a<"B">(w.a<"Û">((String)w.a<"Û">(this.f2784, 174312564406604366L), 252583459449976237L), 273107254583785490L)
         : w.a<"B">(f2785[w.a<"Û">(w.a<"B">(339623076596514038L), f2785.length, 290903900221401347L)], 228465064790135899L));
   }

   static {
      String[] var10000 = new String[(f2786 | 74508) + ~(f2786 & 74508) + 1 ^ -1883923600];
      var10000[(f2786 | 568593) + ~(f2786 & 568593) + 1 ^ -1883499164] = "YOU USELESS SHITSTAIN";
      var10000[(f2786 | 926273) + ~(f2786 & 926273) + 1 ^ -1883596235] = "GAME OVER MOTHERFUCKER! YOU SUCK!";
      var10000[(f2786 | 459484) + ~(f2786 & 459484) + 1 ^ -1884046677] = "HOW THE HELL ARE YOU SO BAD AT THIS GAME?";
      var10000[(f2786 | 882687) + ~(f2786 & 882687) + 1 ^ -1883648119] = "HOW DO YOU FUCK UP SO BADLY JESUS FUCKING CHRIST?";
      var10000[(f2786 | 882349) + ~(f2786 & 882349) + 1 ^ -1883648292] = "YOU DIED! CONGRATS FUCKFACE";
      var10000[(f2786 | 800484) + ~(f2786 & 800484) + 1 ^ -1883730284] = "OH MY GOD YOU SUCK! AUTO-UNINSTALLING";
      var10000[(f2786 | 249892) + ~(f2786 & 249892) + 1 ^ -1883805609] = "HOLY FUCKING SHIT SERIOUSLY";
      var10000[(f2786 | 939232) + ~(f2786 & 939232) + 1 ^ -1883575150] = "YOU FUCKING RETARD!";
      var10000[(f2786 | 634716) + ~(f2786 & 634716) + 1 ^ -1883433183] = "YOU DENSE FUCK";
      f2785 = var10000;
   }

   public static String _XDq9Ng0mcYuxGjmJMOHisBCMuScKCYxo8i18E0G8b4uhqZfdzc5TYK2LD4n6QXI6hnF15s6Ci8W2KHvFqt7Z9YVxIR4K9IaAhQW/* $VF was: 3XDq9Ng0mcYuxGjmJMOHisBCMuScKCYxo8i18E0G8b4uhqZfdzc5TYK2LD4n6QXI6hnF15s6Ci8W2KHvFqt7Z9YVxIR4K9IaAhQW*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
