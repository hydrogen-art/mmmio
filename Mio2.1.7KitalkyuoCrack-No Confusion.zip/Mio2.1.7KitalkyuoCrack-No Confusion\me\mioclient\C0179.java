package me.mioclient;

import java.util.function.Predicate;

public class C0179 implements Predicate {
   public C0671 f0355;

   public C0179(C0671 var1) {
      this.f0355 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0355.f4651, 174312564406604366L) == C0672.f4560 || w.a<"Û">(this.f0355.f4651, 174312564406604366L) == C0672.f4558;
   }
}
