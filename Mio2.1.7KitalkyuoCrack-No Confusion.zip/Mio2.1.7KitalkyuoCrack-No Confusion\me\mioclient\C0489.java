package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import sun.misc.Unsafe;

public class C0489 {
   public Unsafe f1575;
   public List<String> f1576 = new ArrayList<>();
   public static int f1577 = 881762251;

   public C0489() {
      try {
         Field var1 = Unsafe.class.getDeclaredField("theUnsafe");
         var1.setAccessible((boolean)((f1577 | 942625) + ~(f1577 & 942625) + 1 ^ 880868843));
         this.f1575 = (Unsafe)var1.get(null);
      } catch (Exception var2) {
      }
   }

   public <T extends C1266> T m2696(Class<T> var1) {
      if (this.f1575 != null && C0933.f1413 == null) {
         try {
            String var2 = null;
            StackTraceElement[] var3 = Thread.currentThread().getStackTrace();
            int var4 = var3.length;

            for (int var5 = (f1577 | 90008) + ~(f1577 & 90008) + 1 ^ 881836115; var5 < var4; var5++) {
               StackTraceElement var6 = var3[var5];
               String var7 = var6.getClassName();
               if (!var7.contains("java.lang.Thread") && !var7.contains(this.getClass().getName())) {
                  var2 = var7;
                  break;
               }
            }

            if (var2 == null) {
               throw new RuntimeException();
            }

            if (!this.f1576.contains(var2)) {
               this.f1576.add(var2);
            }
         } catch (Exception var8) {
         }

         return null;
      } else {
         return C0933.f1413.m0395(var1);
      }
   }

   public void m2697() {
      for (String var2 : this.f1576) {
         Class var3 = null;

         try {
            var3 = Class.forName(var2, (boolean)((f1577 | 420379) + ~(f1577 & 420379) + 1 ^ 881391056), C0045.class.getClassLoader());
         } catch (Exception var10) {
            throw new RuntimeException();
         }

         Field[] var4 = var3.getDeclaredFields();
         int var5 = var4.length;

         for (int var6 = (f1577 | 364705) + ~(f1577 & 364705) + 1 ^ 881528682; var6 < var5; var6++) {
            Field var7 = var4[var6];
            if (Modifier.isStatic(var7.getModifiers()) && C1266.class.isAssignableFrom(var7.getType())) {
               try {
                  C1266 var8 = C0933.f1413.m0395((Class<C1266>)var7.getType());
                  if (var8 == null) {
                     throw new RuntimeException();
                  }

                  this.f1575.putObject(var3, this.f1575.staticFieldOffset(var7), var8);
               } catch (Exception var9) {
               }
            }
         }
      }

      this.f1576.clear();
      System.gc();
   }

   static {
      long var10000 = 4459495006158396819L;
   }

   public static String Vc5j83Kh9IDKHjtTHfQqytJJ00qlrXadj6ujHupPoAIHDklMq0LqrKFqRgfzu5PafJ4ZAO1eAeUj6VrtDkFlIa9GxJ0wDv0s9KCq(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
