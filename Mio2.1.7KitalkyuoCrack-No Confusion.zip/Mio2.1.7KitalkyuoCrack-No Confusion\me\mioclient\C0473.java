package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1802;

public class C0473 extends C1266 {
   public static int f4462 = w.a<"B">(5649439838055345907L, 257832362129977838L);

   public C0473() {
      super("ItemSaver", "Prevents your tools from breaking.", C1045.f3176);
   }

   @C1027
   public void m3811(C0368 var1) {
      int var2 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545;
      class_1799 var3 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
         var2,
         386860178278302175L
      );
      if (!w.a<"B">(var3, 318666340791049523L)) {
         if (w.a<"Û">(
                  (C0840)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761, 366989514883082794L
               )
               != null
            && w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690.field_1886, 262940020655803083L
            )) {
            w.a<"B">(
               var2 == ((f4462 | 808679) + ~(f4462 & 808679) + 1 ^ 1016137662)
                  ? var2 - ((f4462 | 380046) + ~(f4462 & 380046) + 1 ^ 1016634846)
                  : var2 + ((f4462 | 922962) + ~(f4462 & 922962) + 1 ^ 1016284162),
               279757124141714355L
            );
            w.a<"Û">(var1, 385440235371820560L);
         }
      }
   }

   public static boolean m3812(class_1799 var0) {
      if (!w.a<"Û">(var0, 330190014994709712L)
         && w.a<"Û">(var0, 263055534152868350L)
         && !(w.a<"Û">(var0, 222207108884875224L) instanceof class_1738)
         && !w.a<"Û">(var0, class_1802.field_8833, 282470456889867724L)) {
         return (boolean)(w.a<"B">(var0, 188113691055505329L) > ((f4462 | 296065) + ~(f4462 & 296065) + 1 ^ 1016714714)
            ? (f4462 | 913169) + ~(f4462 & 913169) + 1 ^ 1016118849
            : (f4462 | 729230) + ~(f4462 & 729230) + 1 ^ 1016492511);
      } else {
         return (boolean)((f4462 | 690568) + ~(f4462 & 690568) + 1 ^ 1016584408);
      }
   }

   public static String ihrg6vANEDyBxlblYzM8eAjNo7eFzM9bERhS0CA2XXpGh51U55WK62ptBjA61Cx4nfPAsWrzxXX23yGLgJgiWjkI1WqtBwzLj2LI(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
