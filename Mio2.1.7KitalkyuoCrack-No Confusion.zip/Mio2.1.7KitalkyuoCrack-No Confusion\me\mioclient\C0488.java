package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.List;
import net.minecraft.class_2172;
import net.minecraft.class_2520;
import net.minecraft.class_3169;
import net.minecraft.class_5250;
import net.minecraft.class_2203.class_2209;

public class C0488 extends C0219 {
   public static int f2290 = w.a<"B">(6355714778069490870L, 257832362129977838L);

   public C0488() {
      super("nbt");
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         var1,
         (Command)var0 -> {
            class_3169 var1x = new class_3169(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724);
            class_2209 var2 = w.a<"B">("SelectedItem", 282059471373736290L);
            class_5250 var3 = w.a<"B">(151712998973257886L);
            var3 = w.a<"Û">(var3, "Nbt: ", 194629304146735395L);

            try {
               List var4 = w.a<"Û">(var2, w.a<"Û">(var1x, 193332681619104157L), 280926577636863671L);
               if (!w.a<"Û">(var4, 284469716622774448L)) {
                  w.a<"Û">(
                     w.a<"Û">(var3, " ", 194629304146735395L),
                     w.a<"B">((class_2520)w.a<"Û">(var4, 190855132863596333L), 377159157096852534L),
                     267862536496645581L
                  );
               }
            } catch (CommandSyntaxException var5) {
               w.a<"Û">(var3, "{}", 194629304146735395L);
            }

            w.a<"B">(var3, w.a<"B">((f2290 | 773032) + ~(f2290 & 773032) + 1 ^ 1962848481, 289296048454852994L), 241936116971186271L);
            return (f2290 | 292087) + ~(f2290 & 292087) + 1 ^ -1961955264;
         },
         286944572020109927L
      );
   }

   public static String dCbmqzdvjYmnkrvV6FKjq8Lj0UIDiNhvUiODdx4tUtUQWL0VsZNUIOl83oVimRGR3JhpHjy1wPVF57jb6jY7TwYRijQ2la2nYh7v(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
