package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0508 {
   f2371 {
      @Override
      public boolean m0177(C0015<?> var1) {
         return w.a<"Û">(var1, 174312564406604366L).equals(w.a<"Û">(var1, 282635387798544717L));
      }
   },
   f2372 {
      @Override
      public boolean m0177(C0015<?> var1) {
         return w.a<"Û">(var1, 174312564406604366L).equals(w.a<"Û">(var1, 356267007715237645L));
      }
   };

   public boolean m0177(C0015<?> var1) {
      return false;
   }

   public static String gm7Nr7unOx2Zyr6CY3u1iWK43Yz3DHPluvnz6OGxMKkOv8mM1A2AObiaIVKm1PDtiubKmB1M5YUkxtQf17FLJHjS8nat2dAN2EAt(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
