package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0166 implements C0196 {
   f3589("Full"),
   f3590("Vertical"),
   f3591("Horizontal"),
   f3592("Random");

   public final String f3593;

   public C0166(String var3) {
      this.f3593 = var3;
   }

   @Override
   public String getName() {
      return this.f3593;
   }

   public static String rvRzxI9na1ZDA6JBtT32PzWzUiFTAgjcfQI6EQtqMEq95SDHOQu9Q6DgbVXlwWTMfqmx6qb3lAI27wiVFTVXBW6udty3ipLjuJrb(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
