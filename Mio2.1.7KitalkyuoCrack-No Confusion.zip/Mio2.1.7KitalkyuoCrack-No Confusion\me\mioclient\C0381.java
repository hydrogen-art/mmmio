package me.mioclient;

import net.minecraft.class_2338;

public interface C0381 {
   void m2137(C0502 var1);

   void m2138(C0502 var1);

   boolean m2139();

   boolean m2140();

   void m2141(double var1);

   void m2142(class_2338 var1);

   void m2143(class_2338 var1);

   void m2144();

   void m2145(class_2338 var1);

   boolean m2146(class_2338 var1);

   boolean m2147();

   class_2338 m2148();
}
