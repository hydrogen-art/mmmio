package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1297;
import net.minecraft.class_276;
import net.minecraft.class_310;
import net.minecraft.class_4618;
import net.minecraft.class_6367;
import org.lwjgl.glfw.GLFW;

public abstract class C0319 implements C0045 {
   public class_4618 f2149;
   public class_276 f2150;
   public C1085 f2151;
   public static int f2152 = 1450810920;

   public void m2874(String var1) {
      this.f2149 = new class_4618(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22940().method_23000()
      );
      this.f2150 = new class_6367(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4489(),
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4506(),
         (boolean)((f2152 | 876026) + ~(f2152 & 876026) + 1 ^ 1450492882),
         class_310.field_1703
      );
      this.f2151 = new C1085("/base.vert", new C1002().m2591(var1).m2593("/\u0001.frag"));
   }

   public void m2875(String var1, String var2) {
      this.f2149 = new class_4618(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22940().method_23000()
      );
      this.f2150 = new class_6367(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4489(),
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4506(),
         (boolean)((f2152 | 554565) + ~(f2152 & 554565) + 1 ^ 1450305645),
         class_310.field_1703
      );
      this.f2151 = new C1085(new C1002().m2591(var1).m2593("/\u0001.vert"), new C1002().m2591(var2).m2593("/\u0001.frag"));
   }

   public abstract boolean m2876();

   public abstract boolean m2877(class_1297 var1);

   public void m1462() {
   }

   public void m1463() {
   }

   public abstract void m2878();

   public void m2879() {
      if (this.m2876()) {
         this.f2150.method_1230(class_310.field_1703);
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1522()
            .method_1235((boolean)((f2152 | 195156) + ~(f2152 & 195156) + 1 ^ 1450927228));
      }
   }

   public void m2880(Runnable var1) {
      if (this.m2876()) {
         this.m1462();
         var1.run();
         this.m1463();
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1522()
            .method_1235((boolean)((f2152 | 439759) + ~(f2152 & 439759) + 1 ^ 1451174887));
         C0525.m1296(this.f2150.method_30277(), (f2152 | 861155) + ~(f2152 & 861155) + 1 ^ 1450491339);
         this.f2151.m2504();
         this.f2151
            .m2509(
               "u_Size",
               (double)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4489(),
               (double)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4506()
            );
         this.f2151.m2507("u_Texture", (f2152 | 455362) + ~(f2152 & 455362) + 1 ^ 1451191530);
         this.f2151.m2508("u_Time", GLFW.glfwGetTime());
         this.m2878();
         C0127.m3753();
      }
   }

   public void m2881(int var1, int var2) {
      if (this.f2150 != null) {
         this.f2150.method_1234(var1, var2, class_310.field_1703);
      }
   }

   static {
      long var10000 = 7963853859116379504L;
   }

   public static String X9FZG7RU2XuuTu1d1C79UxBuxfjtOuJ3QWAVRsJHmaczrDwnRjWCyINCvqh5R9pSzSvR7J5Q3K3n4OE1vQNV0CT2tORfu4ZFqC6r(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
