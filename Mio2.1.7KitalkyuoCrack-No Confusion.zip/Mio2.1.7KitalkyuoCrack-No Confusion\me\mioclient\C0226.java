package me.mioclient;

import java.util.function.Predicate;

public class C0226 implements Predicate {
   public C0879 f2825;

   public C0226(C0879 var1) {
      this.f2825 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2825.f3778, 254992554122318132L);
   }
}
