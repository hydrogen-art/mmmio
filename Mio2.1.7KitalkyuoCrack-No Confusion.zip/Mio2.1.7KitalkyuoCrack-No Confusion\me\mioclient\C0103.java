package me.mioclient;

import java.util.function.Predicate;

public class C0103 implements Predicate {
   public C0936 f2339;

   public C0103(C0936 var1) {
      this.f2339 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2339.f1817, 254992554122318132L);
   }
}
