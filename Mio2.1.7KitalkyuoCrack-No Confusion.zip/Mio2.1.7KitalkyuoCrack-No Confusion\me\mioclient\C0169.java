package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_4792;
import net.minecraft.class_4794;
import net.minecraft.class_5165;
import net.minecraft.class_657;
import net.minecraft.class_703;
import net.minecraft.class_709;
import net.minecraft.class_734;
import net.minecraft.class_677.class_680;
import net.minecraft.class_677.class_681;

public class C0169 extends C1266 {
   public final Random f1302 = new Random();
   public final C0015<Boolean> f1303;
   public final C0015<Float> f1304;
   public final C0015<Float> f1305;
   public final C0015<Color> f1306;
   public final C0015<Color> f1307;
   public final C0015<Boolean> f1308;
   public final C0015<Boolean> f1309;
   public final C0015<Float> f1310;
   public final C0015<Color> f1311;
   public final C0015<Boolean> f1312;
   public final C0015<Float> f1313;
   public final C0015<Float> f1314;
   public final C0015<Color> f1315;
   public final C0015<Boolean> f1316;
   public final C0015<Float> f1317;
   public final C0015<Color> f1318;
   public final C0015<Boolean> f1319;
   public final C0015<Color> f1320;
   public final C0015<Color> f1321;
   public static int f1322 = w.a<"B">(9126878708285012764L, 257832362129977838L);

   public C0169() {
      super("Particles", "Allows you to adjust certain particles.", C1045.f3174);
      w.a<"B">(this, 242859112966675773L);
      w.a<"Û">(this, (boolean)((f1322 | 581871) + ~(f1322 & 581871) + 1 ^ 201770188), 135570431627433065L);
   }

   @C1027
   public void m0581(C0521 var1) {
      if (w.a<"Û">(var1, 274841324610399830L) instanceof class_734 var2) {
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f1308, 174312564406604366L), 354697271520518137L)
            && w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L),
               w.a<"Û">(var2, 193276607895770577L),
               133676266014519719L
            )) {
            w.a<"Û">(var1, 385440235371820560L);
         }

         if (!w.a<"Û">((Boolean)w.a<"Û">(this.f1303, 174312564406604366L), 354697271520518137L)) {
            return;
         }

         if (w.a<"Û">(this.f1302, (f1322 | 797675) + ~(f1322 & 797675) + 1 ^ 201461708, 246303119967947802L) == 0) {
            w.a<"Û">(this, var2, w.a<"Û">((Color)w.a<"Û">(this.f1306, 174312564406604366L), 301840407077149108L), 245520536730542653L);
         } else {
            w.a<"Û">(this, var2, w.a<"Û">((Color)w.a<"Û">(this.f1307, 174312564406604366L), 301840407077149108L), 245520536730542653L);
         }

         w.a<"Û">(var2, w.a<"Û">((Float)w.a<"Û">(this.f1304, 174312564406604366L), 149784643039979208L), 339367559908504616L);
         w.a<"Û">(var2, w.a<"Û">((Float)w.a<"Û">(this.f1305, 174312564406604366L), 149784643039979208L), 231898905174635262L);
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1309, 174312564406604366L), 354697271520518137L) && w.a<"Û">(var1, 274841324610399830L) instanceof class_681 var5) {
         w.a<"Û">(this, var5, w.a<"Û">((Color)w.a<"Û">(this.f1311, 174312564406604366L), 301840407077149108L), 245520536730542653L);
         w.a<"Û">(var5, w.a<"Û">((Float)w.a<"Û">(this.f1310, 174312564406604366L), 149784643039979208L), 292771856392727657L);
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1309, 174312564406604366L), 354697271520518137L) && w.a<"Û">(var1, 274841324610399830L) instanceof class_680 var6) {
         w.a<"Û">(this, var6, w.a<"Û">((Color)w.a<"Û">(this.f1311, 174312564406604366L), 301840407077149108L), 245520536730542653L);
         w.a<"Û">(var6, w.a<"Û">((Float)w.a<"Û">(this.f1310, 174312564406604366L), 149784643039979208L), 175453394572431562L);
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1312, 174312564406604366L), 354697271520518137L) && w.a<"Û">(var1, 274841324610399830L) instanceof class_657 var7) {
         w.a<"Û">(this, var7, w.a<"Û">((Color)w.a<"Û">(this.f1315, 174312564406604366L), 301840407077149108L), 245520536730542653L);
         w.a<"Û">(var7, w.a<"Û">((Float)w.a<"Û">(this.f1313, 174312564406604366L), 149784643039979208L), 227694903696533714L);
         w.a<"Û">(var7, w.a<"Û">((Float)w.a<"Û">(this.f1314, 174312564406604366L), 149784643039979208L), 331653774897788617L);
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1316, 174312564406604366L), 354697271520518137L) && w.a<"Û">(var1, 274841324610399830L) instanceof class_709 var8) {
         w.a<"Û">(this, var8, w.a<"Û">((Color)w.a<"Û">(this.f1318, 174312564406604366L), 301840407077149108L), 245520536730542653L);
         w.a<"Û">(var8, w.a<"Û">((Float)w.a<"Û">(this.f1317, 174312564406604366L), 149784643039979208L), 363457033694503682L);
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1319, 174312564406604366L), 354697271520518137L) && w.a<"Û">(var1, 274841324610399830L) instanceof class_4794 var9) {
         if (var9 instanceof class_5165) {
            w.a<"Û">(
               this, var9, w.a<"Û">(w.a<"Û">((Color)w.a<"Û">(this.f1321, 174312564406604366L), 276690253004086927L), 301840407077149108L), 245520536730542653L
            );
         }

         if (var9 instanceof class_4792) {
            ThreadLocalRandom var15 = w.a<"B">(339623076596514038L);
            Color var4 = C0152.m3472(
               (Color)w.a<"Û">(this.f1320, 174312564406604366L), (Color)w.a<"Û">(this.f1321, 174312564406604366L), w.a<"Û">(var15, 311298917740503159L)
            );
            w.a<"Û">(this, var9, w.a<"Û">(var4, 301840407077149108L), 245520536730542653L);
         }
      }
   }

   public void m0582(class_703 var1, int var2) {
      float var3 = (float)(var2 >> ((f1322 | 685527) + ~(f1322 & 685527) + 1 ^ 201609708))
         / w.a<"B">((f1322 | 485831) + ~(f1322 & 485831) + 1 ^ 1333153252, 349057757755238323L);
      float var4 = (float)((var2 & ((f1322 | 977078) + ~(f1322 & 977078) + 1 ^ 218090645)) >> ((f1322 | 609961) + ~(f1322 & 609961) + 1 ^ 201812634))
         / w.a<"B">((f1322 | 687084) + ~(f1322 & 687084) + 1 ^ 1333485519, 349057757755238323L);
      float var5 = (float)((var2 & ((f1322 | 945740) + ~(f1322 & 945740) + 1 ^ 201373039)) >> ((f1322 | 771563) + ~(f1322 & 771563) + 1 ^ 201712064))
         / w.a<"B">((f1322 | 799356) + ~(f1322 & 799356) + 1 ^ 1333597791, 349057757755238323L);
      float var6 = (float)(var2 & ((f1322 | 420906) + ~(f1322 & 420906) + 1 ^ 201869558))
         / w.a<"B">((f1322 | 883195) + ~(f1322 & 883195) + 1 ^ 1333550552, 349057757755238323L);
      w.a<"Û">(var1, var4, var5, var6, 326168234127337563L);
      w.a<"Û">((C1159)var1, var3, 265692447086855334L);
   }

   public static String oqt1bI78F6itTDI9YkM3Rv2QjcqMLRqWJpKdJWOumNFfVIlrckdZh4jkHNHsCqzMPhYkcsSEpwKgqHZYtFkxIYK9tj3YjaQq80qE(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
