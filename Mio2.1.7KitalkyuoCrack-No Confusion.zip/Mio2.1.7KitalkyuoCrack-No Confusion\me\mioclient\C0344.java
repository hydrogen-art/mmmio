package me.mioclient;

import me.mioclient.mixin.ducks.DuckWorldRenderer;
import net.minecraft.class_276;
import net.minecraft.class_761;

public abstract class C0344 extends C0319 {
   public class_276 f3529;
   public static int f3530 = 908636998;

   @Override
   public void m1462() {
      class_761 var1 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1769;
      DuckWorldRenderer var2 = (DuckWorldRenderer)var1;
      this.f3529 = var1.method_22990();
      var2.setEntityOutlinesFramebuffer(this.m$$X2CEbZQr4SlvwxrvKHZdhmXb5mTCASQcNn0SOuhsryuQ5K5MC2yD5xT8l6AZA4RDIyXsjI4xiKJHqjETljYvI1TBA0nMVqTrU);
   }

   @Override
   public void m1463() {
      if (this.f3529 != null) {
         class_761 var1 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1769;
         DuckWorldRenderer var2 = (DuckWorldRenderer)var1;
         var2.setEntityOutlinesFramebuffer(this.f3529);
         this.f3529 = null;
      }
   }

   public void m1464() {
      this.m$$GmqWRJmEpgeNc7TLRNJ9A8zaV6NS4hgu824NfKKW2QB3t4LuMpVPodxJF3gu3qG8Ih5MUed2Utw8kr4hcmiPsI2pVPk39XRdd(
         () -> this.m$$D2Azy1oMT0A9jULp75MJoT61sp1MSsq9TNzibl81TE1bLOjJ6WC0WyS94jT7AMeMoAtZH1XStxf9lKcSFYgefROiGy2Gn5psH.method_23285()
      );
   }

   static {
      long var10000 = 3140312185769421880L;
   }
}
