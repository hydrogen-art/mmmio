package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.Supplier;

public enum C0371 {
   f0343(() -> w.a<"B">(w.a<"B">(221185, 165301049384264823L), 279131300036783447L)),
   f0344(() -> w.a<"B">(w.a<"B">(221188, 165301049384264823L), 279131300036783447L)),
   f0345(() -> w.a<"B">(w.a<"B">(221186, 165301049384264823L), 279131300036783447L));

   public static C0371 f0346 = f0343;
   public final Supplier<Long> f0347;
   public long f0348 = -1L;

   public C0371(Supplier<Long> var3) {
      this.f0347 = var3;
   }

   public long m0210() {
      if (this.f0348 == -1L) {
         this.f0348 = w.a<"Û">((Long)w.a<"Û">(this.f0347, 151449370165949320L), 151184307344636838L);
      }

      return this.f0348;
   }

   public void m0211() {
      if (this != f0346) {
         w.a<"B">(
            w.a<"Û">(w.a<"Û">(w.a<"B">(249781506980689257L), 165739045880072086L), 357688778031378998L),
            w.a<"Û">(this, 176893772025591446L),
            173087133782835375L
         );
         f0346 = this;
      }
   }

   public static String BmTUM9vr6WcYaT5tQxVObMPd78HkkyCtc9eL3xxz7Ytd2xp0hzZ9kiSlhv93njfzl1Pb7D1odiQ3eRPgZ1WbrkSiX5oZa9VsBQf0(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
