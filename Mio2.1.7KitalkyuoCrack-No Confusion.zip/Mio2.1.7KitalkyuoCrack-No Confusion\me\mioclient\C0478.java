package me.mioclient;

public interface C0478<T> {
   C0872<T> mio$data();
}
