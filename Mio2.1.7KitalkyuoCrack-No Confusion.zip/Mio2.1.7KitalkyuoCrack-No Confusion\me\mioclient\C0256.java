package me.mioclient;

import java.util.function.Predicate;

public class C0256 implements Predicate {
   public C0936 f2922;

   public C0256(C0936 var1) {
      this.f2922 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2922.f1817, 254992554122318132L) && w.a<"Û">(this.f2922.f1822, 254992554122318132L);
   }
}
