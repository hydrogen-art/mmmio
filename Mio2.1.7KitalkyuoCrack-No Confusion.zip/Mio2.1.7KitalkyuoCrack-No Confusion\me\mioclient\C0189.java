package me.mioclient;

import java.util.function.Predicate;

public class C0189 implements Predicate {
   public C0931 f5141;

   public C0189(C0931 var1) {
      this.f5141 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f5141.f2421, 254992554122318132L);
   }
}
