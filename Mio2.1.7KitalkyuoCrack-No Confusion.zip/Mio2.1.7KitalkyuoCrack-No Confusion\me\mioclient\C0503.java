package me.mioclient;

import java.util.function.Predicate;

public class C0503 implements Predicate {
   public C1161 f3742;

   public C0503(C1161 var1) {
      this.f3742 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3742.f1185, 254992554122318132L);
   }
}
