package me.mioclient;

import java.util.function.Predicate;

public class C0390 implements Predicate {
   public C0039 f5082;

   public C0390(C0039 var1) {
      this.f5082 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f5082.f5265, 254992554122318132L) && w.a<"Û">(this.f5082.f5266, 254992554122318132L);
   }
}
