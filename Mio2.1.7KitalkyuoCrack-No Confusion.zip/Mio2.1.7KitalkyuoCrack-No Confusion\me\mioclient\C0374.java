package me.mioclient;

import java.util.function.Predicate;

public class C0374 implements Predicate {
   public C1367 f4170;

   public C0374(C1367 var1) {
      this.f4170 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4170.f3921, 254992554122318132L);
   }
}
