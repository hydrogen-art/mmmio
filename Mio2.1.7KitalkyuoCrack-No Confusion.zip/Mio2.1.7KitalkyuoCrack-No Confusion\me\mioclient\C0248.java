package me.mioclient;

import net.minecraft.class_1309;
import net.minecraft.class_1799;

public interface C0248 {
   long mio$getLastEatingTime();

   C0720 mio$getRole();

   void mio$setRole(C0720 var1);

   boolean mio$isNextToWall();

   default float m0440(class_1799 var1, class_1309 var2) {
      return (float)(w.a<"B">(223409559795593705L) - w.a<"Û">(this, 350308488708559406L)) / ((float)w.a<"Û">(var1, var2, 318425906657447077L) * 50.0F + 50.0F);
   }
}
