package me.mioclient;

import net.minecraft.class_332;
import net.minecraft.class_4587;

public interface C0448 {
   default void m0001(class_332 var1, class_4587 var2, double var3, double var5) {
   }

   default void m0002(double var1, double var3) {
   }

   default void m0003(double var1, double var3, int var5) {
   }

   default void m0004(double var1, double var3, int var5) {
   }

   default void m0005(double var1, double var3, double var5) {
   }

   default void m0006(int var1) {
   }

   default void m0007(char var1) {
   }

   default void m0008(int var1) {
   }

   default int m0009() {
      return 0;
   }

   default void init() {
   }

   default int m0010() {
      return this.m0013();
   }

   default boolean m0011(double var1, double var3) {
      return false;
   }

   default float m0012() {
      return (float)(this.m0013() - C0498.f4738.m3897() + 1) / 2.0F;
   }

   default int m0013() {
      return 2 + C0498.f4738.m3897() + C0879.f3743.f3751.getValue();
   }

   default C0879 m0014() {
      return C0879.f3743;
   }
}
