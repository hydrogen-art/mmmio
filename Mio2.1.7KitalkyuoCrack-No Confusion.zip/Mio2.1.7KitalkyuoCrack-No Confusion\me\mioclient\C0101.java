package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0101 implements C0196 {
   f2798("Vanilla"),
   f2799("1.8"),
   f2800("1.12");

   public final String f2801;

   public C0101(String var3) {
      this.f2801 = var3;
   }

   @Override
   public String getName() {
      return this.f2801;
   }

   public static String Jby7hSzs8O82QHvEwgmsvKJT392a3my4s9CfnSKXGUEw89EPQUPPScYstIi9gAbQkCyWgeyeSaLtAQFhBRRyjgfzqU1fgFO9QVr3(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
