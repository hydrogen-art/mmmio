package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0277 {
   f4214,
   f4215;

   public static String _jR0NmlB5y5NdN63slcYs7Ktr4zckH2HKJdYk2ge1Zik65vCouEESKAubjMpi7HQNpIZr2zpqiF2lnEhZBfW8dpmVFrUHclJTxgd/* $VF was: 3jR0NmlB5y5NdN63slcYs7Ktr4zckH2HKJdYk2ge1Zik65vCouEESKAubjMpi7HQNpIZr2zpqiF2lnEhZBfW8dpmVFrUHclJTxgd*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
