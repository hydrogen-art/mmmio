package me.mioclient;

import java.awt.Color;
import net.minecraft.class_1297;

public class C0144 extends C1180 {
   public static final C0144 f2107 = new C0144();
   public class_1297 f2108;
   public int f2109;
   public float f2110;
   public float f2111;
   public float f2112;
   public float f2113;

   public static C0144 m0895(class_1297 var0, int var1, float var2, float var3, float var4, float var5) {
      f2107.f2109 = var1;
      f2107.f2108 = var0;
      f2107.f2110 = var2;
      f2107.f2111 = var3;
      f2107.f2112 = var4;
      f2107.f2113 = var5;
      f2107.m$$PnImoBYt9TWIQWIZlu7x4PlhMDyByiNsAByNVyDskMUoK138NBsECzhidsQ4dW8jIrxRO1miiLIJHcgVioDyfs0PQSZvvw3Cx();
      return f2107;
   }

   public class_1297 m0896() {
      return this.f2108;
   }

   public void m0897(class_1297 var1) {
      this.f2108 = var1;
   }

   public float m0898() {
      return this.f2110;
   }

   public void m0899(float var1) {
      this.f2110 = var1;
   }

   public float m0900() {
      return this.f2111;
   }

   public void m0901(float var1) {
      this.f2111 = var1;
   }

   public float m0902() {
      return this.f2112;
   }

   public void m0903(float var1) {
      this.f2112 = var1;
   }

   public float m0904() {
      return this.f2113;
   }

   public void m0905(float var1) {
      this.f2113 = var1;
   }

   public int m0906() {
      return this.f2109;
   }

   public void m0907(int var1) {
      this.f2109 = var1;
   }

   public void m0908(Color var1) {
      this.m0899((float)var1.getRed() / 255.0F);
      this.m0901((float)var1.getGreen() / 255.0F);
      this.m0903((float)var1.getBlue() / 255.0F);
      this.m0905((float)var1.getAlpha() / 255.0F);
   }
}
