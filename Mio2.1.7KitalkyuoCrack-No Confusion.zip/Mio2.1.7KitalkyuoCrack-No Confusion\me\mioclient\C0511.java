package me.mioclient;

public class C0511 {
   public final C0277 f2115;
   public float f2116;

   public C0511(C0277 var1, float var2) {
      this.f2115 = var1;
      this.f2116 = var2;
   }

   public C0277 m2862() {
      return this.f2115;
   }

   public float m2863() {
      return this.f2116;
   }

   public void m2864(float var1) {
      this.f2116 = var1;
   }
}
