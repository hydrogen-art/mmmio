package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0501 implements C0196 {
   f2779("Custom"),
   f2780("Random");

   public final String f2781;

   public C0501(String var3) {
      this.f2781 = var3;
   }

   @Override
   public String getName() {
      return this.f2781;
   }

   public static String OntsaFCj82aNwlTNN0an32vPQeoHXBSEpBexzZUbfSKcYEu0oOEOYhLsAZnoxxX5IvRBbT9HJlIlAVlEKoT7zlE3IpAzCIGLOLAH(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
