package me.mioclient;

import java.util.ArrayList;

public final class C0296<T> extends ArrayList<T> {
   public static int f2983 = 1256950890;

   public T m1204() {
      return this.get(this.size() - ((f2983 | 534206) + ~(f2983 & 534206) + 1 ^ 1256434389));
   }

   static {
      long var10000 = 2382028359092198761L;
   }
}
