package me.mioclient;

import java.util.function.Predicate;

public class C0260 implements Predicate {
   public C0340 f2354;

   public C0260(C0340 var1) {
      this.f2354 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2354.f2167, 254992554122318132L);
   }
}
