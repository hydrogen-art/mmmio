package me.mioclient;

public interface C0377 {
   long mio$getJoinTime();
}
