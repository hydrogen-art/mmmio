package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.class_2596;
import net.minecraft.class_2827;
import net.minecraft.class_6374;

public class C0526 extends C1266 {
   public final C0015<Integer> f1941;
   public final C0015<Integer> f1942;
   public final Queue<class_2596<?>> f1943;
   public final C0083 f1944;
   public boolean hold;
   public static int f1945 = w.a<"B">(4016017053402355047L, 257832362129977838L);

   public C0526() {
      super("PingSpoof", "Fakes your latency server-side.", C1045.f3177);
      w.a<"B">(this, 242859112966675773L);
      this.f1943 = new ConcurrentLinkedQueue<>();
      this.f1944 = new C0083();
      this.hold = (boolean)((f1945 | 753158) + ~(f1945 & 753158) + 1 ^ -47898297);
   }

   @Override
   public void onToggle() {
      w.a<"Û">(this, 341058369399883935L);
   }

   @C1027
   public void m0838(C0612 var1) {
      w.a<"Û">(this, 341058369399883935L);
   }

   @C1027
   public void m0839(C0132 var1) {
      if (w.a<"Û">(this, 203085347691421241L)
         && this.hold
         && (w.a<"Û">(var1, 127302489982333990L) instanceof class_2827 || w.a<"Û">(var1, 127302489982333990L) instanceof class_6374)) {
         w.a<"Û">(this.f1943, w.a<"Û">(var1, 127302489982333990L), 276905752407976510L);
         w.a<"Û">(var1, 385440235371820560L);
      }
   }

   public void m0840() {
      if (w.a<"Û">(this, 203085347691421241L) && w.a<"Û">(this.f1944, (long)w.a<"Û">(this, 252059114953940624L), 309642602085515378L)) {
         this.hold = (boolean)((f1945 | 342273) + ~(f1945 & 342273) + 1 ^ -47487423);
         if (!w.a<"Û">(this.f1943, 296374206093673190L)) {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
               (class_2596)w.a<"Û">(this.f1943, 154912847677331014L),
               125787698683892978L
            );
         }

         w.a<"Û">(this.f1944, 387780412884547639L);
         this.hold = (boolean)((f1945 | 836670) + ~(f1945 & 836670) + 1 ^ -48063617);
      }
   }

   public int m0841() {
      return w.a<"Û">((Integer)w.a<"Û">(this.f1941, 174312564406604366L), 260981171345819427L)
         + w.a<"B">(
            (f1945 | 668450) + ~(f1945 & 668450) + 1 ^ -47944606,
            w.a<"Û">((Integer)w.a<"Û">(this.f1942, 174312564406604366L), 260981171345819427L),
            220265004694221668L
         );
   }

   public boolean m0842() {
      return (boolean)(!w.a<"Û">(this, 205492958615326489L)
            && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 234848095888453726L)
            && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 300193738958224619L)
            && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6012
               > ((f1945 | 959543) + ~(f1945 & 959543) + 1 ^ -48170145)
         ? (f1945 | 789615) + ~(f1945 & 789615) + 1 ^ -48082130
         : (f1945 | 947459) + ~(f1945 & 947459) + 1 ^ -48223677);
   }

   public static String _rz6R9uUAcMIrxXznnsWqo6jZ58gbjdq7WZZOOl8FUXEhj8Mrm3RPEa0bS6pxdNWVTUbT9srXuAbQqZAHlrgn7ejoGjRMFeS6Aiv/* $VF was: 3rz6R9uUAcMIrxXznnsWqo6jZ58gbjdq7WZZOOl8FUXEhj8Mrm3RPEa0bS6pxdNWVTUbT9srXuAbQqZAHlrgn7ejoGjRMFeS6Aiv*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
