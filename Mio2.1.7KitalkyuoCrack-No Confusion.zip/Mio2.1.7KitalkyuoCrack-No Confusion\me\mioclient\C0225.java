package me.mioclient;

import java.util.function.Predicate;

public class C0225 implements Predicate {
   public C1248 f2456;

   public C0225(C1248 var1) {
      this.f2456 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2456.f2402, 174312564406604366L) == C1249.f1948;
   }
}
