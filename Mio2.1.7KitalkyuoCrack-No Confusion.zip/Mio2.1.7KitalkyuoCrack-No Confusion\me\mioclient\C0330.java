package me.mioclient;

public class C0330 extends C1180 {
   public static final C0330 f0363 = new C0330();
}
