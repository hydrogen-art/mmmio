package me.mioclient;

public interface C0192 {
   boolean mio$isAttacking();
}
