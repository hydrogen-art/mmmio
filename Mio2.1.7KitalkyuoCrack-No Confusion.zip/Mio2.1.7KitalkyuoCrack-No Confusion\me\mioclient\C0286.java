package me.mioclient;

import java.util.function.Predicate;

public class C0286 implements Predicate {
   public C0464 f3825;

   public C0286(C0464 var1) {
      this.f3825 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3825.f4342, 174312564406604366L) == C0466.f3597 || w.a<"Û">(this.f3825.f4342, 174312564406604366L) == C0466.f3599;
   }
}
