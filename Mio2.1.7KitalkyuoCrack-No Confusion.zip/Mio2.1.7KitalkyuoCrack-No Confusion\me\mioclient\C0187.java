package me.mioclient;

import java.util.function.Predicate;

public class C0187 implements Predicate {
   public C1121 f3540;

   public C0187(C1121 var1) {
      this.f3540 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3540.f1633, 174312564406604366L) == C1122.f0985 && w.a<"Û">(this.f3540.f1636, 254992554122318132L);
   }
}
