package me.mioclient;

import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.class_1657;

record C0467() {
   public final class_1657 f4063;
   public final long f4064;
   public final AtomicBoolean f4065;
   public static int f4066 = w.a<"B">(1957858143769944967L, 257832362129977838L);

   public C0467(class_1657 var1, long var2, AtomicBoolean var4) {
      this.f4063 = var1;
      this.f4064 = var2;
      this.f4065 = var4;
   }

   public boolean m1688() {
      return (boolean)(w.a<"B">(223409559795593705L) - this.f4064 < (((long)f4066 | 591970L) + ~((long)f4066 & 591970L) + 1L ^ 865380706L)
            && !w.a<"Û">(this.f4065, 248424813730317294L)
         ? (f4066 | 249733) + ~(f4066 & 249733) + 1 ^ 866021289
         : (f4066 | 615823) + ~(f4066 & 615823) + 1 ^ 865387938);
   }

   public class_1657 m1689() {
      return this.f4063;
   }

   public long m1690() {
      return this.f4064;
   }

   public AtomicBoolean m1691() {
      return this.f4065;
   }
}
