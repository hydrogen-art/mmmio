package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0367 implements C0196 {
   f3280("Steal"),
   f3281("Fill"),
   f3282("Drop"),
   f3283("Refill"),
   f3284("Rekit");

   public final String f3285;

   public C0367(String var3) {
      this.f3285 = var3;
   }

   @Override
   public String getName() {
      return this.f3285;
   }

   public static String wyX4Dp2WXvF5XmwewuHYhgRnQuk7i11zXXqgJAaWJaDa3SakL0zxCu8pikfXEpKZ6tWQnVzGb8GnHRWOeIeptua00iiThgHrNPTR(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
