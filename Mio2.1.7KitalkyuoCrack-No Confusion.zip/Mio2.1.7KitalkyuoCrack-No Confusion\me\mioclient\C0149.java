package me.mioclient;

import java.util.function.Predicate;

public class C0149 implements Predicate {
   public C0814 f2051;

   public C0149(C0814 var1) {
      this.f2051 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2051.f4938, 254992554122318132L);
   }
}
