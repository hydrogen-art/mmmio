package me.mioclient;

import java.io.ByteArrayInputStream;
import me.mioclient.mixin.ducks.DuckAbstractSoundInstance;
import net.minecraft.class_243;

public class C0134 implements C0045 {
   public static final C0134 f0802 = new C0134(null) {
      public static int f0942 = w.a<"B">(1256882054023769331L, 257832362129977838L);

      @Override
      public void m0375(float var1) {
      }

      @Override
      public void m0376(class_243 var1, float var2) {
      }
   };
   public final byte[] f0803;
   public static int f0804 = w.a<"B">(180639111877254365L, 257832362129977838L);

   public C0134(byte[] var1) {
      this.f0803 = var1;
   }

   public void m0373() {
      w.a<"Û">(this, w.a<"B">((f0804 | 359583) + ~(f0804 & 359583) + 1 ^ 2106644461, 349057757755238323L), 212279982900710395L);
   }

   public void m0374(class_243 var1) {
      w.a<"Û">(this, var1, w.a<"B">((f0804 | 453399) + ~(f0804 & 453399) + 1 ^ 2106802277, 349057757755238323L), 186229093920531417L);
   }

   public void m0375(float var1) {
      if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 162265561606807161L) != null) {
         try {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff,
               (Runnable)() -> {
                  C0191 var2 = new C0191(new ByteArrayInputStream(w.a<"Û">(this, 153541387356376371L)));
                  ((DuckAbstractSoundInstance)var2).setVolume(var1);
                  w.a<"Û">(
                     w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 162265561606807161L),
                     var2,
                     158014032807064624L
                  );
               },
               302363253312076733L
            );
         } catch (Exception var3) {
            w.a<"Û">(var3, 277292852406578821L);
         }
      }
   }

   public void m0376(class_243 var1, float var2) {
      if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687 != null) {
         try {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff,
               (Runnable)() -> {
                  C0191 var3 = new C0191(var1, new ByteArrayInputStream(w.a<"Û">(this, 153541387356376371L)));
                  ((DuckAbstractSoundInstance)var3).setVolume(var2);
                  w.a<"Û">(
                     w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 162265561606807161L),
                     var3,
                     158014032807064624L
                  );
               },
               302363253312076733L
            );
         } catch (Exception var4) {
            w.a<"Û">(var4, 277292852406578821L);
         }
      }
   }

   public byte[] m0377() {
      return this.f0803;
   }
}
