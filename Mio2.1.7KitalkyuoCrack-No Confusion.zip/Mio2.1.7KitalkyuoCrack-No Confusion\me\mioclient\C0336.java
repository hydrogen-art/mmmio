package me.mioclient;

import java.util.function.Predicate;

public class C0336 implements Predicate {
   public C0345 f0067;

   public C0336(C0345 var1) {
      this.f0067 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0067.f0369, 174312564406604366L) == C0347.f1910 || w.a<"Û">(this.f0067.f0369, 174312564406604366L) == C0347.f1909;
   }
}
