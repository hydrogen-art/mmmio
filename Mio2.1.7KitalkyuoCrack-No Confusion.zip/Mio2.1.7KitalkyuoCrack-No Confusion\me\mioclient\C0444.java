package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0444 implements C0196 {
   f2248("NCP"),
   f2249("Grim");

   public final String f2250;

   public C0444(String var3) {
      this.f2250 = var3;
   }

   @Override
   public String getName() {
      return this.f2250;
   }

   public static String xIy71vl35EwxlVyUjYyIXlydI0CND1w7ZDH47DgoRdkzRBmVhWyOjI3ZhQVmH01yShwTuFA0LHun0oRw5Ou9mgbM6bJXm3dkgdFk(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
