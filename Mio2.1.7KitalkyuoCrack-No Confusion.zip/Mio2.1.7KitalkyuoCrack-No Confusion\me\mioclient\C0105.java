package me.mioclient;

public abstract class C0105 implements C0045 {
   public final C0345 f3481;
   public final double f3482;
   public double f3483;
   public double f3484;
   public int f3485;
   public static int f3486 = w.a<"B">(6973498936379171307L, 257832362129977838L);

   public C0105(C0345 var1) {
      this.f3482 = w.a<"B">(((long)f3486 | 979364L) + ~((long)f3486 & 979364L) + 1L ^ 4598847157788913739L, 317139102743630955L);
      this.f3482 = w.a<"B">(((long)f3486 | 411966L) + ~((long)f3486 & 411966L) + 1L ^ 4598847157789395153L, 317139102743630955L);
      this.f3481 = var1;
   }

   public abstract void m0455(C0650 var1);

   public void m0456(C1095 var1) {
      if (w.a<"Û">(var1, 336212328865671254L) != C0277.f4215) {
         if (!w.a<"B">(239474890139367192L)) {
            this.f3485 = (f3486 | 219276) + ~(f3486 & 219276) + 1 ^ 1515592633;
            this.f3483 = 0.0;
         }

         double var2 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L
            )
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6014;
         double var4 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L
            )
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_5969;
         this.f3484 = w.a<"B">(var2 * var2 + var4 * var4, 372068007575431175L);
      }
   }

   public void m1433() {
   }

   public void onEnable() {
   }

   public boolean m1434() {
      return (boolean)(!w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L),
               0.0,
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 214921524804283555L).field_1351,
               0.0,
               240768051853680291L
            ),
            116811053208981688L
         )
         ? (f3486 | 301954) + ~(f3486 & 301954) + 1 ^ 1515313330
         : (f3486 | 691488) + ~(f3486 & 691488) + 1 ^ 1516228113);
   }
}
