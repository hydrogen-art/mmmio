package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

enum C0532 implements C0196 {
   f4463("None"),
   f4464("Arrow"),
   f4465("Dot");

   public final String f4466;

   public C0532(String var3) {
      this.f4466 = var3;
   }

   @Override
   public String getName() {
      return this.f4466;
   }

   public static String IZ2KzwVFYasyYbCNVUwPcdIgzq2uwfoa642FjZdN15Zd5gVcRWDBMt59x8q1qTCzv6bOtxHXg6dJCc2Cnk5b2ZQEAFV0jTYxcr84(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
