package me.mioclient;

import net.minecraft.class_1268;

public class C0254 extends C1180 {
   public final class_1268 f5063;

   public C0254(class_1268 var1) {
      this.f5063 = var1;
   }

   public class_1268 m2069() {
      return this.f5063;
   }
}
