package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_2172;

public final class C0362 extends C0219 {
   public static int f2615 = w.a<"B">(2522259298243332508L, 257832362129977838L);

   public C0362() {
      super("bind");
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         (LiteralArgumentBuilder)w.a<"Û">(
            var1,
            w.a<"Û">(
               w.a<"B">("set", 233839479830701924L),
               w.a<"Û">(
                  w.a<"B">("module", new C1036(), 191188367299315725L),
                  w.a<"Û">(
                     w.a<"B">("key", new C1076(), 191188367299315725L),
                     (Command)var1x -> {
                        C1266 var2 = (C1266)w.a<"Û">(var1x, "module", C1266.class, 275658406246533271L);
                        C1088 var3 = (C1088)w.a<"Û">(var1x, "key", C1088.class, 275658406246533271L);
                        w.a<"Û">(
                           var2,
                           (Function<C1088, C1088>)var1xx -> w.a<"Û">(
                                 w.a<"Û">(var1xx, w.a<"Û">(var3, 351828820835781238L), 297190102171421307L),
                                 w.a<"Û">(var3, 291175998333163099L),
                                 186072248004628731L
                              ),
                           123564429822166450L
                        );
                        w.a<"B">(
                           w.a<"Û">(
                              w.a<"Û">(
                                 w.a<"Û">(
                                    w.a<"B">("Bind for ", 228465064790135899L),
                                    w.a<"Û">(this, w.a<"Û">(var2, 248211090350577353L), 187170534302109250L),
                                    267862536496645581L
                                 ),
                                 " has been set to ",
                                 194629304146735395L
                              ),
                              w.a<"Û">(
                                 this,
                                 w.a<"B">(w.a<"Û">(var3, 351828820835781238L), w.a<"Û">(var3, 291175998333163099L), 257767192109484343L),
                                 187170534302109250L
                              ),
                              267862536496645581L
                           ),
                           w.a<"B">((f2615 | 165692) + ~(f2615 & 165692) + 1 ^ -1593617782, 289296048454852994L),
                           241936116971186271L
                        );
                        return (f2615 | 950402) + ~(f2615 & 950402) + 1 ^ 1592830666;
                     },
                     368995281709124746L
                  ),
                  364326416200407929L
               ),
               289819728773344295L
            ),
            289819728773344295L
         ),
         w.a<"Û">(
            (LiteralArgumentBuilder)w.a<"Û">(
               w.a<"B">("clear", 233839479830701924L),
               w.a<"Û">(
                  w.a<"B">("module", new C1036(), 191188367299315725L),
                  (Command)var1x -> {
                     C1266 var2 = (C1266)w.a<"Û">(var1x, "module", C1266.class, 275658406246533271L);
                     w.a<"Û">(
                        var2,
                        (Function<C1088, C1088>)var0 -> w.a<"Û">(var0, (f2615 | 467034) + ~(f2615 & 467034) + 1 ^ -1593379348, 297190102171421307L),
                        123564429822166450L
                     );
                     w.a<"B">(
                        w.a<"Û">(
                           w.a<"Û">(
                              w.a<"B">("Bind for ", 228465064790135899L),
                              w.a<"Û">(this, w.a<"Û">(var2, 248211090350577353L), 187170534302109250L),
                              267862536496645581L
                           ),
                           " has been reset",
                           194629304146735395L
                        ),
                        w.a<"B">((f2615 | 256104) + ~(f2615 & 256104) + 1 ^ -1593688610, 289296048454852994L),
                        241936116971186271L
                     );
                     return (f2615 | 214969) + ~(f2615 & 214969) + 1 ^ 1593667057;
                  },
                  368995281709124746L
               ),
               289819728773344295L
            ),
            w.a<"Û">(
               w.a<"B">("all", 233839479830701924L),
               (Command)var0 -> {
                  Iterator var1x = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

                  while (w.a<"Û">(var1x, 333900474771661065L)) {
                     C1266 var2 = (C1266)w.a<"Û">(var1x, 192468336863492695L);
                     w.a<"Û">(
                        var2,
                        (Function<C1088, C1088>)var0x -> w.a<"Û">(var0x, (f2615 | 492751) + ~(f2615 & 492751) + 1 ^ -1593421447, 297190102171421307L),
                        123564429822166450L
                     );
                  }

                  w.a<"B">(
                     w.a<"B">("Bind for all modules has been reset", 228465064790135899L),
                     w.a<"B">((f2615 | 148811) + ~(f2615 & 148811) + 1 ^ -1593601795, 289296048454852994L),
                     241936116971186271L
                  );
                  return (f2615 | 16043) + ~(f2615 & 16043) + 1 ^ 1593709795;
               },
               286944572020109927L
            ),
            289819728773344295L
         ),
         289819728773344295L
      );
   }

   public static String HxyG5UpCbTkUcqqBqadWga4VMyFr5G6p3D97YgsDTsl8AaNteZQxLQB4EBOljjsx88U3p1z3JWuj6Jcs9uMz4RhBuFllodye1ezL(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
