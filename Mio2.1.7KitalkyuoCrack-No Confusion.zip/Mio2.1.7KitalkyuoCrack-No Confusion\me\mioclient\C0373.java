package me.mioclient;

import java.util.function.Predicate;

public class C0373 implements Predicate {
   public C1093 f1582;

   public C0373(C1093 var1) {
      this.f1582 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1582.f2661, 174312564406604366L) == C1328.f4084 || w.a<"Û">(this.f1582.f2667, 254992554122318132L);
   }
}
