package me.mioclient;

import java.util.function.Predicate;

public class C0496 implements Predicate {
   public C0464 f3827;

   public C0496(C0464 var1) {
      this.f3827 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3827.f4342, 174312564406604366L) == C0466.f3597 || w.a<"Û">(this.f3827.f4342, 174312564406604366L) == C0466.f3599;
   }
}
