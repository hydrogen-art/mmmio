package me.mioclient;

import java.util.function.Predicate;

public class C0141 implements Predicate {
   public C1168 f0076;

   public C0141(C1168 var1) {
      this.f0076 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0076.f2523, 174312564406604366L) == C1169.f5136;
   }
}
