package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class C0326 extends C1266 {
   public final C0015<Boolean> f0806;
   public final C0015<Integer> f0807;
   public final C0083 f0808;
   public static int f0809 = w.a<"B">(5595565720115859781L, 257832362129977838L);

   public C0326() {
      super("SafeWalk", "Helps not to fall from blocks if you're bad.", C1045.f3175);
      w.a<"B">(this, 242859112966675773L);
      this.f0808 = new C0083();
   }

   @Override
   public void onDisable() {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0806, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690.field_1832,
            (boolean)((f0809 | 649107) + ~(f0809 & 649107) + 1 ^ -1155138873),
            180533258540422459L
         );
      }
   }

   @C1027
   public void m2428(C0612 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0806, 174312564406604366L), 354697271520518137L)) {
         class_2338 var2 = w.a<"Û">(
            w.a<"B">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L),
               274163478939689086L
            ),
            210046241258394501L
         );
         class_2680 var3 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var2, 310987074049434965L
         );
         if (!w.a<"Û">(var3, class_2246.field_10124, 272812080270536171L)
            && !w.a<"Û">(
               w.a<"Û">(
                  var3,
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  var2,
                  127692959363775057L
               ),
               125999939138686596L
            )) {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690.field_1832,
               (boolean)(!w.a<"Û">(this.f0808, (long)w.a<"Û">((Integer)w.a<"Û">(this.f0807, 174312564406604366L), 260981171345819427L), 309642602085515378L)
                  ? (f0809 | 802273) + ~(f0809 & 802273) + 1 ^ -1155522380
                  : (f0809 | 956743) + ~(f0809 & 956743) + 1 ^ -1155365869),
               180533258540422459L
            );
         } else {
            w.a<"Û">(this.f0808, 387780412884547639L);
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690.field_1832,
               (boolean)((f0809 | 474163) + ~(f0809 & 474163) + 1 ^ -1154801306),
               180533258540422459L
            );
         }
      }
   }

   @C1027
   public void m2429(C0618 var1) {
      if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 253770948380550228L)
         && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 336376540029688385L)
         && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 217818920055373591L)
         && !w.a<"Û">((Boolean)w.a<"Û">(this.f0806, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(var1, 385440235371820560L);
      }
   }

   public static String _KlALTeAmsT9BkorzyrKft3rBNfxAMlHahjYWz6W9E55zXIt1L6zViynhMlW9PTxDsL0YwGltfxLcYPFtf1wE3foZyIW7iW1rsIU/* $VF was: 3KlALTeAmsT9BkorzyrKft3rBNfxAMlHahjYWz6W9E55zXIt1L6zViynhMlW9PTxDsL0YwGltfxLcYPFtf1wE3foZyIW7iW1rsIU*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
