package me.mioclient;

import java.util.function.Predicate;

public class C0376 implements Predicate {
   public C1248 f1133;

   public C0376(C1248 var1) {
      this.f1133 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1133.f2402, 174312564406604366L) != C1249.f1948;
   }
}
