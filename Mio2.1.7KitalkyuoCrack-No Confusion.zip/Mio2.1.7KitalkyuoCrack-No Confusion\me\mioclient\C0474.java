package me.mioclient;

public interface C0474 {
   void sendMovementPacketsWrapper();

   void superTick();

   void resetEvent();

   void resetRotations();
}
