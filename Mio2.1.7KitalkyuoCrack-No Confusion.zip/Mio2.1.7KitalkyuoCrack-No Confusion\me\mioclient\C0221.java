package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.net.SocketAddress;
import net.minecraft.class_2338;

public final class C0221 {
   public transient long spawnTime = w.a<"B">(223409559795593705L);
   public final String f3213;
   public final String f3214;
   public final int f3215;
   public final int f3216;
   public final int f3217;
   public transient class_2338 f3218;
   public static int f3219 = w.a<"B">(3849198636728245320L, 257832362129977838L);

   public C0221(String var1, String var2, int var3, int var4, int var5) {
      this.f3213 = var1;
      this.f3214 = var2;
      this.f3215 = var3;
      this.f3216 = var4;
      this.f3217 = var5;
   }

   public C0221(String var1, String var2, class_2338 var3) {
      this.f3213 = var1;
      this.f3214 = var2;
      this.f3215 = w.a<"Û">(var3, 188922896808372924L);
      this.f3216 = w.a<"Û">(var3, 171752333823210875L);
      this.f3217 = w.a<"Û">(var3, 278942455661123424L);
   }

   public String m3349() {
      return this.f3213;
   }

   public String m3350() {
      return w.a<"B">(this.f3213, 222815525246781378L);
   }

   public String m3351() {
      return this.f3214;
   }

   public int getX() {
      return this.f3215;
   }

   public int getY() {
      return this.f3216;
   }

   public int m3352() {
      return this.f3217;
   }

   public class_2338 m3353() {
      if (this.f3218 == null) {
         this.f3218 = new class_2338(this.f3215, this.f3216, this.f3217);
      }

      return this.f3218;
   }

   public long getSpawnTime() {
      return this.spawnTime;
   }

   public void reset() {
      this.spawnTime = w.a<"B">(223409559795593705L);
   }

   public boolean m3354() {
      String var1 = null;

      try {
         SocketAddress var2 = w.a<"Û">(w.a<"Û">(w.a<"Û">(C0045.f2103, 231206531387546689L), 337197838954396671L), 169458892264373397L);
         var1 = w.a<"Û">(var2, 232385667124573302L);
         int var3 = w.a<"Û">(var1, (f3219 | 749136) + ~(f3219 & 749136) + 1 ^ 562075978, 383892207150435267L);
         if (var3 > 0) {
            var1 = w.a<"Û">(var1, (f3219 | 872182) + ~(f3219 & 872182) + 1 ^ 562477507, var3, 145614115509746641L);
         }

         while (w.a<"Û">(var1, ".", 174791773650947361L)) {
            var1 = w.a<"Û">(
               var1,
               (f3219 | 391151) + ~(f3219 & 391151) + 1 ^ 562954458,
               w.a<"Û">(var1, 120891947504160641L) - ((f3219 | 312680) + ~(f3219 & 312680) + 1 ^ 563032668),
               145614115509746641L
            );
         }
      } catch (Exception var4) {
      }

      if (var1 == null || w.a<"Û">(var1, 226515538076917205L)) {
         var1 = "singleplayer";
      }

      return var1.equals(this.f3214);
   }

   public static String I4GRq6SgjWTwizlM224uVcJFjjI063siOQcL1Kr3TYHXZc8owuf0SboWJZCWKYArCE21YWckRPeLdGEtL2n2LeX5Ihm5PvYBKCmk(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
