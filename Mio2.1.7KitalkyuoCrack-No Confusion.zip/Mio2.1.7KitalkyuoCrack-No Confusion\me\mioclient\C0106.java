package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0106 implements C0196 {
   f4541("Normal"),
   f4542("Alternative"),
   f4543("Pick");

   public final String f4544;

   public C0106(String var3) {
      this.f4544 = var3;
   }

   @Override
   public String getName() {
      return this.f4544;
   }

   public static String _62TbooKrafaEPsksYz0P2HiAEpaky9HJBo5ED3xGTYnYahJ07Jrmei4yNqFu8v9nNPUuUEf4Ky3nJdmAZQveRO25oiwtaX58Nk1/* $VF was: 162TbooKrafaEPsksYz0P2HiAEpaky9HJBo5ED3xGTYnYahJ07Jrmei4yNqFu8v9nNPUuUEf4Ky3nJdmAZQveRO25oiwtaX58Nk1*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
