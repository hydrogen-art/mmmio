package me.mioclient;

import com.google.gson.JsonObject;
import java.util.Iterator;
import java.util.Map.Entry;

public class C0126 {
   public static int f4069 = w.a<"B">(1193464041947398473L, 257832362129977838L);

   public static boolean m1692(JsonObject var0, String... var1) {
      String[] var2 = var1;
      int var3 = var1.length;

      for (int var4 = (f4069 | 819073) + ~(f4069 & 819073) + 1 ^ 138588302; var4 < var3; var4++) {
         String var5 = var2[var4];
         if (!w.a<"Û">(var0, var5, 314399812765309162L)) {
            return (boolean)((f4069 | 650164) + ~(f4069 & 650164) + 1 ^ 138880187);
         }
      }

      return (boolean)((f4069 | 264908) + ~(f4069 & 264908) + 1 ^ 139118018);
   }

   public static boolean m1693(JsonObject var0) {
      Iterator var1 = w.a<"Û">(w.a<"Û">(var0, 365019034879995407L), 194435811056609302L);

      while (w.a<"Û">(var1, 333900474771661065L)) {
         Entry var2 = (Entry)w.a<"Û">(var1, 192468336863492695L);
         if (!(w.a<"Û">(var2, 196870340575900401L) instanceof JsonObject) || !w.a<"B">((JsonObject)w.a<"Û">(var2, 196870340575900401L), 315391762572328805L)) {
            return (boolean)((f4069 | 405842) + ~(f4069 & 405842) + 1 ^ 139001437);
         }
      }

      return (boolean)((f4069 | 495926) + ~(f4069 & 495926) + 1 ^ 139025976);
   }
}
