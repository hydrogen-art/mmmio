package me.mioclient;

import net.minecraft.class_276;

public interface C0238 {
   void m2836(String var1, class_276 var2);
}
