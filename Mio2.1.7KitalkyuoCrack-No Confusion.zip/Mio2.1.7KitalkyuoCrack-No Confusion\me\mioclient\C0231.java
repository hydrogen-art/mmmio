package me.mioclient;

import java.util.function.Predicate;

public class C0231 implements Predicate {
   public C0309 f4035;

   public C0231(C0309 var1) {
      this.f4035 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4035.f3395, 254992554122318132L);
   }
}
