package me.mioclient;

import me.mioclient.mixin.ducks.DuckEntityVelocityUpdateS2CPacket;
import net.minecraft.class_2743;

public class C0161 extends C0378 {
   public static int f0684 = w.a<"B">(5168961409354027911L, 257832362129977838L);

   public C0161(C0551 var1) {
      super(var1);
   }

   @Override
   public void m0465(C0133 var1) {
      int var2 = w.a<"Û">(
         (Integer)w.a<"Û">(this.m$$ydvOzKZ85u41ts6obCgGQ66XpqGtY4zNx1jp4M3P6x0nyDUcvD4Qp5FDEOCuII1WqbkpuA8pdILEzMvsJyXlDrGQCqczRfvdg.f1767, 174312564406604366L),
         260981171345819427L
      );
      int var3 = w.a<"Û">(
         (Integer)w.a<"Û">(this.m$$ydvOzKZ85u41ts6obCgGQ66XpqGtY4zNx1jp4M3P6x0nyDUcvD4Qp5FDEOCuII1WqbkpuA8pdILEzMvsJyXlDrGQCqczRfvdg.f1768, 174312564406604366L),
         260981171345819427L
      );
      int var4 = w.a<"Û">(
            (Boolean)w.a<"Û">(
               this.m$$ydvOzKZ85u41ts6obCgGQ66XpqGtY4zNx1jp4M3P6x0nyDUcvD4Qp5FDEOCuII1WqbkpuA8pdILEzMvsJyXlDrGQCqczRfvdg.f1769, 174312564406604366L
            ),
            354697271520518137L
         )
         ? (f0684 | 968885) + ~(f0684 & 968885) + 1 ^ -1298439336
         : (f0684 | 975383) + ~(f0684 & 975383) + 1 ^ 1298445828;
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2743 var5
         && w.a<"Û">(var5, 113708748171017268L)
            == w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 382037140928290916L)) {
         DuckEntityVelocityUpdateS2CPacket var7 = (DuckEntityVelocityUpdateS2CPacket)var5;
         var7.setX(
            (int)(
               w.a<"Û">(var5, 321230316942746608L)
                  * w.a<"B">(((long)f0684 | 553349L) + ~((long)f0684 & 553349L) + 1L ^ 4665518109021578647L, 317139102743630955L)
                  * (double)((float)var2 * w.a<"B">((f0684 | 378596) + ~(f0684 & 378596) + 1 ^ 1900824060, 349057757755238323L))
                  * (double)var4
            )
         );
         var7.setY(
            (int)(
               w.a<"Û">(var5, 254848755021809677L)
                  * w.a<"B">(((long)f0684 | 654692L) + ~((long)f0684 & 654692L) + 1L ^ 4665518109021677942L, 317139102743630955L)
                  * (double)((float)var3 * w.a<"B">((f0684 | 860777) + ~(f0684 & 860777) + 1 ^ 1900323185, 349057757755238323L))
            )
         );
         var7.setZ(
            (int)(
               w.a<"Û">(var5, 210448125042287125L)
                  * w.a<"B">(((long)f0684 | 564271L) + ~((long)f0684 & 564271L) + 1L ^ 4665518109021620285L, 317139102743630955L)
                  * (double)((float)var2 * w.a<"B">((f0684 | 425681) + ~(f0684 & 425681) + 1 ^ 1901067721, 349057757755238323L))
                  * (double)var4
            )
         );
         if (var2 == 0 && var3 == 0) {
            w.a<"Û">(var1, 385440235371820560L);
         }
      }
   }

   @Override
   public void m0468(C1006 var1) {
      if (w.a<"Û">(
         (Boolean)w.a<"Û">(this.m$$ydvOzKZ85u41ts6obCgGQ66XpqGtY4zNx1jp4M3P6x0nyDUcvD4Qp5FDEOCuII1WqbkpuA8pdILEzMvsJyXlDrGQCqczRfvdg.f1770, 174312564406604366L),
         354697271520518137L
      )) {
         int var2 = w.a<"Û">(
            (Integer)w.a<"Û">(
               this.m$$ydvOzKZ85u41ts6obCgGQ66XpqGtY4zNx1jp4M3P6x0nyDUcvD4Qp5FDEOCuII1WqbkpuA8pdILEzMvsJyXlDrGQCqczRfvdg.f1767, 174312564406604366L
            ),
            260981171345819427L
         );
         int var3 = w.a<"Û">(
            (Integer)w.a<"Û">(
               this.m$$ydvOzKZ85u41ts6obCgGQ66XpqGtY4zNx1jp4M3P6x0nyDUcvD4Qp5FDEOCuII1WqbkpuA8pdILEzMvsJyXlDrGQCqczRfvdg.f1768, 174312564406604366L
            ),
            260981171345819427L
         );
         int var4 = w.a<"Û">(
               (Boolean)w.a<"Û">(
                  this.m$$ydvOzKZ85u41ts6obCgGQ66XpqGtY4zNx1jp4M3P6x0nyDUcvD4Qp5FDEOCuII1WqbkpuA8pdILEzMvsJyXlDrGQCqczRfvdg.f1769, 174312564406604366L
               ),
               354697271520518137L
            )
            ? (f0684 | 194835) + ~(f0684 & 194835) + 1 ^ -1298705666
            : (f0684 | 712274) + ~(f0684 & 712274) + 1 ^ 1298172481;
         w.a<"Û">(
            var1,
            (float)(
               (int)(
                  w.a<"Û">(var1, 288509859097678034L)
                     * (float)var2
                     * w.a<"B">((f0684 | 642958) + ~(f0684 & 642958) + 1 ^ 1900039318, 349057757755238323L)
                     * (float)var4
               )
            ),
            205191192696274684L
         );
         w.a<"Û">(
            var1,
            (float)(
               (int)(w.a<"Û">(var1, 214156591682788158L) * (float)var3 * w.a<"B">((f0684 | 815369) + ~(f0684 & 815369) + 1 ^ 1900409361, 349057757755238323L))
            ),
            291989498985769476L
         );
         w.a<"Û">(
            var1,
            (float)(
               (int)(
                  w.a<"Û">(var1, 336640210457523802L)
                     * (float)var2
                     * w.a<"B">((f0684 | 778201) + ~(f0684 & 778201) + 1 ^ 1900174529, 349057757755238323L)
                     * (float)var4
               )
            ),
            256840077760208687L
         );
      }
   }
}
