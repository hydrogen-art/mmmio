package me.mioclient;

import java.util.function.Predicate;

public class C0524 implements Predicate {
   public C0159 f5057;

   public C0524(C0159 var1) {
      this.f5057 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f5057.f5296, 174312564406604366L) == C0160.f4388;
   }
}
