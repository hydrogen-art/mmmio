package me.mioclient;

import net.minecraft.class_2248;

public record C0394() {
   public final long f1901;
   public final class_2248 f1902;
   public static int f1903 = w.a<"B">(3111317480310546758L, 257832362129977838L);

   public C0394(long var1, class_2248 var3) {
      this.f1901 = var1;
      this.f1902 = var3;
   }

   public static C0394 m0796(class_2248 var0) {
      return new C0394(w.a<"B">(223409559795593705L), var0);
   }

   public long m0797() {
      return this.f1901;
   }

   public class_2248 m0798() {
      return this.f1902;
   }
}
