package me.mioclient;

import java.util.function.Predicate;

public class C0492 implements Predicate {
   public C0814 f1681;

   public C0492(C0814 var1) {
      this.f1681 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1681.f4938, 254992554122318132L);
   }
}
