package me.mioclient;

import java.util.function.Predicate;

public class C0235 implements Predicate {
   public C0396 f3850;

   public C0235(C0396 var1) {
      this.f3850 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3850.f0146, 174312564406604366L) == C0069.f3532 || w.a<"Û">(this.f3850.f0146, 174312564406604366L) == C0069.f3533;
   }
}
