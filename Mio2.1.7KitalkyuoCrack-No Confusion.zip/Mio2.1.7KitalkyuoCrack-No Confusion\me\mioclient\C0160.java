package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0160 implements C0196 {
   f4388("Pearl"),
   f4389("Clip");

   public final String f4390;

   public C0160(String var3) {
      this.f4390 = var3;
   }

   @Override
   public String getName() {
      return this.f4390;
   }

   public static String _t0yHWTrVNOi2KCFGQSX35IypGVeYMbTxKma7pQ4Qz9mIV6qyhQRCk48uuQnmgJge2gD1UcMIVeHPNDUMBW2geSicDkqK3wrxAkI/* $VF was: 7t0yHWTrVNOi2KCFGQSX35IypGVeYMbTxKma7pQ4Qz9mIV6qyhQRCk48uuQnmgJge2gD1UcMIVeHPNDUMBW2geSicDkqK3wrxAkI*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
