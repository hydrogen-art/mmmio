package me.mioclient;

import java.util.function.Predicate;

public class C0120 implements Predicate {
   public C0309 f3536;

   public C0120(C0309 var1) {
      this.f3536 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3536.f3401, 174312564406604366L) == C0312.f0220;
   }
}
