package me.mioclient;

import java.util.function.Predicate;

public class C0156 implements Predicate {
   public C0423 f0981;

   public C0156(C0423 var1) {
      this.f0981 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0981.f2188, 254992554122318132L);
   }
}
