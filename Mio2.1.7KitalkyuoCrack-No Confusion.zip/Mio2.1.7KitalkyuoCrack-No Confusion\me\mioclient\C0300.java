package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_238;

public class C0300 extends C1266 {
   public final C0015<Float> f0705;
   public final C0015<Boolean> f0706;
   public final C0015<Boolean> f0707;
   public final C0015<Boolean> f0708;
   public double f0709;
   public double f0710;
   public int f0711;
   public boolean f0712;
   public static int f0713 = w.a<"B">(58889298923432231L, 257832362129977838L);

   public C0300() {
      super("LongJump", "Makes you jump fast 'n far.", C1045.f3175);
      w.a<"B">(this, 242859112966675773L);
      this.f0711 = (f0713 | 190070) + ~(f0713 & 190070) + 1 ^ -925855135;
   }

   @C1027
   public void m0344(C0650 var1) {
      if (!w.a<"Û">(this, 167294190240841013L)
         && !w.a<"Û">(this, 108748633880449036L)
         && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)
         && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 216539022803564207L)) {
         double var6 = w.a<"Û">(var1, 142189287634836180L);
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f0707, 174312564406604366L), 354697271520518137L)
            && w.a<"Û">(w.a<"Û">(C0933.f1416, 131737481540982891L), ((long)f0713 | 74996L) + ~((long)f0713 & 74996L) + 1L ^ -925675491L, 309642602085515378L)) {
            w.a<"Û">(C0933.f1410, this, w.a<"B">((f0713 | 664002) + ~(f0713 & 664002) + 1 ^ -145553379, 349057757755238323L), 371685643619254063L);
         } else if (w.a<"Û">((Boolean)w.a<"Û">(this.f0707, 174312564406604366L), 354697271520518137L)) {
            w.a<"Û">(C0933.f1410, this, 150212528603319406L);
         }

         if (!w.a<"Û">(w.a<"Û">(C0933.f1416, 131737481540982891L), ((long)f0713 | 760794L) + ~((long)f0713 & 760794L) + 1L ^ -925241549L, 309642602085515378L)
            && w.a<"Û">((Boolean)w.a<"Û">(this.f0708, 174312564406604366L), 354697271520518137L)) {
            w.a<"Û">(this, 289688631157446311L);
         }

         double var8 = (double)(
            w.a<"B">((f0713 | 291509) + ~(f0713 & 291509) + 1 ^ -1999239514, 349057757755238323L)
               * w.a<"Û">((Float)w.a<"Û">(this.f0705, 174312564406604366L), 149784643039979208L)
         );
         if (this.f0711 == ((f0713 | 393339) + ~(f0713 & 393339) + 1 ^ -925600663) && w.a<"B">(239474890139367192L)) {
            this.f0709 = w.a<"B">(((long)f0713 | 891247L) + ~((long)f0713 & 891247L) + 1L ^ -4608758679024012058L, 317139102743630955L)
                  * w.a<"B">(
                     (boolean)((f0713 | 130215) + ~(f0713 & 130215) + 1 ^ -925661004),
                     w.a<"B">(((long)f0713 | 85656L) + ~((long)f0713 & 85656L) + 1L ^ -4598847157467203499L, 317139102743630955L) * var8,
                     328551394550687600L
                  )
               - w.a<"B">(((long)f0713 | 45740L) + ~((long)f0713 & 45740L) + 1L ^ -4576918229989141820L, 317139102743630955L);
         } else if (this.f0711 == ((f0713 | 380708) + ~(f0713 & 380708) + 1 ^ -925385931) && w.a<"B">(239474890139367192L)) {
            var6 = w.a<"B">(((long)f0713 | 785798L) + ~((long)f0713 & 785798L) + 1L ^ -4601237666941504652L, 317139102743630955L)
               + w.a<"B">(346349225321202810L);
            this.f0709 = this.f0709
               * (
                  this.f0712
                     ? w.a<"B">(((long)f0713 | 610534L) + ~((long)f0713 & 610534L) + 1L ^ -4610260628388042077L, 317139102743630955L)
                     : w.a<"B">(((long)f0713 | 66896L) + ~((long)f0713 & 66896L) + 1L ^ -4608961341409081071L, 317139102743630955L)
               );
         } else if (this.f0711 == ((f0713 | 631743) + ~(f0713 & 631743) + 1 ^ -925116497)) {
            this.f0709 = this.f0710
               - w.a<"B">(((long)f0713 | 49892L) + ~((long)f0713 & 49892L) + 1L ^ -4604119971141601545L, 317139102743630955L)
                  * (
                     this.f0710
                        - w.a<"B">(
                           (boolean)((f0713 | 544338) + ~(f0713 & 544338) + 1 ^ -925222336),
                           w.a<"B">(((long)f0713 | 189154L) + ~((long)f0713 & 189154L) + 1L ^ -4598847157467245521L, 317139102743630955L) * var8,
                           328551394550687600L
                        )
                  );
            this.f0712 = (boolean)(!this.f0712 ? (f0713 | 886738) + ~(f0713 & 886738) + 1 ^ -924847168 : (f0713 | 763040) + ~(f0713 & 763040) + 1 ^ -925249357);
         } else {
            if ((
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_5992
                     || !w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                        w.a<"Û">(
                           w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                              261249985676109960L
                           ),
                           0.0,
                           w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 214921524804283555L
                              )
                              .field_1351,
                           0.0,
                           240768051853680291L
                        ),
                        116811053208981688L
                     )
               )
               && this.f0711 > 0) {
               this.f0711 = w.a<"B">(239474890139367192L)
                  ? (f0713 | 128357) + ~(f0713 & 128357) + 1 ^ -925662857
                  : (f0713 | 314124) + ~(f0713 & 314124) + 1 ^ -925450465;
            }

            this.f0709 = this.f0710
               - this.f0710 / w.a<"B">(((long)f0713 | 821295L) + ~((long)f0713 & 821295L) + 1L ^ -4639798332651275204L, 317139102743630955L);
         }

         this.f0709 = w.a<"B">(
            this.f0709,
            w.a<"B">(
               (boolean)((f0713 | 62827) + ~(f0713 & 62827) + 1 ^ -925728392),
               w.a<"B">(((long)f0713 | 727279L) + ~((long)f0713 & 727279L) + 1L ^ -4598847157467845086L, 317139102743630955L) * var8,
               328551394550687600L
            ),
            354112003008534934L
         );
         double var2;
         double var4;
         if (!w.a<"B">(239474890139367192L)) {
            var2 = 0.0;
            var4 = 0.0;
         } else {
            double[] var10 = w.a<"B">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  C0094.m1872(),
                  111737428835766792L
               ),
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913,
               this.f0709,
               108620803423508722L
            );
            var2 = var10[(f0713 | 706876) + ~(f0713 & 706876) + 1 ^ -925319889];
            var4 = var10[(f0713 | 873991) + ~(f0713 & 873991) + 1 ^ -924900843];
         }

         w.a<"B">(w.a<"Û">(var1, 240677964963708953L), var2, var6, var4, 340489545772167457L);
         if (w.a<"B">(239474890139367192L)) {
            this.f0711 = this.f0711 + ((f0713 | 926762) + ~(f0713 & 926762) + 1 ^ -925085640);
         }
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = 100
   )
   public void m0345(C1095 var1) {
      if (w.a<"Û">(var1, 336212328865671254L) != C0277.f4215) {
         if (!w.a<"B">(239474890139367192L)) {
            this.f0711 = (f0713 | 153449) + ~(f0713 & 153449) + 1 ^ -925883522;
         }

         double var2 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L
            )
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6014;
         double var4 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L
            )
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_5969;
         this.f0710 = w.a<"B">(var2 * var2 + var4 * var4, 372068007575431175L);
      }
   }

   public boolean m0346() {
      return (boolean)(w.a<"B">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229073305445517953L
            )
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f0706, 174312564406604366L), 354697271520518137L)
         ? (f0713 | 803700) + ~(f0713 & 803700) + 1 ^ -924960922
         : (f0713 | 923629) + ~(f0713 & 923629) + 1 ^ -925080578);
   }

   public boolean m0347() {
      class_238 var1 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L
      );
      class_238 var2 = w.a<"Û">(
         new class_238(
            (double)w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
               188922896808372924L
            ),
            var1.field_1322,
            (double)w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
               278942455661123424L
            ),
            (double)w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
                  188922896808372924L
               )
               + w.a<"B">(((long)f0713 | 47245L) + ~((long)f0713 & 47245L) + 1L ^ -4607182419725726562L, 317139102743630955L),
            var1.field_1325,
            (double)w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
                  278942455661123424L
               )
               + w.a<"B">(((long)f0713 | 469017L) + ~((long)f0713 & 469017L) + 1L ^ -4607182419725558774L, 317139102743630955L)
         ),
         w.a<"B">(((long)f0713 | 595445L) + ~((long)f0713 & 595445L) + 1L ^ -4502148214804722002L, 317139102743630955L),
         159810520123761168L
      );
      return w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
         var2,
         180086335891483828L
      );
   }

   public static String xh9kERA2eReFGInWU6wF03NZJFKYzwlzKsVFl9XvGMkEF6LdOnXzCiuxQAw9CEFp8HLkOzKwZxjD7BFKfY0AXL5ETYsshjNPvqNA(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
