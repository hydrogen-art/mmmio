package me.mioclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_2378;
import net.minecraft.class_2960;

public class C0275<T> extends C0298<T> {
   public final class_2378<T> f3950;
   public static int f3951 = w.a<"B">(8709841648715949018L, 257832362129977838L);

   @SafeVarargs
   public C0275(String var1, class_2378<T> var2, T... var3) {
      super(var1, (T[])var3);
      this.f3950 = var2;
   }

   @SafeVarargs
   public C0275(String var1, class_2378<T> var2, Predicate<Set<T>> var3, T... var4) {
      super(var1, var3, (T[])var4);
      this.f3950 = var2;
   }

   @Override
   public T m0855(String var1) {
      return (T)w.a<"Û">(w.a<"Û">(this.f3950, w.a<"B">(var1, 353986064610202245L), 217572722611859283L), null, 237682386832069967L);
   }

   @Override
   public String m0854(T var1) {
      class_2960 var2 = w.a<"Û">(this.f3950, var1, 124284614526337232L);
      return var2 == null ? null : w.a<"Û">(var2, 278176929127734773L);
   }

   @Override
   public Collection<T> m0853() {
      return w.a<"Û">(w.a<"Û">(this.f3950, 296074641005113474L), 325049488880240942L);
   }

   @Override
   public void fromJson(JsonElement var1) {
      if (w.a<"Û">(var1, 367744543492804990L)) {
         w.a<"Û">((Set)w.a<"Û">(this, 174312564406604366L), 259971657844247781L);
         JsonArray var2 = w.a<"Û">(var1, 314159340980532448L);
         Iterator var3 = w.a<"Û">(var2, 160599635136516371L);

         while (w.a<"Û">(var3, 333900474771661065L)) {
            JsonElement var4 = (JsonElement)w.a<"Û">(var3, 192468336863492695L);
            Object var5 = w.a<"Û">(this.f3950, w.a<"B">(w.a<"Û">(var4, 327479800495025542L), 353986064610202245L), 381800485534020400L);
            w.a<"Û">((Set)w.a<"Û">(this, 174312564406604366L), var5, 309270453639690490L);
         }
      }
   }

   public class_2378<T> m3626() {
      return this.f3950;
   }
}
