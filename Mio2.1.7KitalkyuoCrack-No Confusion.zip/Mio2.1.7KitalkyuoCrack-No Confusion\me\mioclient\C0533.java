package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2172;

public final class C0533 extends C0219 {
   public static int f2353 = w.a<"B">(7869075328945862258L, 257832362129977838L);

   public C0533() {
      super("disconnect");
      String[] var10001 = new String[(f2353 | 850518) + ~(f2353 & 850518) + 1 ^ 292624583];
      var10001[(f2353 | 9026) + ~(f2353 & 9026) + 1 ^ 293454290] = "dc";
      w.a<"Û">(this, var10001, 219242751041471617L);
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         (LiteralArgumentBuilder)w.a<"Û">(var1, w.a<"Û">(w.a<"B">("illegal", 233839479830701924L), (Command)var1x -> {
            if (!w.a<"Û">(this, 205492958615326489L)) {
               w.a<"B">(163001575677976185L);
            }

            return (f2353 | 402347) + ~(f2353 & 402347) + 1 ^ 293323066;
         }, 286944572020109927L), 289819728773344295L),
         (Command)var1x -> {
            if (!w.a<"Û">(this, 205492958615326489L)) {
               w.a<"Û">(
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
                     337197838954396671L
                  ),
                  w.a<"B">("Disconnected", 273107254583785490L),
                  165895829995046834L
               );
            }

            return (f2353 | 532950) + ~(f2353 & 532950) + 1 ^ 292930375;
         },
         286944572020109927L
      );
   }

   public static String _2t7JmpfwyIgAFXRnAEe3LYvhBie79t9WJYjxYi5v85fxdj7VVII6cmYAgvd8kEtvTaKkIM5PeU5Ud2AVzttAMoU6mBaZgWqbvml/* $VF was: 22t7JmpfwyIgAFXRnAEe3LYvhBie79t9WJYjxYi5v85fxdj7VVII6cmYAgvd8kEtvTaKkIM5PeU5Ud2AVzttAMoU6mBaZgWqbvml*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
