package me.mioclient;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import me.mioclient.mixin.ducks.DuckLivingEntity;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;

public class C0397 implements C0045 {
   public static double f2037 = w.a<"B">(((long)C0397.f2038 | 880753L) + ~((long)C0397.f2038 & 880753L) + 1L ^ -4589168020737752297L, 317139102743630955L);
   public static int f2038 = w.a<"B">(838199417978599264L, 257832362129977838L);

   public static class_243 m0866(class_238 var0) {
      return new class_243(
         w.a<"B">(C1074.f4550, var0.field_1323, var0.field_1320, 308057504384614299L),
         var0.field_1322,
         w.a<"B">(C1074.f4550, var0.field_1321, var0.field_1324, 308057504384614299L)
      );
   }

   public static class_243 m0867(class_238 var0) {
      return w.a<"Û">(
         w.a<"B">(var0, 351265736671775343L),
         0.0,
         w.a<"Û">(var0, 328102654916935210L) * w.a<"B">(((long)f2038 | 758372L) + ~((long)f2038 & 758372L) + 1L ^ -4598175219992043262L, 317139102743630955L),
         0.0,
         215037093685651073L
      );
   }

   public static class_243 m0868(class_238 var0) {
      return new class_243(
         w.a<"B">(C1074.f4550, var0.field_1323, var0.field_1320, 308057504384614299L),
         var0.field_1325,
         w.a<"B">(C1074.f4550, var0.field_1321, var0.field_1324, 308057504384614299L)
      );
   }

   public static class_238 m0869(class_238 var0, class_243 var1) {
      double var2 = w.a<"Û">(var0, 144760074921415609L) * C1074.f4550;
      double var4 = w.a<"Û">(var0, 328102654916935210L) * C1074.f4550;
      double var6 = w.a<"Û">(var0, 313282100453182033L) * C1074.f4550;
      return new class_238(
         var1.field_1352 - var2, var1.field_1351 - var4, var1.field_1350 - var6, var1.field_1352 + var2, var1.field_1351 + var4, var1.field_1350 + var6
      );
   }

   public static class_238 m0870(class_238 var0, class_2338 var1) {
      return w.a<"B">(
         var0,
         new class_243(
            (double)w.a<"Û">(var1, 188922896808372924L) + C1074.f4550,
            (double)w.a<"Û">(var1, 171752333823210875L) + w.a<"Û">(var0, 328102654916935210L) * C1074.f4550,
            (double)w.a<"Û">(var1, 278942455661123424L) + C1074.f4550
         ),
         307108632476026139L
      );
   }

   public static class_238 m0871(class_2338 var0) {
      class_2680 var1 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var0, 310987074049434965L
      );
      if (!w.a<"Û">(var1, 363526675043086623L) && !w.a<"Û">(var1, class_2246.field_10124, 272812080270536171L)) {
         class_265 var2 = w.a<"Û">(
            var1, m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var0, 385368692334192390L
         );
         if (w.a<"Û">(var2, 125999939138686596L)) {
            var2 = w.a<"B">(
               0.0,
               0.0,
               0.0,
               w.a<"B">(((long)f2038 | 512816L) + ~((long)f2038 & 512816L) + 1L ^ -4607182419247587242L, 317139102743630955L),
               w.a<"B">(((long)f2038 | 487638L) + ~((long)f2038 & 487638L) + 1L ^ -4607182419247627344L, 317139102743630955L),
               w.a<"B">(((long)f2038 | 965508L) + ~((long)f2038 & 965508L) + 1L ^ -4607182419246987038L, 317139102743630955L),
               312203480862227361L
            );
         }

         return w.a<"Û">(w.a<"Û">(var2, 153037909352617834L), var0, 252103202185457587L);
      } else {
         return new class_238(var0);
      }
   }

   public static List<class_243> m0872(class_238 var0, double var1) {
      ArrayList var3 = new ArrayList(
         w.a<"B">(
            new class_243(var0.field_1323, var1, var0.field_1321),
            new class_243(var0.field_1320, var1, var0.field_1321),
            new class_243(var0.field_1323, var1, var0.field_1324),
            new class_243(var0.field_1320, var1, var0.field_1324),
            319034520487861803L
         )
      );
      w.a<"Û">(
         var3,
         w.a<"B">(
            (Function<class_243, Double>)var0x -> w.a<"B">(
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 270398306108537951L
                     ),
                     var0x,
                     271768320413122837L
                  ),
                  165155940100814265L
               ),
            224107444354928270L
         ),
         369116887926758393L
      );
      return var3;
   }

   public static boolean m0873(class_238 var0) {
      return (boolean)(w.a<"Û">(var0, 313282100453182033L)
               == w.a<"B">(((long)f2038 | 635869L) + ~((long)f2038 & 635869L) + 1L ^ -4607182419246923589L, 317139102743630955L)
            && w.a<"Û">(var0, 328102654916935210L)
               == w.a<"B">(((long)f2038 | 517602L) + ~((long)f2038 & 517602L) + 1L ^ -4607182419247589756L, 317139102743630955L)
            && w.a<"Û">(var0, 144760074921415609L)
               == w.a<"B">(((long)f2038 | 627652L) + ~((long)f2038 & 627652L) + 1L ^ -4607182419246915422L, 317139102743630955L)
         ? (f2038 | 712167) + ~(f2038 & 712167) + 1 ^ -446714240
         : (f2038 | 784481) + ~(f2038 & 784481) + 1 ^ -446788857);
   }

   public static boolean m0874(class_265 var0) {
      return (boolean)(w.a<"Û">(var0, 125999939138686596L)
         ? (f2038 | 642243) + ~(f2038 & 642243) + 1 ^ -446906459
         : w.a<"B">(w.a<"Û">(var0, 153037909352617834L), 142891869907128826L));
   }

   public static int m0875(class_1657 var0, C0015<Integer> var1) {
      if (w.a<"Û">(var1, 234167214910835683L)) {
         double var2 = w.a<"B">(
               w.a<"Û">(var0, 232702264516987563L) - var0.field_6014, w.a<"Û">(var0, 203672616216990522L) - var0.field_5969, 263950649710151907L
            )
            * w.a<"B">(((long)f2038 | 565483L) + ~((long)f2038 & 565483L) + 1L ^ -4626322717663177843L, 317139102743630955L)
            * w.a<"B">(((long)f2038 | 867181L) + ~((long)f2038 & 867181L) + 1L ^ -4615288898290678586L, 317139102743630955L);
         if (var2 < w.a<"B">(((long)f2038 | 274913L) + ~((long)f2038 & 274913L) + 1L ^ -4613937818688732537L, 317139102743630955L)) {
            return (f2038 | 916184) + ~(f2038 & 916184) + 1 ^ -447182402;
         } else if (var2 <= w.a<"B">(((long)f2038 | 548172L) + ~((long)f2038 & 548172L) + 1L ^ -4621819118035849686L, 317139102743630955L)) {
            return (f2038 | 573654) + ~(f2038 & 573654) + 1 ^ -446843983;
         } else if (var2 <= w.a<"B">(((long)f2038 | 40489L) + ~((long)f2038 & 40489L) + 1L ^ -4626322717663695537L, 317139102743630955L)) {
            return (f2038 | 939826) + ~(f2038 & 939826) + 1 ^ -447011753;
         } else {
            return var2 <= w.a<"B">(((long)f2038 | 224389L) + ~((long)f2038 & 224389L) + 1L ^ -4629137467430789149L, 317139102743630955L)
               ? (f2038 | 283997) + ~(f2038 & 283997) + 1 ^ -447666625
               : (f2038 | 687084) + ~(f2038 & 687084) + 1 ^ -446756721;
         }
      } else {
         return w.a<"Û">((Integer)w.a<"Û">(var1, 174312564406604366L), 260981171345819427L);
      }
   }

   public static class_243 m0876(class_243 var0, class_238 var1) {
      return new class_243(
         w.a<"B">(w.a<"Û">(var0, 366754089402394978L), var1.field_1323, var1.field_1320, 318037245528159060L),
         w.a<"B">(w.a<"Û">(var0, 292829928904272542L), var1.field_1322, var1.field_1325, 318037245528159060L),
         w.a<"B">(w.a<"Û">(var0, 317360164092454553L), var1.field_1321, var1.field_1324, 318037245528159060L)
      );
   }

   public static class_238 m0877(class_1297 var0, float var1) {
      double var2 = w.a<"B">((double)var1, var0.field_6038, w.a<"Û">(var0, 232310121460392074L), 308057504384614299L) - w.a<"Û">(var0, 232310121460392074L);
      double var4 = w.a<"B">((double)var1, var0.field_5971, w.a<"Û">(var0, 113892722580447470L), 308057504384614299L) - w.a<"Û">(var0, 113892722580447470L);
      double var6 = w.a<"B">((double)var1, var0.field_5989, w.a<"Û">(var0, 204214536009510197L), 308057504384614299L) - w.a<"Û">(var0, 204214536009510197L);
      class_238 var8 = w.a<"Û">(var0, 225708705569795011L);
      return w.a<"Û">(var8, var2, var4, var6, 240768051853680291L);
   }

   public static class_238 m0878(class_1309 var0) {
      if (var0 instanceof C0804) {
         return w.a<"Û">(var0, 381939097272295099L);
      } else {
         class_238 var1 = w.a<"Û">(var0, 381939097272295099L);
         DuckLivingEntity var2 = (DuckLivingEntity)var0;
         class_243 var3 = new class_243(var2.mio$getServerX(), var2.mio$getServerY(), var2.mio$getServerZ());
         if (w.a<"Û">(var3, 139988537239508045L) == 0.0) {
            return w.a<"Û">(var0, 381939097272295099L);
         } else {
            double var4 = w.a<"Û">(var1, 144760074921415609L)
               / w.a<"B">(((long)f2038 | 358588L) + ~((long)f2038 & 358588L) + 1L ^ -4611686018875126822L, 317139102743630955L);
            double var6 = w.a<"Û">(var1, 313282100453182033L)
               / w.a<"B">(((long)f2038 | 281968L) + ~((long)f2038 & 281968L) + 1L ^ -4611686018875048426L, 317139102743630955L);
            var1 = new class_238(-var4, 0.0, -var6, var4, w.a<"Û">(var1, 328102654916935210L), var6);
            return w.a<"Û">(var1, var3, 297547269964217781L);
         }
      }
   }

   public static boolean m0879(class_238 var0, class_238 var1) {
      class_238 var2 = w.a<"Û">(var0, var1, 345295023867514694L);
      float var3 = (float)w.a<"B">(
         w.a<"Û">(var2, 144760074921415609L),
         w.a<"B">(w.a<"Û">(var2, 328102654916935210L), w.a<"Û">(var2, 313282100453182033L), 199488685501753436L),
         199488685501753436L
      );
      return (boolean)((double)var3 > w.a<"B">(((long)f2038 | 274451L) + ~((long)f2038 & 274451L) + 1L ^ -4502148214040957891L, 317139102743630955L)
         ? (f2038 | 741151) + ~(f2038 & 741151) + 1 ^ -446808968
         : (f2038 | 31062) + ~(f2038 & 31062) + 1 ^ -447411664);
   }
}
