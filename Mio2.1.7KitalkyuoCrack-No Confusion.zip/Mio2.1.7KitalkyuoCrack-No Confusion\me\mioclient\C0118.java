package me.mioclient;

import java.util.function.Predicate;

public class C0118 implements Predicate {
   public C0366 f0770;

   public C0118(C0366 var1) {
      this.f0770 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0770.f3251, 254992554122318132L);
   }
}
