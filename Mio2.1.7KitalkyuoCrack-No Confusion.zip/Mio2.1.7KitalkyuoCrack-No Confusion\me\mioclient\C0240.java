package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.Predicate;

public final class C0240 extends C0015<Boolean> {
   public static int f3011 = w.a<"B">(7440671658165073905L, 257832362129977838L);

   public C0240(String var1, Boolean var2, Predicate<Boolean> var3) {
      super(var1, var2, var3);
   }

   public C0240(String var1, Boolean var2) {
      super(var1, var2);
   }

   @Override
   public void m0645(String var1) {
      if (w.a<"Û">("toggle", var1, 307662238383225114L)) {
         w.a<"Û">(
            this,
            w.a<"B">(
               (boolean)(!w.a<"Û">((Boolean)w.a<"Û">(this, 174312564406604366L), 354697271520518137L)
                  ? (f3011 | 334875) + ~(f3011 & 334875) + 1 ^ 2032733477
                  : (f3011 | 556130) + ~(f3011 & 556130) + 1 ^ 2032430429),
               320330632857389983L
            ),
            277551887451345681L
         );
      } else if (var1.equals("0") || w.a<"Û">(var1, "false", 307662238383225114L)) {
         w.a<"Û">(this, w.a<"B">((boolean)((f3011 | 750404) + ~(f3011 & 750404) + 1 ^ 2032624251), 320330632857389983L), 277551887451345681L);
      } else if (var1.equals("1") || w.a<"Û">(var1, "true", 307662238383225114L)) {
         w.a<"Û">(this, w.a<"B">((boolean)((f3011 | 976290) + ~(f3011 & 976290) + 1 ^ 2032333980), 320330632857389983L), 277551887451345681L);
      }
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive((Boolean)w.a<"Û">(this, 174312564406604366L));
   }

   @Override
   public void fromJson(JsonElement var1) {
      w.a<"Û">(this, w.a<"B">(w.a<"Û">(var1, 377634429648480575L), 320330632857389983L), 277551887451345681L);
   }

   public static String _rq5G95RJAOK2rzr4ZTaupElmSnwC2x2etYAp86xx0nBM6x2q3Iu9siKBoB6KcuPNttWDSt3ToHT5MVHdM6lCL0EUdATJsOSiqB6/* $VF was: 1rq5G95RJAOK2rzr4ZTaupElmSnwC2x2etYAp86xx0nBM6x2q3Iu9siKBoB6KcuPNttWDSt3ToHT5MVHdM6lCL0EUdATJsOSiqB6*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
