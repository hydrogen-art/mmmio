package me.mioclient;

import java.util.function.Supplier;
import org.jetbrains.annotations.Nullable;

public interface C0168 {
   @Nullable
   Supplier<Integer> getSupplier();

   void setSupplier(@Nullable Supplier<Integer> var1);
}
