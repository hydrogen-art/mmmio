package me.mioclient;

import java.util.function.Predicate;

public class C0365 implements Predicate {
   public C0396 f0270;

   public C0365(C0396 var1) {
      this.f0270 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return (w.a<"Û">(this.f0270.f0146, 174312564406604366L) == C0069.f3531 || w.a<"Û">(this.f0270.f0146, 174312564406604366L) == C0069.f3533)
         && w.a<"Û">(this.f0270.f0130, 254992554122318132L)
         && w.a<"Û">(this.f0270.f0145, 254992554122318132L);
   }
}
