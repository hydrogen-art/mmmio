package me.mioclient;

public interface C0209 {
   boolean isToggled();

   default void m1972(boolean var1) {
      if (w.a<"Û">(this, 207329493047481482L) != var1) {
         w.a<"Û">(this, 289688631157446311L);
      }
   }

   default void m1973() {
      if (w.a<"Û">(this, 207329493047481482L)) {
         w.a<"Û">(this, 233322433572713897L);
      } else {
         w.a<"Û">(this, 223550862439764137L);
      }
   }

   void enable();

   void disable();
}
