package me.mioclient;

import com.mojang.blaze3d.systems.RenderSystem;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.awt.Color;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL32C;

public final class C0485 implements C0045 {
   public static final C0066 f2881 = C0066.m0745();
   public static final C0066 f2882 = C0066.m0745();
   public static final List<C0486> f2883 = new ObjectArrayList();

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = -9999
   )
   public static void m3214(C1358 var0) {
      m3223();
      RenderSystem.enablePolygonOffset();
      RenderSystem.polygonOffset(1.0F, -1500000.0F);
      GL20.glDepthRange(0.0, 0.1);
      C0438.m3968();
      GL20.glDepthRange(0.0, 1.0);
      RenderSystem.polygonOffset(1.0F, 1500000.0F);
      RenderSystem.disablePolygonOffset();
   }

   public static void m3215(class_4587 var0, class_2338 var1, Color var2) {
      m3216(var0, new class_238(var1), var2);
   }

   public static void m3216(class_4587 var0, class_238 var1, Color var2) {
      if (var2.getAlpha() != 0) {
         float var3 = (float)(
            var1.field_1323
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10216()
         );
         float var4 = (float)(
            var1.field_1322
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10214()
         );
         float var5 = (float)(
            var1.field_1321
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10215()
         );
         float var6 = (float)(
            var1.field_1320
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10216()
         );
         float var7 = (float)(
            var1.field_1325
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10214()
         );
         float var8 = (float)(
            var1.field_1324
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10215()
         );
         int var9 = m3221(var2).hashCode();
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var5).method_39415(var9);
      }
   }

   public static void m3217(class_4587 var0, class_238 var1, Color var2) {
      if (var2.getAlpha() != 0) {
         float var3 = (float)(
            var1.field_1323
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10216()
         );
         float var4 = (float)(
            var1.field_1322
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10214()
         );
         float var5 = (float)(
            var1.field_1321
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10215()
         );
         float var6 = (float)(
            var1.field_1320
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10216()
         );
         float var7 = (float)(
            var1.field_1325
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10214()
         );
         float var8 = (float)(
            var1.field_1324
               - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
                  .field_4686
                  .method_19326()
                  .method_10215()
         );
         int var9 = var2.hashCode();
         int var10 = C0152.m3475(var2, 0);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var5).method_39415(var10);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var5).method_39415(var10);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var5).method_39415(var10);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var8).method_39415(var10);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var6, var7, var8).method_39415(var10);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var8).method_39415(var10);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var5).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var4, var8).method_39415(var9);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var8).method_39415(var10);
         f2881.method_22918(var0.method_23760().method_23761(), var3, var7, var5).method_39415(var10);
      }
   }

   public static void m3218(class_4587 var0, class_2338 var1, Color var2, float var3) {
      m3219(var0, new class_238(var1), var2, var3);
   }

   public static void m3219(class_4587 var0, class_238 var1, Color var2, float var3) {
      if (var2.getAlpha() != 0) {
         if (!(var3 <= 0.0F)) {
            f2883.add(C0486.m1815(var0, var1, m3221(var2), var3));
         }
      }
   }

   public static void m3220(C0486 var0) {
      Matrix4f var1 = var0.f4502;
      Matrix3f var2 = var0.f4503;
      float var3 = (float)(
         var0.f4504.field_1323
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
               .field_4686
               .method_19326()
               .method_10216()
      );
      float var4 = (float)(
         var0.f4504.field_1322
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
               .field_4686
               .method_19326()
               .method_10214()
      );
      float var5 = (float)(
         var0.f4504.field_1321
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
               .field_4686
               .method_19326()
               .method_10215()
      );
      float var6 = (float)(
         var0.f4504.field_1320
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
               .field_4686
               .method_19326()
               .method_10216()
      );
      float var7 = (float)(
         var0.f4504.field_1325
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
               .field_4686
               .method_19326()
               .method_10214()
      );
      float var8 = (float)(
         var0.f4504.field_1324
            - m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
               .field_4686
               .method_19326()
               .method_10215()
      );
      int var9 = var0.f4505.hashCode();
      f2882.method_22918(var1, var3, var4, var5).method_39415(var9);
      f2882.method_22918(var1, var6, var4, var5).method_39415(var9);
      f2882.method_22918(var1, var3, var4, var5).method_39415(var9);
      f2882.method_22918(var1, var3, var7, var5).method_39415(var9);
      f2882.method_22918(var1, var3, var4, var5).method_39415(var9);
      f2882.method_22918(var1, var3, var4, var8).method_39415(var9);
      f2882.method_22918(var1, var6, var4, var5).method_39415(var9);
      f2882.method_22918(var1, var6, var7, var5).method_39415(var9);
      f2882.method_22918(var1, var6, var7, var5).method_39415(var9);
      f2882.method_22918(var1, var3, var7, var5).method_39415(var9);
      f2882.method_22918(var1, var3, var7, var5).method_39415(var9);
      f2882.method_22918(var1, var3, var7, var8).method_39415(var9);
      f2882.method_22918(var1, var3, var7, var8).method_39415(var9);
      f2882.method_22918(var1, var3, var4, var8).method_39415(var9);
      f2882.method_22918(var1, var3, var4, var8).method_39415(var9);
      f2882.method_22918(var1, var6, var4, var8).method_39415(var9);
      f2882.method_22918(var1, var6, var4, var8).method_39415(var9);
      f2882.method_22918(var1, var6, var4, var5).method_39415(var9);
      f2882.method_22918(var1, var3, var7, var8).method_39415(var9);
      f2882.method_22918(var1, var6, var7, var8).method_39415(var9);
      f2882.method_22918(var1, var6, var4, var8).method_39415(var9);
      f2882.method_22918(var1, var6, var7, var8).method_39415(var9);
      f2882.method_22918(var1, var6, var7, var5).method_39415(var9);
      f2882.method_22918(var1, var6, var7, var8).method_39415(var9);
   }

   public static Color m3221(Color var0) {
      return m3222(var0, RenderSystem.getShaderColor());
   }

   public static Color m3222(Color var0, float[] var1) {
      return new Color(
         (int)((float)var0.getRed() * var1[0]),
         (int)((float)var0.getGreen() * var1[1]),
         (int)((float)var0.getBlue() * var1[2]),
         (int)((float)var0.getAlpha() * var1[3])
      );
   }

   public static void m3223() {
      C0094.f4640.m1900();
      RenderSystem.setShader(class_757::method_34540);
      f2881.m0752();
      f2883.sort(Comparator.comparing(var0x -> var0x.f4506));
      float var0 = 0.0F;

      for (C0486 var2 : f2883) {
         if (var2.f4506 != var0) {
            m3225();
         }

         var0 = var2.f4506;
         m3224(var0);
         m3220(var2);
      }

      f2883.clear();
      m3225();
      C0094.f4640.m1902();
   }

   public static void m3224(float var0) {
      GL32C.glLineWidth(var0);
   }

   public static void m3225() {
      f2882.m0752();
      GL32C.glLineWidth(1.0F);
   }

   static {
      m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8.m0193(C0485.class);
      f2881.m0747(class_5596.field_27382, class_290.field_1576);
      f2882.m0747(class_5596.field_29344, class_290.field_1576);
   }
}
