package me.mioclient;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Font;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Locale;
import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_286;
import net.minecraft.class_290;
import net.minecraft.class_379;
import net.minecraft.class_382;
import net.minecraft.class_383;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5481;
import net.minecraft.class_757;
import net.minecraft.class_293.class_5596;

public class C0462 implements class_379 {
   public static final C0066 f4718 = C0066.m0745();
   public static final C0066 f4719 = C0066.m0745();
   public static class_1921 f4720;
   public static final class_4597 f4721 = var0x -> {
      if (f4720 != null && f4720 != var0x) {
         C0438.m3968();
      }

      if (!f4719.m0748()) {
         f4719.m0749(var0x.method_23033(), var0x.method_23031());
      }

      f4720 = var0x;
      return f4719;
   };
   public static final int[] f4722 = new int[(C0462.f4727 | 697506) + ~(C0462.f4727 & 697506) + 1 ^ -1564289693];
   public final C0605 f4723 = new C0605(this);
   public final C1177 f4724;
   public float f4725;
   public float f4726;
   public static int f4727 = -1563921951;

   public C0462(C1177 var1) {
      this.f4724 = var1;
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public static C0462 m1941(String var0, int var1, C0934 var2) {
      char[] var3 = new char[(f4727 | 30783) + ~(f4727 & 30783) + 1 ^ -1563948029];

      for (int var4 = (f4727 | 138052) + ~(f4727 & 138052) + 1 ^ -1563792731;
         var4 < var3.length - ((f4727 | 455558) + ~(f4727 & 455558) + 1 ^ -1563524506);
         var4++
      ) {
         var3[var4] = (char)var4;
      }

      var3[var3.length - ((f4727 | 553551) + ~(f4727 & 553551) + 1 ^ -1564474449)] = (char)((f4727 | 449430) + ~(f4727 & 449430) + 1 ^ -1563522967);

      C1177 var5 = switch (<unrepresentable>.f3435[var2.ordinal()]) {
         case 1 -> new C1177(
         new Font(var0, (f4727 | 593121) + ~(f4727 & 593121) + 1 ^ -1564377856, var1),
         (boolean)((f4727 | 124852) + ~(f4727 & 124852) + 1 ^ -1563847084),
         (boolean)((f4727 | 752080) + ~(f4727 & 752080) + 1 ^ -1564276688)
      );
         case 2 -> new C1177(
         new Font(var0, (f4727 | 394481) + ~(f4727 & 394481) + 1 ^ -1563527919, var1),
         (boolean)((f4727 | 13550) + ~(f4727 & 13550) + 1 ^ -1563933426),
         (boolean)((f4727 | 670530) + ~(f4727 & 670530) + 1 ^ -1564325214)
      );
         case 3 -> new C1177(
         new Font(var0, (f4727 | 798473) + ~(f4727 & 798473) + 1 ^ -1564188950, var1),
         (boolean)((f4727 | 338194) + ~(f4727 & 338194) + 1 ^ -1563600654),
         (boolean)((f4727 | 660042) + ~(f4727 & 660042) + 1 ^ -1564318806)
      );
         case 4 -> new C1177(
         new Font(var0, (f4727 | 610834) + ~(f4727 & 610834) + 1 ^ -1564400656, var1),
         (boolean)((f4727 | 3094) + ~(f4727 & 3094) + 1 ^ -1563918858),
         (boolean)((f4727 | 775311) + ~(f4727 & 775311) + 1 ^ -1564236433)
      );
         default -> throw new MatchException(null, null);
      };
      var5.m3600(var3);
      var5.m3601();
      return new C0462(var5);
   }

   public int m1942(class_4587 var1, String var2, float var3, float var4, int var5) {
      return this.m1949(var1, var2, var3, var4, var5, (boolean)((f4727 | 415688) + ~(f4727 & 415688) + 1 ^ -1563548120));
   }

   public int m1943(class_4587 var1, String var2, double var3, double var5, int var7) {
      return this.m1949(var1, var2, (float)var3, (float)var5, var7, (boolean)((f4727 | 998856) + ~(f4727 & 998856) + 1 ^ -1563997144));
   }

   public int m1944(class_4587 var1, String var2, float var3, float var4, int var5) {
      return this.m1949(var1, var2, var3, var4, var5, (boolean)((f4727 | 545042) + ~(f4727 & 545042) + 1 ^ -1564466957));
   }

   public int m1945(class_4587 var1, String var2, double var3, double var5, int var7) {
      return this.m1949(var1, var2, (float)var3, (float)var5, var7, (boolean)((f4727 | 388536) + ~(f4727 & 388536) + 1 ^ -1563583399));
   }

   public int m1946(class_4587 var1, String var2, double var3, double var5, int var7) {
      return this.m1949(
         var1,
         var2,
         (float)var3 - (float)this.m1955(var2) / Float.intBitsToFloat((f4727 | 525681) + ~(f4727 & 525681) + 1 ^ -490703728),
         (float)var5,
         var7,
         (boolean)((f4727 | 515638) + ~(f4727 & 515638) + 1 ^ -1563447337)
      );
   }

   public int m1947(class_4587 var1, String var2, double var3, double var5, int var7) {
      return this.m1949(
         var1,
         var2,
         (float)var3 - (float)this.m1955(var2) / Float.intBitsToFloat((f4727 | 17922) + ~(f4727 & 17922) + 1 ^ -490194973),
         (float)var5,
         var7,
         (boolean)((f4727 | 697537) + ~(f4727 & 697537) + 1 ^ -1564289759)
      );
   }

   public int m1948(class_4587 var1, class_5481 var2, float var3, float var4, int var5, boolean var6) {
      int var9;
      if (var6) {
         C0921 var8 = new C0921(var1, var5, Float.intBitsToFloat((f4727 | 618660) + ~(f4727 & 618660) + 1 ^ -1673461435), this.f4724);
         var9 = var8.m3593(var2, var3 + C0498.m3899(), var4 + C0498.m3899());
         var8 = new C0921(var1, var5, Float.intBitsToFloat((f4727 | 221044) + ~(f4727 & 221044) + 1 ^ -1656017259), this.f4724);
         var9 = Math.max(var9, var8.m3593(var2, var3, var4));
      } else {
         C0921 var11 = new C0921(var1, var5, Float.intBitsToFloat((f4727 | 458184) + ~(f4727 & 458184) + 1 ^ -1655796695), this.f4724);
         var9 = var11.m3593(var2, var3, var4);
      }

      return var9;
   }

   public int m1949(class_4587 var1, String var2, float var3, float var4, int var5, boolean var6) {
      int var8;
      if (var6) {
         var8 = this.m1950(var1, var2, var3 + C0498.m3899(), var4 + C0498.m3899(), var5, (boolean)((f4727 | 691627) + ~(f4727 & 691627) + 1 ^ -1564279733));
         var8 = Math.max(var8, this.m1950(var1, var2, var3, var4, var5, (boolean)((f4727 | 667611) + ~(f4727 & 667611) + 1 ^ -1564320198)));
      } else {
         var8 = this.m1950(var1, var2, var3, var4, var5, (boolean)((f4727 | 686309) + ~(f4727 & 686309) + 1 ^ -1564342012));
      }

      return var8;
   }

   public int m1950(class_4587 var1, String var2, float var3, float var4, int var5, boolean var6) {
      if (var2 == null) {
         return (f4727 | 588742) + ~(f4727 & 588742) + 1 ^ -1564440025;
      } else {
         if ((var5 & ((f4727 | 547421) + ~(f4727 & 547421) + 1 ^ 1589652412)) == 0) {
            var5 |= (f4727 | 917358) + ~(f4727 & 917358) + 1 ^ 1573228175;
         }

         if (var6) {
            var5 = (var5 & ((f4727 | 71172) + ~(f4727 & 71172) + 1 ^ -1573545191)) >> ((f4727 | 571521) + ~(f4727 & 571521) + 1 ^ -1564423838)
               | var5 & ((f4727 | 182416) + ~(f4727 & 182416) + 1 ^ 1573566833);
         }

         this.f4725 = var3 * Float.intBitsToFloat((f4727 | 234794) + ~(f4727 & 234794) + 1 ^ -489954101);
         this.f4726 = var4 * Float.intBitsToFloat((f4727 | 980870) + ~(f4727 & 980870) + 1 ^ -490305945);
         this.m1951(var1, var2, var6, var5);
         return (int)(this.f4725 / Float.intBitsToFloat((f4727 | 394846) + ~(f4727 & 394846) + 1 ^ -498174017));
      }
   }

   public void m1951(class_4587 var1, String var2, boolean var3, int var4) {
      float var5 = (float)(var4 >> ((f4727 | 388318) + ~(f4727 & 388318) + 1 ^ -1563583193) & ((f4727 | 994310) + ~(f4727 & 994310) + 1 ^ -1563992808))
         / Float.intBitsToFloat((f4727 | 237765) + ~(f4727 & 237765) + 1 ^ -508243676);
      float var6 = (float)(var4 >> ((f4727 | 303124) + ~(f4727 & 303124) + 1 ^ -1563635227) & ((f4727 | 861994) + ~(f4727 & 861994) + 1 ^ -1564125644))
         / Float.intBitsToFloat((f4727 | 68040) + ~(f4727 & 68040) + 1 ^ -508135383);
      float var7 = (float)(var4 >> ((f4727 | 559436) + ~(f4727 & 559436) + 1 ^ -1564411739) & ((f4727 | 63631) + ~(f4727 & 63631) + 1 ^ -1563915887))
         / Float.intBitsToFloat((f4727 | 317232) + ~(f4727 & 317232) + 1 ^ -508320047);
      float var8 = (float)(var4 & ((f4727 | 428261) + ~(f4727 & 428261) + 1 ^ -1563493893))
         / Float.intBitsToFloat((f4727 | 260800) + ~(f4727 & 260800) + 1 ^ -508261599);
      var1.method_22903();
      var1.method_46416((float)C0498.m3900(), (float)C0498.m3898(), 0.0F);
      var1.method_22905(
         Float.intBitsToFloat((f4727 | 956747) + ~(f4727 & 956747) + 1 ^ -1647908694),
         Float.intBitsToFloat((f4727 | 22341) + ~(f4727 & 22341) + 1 ^ -1647827292),
         Float.intBitsToFloat((f4727 | 9429) + ~(f4727 & 9429) + 1 ^ -1647815372)
      );
      if (!f4718.m0748()) {
         f4718.m0749(class_5596.field_27382, class_290.field_1575);
      }

      for (int var9 = (f4727 | 39856) + ~(f4727 & 39856) + 1 ^ -1563891119; var9 < var2.length(); var9++) {
         char var10 = var2.charAt(var9);
         if (var10 == ((f4727 | 616024) + ~(f4727 & 616024) + 1 ^ -1564403938)
            && var9 + ((f4727 | 980792) + ~(f4727 & 980792) + 1 ^ -1564047656) < var2.length()) {
            int var13 = "0123456789abcdefklmnor"
               .indexOf(var2.toLowerCase(Locale.ENGLISH).charAt(var9 + ((f4727 | 233250) + ~(f4727 & 233250) + 1 ^ -1563689278)));
            if (var13 < ((f4727 | 630478) + ~(f4727 & 630478) + 1 ^ -1564348609)) {
               if (var13 < 0) {
                  var13 = (f4727 | 187201) + ~(f4727 & 187201) + 1 ^ -1563776337;
               }

               if (var3) {
                  var13 += 16;
               }

               int var12 = f4722[var13];
               var6 = (float)(var12 >> ((f4727 | 943771) + ~(f4727 & 943771) + 1 ^ -1564076182) & ((f4727 | 209369) + ~(f4727 & 209369) + 1 ^ -1563737913))
                  / Float.intBitsToFloat((f4727 | 475148) + ~(f4727 & 475148) + 1 ^ -508546579);
               var7 = (float)(var12 >> ((f4727 | 932179) + ~(f4727 & 932179) + 1 ^ -1564063558) & ((f4727 | 856544) + ~(f4727 & 856544) + 1 ^ -1564122882))
                  / Float.intBitsToFloat((f4727 | 515438) + ~(f4727 & 515438) + 1 ^ -508515185);
               var8 = (float)(var12 & ((f4727 | 760451) + ~(f4727 & 760451) + 1 ^ -1564218467))
                  / Float.intBitsToFloat((f4727 | 911779) + ~(f4727 & 911779) + 1 ^ -507865022);
            } else {
               var6 = (float)(var4 >> ((f4727 | 413670) + ~(f4727 & 413670) + 1 ^ -1563541993) & ((f4727 | 377276) + ~(f4727 & 377276) + 1 ^ -1563578206))
                  / Float.intBitsToFloat((f4727 | 592336) + ~(f4727 & 592336) + 1 ^ -507611087);
               var7 = (float)(var4 >> ((f4727 | 982045) + ~(f4727 & 982045) + 1 ^ -1564045836) & ((f4727 | 593099) + ~(f4727 & 593099) + 1 ^ -1564377643))
                  / Float.intBitsToFloat((f4727 | 286052) + ~(f4727 & 286052) + 1 ^ -508351355);
               var8 = (float)(var4 & ((f4727 | 527382) + ~(f4727 & 527382) + 1 ^ -1564443384))
                  / Float.intBitsToFloat((f4727 | 858436) + ~(f4727 & 858436) + 1 ^ -507877211);
            }

            var9++;
         } else {
            this.f4724.m3602();
            float var11 = this.f4724.m3604(var1, f4718, var10, this.f4725, this.f4726, var6, var8, var7, var5);
            this.m1952(var11, this.f4724);
         }
      }

      var1.method_22909();
   }

   public void m1952(float var1, C1177 var2) {
      this.f4725 += var1;
   }

   public C1177 m1953() {
      return this.f4724;
   }

   public int m1954() {
      return this.f4724.m3606() / ((f4727 | 835291) + ~(f4727 & 835291) + 1 ^ -1564160200);
   }

   public int m1955(String var1) {
      if (var1 == null) {
         return (f4727 | 938269) + ~(f4727 & 938269) + 1 ^ -1564073732;
      } else {
         int var2 = (f4727 | 284042) + ~(f4727 & 284042) + 1 ^ -1563679637;
         int var4 = var1.length();
         int var5 = (f4727 | 421161) + ~(f4727 & 421161) + 1 ^ -1563550520;

         for (int var6 = (f4727 | 34219) + ~(f4727 & 34219) + 1 ^ -1563888566; var6 < var4; var6++) {
            char var7 = var1.charAt(var6);
            if (var7 == ((f4727 | 346143) + ~(f4727 & 346143) + 1 ^ -1563608743) && var6 + ((f4727 | 844820) + ~(f4727 & 844820) + 1 ^ -1564174860) < var4) {
               var6++;
            } else {
               var7 = var1.charAt(var6);
               C1177 var3 = this.m1953();
               var2 += (int)(var3.m3605(var7) - Float.intBitsToFloat((f4727 | 954022) + ~(f4727 & 954022) + 1 ^ -473497785));
            }
         }

         return var2 / ((f4727 | 68203) + ~(f4727 & 68203) + 1 ^ -1563853944) + ((f4727 | 119894) + ~(f4727 & 119894) + 1 ^ -1563843146);
      }
   }

   public float m1956(char var1) {
      return (this.m1953().m3605(var1) - Float.intBitsToFloat((f4727 | 613038) + ~(f4727 & 613038) + 1 ^ -473879729))
         / Float.intBitsToFloat((f4727 | 574048) + ~(f4727 & 574048) + 1 ^ -490687615);
   }

   public void m1957() {
      if (f4718.m0748()) {
         C1177 var1 = this.m1953();
         GlStateManager._enableBlend();
         GlStateManager._blendFunc((f4727 | 228366) + ~(f4727 & 228366) + 1 ^ -1563750675, (f4727 | 501885) + ~(f4727 & 501885) + 1 ^ -1563436385);
         var1.m3602();
         RenderSystem.setShader(class_757::method_34543);
         RenderSystem.disableDepthTest();
         C0066.m0753(f4718);
         RenderSystem.enableDepthTest();
         var1.m3603();
      }

      m1958();
   }

   public static void m1958() {
      if (f4719.m0748() && f4720 != null) {
         f4720.method_23516();
         RenderSystem.disableDepthTest();
         class_286.method_43433(f4719.m0751());
         RenderSystem.enableDepthTest();
         f4720.method_23518();
         f4720 = null;
      }
   }

   public class_4597 m1959() {
      return f4721;
   }

   public C0605 m1960() {
      return this.f4723;
   }

   public float getAdvance() {
      return 0.0F;
   }

   public class_382 bake(Function<class_383, class_382> var1) {
      return null;
   }

   static {
      long var10000 = 7396746155988017480L;

      for (int var0 = (f4727 | 415836) + ~(f4727 & 415836) + 1 ^ -1563547203; var0 < ((f4727 | 406985) + ~(f4727 & 406985) + 1 ^ -1563540472); var0++) {
         int var1 = (var0 >> ((f4727 | 225097) + ~(f4727 & 225097) + 1 ^ -1563746645) & ((f4727 | 655010) + ~(f4727 & 655010) + 1 ^ -1564373182))
            * ((f4727 | 259725) + ~(f4727 & 259725) + 1 ^ -1563719879);
         int var2 = (var0 >> ((f4727 | 604951) + ~(f4727 & 604951) + 1 ^ -1564390668) & ((f4727 | 505967) + ~(f4727 & 505967) + 1 ^ -1563440753))
               * ((f4727 | 516562) + ~(f4727 & 516562) + 1 ^ -1563455335)
            + var1;
         int var3 = (var0 >> ((f4727 | 308073) + ~(f4727 & 308073) + 1 ^ -1563639159) & ((f4727 | 704846) + ~(f4727 & 704846) + 1 ^ -1564299090))
               * ((f4727 | 912075) + ~(f4727 & 912075) + 1 ^ -1564107904)
            + var1;
         int var4 = (var0 & ((f4727 | 990872) + ~(f4727 & 990872) + 1 ^ -1563988104)) * ((f4727 | 871063) + ~(f4727 & 871063) + 1 ^ -1564132388) + var1;
         if (var0 == ((f4727 | 326677) + ~(f4727 & 326677) + 1 ^ -1563652622)) {
            var2 += 85;
         }

         if (var0 >= ((f4727 | 46870) + ~(f4727 & 46870) + 1 ^ -1563900185)) {
            var2 /= (f4727 | 988140) + ~(f4727 & 988140) + 1 ^ -1563991543;
            var3 /= (f4727 | 812973) + ~(f4727 & 812973) + 1 ^ -1564207544;
            var4 /= (f4727 | 594019) + ~(f4727 & 594019) + 1 ^ -1564384890;
         }

         f4722[var0] = (var2 & ((f4727 | 362241) + ~(f4727 & 362241) + 1 ^ -1563560417)) << ((f4727 | 510777) + ~(f4727 & 510777) + 1 ^ -1563444536)
            | (var3 & ((f4727 | 545075) + ~(f4727 & 545075) + 1 ^ -1564467155)) << ((f4727 | 160348) + ~(f4727 & 160348) + 1 ^ -1563819083)
            | var4 & ((f4727 | 562470) + ~(f4727 & 562470) + 1 ^ -1564416968);
      }
   }

   public static String BWExoNPWY9wKTU0DnOK5PMDMvnv0BiBSH7ygJUMBH8IWMtbOSIlEnjJbRU6RdrGvHcNMy5GwB4iH7PmNsLJnchoRBB6GlVXpO74Z(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
