package me.mioclient;

import net.minecraft.class_703;

public class C0521 extends C1180 {
   public class_703 f1136;

   public C0521(class_703 var1) {
      this.f1136 = var1;
   }

   public class_703 m0535() {
      return this.f1136;
   }

   public void m0536(class_703 var1) {
      this.f1136 = var1;
   }
}
