package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Predicate;

public final class C0264 implements C0045, C0997 {
   public final Map<C1266, String> f3625 = new HashMap<>();
   public final Map<String, String> f3626 = new HashMap<>();
   public static int f3627 = w.a<"B">(1369670234527306414L, 257832362129977838L);

   public void m1490(C1266 var1, String var2) {
      w.a<"Û">(this.f3625, var1, (BiFunction<C1266, String, String>)(var1x, var2x) -> var2, 280205116198276366L);
   }

   public void m1491(String var1, String var2) {
      w.a<"Û">(this.f3626, var1, (BiFunction<String, String, String>)(var1x, var2x) -> var2, 280205116198276366L);
   }

   public void m1492(C1266 var1) {
      w.a<"Û">(this.f3625, var1, 128627855127182569L);
   }

   public void m1493(String var1) {
      w.a<"Û">(this.f3626, var1, 128627855127182569L);
   }

   public String m1494(C1266 var1) {
      return (String)w.a<"Û">(this.f3625, var1, w.a<"Û">(var1, 248211090350577353L), 183430545168542698L);
   }

   public String m1495(String var1) {
      return (String)w.a<"Û">(this.f3626, var1, var1, 183430545168542698L);
   }

   @Override
   public JsonElement toJson() {
      JsonObject var1 = new JsonObject();
      JsonObject var2 = new JsonObject();
      JsonObject var3 = new JsonObject();
      w.a<"Û">(
         this.f3625,
         (BiConsumer<C1266, String>)(var1x, var2x) -> w.a<"Û">(var2, w.a<"Û">(var1x, 248211090350577353L), var2x, 179792809915938270L),
         316328768057134350L
      );
      Map var10000 = this.f3626;
      w.a<"B">(var3, 131918113315390561L);
      w.a<"Û">(var10000, var3::addProperty, 316328768057134350L);
      w.a<"Û">(var1, "module", var2, 130151082343781043L);
      w.a<"Û">(var1, "players", var3, 130151082343781043L);
      return var1;
   }

   @Override
   public void fromJson(JsonElement var1) {
      JsonObject var2 = w.a<"Û">(var1, 322749330123725882L);
      if (w.a<"Û">(var2, "module", 314399812765309162L)) {
         w.a<"Û">(
            w.a<"Û">(w.a<"Û">(var2, "module", 216368726004279618L), 274534791465332761L),
            (BiConsumer<String, JsonElement>)(var1x, var2x) -> w.a<"Û">(
                  w.a<"Û">(
                     C0933.f1413, (Predicate<C1266>)var1xx -> w.a<"Û">(w.a<"Û">(var1xx, 248211090350577353L), var1x, 307662238383225114L), 120632717548688135L
                  ),
                  (Consumer<C1266>)var2xx -> w.a<"Û">(this, var2xx, w.a<"Û">(var2x, 327479800495025542L), 108830481518658597L),
                  256723684597323177L
               ),
            316328768057134350L
         );
      }

      if (w.a<"Û">(var2, "players", 314399812765309162L)) {
         w.a<"Û">(
            w.a<"Û">(w.a<"Û">(var2, "players", 216368726004279618L), 274534791465332761L),
            (BiConsumer<String, JsonElement>)(var1x, var2x) -> w.a<"Û">(this, var1x, w.a<"Û">(var2x, 327479800495025542L), 190306567914318474L),
            316328768057134350L
         );
      }
   }

   @Override
   public String getConfigName() {
      return "aliases.json";
   }

   public static String pyxWOpZQJz0Gecx8XZgA1ljw7XAck4OGJN2q77psMAGmNkXOr8eKbrpq13Stp9OcERZ9JRxM76t3iy1YHRPaYmLMmLcd7o0YPiWR(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
