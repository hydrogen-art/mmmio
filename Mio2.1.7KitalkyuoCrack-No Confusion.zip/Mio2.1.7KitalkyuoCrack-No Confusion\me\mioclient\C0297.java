package me.mioclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_290;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_630;
import net.minecraft.class_757;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_630.class_593;
import net.minecraft.class_630.class_628;
import org.joml.Vector4f;

public class C0297 implements C0045 {
   public static final Vector4f f0846 = new Vector4f();
   public static final Vector4f f0847 = new Vector4f();
   public static final Vector4f f0848 = new Vector4f();
   public static final Vector4f f0849 = new Vector4f();
   public static final Map<class_1299<?>, C0967<?>> f0850 = new HashMap<>();
   public static final C1265 f0851 = new C1265();
   public static final C0066 f0852 = C0066.m0745();
   public static final C0066 f0853 = C0066.m0745();
   public static Color f0854 = Color.white;
   public static Color f0855 = Color.white;
   public static boolean f0856;
   public static double f0857;

   public C0297() {
      throw new AssertionError();
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = -9999
   )
   public static void m2452(C1358 var0) {
      C0094.f4640.m1900();
      RenderSystem.setShader(class_757::method_34540);
      f0852.m0752();
      RenderSystem.setShader(class_757::method_34535);
      RenderSystem.lineWidth((float)f0857);
      f0853.m0752();
      RenderSystem.lineWidth(1.0F);
      C0094.f4640.m1902();
   }

   public static void m2453(Color var0, Color var1) {
      f0854 = var0;
      f0855 = var1;
   }

   public static void m2454(boolean var0) {
      f0856 = var0;
   }

   public static boolean m2455() {
      return f0856;
   }

   public static void m2456(class_4587 var0, class_1297 var1) {
      var0.method_22903();
      class_243 var2 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773
         .method_19418()
         .method_19326();
      float var3 = C0094.m1872();
      if (var1 instanceof C0164) {
         var3 = 1.0F;
      }

      double var4 = class_3532.method_16436((double)var3, var1.field_6038, var1.method_23317()) - var2.field_1352;
      double var6 = class_3532.method_16436((double)var3, var1.field_5971, var1.method_23318()) - var2.field_1351;
      double var8 = class_3532.method_16436((double)var3, var1.field_5989, var1.method_23321()) - var2.field_1350;
      class_243 var10 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
         .method_3953(var1)
         .method_23169(var1, var3);
      double var11 = var4 + var10.method_10216();
      double var13 = var6 + var10.method_10214();
      double var15 = var8 + var10.method_10215();
      var0.method_22903();
      var0.method_22904(var11, var13, var15);
      C0967 var17 = m2457(var1);
      if (var17 != null) {
         var17.m0802(var1, C0094.m1872(), var0);
      }

      var0.method_22909();
   }

   public static <E extends class_1297> C0967<E> m2457(E var0) {
      return (C0967<E>)f0850.getOrDefault(var0.method_5864(), var0 instanceof class_1309 ? f0851 : null);
   }

   public static void m2458(C0550 var0, class_630 var1) {
      if (var1.field_3665) {
         var0.m0732().method_22903();
         var1.method_22703(var0.m0732());

         for (class_628 var3 : var1.field_3663) {
            m2459(var0, var3);
         }

         for (class_630 var5 : var1.field_3661.values()) {
            m2458(var0, var5);
         }

         var0.m0732().method_22909();
      }
   }

   public static void m2459(C0550 var0, class_628 var1) {
      for (class_593 var5 : var1.field_3649) {
         f0846.set(var5.field_3502[0].field_3605.x / 16.0F, var5.field_3502[0].field_3605.y / 16.0F, var5.field_3502[0].field_3605.z / 16.0F, 1.0F);
         f0847.set(var5.field_3502[1].field_3605.x / 16.0F, var5.field_3502[1].field_3605.y / 16.0F, var5.field_3502[1].field_3605.z / 16.0F, 1.0F);
         f0848.set(var5.field_3502[2].field_3605.x / 16.0F, var5.field_3502[2].field_3605.y / 16.0F, var5.field_3502[2].field_3605.z / 16.0F, 1.0F);
         f0849.set(var5.field_3502[3].field_3605.x / 16.0F, var5.field_3502[3].field_3605.y / 16.0F, var5.field_3502[3].field_3605.z / 16.0F, 1.0F);
         if (f0855.getAlpha() != 0) {
            if (!f0852.m0748()) {
               f0852.m0749(class_5596.field_27382, class_290.field_1576);
            }

            f0852.method_22918(var0.m0732().method_23760().method_23761(), f0846.x, f0846.y, f0846.z).method_39415(f0855.hashCode());
            f0852.method_22918(var0.m0732().method_23760().method_23761(), f0847.x, f0847.y, f0847.z).method_39415(f0855.hashCode());
            f0852.method_22918(var0.m0732().method_23760().method_23761(), f0848.x, f0848.y, f0848.z).method_39415(f0855.hashCode());
            f0852.method_22918(var0.m0732().method_23760().method_23761(), f0849.x, f0849.y, f0849.z).method_39415(f0855.hashCode());
         }

         if (f0854.getAlpha() != 0) {
            if (!f0853.m0748()) {
               f0853.m0749(class_5596.field_27377, class_290.field_29337);
            }

            m2460(var0, f0846.x, f0846.y, f0846.z, f0847.x, f0847.y, f0847.z);
            m2460(var0, f0847.x, f0847.y, f0847.z, f0848.x, f0848.y, f0848.z);
            m2460(var0, f0848.x, f0848.y, f0848.z, f0849.x, f0849.y, f0849.z);
            m2460(var0, f0846.x, f0846.y, f0846.z, f0846.x, f0846.y, f0846.z);
         }
      }
   }

   public static void m2460(C0550 var0, float var1, float var2, float var3, float var4, float var5, float var6) {
      f0853.method_22918(var0.m0732().method_23760().method_23761(), var1, var2, var3)
         .method_39415(f0854.hashCode())
         .method_60831(var0.m0732().method_23760(), var4 - var1, var5 - var2, var6 - var3);
      f0853.method_22918(var0.m0732().method_23760().method_23761(), var4, var5, var6)
         .method_39415(f0854.hashCode())
         .method_60831(var0.m0732().method_23760(), var4 - var1, var5 - var2, var6 - var3);
   }

   public static void m2461(double var0) {
      f0857 = var0;
   }

   static {
      m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8.m0193(C0297.class);
      f0850.put(class_1299.field_6110, new C0459());
      f0850.put(class_1299.field_6121, new C0522());
      f0850.put(class_1299.field_38096, new C0522());
      f0850.put(class_1299.field_6074, new C0733());
      f0850.put(class_1299.field_6140, new C0713());
      f0850.put(class_1299.field_6116, new C0896());
   }
}
