package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2596;
import net.minecraft.class_2708;
import net.minecraft.class_2761;
import net.minecraft.class_2772;
import net.minecraft.class_2793;
import net.minecraft.class_2848;
import net.minecraft.class_640;
import net.minecraft.class_642;
import net.minecraft.class_8042;
import net.minecraft.class_2848.class_2849;

public final class C0470 implements C0045 {
   public static final C1112 f1393 = C0933.f1409.m2696(C1112.class);
   public static final Pattern f1394 = w.a<"B">("\\d+ ping", 335866471913774299L);
   public final ArrayDeque<Float> f1395;
   public final C0083 f1396;
   public final C0083 f1397;
   public float f1398;
   public float f1399;
   public long f1400;
   public long f1401;
   public int f1402;
   public boolean f1403;
   public boolean f1404;
   public class_642 f1405;
   public int f1406;
   public boolean f1407;
   public static int f1408 = w.a<"B">(61090746042392229L, 257832362129977838L);

   public C0470() {
      this.f1395 = new ArrayDeque<>((f1408 | 776096) + ~(f1408 & 776096) + 1 ^ -160285520);
      this.f1396 = new C0083();
      this.f1397 = new C0083();
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   @C1027
   public void m0590(C0133 var1) {
      this.f1400 = w.a<"B">(223409559795593705L);
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2708 var2) {
         this.f1402 = w.a<"Û">(var2, 337120726973903305L);
         if (w.a<"Û">(this.f1397, ((long)f1408 | 540358L) + ~((long)f1408 & 540358L) + 1L ^ -160311824L, 309642602085515378L)) {
            w.a<"Û">(this.f1396, 387780412884547639L);
         }

         this.f1403 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 210159634295343391L
         );
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2761) {
         if (this.f1401 != 0L) {
            if (w.a<"Û">(this.f1395, 283706259111234002L) > ((f1408 | 113622) + ~(f1408 & 113622) + 1 ^ -159887162)) {
               w.a<"Û">(this.f1395, 328553958815810004L);
            }

            this.f1398 = w.a<"B">(
               0.0F,
               w.a<"B">(
                  w.a<"B">((f1408 | 317006) + ~(f1408 & 317006) + 1 ^ -1210237622, 349057757755238323L),
                  w.a<"B">((f1408 | 798992) + ~(f1408 & 798992) + 1 ^ -1210721772, 349057757755238323L)
                     * (
                        w.a<"B">((f1408 | 990555) + ~(f1408 & 990555) + 1 ^ -1307773345, 349057757755238323L)
                           / (float)(w.a<"B">(223409559795593705L) - this.f1401)
                     ),
                  304661293439332345L
               ),
               121763288940510105L
            );
            w.a<"Û">(this.f1395, w.a<"B">(this.f1398, 243402859552372891L), 200287291475119704L);
            float var9 = 0.0F;
            Iterator var12 = w.a<"Û">(this.f1395, 302088629320389456L);

            while (w.a<"Û">(var12, 333900474771661065L)) {
               Float var4 = (Float)w.a<"Û">(var12, 192468336863492695L);
               var9 += w.a<"B">(
                  0.0F,
                  w.a<"B">(
                     w.a<"B">((f1408 | 952183) + ~(f1408 & 952183) + 1 ^ -1210618765, 349057757755238323L),
                     w.a<"Û">(var4, 149784643039979208L),
                     304661293439332345L
                  ),
                  121763288940510105L
               );
            }

            if (w.a<"Û">(this.f1395, 283706259111234002L) > 0) {
               var9 /= (float)w.a<"Û">(this.f1395, 283706259111234002L);
            }

            this.f1399 = var9;
         }

         this.f1401 = w.a<"B">(223409559795593705L);
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_8042 var10) {
         Iterator var14 = w.a<"Û">(w.a<"Û">(var10, 340282755371989099L), 191661729848227466L);

         while (w.a<"Û">(var14, 333900474771661065L)) {
            class_2596 var17 = (class_2596)w.a<"Û">(var14, 192468336863492695L);
            w.a<"Û">(
               m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, new C0133(var17), 248673416841067458L
            );
         }
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2772 var11) {
         class_642 var16 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944, 131347417028836246L
         );
         if (var16 == null) {
            return;
         }

         String var18 = w.a<"Û">(w.a<"Û">(var11, 114122975502191188L), 286788181028845103L);
         Matcher var5 = w.a<"Û">(f1394, var18, 261534928474231885L);
         if (w.a<"Û">(var5, 125152528927061705L)) {
            String var6 = w.a<"Û">(var5, 285099699337974642L);

            try {
               var6 = w.a<"Û">(
                  var6,
                  (f1408 | 949547) + ~(f1408 & 949547) + 1 ^ -159934929,
                  w.a<"Û">(var6, 120891947504160641L) - ((f1408 | 507405) + ~(f1408 & 507405) + 1 ^ -159492852),
                  145614115509746641L
               );
               this.f1406 = w.a<"B">(var6, 217089499813018459L);
            } catch (Throwable var8) {
            }
         }
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = 200
   )
   public void m0591(C0132 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2848 var2) {
         if (w.a<"Û">(var2, 147437756794204774L) == class_2849.field_12981) {
            if (this.f1403) {
               w.a<"Û">(var1, 385440235371820560L);
            }

            this.f1403 = (boolean)((f1408 | 893317) + ~(f1408 & 893317) + 1 ^ -160150912);
         }

         if (w.a<"Û">(var2, 147437756794204774L) == class_2849.field_12985) {
            if (!this.f1403) {
               w.a<"Û">(var1, 385440235371820560L);
            }

            this.f1403 = (boolean)((f1408 | 637251) + ~(f1408 & 637251) + 1 ^ -160411065);
         }

         if (w.a<"Û">(var2, 147437756794204774L) == class_2849.field_12979) {
            this.f1404 = (boolean)((f1408 | 367111) + ~(f1408 & 367111) + 1 ^ -159616766);
         }

         if (w.a<"Û">(var2, 147437756794204774L) == class_2849.field_12984) {
            this.f1404 = (boolean)((f1408 | 598336) + ~(f1408 & 598336) + 1 ^ -160380348);
         }
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2793) {
         w.a<"Û">(this.f1397, 387780412884547639L);
      }
   }

   @C1027
   public void m0592(C1243 var1) {
      this.f1407 = (boolean)((f1408 | 534187) + ~(f1408 & 534187) + 1 ^ -160313937);
      this.f1406 = (f1408 | 78084) + ~(f1408 & 78084) + 1 ^ -159852032;
   }

   public int m0593() {
      if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724 == null) {
         return (f1408 | 990804) + ~(f1408 & 990804) + 1 ^ -159976112;
      } else if (w.a<"Û">(f1393, 314537768572362865L)) {
         return w.a<"Û">(f1393, 260195533608793873L);
      } else {
         class_640 var1 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 383398777546283023L),
               154730467096297857L
            ),
            206948680432662858L
         );
         int var2 = var1 == null ? (f1408 | 154222) + ~(f1408 & 154222) + 1 ^ -159665814 : w.a<"Û">(var1, 227266915151442255L);
         return var2 == 0 ? this.f1406 : var2;
      }
   }

   public C0083 m0594() {
      return this.f1396;
   }

   public C0083 m0595() {
      return this.f1397;
   }

   public int m0596() {
      return this.f1402;
   }

   public long m0597() {
      return this.f1400;
   }

   public float m0598() {
      return this.f1398;
   }

   public float m0599() {
      return this.f1399;
   }

   public float m0600() {
      return this.f1399 / w.a<"B">((f1408 | 490083) + ~(f1408 & 490083) + 1 ^ -1210150553, 349057757755238323L);
   }

   public class_642 m0601() {
      return this.f1405;
   }

   public void m0602(class_642 var1) {
      this.f1405 = var1;
   }

   public boolean m0603() {
      return this.f1403;
   }

   public boolean m0604() {
      return this.f1404;
   }

   public static String _ABFbIDmNidIcWtzpfKStGC34VklyWxpNayE6l3ygTNLC7vu5HkPdqvmlZj8vvbXN3WpLrdfxihftny88cEKF9yMNs1mpKdmSMak/* $VF was: 1ABFbIDmNidIcWtzpfKStGC34VklyWxpNayE6l3ygTNLC7vu5HkPdqvmlZj8vvbXN3WpLrdfxihftny88cEKF9yMNs1mpKdmSMak*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
