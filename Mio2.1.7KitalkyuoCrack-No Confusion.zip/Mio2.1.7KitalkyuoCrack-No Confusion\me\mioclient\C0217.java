package me.mioclient;

import java.awt.Color;
import net.minecraft.class_238;
import net.minecraft.class_4587;

record C0217() {
   public final int f2794;
   public final int f2795;
   public final int f2796;
   public static int f2797 = w.a<"B">(1959106812493441370L, 257832362129977838L);

   public C0217(int var1, int var2, int var3) {
      this.f2794 = var1;
      this.f2795 = var2;
      this.f2796 = var3;
   }

   public void m3187(class_4587 var1, Color var2, int var3, float var4) {
      double var5 = (double)var3;
      if (var3 == ((f2797 | 855203) + ~(f2797 & 855203) + 1 ^ 819675436)) {
         var5 = w.a<"Û">(C0045.f2103.field_1724, C0094.m1872(), 121483117111144555L).field_1351;
      }

      class_238 var7 = w.a<"Û">(this, var5, 340370189065030623L);
      C0485.m3219(var1, var7, var2, var4);
   }

   public class_238 m3188(double var1) {
      int var3 = this.f2796 / ((f2797 | 49405) + ~(f2797 & 49405) + 1 ^ -819367281);
      return new class_238((double)(this.f2794 - var3), var1, (double)(this.f2795 - var3), (double)(this.f2794 + var3), var1, (double)(this.f2795 + var3));
   }

   public int m3189() {
      return this.f2794;
   }

   public int m3190() {
      return this.f2795;
   }

   public int m3191() {
      return this.f2796;
   }
}
