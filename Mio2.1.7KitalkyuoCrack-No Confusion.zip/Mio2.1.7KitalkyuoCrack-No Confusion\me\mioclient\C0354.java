package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2382;

public enum C0354 implements C0196 {
   f1072(
      "Full",
      new class_2382(1, 0, 0),
      new class_2382(0, 0, 1),
      new class_2382(-1, 0, 0),
      new class_2382(0, 0, -1),
      new class_2382(1, 1, 0),
      new class_2382(0, 1, 1),
      new class_2382(-1, 1, 0),
      new class_2382(0, 1, -1),
      new class_2382(0, 2, 0),
      new class_2382(0, 3, 0)
   ),
   f1073("Surround", new class_2382(1, 0, 0), new class_2382(0, 0, 1), new class_2382(-1, 0, 0), new class_2382(0, 0, -1)),
   f1074("Cev", new class_2382(0, 2, 0), new class_2382(0, 3, 0));

   public final String f1075;
   public final class_2382[] f1076;

   public C0354(String var3, class_2382... var4) {
      this.f1075 = var3;
      this.f1076 = var4;
   }

   @Override
   public String getName() {
      return this.f1075;
   }

   public class_2382[] m2513() {
      return this.f1076;
   }

   public static String E7v1tHCBaNRyT6ecLF9uci8zXhE6XQFuXahqOLdIg4zKtAd1IJilfZEdhLa5KKjZeWLztPAoPOHIJ7euVBB6kU8n16O0xwxJg2ha(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
