package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0425 implements C0196 {
   f0972("Alphabet"),
   f0973("Socials"),
   f0974("Latency"),
   f0975("Length");

   public final String f0976;

   public C0425(String var3) {
      this.f0976 = var3;
   }

   @Override
   public String getName() {
      return this.f0976;
   }

   public static String oAPuFhP4VFYkBzD3mlEpKZv6HWDiS1R13qBdfcKuRA2C79Ef4BnRh2SEmHOAyb82Ko475dO0ykuQwLuz9B54Jsv7Vxh4JCkBCbtE(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
