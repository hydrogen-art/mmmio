package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0472 {
   f2788(0, -1),
   f2789(1, 0),
   f2790(0, 1),
   f2791(-1, 0);

   public final C0490 f2792;

   public C0472(int var3, int var4) {
      this.f2792 = new C0490(var3, var4);
   }

   public C0490 m1110() {
      return this.f2792;
   }

   public C0472 m1111() {
      return switch (this) {
         case f2788 -> f2790;
         case f2789 -> f2791;
         case f2790 -> f2788;
         case f2791 -> f2789;
      };
   }

   public static String WNDs1c2QeL8bDGfucmfpJbGtpXqbkXdzpm4FByhVwoKfZ5MF9HxNpw0uWPlo5YR9LtBHCdRw5IZRHk16L5x4cofBPdfquxDhgbGE(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
