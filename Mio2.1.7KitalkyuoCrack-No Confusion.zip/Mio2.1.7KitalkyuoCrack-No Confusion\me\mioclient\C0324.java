package me.mioclient;

import java.util.function.Predicate;

public class C0324 implements Predicate {
   public C0671 f3069;

   public C0324(C0671 var1) {
      this.f3069 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3069.f4651, 174312564406604366L) == C0672.f4559 && w.a<"Û">(this.f3069.f4662, 254992554122318132L);
   }
}
