package me.mioclient;

import net.minecraft.class_276;

public final class C0479 implements C0045 {
   public static class_276 f1775;
   public static int f1776 = 620955316;

   public C0479() {
      throw new AssertionError();
   }

   public static void m2762(C0319 var0, boolean var1, Runnable var2) {
      m2763(var0, var1);
      var2.run();
      m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22940().method_23000().method_22993();
      m2764(var1);
   }

   public static void m2763(C0319 var0, boolean var1) {
      if (var1) {
         C0789.m2604();
      }

      f1775 = ((C0157)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1769).getFramebuffer();
      ((C0157)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1769).setFramebuffer(var0.f2150);
      m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1522().method_1240();
      C0789.f1299 = (boolean)((f1776 | 754303) + ~(f1776 & 754303) + 1 ^ 621315274);
   }

   public static void m2764(boolean var0) {
      C0789.f1299 = (boolean)((f1776 | 223947) + ~(f1776 & 223947) + 1 ^ 620784767);
      ((C0157)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1769).setFramebuffer(f1775);
      m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1522()
         .method_1235((boolean)((f1776 | 9637) + ~(f1776 & 9637) + 1 ^ 620962577));
      if (var0) {
         C0789.m2605();
      }
   }

   static {
      long var10000 = 4112971587042991299L;
   }
}
