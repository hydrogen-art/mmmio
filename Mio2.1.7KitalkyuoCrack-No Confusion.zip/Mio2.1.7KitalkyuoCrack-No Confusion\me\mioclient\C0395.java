package me.mioclient;

import java.util.function.Predicate;

public class C0395 implements Predicate {
   public C0039 f3820;

   public C0395(C0039 var1) {
      this.f3820 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3820.f5265, 254992554122318132L) && w.a<"Û">(this.f3820.f5266, 254992554122318132L);
   }
}
