package me.mioclient;

import java.util.function.Predicate;

public class C0253 implements Predicate {
   public C0023 f1159;

   public C0253(C0023 var1) {
      this.f1159 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1159.f2135, 254992554122318132L);
   }
}
