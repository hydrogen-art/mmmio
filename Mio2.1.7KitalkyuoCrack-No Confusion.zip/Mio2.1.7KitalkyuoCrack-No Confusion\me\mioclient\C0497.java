package me.mioclient;

import java.util.function.Predicate;

public class C0497 implements Predicate {
   public C0023 f3844;

   public C0497(C0023 var1) {
      this.f3844 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3844.f2135, 254992554122318132L);
   }
}
