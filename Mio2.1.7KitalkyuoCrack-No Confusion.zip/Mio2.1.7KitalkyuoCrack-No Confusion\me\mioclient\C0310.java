package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0310 implements C0196 {
   f1935("None"),
   f1936("Require"),
   f1937("Swap");

   public final String f1938;

   public C0310(String var3) {
      this.f1938 = var3;
   }

   @Override
   public String getName() {
      return this.f1938;
   }

   public static String VYw2Wb56G9a9XpBkca1wRjS5hgrxFqZj8vVFk3tvpeG9oqqTxLUpuJk18HnSIBXymx4ztS04rFQap5AAasykKZ4nmi0xg7gkZePq(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
