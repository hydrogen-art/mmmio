package me.mioclient;

import java.util.function.Predicate;

public class C0321 implements Predicate {
   public C0671 f2705;

   public C0321(C0671 var1) {
      this.f2705 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2705.f4651, 174312564406604366L) == C0672.f4559 || w.a<"Û">(this.f2705.f4651, 174312564406604366L) == C0672.f4562;
   }
}
