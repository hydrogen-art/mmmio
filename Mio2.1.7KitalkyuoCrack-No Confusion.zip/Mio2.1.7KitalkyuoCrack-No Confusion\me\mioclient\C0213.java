package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_332;

public class C0213 extends C0601 {
   public final C0015<Color> f1559;
   public final C0015<Color> f1560;
   public final C0015<Boolean> f1561;
   public final C0072 f1562;
   public static int f1563 = w.a<"B">(376592286244205990L, 257832362129977838L);

   public C0213() {
      super("Inventory");
      this.f1559 = w.a<"Û">(
         this,
         new C1118(
            "Background",
            new Color(
               (f1563 | 277246) + ~(f1563 & 277246) + 1 ^ 1999402605,
               (f1563 | 999478) + ~(f1563 & 999478) + 1 ^ 1999047845,
               (f1563 | 106735) + ~(f1563 & 106735) + 1 ^ 1999236220,
               (f1563 | 941256) + ~(f1563 & 941256) + 1 ^ 1998983267
            )
         ),
         192839886211813275L
      );
      this.f1560 = w.a<"Û">(
         this,
         new C1118(
            "Outline",
            new Color(
               (f1563 | 734060) + ~(f1563 & 734060) + 1 ^ 1998815231,
               (f1563 | 987962) + ~(f1563 & 987962) + 1 ^ 1999069097,
               (f1563 | 673235) + ~(f1563 & 673235) + 1 ^ 1998719296,
               (f1563 | 192732) + ~(f1563 & 192732) + 1 ^ 1999289377
            )
         ),
         192839886211813275L
      );
      this.f1561 = w.a<"Û">(
         this, new C0240("HideEmpty", w.a<"B">((boolean)((f1563 | 546717) + ~(f1563 & 546717) + 1 ^ 1998592773), 320330632857389983L)), 192839886211813275L
      );
      this.f1562 = new C0072();
      C0024 var1 = new C0024(this);
      var1.m1074(this);
      this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(var1);
   }

   @Override
   public void m0562(class_332 var1) {
      w.a<"Û">(
         this.f1562,
         (boolean)(!w.a<"Û">(this, 302783632382898940L)
            ? (f1563 | 133940) + ~(f1563 & 133940) + 1 ^ 1999259564
            : (f1563 | 42450) + ~(f1563 & 42450) + 1 ^ 1999169867),
         ((long)f1563 | 976085L) + ~((long)f1563 & 976085L) + 1L ^ 1999022212L,
         269150256154870082L
      );
      float var2 = w.a<"Û">(this.f1562, 130550643917971814L);
      if (!w.a<"Û">((Boolean)w.a<"Û">(this.f1561, 174312564406604366L), 354697271520518137L)) {
         var2 = w.a<"B">((f1563 | 256454) + ~(f1563 & 256454) + 1 ^ 1219208543, 349057757755238323L);
      }

      Color var3 = C0152.m3474(
         (Color)w.a<"Û">(this.f1559, 174312564406604366L),
         (float)w.a<"Û">((Color)w.a<"Û">(this.f1559, 174312564406604366L), 245270953955453918L)
            / w.a<"B">((f1563 | 860326) + ~(f1563 & 860326) + 1 ^ 878341183, 349057757755238323L)
            * var2
      );
      Color var4 = C0152.m3474(
         (Color)w.a<"Û">(this.f1560, 174312564406604366L),
         (float)w.a<"Û">((Color)w.a<"Û">(this.f1560, 174312564406604366L), 245270953955453918L)
            / w.a<"B">((f1563 | 791540) + ~(f1563 & 791540) + 1 ^ 878403437, 349057757755238323L)
            * var2
      );
      C0094.f4640
         .m1883(
            w.a<"Û">(var1, 138110712227765901L),
            0.0F,
            0.0F,
            w.a<"B">((f1563 | 757370) + ~(f1563 & 757370) + 1 ^ 872530659, 349057757755238323L),
            w.a<"B">((f1563 | 265538) + ~(f1563 & 265538) + 1 ^ 896811483, 349057757755238323L),
            var3
         );
      C0094.f4640
         .m1876(
            w.a<"Û">(var1, 138110712227765901L),
            w.a<"B">((f1563 | 744788) + ~(f1563 & 744788) + 1 ^ -928837171, 349057757755238323L),
            w.a<"B">((f1563 | 963850) + ~(f1563 & 963850) + 1 ^ -928581229, 349057757755238323L),
            w.a<"B">((f1563 | 990081) + ~(f1563 & 990081) + 1 ^ 872765208, 349057757755238323L),
            w.a<"B">((f1563 | 394184) + ~(f1563 & 394184) + 1 ^ 896946001, 349057757755238323L),
            var4
         );
      class_2371 var5 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
         )
         .field_7547;

      for (int var6 = (f1563 | 468857) + ~(f1563 & 468857) + 1 ^ 1999596512;
         var6 < w.a<"Û">(var5, 281692963295227694L) - ((f1563 | 176277) + ~(f1563 & 176277) + 1 ^ 1999305733);
         var6++
      ) {
         int var7 = var6 % ((f1563 | 365819) + ~(f1563 & 365819) + 1 ^ 1999493227) * ((f1563 | 588641) + ~(f1563 & 588641) + 1 ^ 1998632938);
         int var8 = var6 / ((f1563 | 509085) + ~(f1563 & 509085) + 1 ^ 1999603725) * ((f1563 | 207434) + ~(f1563 & 207434) + 1 ^ 1999333057);
         class_1799 var9 = (class_1799)w.a<"Û">(var5, var6 + ((f1563 | 527246) + ~(f1563 & 527246) + 1 ^ 1998604062), 315632267894795364L);
         w.a<"Û">(var1, var9, var7, var8, 235588228935023387L);
         w.a<"Û">(
            var1,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1772,
            var9,
            var7,
            var8,
            210949393962591390L
         );
      }
   }

   public boolean isEmpty() {
      class_2371 var1 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
         )
         .field_7547;

      for (int var2 = (f1563 | 685385) + ~(f1563 & 685385) + 1 ^ 1998731728;
         var2 < w.a<"Û">(var1, 281692963295227694L) - ((f1563 | 428651) + ~(f1563 & 428651) + 1 ^ 1999554299);
         var2++
      ) {
         class_1799 var3 = (class_1799)w.a<"Û">(var1, var2 + ((f1563 | 155110) + ~(f1563 & 155110) + 1 ^ 1999245686), 315632267894795364L);
         if (!w.a<"Û">(var3, 330190014994709712L)) {
            return (boolean)((f1563 | 432314) + ~(f1563 & 432314) + 1 ^ 1999557667);
         }
      }

      return (boolean)((f1563 | 419116) + ~(f1563 & 419116) + 1 ^ 1999514036);
   }

   @Override
   public float[] m0563() {
      float[] var10000 = new float[(f1563 | 244556) + ~(f1563 & 244556) + 1 ^ 1999370199];
      var10000[(f1563 | 509558) + ~(f1563 & 509558) + 1 ^ 1999604463] = w.a<"B">((f1563 | 727540) + ~(f1563 & 727540) + 1 ^ 872502637, 349057757755238323L);
      var10000[(f1563 | 920638) + ~(f1563 & 920638) + 1 ^ 1998995622] = w.a<"B">((f1563 | 356159) + ~(f1563 & 356159) + 1 ^ 896869286, 349057757755238323L);
      return var10000;
   }

   public static String wwHz2kcVoV2oGLO79Kjc7tCc75pLpQdJqzcFsmXrBviFI8JscFPz8alOM6bcNGPaKbqQyqGTLP0pL88JIEBWr6nrNpD9jriLTSma(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
