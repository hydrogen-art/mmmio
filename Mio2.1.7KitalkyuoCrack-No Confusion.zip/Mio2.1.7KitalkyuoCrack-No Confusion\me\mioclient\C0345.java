package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2708;

public class C0345 extends C1266 {
   public static C0712 f0368 = C0933.f1409.m2696(C0712.class);
   public final C0015<C0347> f0369;
   public final C0015<Float> f0370;
   public final C0015<Boolean> f0371;
   public final C0015<Boolean> f0372;
   public final C0015<Boolean> f0373;
   public final C0015<Boolean> f0374;
   public boolean f0375;
   public final C0083 f0376;
   public final C0198<C0347, C0105> f0377;
   public static int f0378 = w.a<"B">(1287580667987137744L, 257832362129977838L);

   public C0345() {
      super("Speed", "Makes you move faster.", C1045.f3175);
      w.a<"B">(this, 242859112966675773L);
      this.f0376 = new C0083();
      this.f0377 = new C0198<>(this.f0369);
      w.a<"Û">(this.f0377, C0347.f1909, new C0710(this), 330724867183972648L);
      w.a<"Û">(this.f0377, C0347.f1910, new C0146(this), 330724867183972648L);
      w.a<"Û">(this.f0377, C0347.f1911, new C0791(this), 330724867183972648L);
      w.a<"Û">(this.f0377, C0347.f1912, new C1018(this), 330724867183972648L);
      w.a<"Û">(this.f0377, C0347.f1913, new C0458(this), 330724867183972648L);
      w.a<"Û">(this.f0377, C0347.f1914, new C0105(this) {
         public static int f0233 = w.a<"B">(3604443034623446108L, 257832362129977838L);

         @Override
         public void m0455(C0650 var1) {
         }
      }, 330724867183972648L);
   }

   @Override
   public String getInfo() {
      return w.a<"Û">((C0347)w.a<"Û">(this.f0369, 174312564406604366L), 352801181599163784L);
   }

   @Override
   public void onEnable() {
      w.a<"Û">((C0105)w.a<"Û">(this.f0377, 347554191093565894L), 257306972567610349L);
   }

   @C1027
   public void m0222(C0158 var1) {
      if (w.a<"Û">(this.f0369, 174312564406604366L) == C0347.f1910 && !w.a<"Û">(this, 197027146981224508L)) {
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            (boolean)((f0378 | 97081) + ~(f0378 & 97081) + 1 ^ -1184271022),
            343736006055686636L
         );
      }
   }

   @C1027
   public void m0223(C0874 var1) {
      if (!w.a<"Û">(var1, 140104875474003023L)) {
         w.a<"Û">((C0105)w.a<"Û">(this.f0377, 347554191093565894L), 154745091533351347L);
      }
   }

   @C1027
   public void m0224(C0650 var1) {
      if (w.a<"Û">(w.a<"Û">(C0933.f1416, 284526657513910806L), ((long)f0378 | 821437L) + ~((long)f0378 & 821437L) + 1L ^ -1184594211L, 309642602085515378L)
         && !this.f0375) {
         w.a<"Û">((C0105)w.a<"Û">(this.f0377, 347554191093565894L), var1, 198326154536398227L);
      }
   }

   @C1027
   public void m0225(C0511 var1) {
      if (w.a<"Û">(var1, 363992885454137469L) == C0277.f4215
         && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)
         && (double)w.a<"Û">(var1, 115683400247265285L)
            > w.a<"B">(((long)f0378 | 937039L) + ~((long)f0378 & 937039L) + 1L ^ -4603579540213239530L, 317139102743630955L)) {
         this.f0375 = (boolean)((f0378 | 918591) + ~(f0378 & 918591) + 1 ^ -1184495020);
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = 100
   )
   public void m0226(C1095 var1) {
      this.f0375 = (boolean)((f0378 | 547248) + ~(f0378 & 547248) + 1 ^ -1184868390);
      if (w.a<"Û">(w.a<"Û">(C0933.f1416, 284526657513910806L), ((long)f0378 | 489270L) + ~((long)f0378 & 489270L) + 1L ^ -1183876778L, 309642602085515378L)) {
         w.a<"Û">((C0105)w.a<"Û">(this.f0377, 347554191093565894L), var1, 377293334000865523L);
      }
   }

   @C1027
   public void m0227(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2708) {
         w.a<"Û">(this, 372671496522508785L);
      }
   }

   @C1027
   public void m0228(C1006 var1) {
      class_243 var2 = new class_243(w.a<"Û">(var1, 230214535956157344L), w.a<"Û">(var1, 295145405871652441L), w.a<"Û">(var1, 356396314528004979L));
      double var3 = (double)w.a<"B">(
         var2,
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L),
         w.a<"B">(((long)f0378 | 686179L) + ~((long)f0378 & 686179L) + 1L ^ -4618441419053173239L, 317139102743630955L),
         (boolean)((f0378 | 227609) + ~(f0378 & 227609) + 1 ^ -1184139406),
         null,
         null,
         288791306669618563L
      );
      if (w.a<"B">(239474890139367192L)
         && w.a<"Û">(w.a<"Û">(C0933.f1416, 131737481540982891L), ((long)f0378 | 592198L) + ~((long)f0378 & 592198L) + 1L ^ -1184823592L, 309642602085515378L)
         && w.a<"Û">((Boolean)w.a<"Û">(this.f0371, 174312564406604366L), 354697271520518137L)
         && !(
            w.a<"B">(
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, var2, 252871452602035869L
                  ),
                  372068007575431175L
               )
               > w.a<"B">(((long)f0378 | 57914L) + ~((long)f0378 & 57914L) + 1L ^ -4618441419052749744L, 317139102743630955L)
         )
         && !(var3 < w.a<"B">(((long)f0378 | 803697L) + ~((long)f0378 & 803697L) + 1L ^ -4616189619239367397L, 317139102743630955L))) {
         w.a<"Û">(this.f0376, 387780412884547639L);
      }
   }

   public void reset() {
      ((C0105)w.a<"Û">(this.f0377, 347554191093565894L)).f3484 = 0.0;
      ((C0105)w.a<"Û">(this.f0377, 347554191093565894L)).f3483 = 0.0;
      ((C0105)w.a<"Û">(this.f0377, 347554191093565894L)).f3485 = (f0378 | 109013) + ~(f0378 & 109013) + 1 ^ -1184258117;
      if (w.a<"Û">(this.f0369, 174312564406604366L) == C0347.f1912) {
         ((C0105)w.a<"Û">(this.f0377, 347554191093565894L)).f3485 = (f0378 | 543673) + ~(f0378 & 543673) + 1 ^ -1184873007;
      }
   }

   public boolean m0229() {
      return (boolean)(w.a<"B">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229073305445517953L
            )
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f0372, 174312564406604366L), 354697271520518137L)
         ? (f0378 | 95510) + ~(f0378 & 95510) + 1 ^ -1184269443
         : (f0378 | 919027) + ~(f0378 & 919027) + 1 ^ -1184494695);
   }

   public boolean m0230() {
      class_238 var1 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L
      );
      class_238 var2 = w.a<"Û">(
         new class_238(
            (double)w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
               188922896808372924L
            ),
            var1.field_1322,
            (double)w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
               278942455661123424L
            ),
            (double)w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
                  188922896808372924L
               )
               + w.a<"B">(((long)f0378 | 922612L) + ~((long)f0378 & 922612L) + 1L ^ -4607182419984507490L, 317139102743630955L),
            var1.field_1325,
            (double)w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
                  278942455661123424L
               )
               + w.a<"B">(((long)f0378 | 994241L) + ~((long)f0378 & 994241L) + 1L ^ -4607182419984439893L, 317139102743630955L)
         ),
         w.a<"B">(((long)f0378 | 544874L) + ~((long)f0378 & 544874L) + 1L ^ -4502148215585574584L, 317139102743630955L),
         159810520123761168L
      );
      return (boolean)(w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               var2,
               180086335891483828L
            )
            && w.a<"Û">((Boolean)w.a<"Û">(this.f0374, 174312564406604366L), 354697271520518137L)
         ? (f0378 | 716534) + ~(f0378 & 716534) + 1 ^ -1184702307
         : (f0378 | 761388) + ~(f0378 & 761388) + 1 ^ -1184657338);
   }

   public boolean m0231() {
      return (boolean)(f0368 == null ? (f0378 | 778728) + ~(f0378 & 778728) + 1 ^ -1184632958 : w.a<"Û">(f0368, 116425607651236974L));
   }

   public boolean m0232() {
      if (w.a<"Û">(this, 205492958615326489L)) {
         return (boolean)((f0378 | 288682) + ~(f0378 & 288682) + 1 ^ -1184077375);
      } else {
         return (boolean)(!w.a<"Û">(this, 119633580786107485L)
               && !w.a<"Û">(this, 291728366122999264L)
               && !w.a<"B">(132944285386342797L)
               && !w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L
               )
               && !w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 216539022803564207L
               )
            ? (f0378 | 352041) + ~(f0378 & 352041) + 1 ^ -1184018109
            : (f0378 | 274526) + ~(f0378 & 274526) + 1 ^ -1184088523);
      }
   }

   public static String jizClbVLiR9iiQ7bRqeOpJNaysYUsy9CLU8MOYR46NVqs7MRvQpLadbMywrgVltdyNwO6fHsbNE1MbbcQAa1eux9r5KYN1jh7NTi(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
