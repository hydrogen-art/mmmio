package me.mioclient;

public class C0358 {
   public static final int f4536 = 200;
   public static final int f4537 = 100;
   public static final int f4538 = 0;
   public static final int f4539 = -100;
   public static final int f4540 = -200;
}
