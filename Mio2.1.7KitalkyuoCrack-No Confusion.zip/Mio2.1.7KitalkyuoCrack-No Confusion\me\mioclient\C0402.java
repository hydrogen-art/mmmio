package me.mioclient;

import net.minecraft.class_1887;
import net.minecraft.class_5321;

record C0402() {
   public final class_5321<class_1887> f3992;
   public final int f3993;
   public static int f3994 = w.a<"B">(4958131045351391233L, 257832362129977838L);

   public C0402(class_5321<class_1887> var1, int var2) {
      this.f3992 = var1;
      this.f3993 = var2;
   }

   public class_5321<class_1887> m3644() {
      return this.f3992;
   }

   public int m3645() {
      return this.f3993;
   }
}
