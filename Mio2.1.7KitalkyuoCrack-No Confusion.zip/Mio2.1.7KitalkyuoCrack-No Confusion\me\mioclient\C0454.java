package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_124;

public class C0454 extends C0601 {
   public final C0015<Boolean> f2616;
   public final C0015<String> f2617;
   public static int f2618 = w.a<"B">(2371948162933885963L, 257832362129977838L);

   public C0454() {
      super("Watermark");
      this.f2616 = w.a<"Û">(
         this, new C0240("VersionColor", w.a<"B">((boolean)((f2618 | 286684) + ~(f2618 & 286684) + 1 ^ 1561841532), 320330632857389983L)), 192839886211813275L
      );
      this.f2617 = w.a<"Û">(this, new C0975("Text", "Mio"), 192839886211813275L);
      C1050 var1 = new C1050(
         () -> {
            String var1x = w.a<"Û">(this, 215053741099612567L);
            return w.a<"B">(
               new C1002()
                  .m2591(var1x)
                  .m2591(
                     w.a<"B">(
                        w.a<"Û">((Boolean)w.a<"Û">(this.f2616, 174312564406604366L), 354697271520518137L) ? class_124.field_1068 : "", 174997918119584642L
                     )
                  )
                  .m2591(w.a<"Û">((String)w.a<"Û">(this.f2617, 174312564406604366L), 252583459449976237L))
                  .m2593("\u0001\u0001\u0001"),
               228465064790135899L
            );
         },
         () -> w.a<"B">((boolean)((f2618 | 691998) + ~(f2618 & 691998) + 1 ^ 1561927614), 320330632857389983L)
      );
      this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(new C0442(this, var1));
      this.m$$dCWfdQIdncjw3C36JBKuGBPhCxwNCBNq9BLXnKT9M0G3iCBjQNXLd0cZJN4EvUz82FwhjiPY4ybE89OjXPtXYsApcHdJy3GI9().m2955(C0860.f2176);
      w.a<"Û">(this, (boolean)((f2618 | 411837) + ~(f2618 & 411837) + 1 ^ 1561712669), 116379243843723603L);
   }

   public String m1011() {
      return w.a<"Û">(C0933.f1423, 215809475655423530L) == ((f2618 | 316267) + ~(f2618 & 316267) + 1 ^ 1561805812) ? " v2.1.7+" : " v2.1.7";
   }

   public static String NsLuilsvWKxijohdG29aEreCLv6Iip2EolmZtpZw8XngGGh0dswUMG5V5LUdVdzz4gbyiDsV4QB2D1JoB0P0r4n57HaS5kcmaFlw(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
