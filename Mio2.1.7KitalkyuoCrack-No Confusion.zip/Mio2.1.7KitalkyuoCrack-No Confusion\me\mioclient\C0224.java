package me.mioclient;

import java.util.function.Predicate;

public class C0224 implements Predicate {
   public C1104 f1087;

   public C0224(C1104 var1) {
      this.f1087 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1087.f0468, 254992554122318132L) && w.a<"Û">(this.f1087.f0470, 254992554122318132L);
   }
}
