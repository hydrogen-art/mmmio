package me.mioclient;

import java.util.function.Predicate;

public class C0128 implements Predicate {
   public C0309 f0174;

   public C0128(C0309 var1) {
      this.f0174 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0174.f3395, 254992554122318132L);
   }
}
