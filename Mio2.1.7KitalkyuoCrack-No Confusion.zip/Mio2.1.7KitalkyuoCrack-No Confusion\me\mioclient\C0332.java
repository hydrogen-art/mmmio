package me.mioclient;

public final class C0332 extends C1180 {
   public final int f1232;

   public C0332(int var1) {
      this.f1232 = var1;
   }

   public String m2569() {
      return Character.toString(this.f1232);
   }

   public char m2570() {
      return this.m2569().charAt(0);
   }
}
