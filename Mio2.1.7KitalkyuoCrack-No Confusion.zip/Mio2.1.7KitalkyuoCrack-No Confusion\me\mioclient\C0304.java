package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.BiConsumer;
import java.util.function.Predicate;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_5498;
import net.minecraft.class_293.class_5596;

public class C0304 extends C1266 {
   public static final class_2960 f2573 = w.a<"B">("mio-mount", "textures/shine.png", 226297093937582094L);
   public static C1055 f2574 = C0933.f1409.m2696(C1055.class);
   public static C0677 norender = C0933.f1409.m2696(C0677.class);
   public static C0038 animations = C0933.f1409.m2696(C0038.class);
   public static final C0461 f2575 = C0933.f1409.m2696(C0461.class);
   public final C0015<Integer> f2576;
   public final C0015<Boolean> f2577;
   public final C0015<Integer> f2578;
   public final C0015<Float> f2579;
   public final C0015<Boolean> f2580;
   public final C0015<Boolean> f2581;
   public final C0015<Boolean> f2582;
   public final C0015<Integer> f2583;
   public final C0015<Boolean> f2584;
   public final C0015<Float> f2585;
   public final C0015<Float> f2586;
   public final C0015<Integer> f2587;
   public final C0015<Boolean> f2588;
   public final C0015<C1029> f2589;
   public final C0015<C1029> f2590;
   public final C0015<C1029> f2591;
   public final C0015<C1029> f2592;
   public final C0015<C1029> f2593;
   public final C0015<Boolean> f2594;
   public final C0015<Boolean> f2595;
   public final C0015<C0076> f2596;
   public final C0015<Boolean> f2597;
   public final C0015<Boolean> f2598;
   public final C0015<Float> f2599;
   public final C0015<Float> f2600;
   public final C0015<Boolean> f2601;
   public final C0015<Boolean> f2602;
   public final C0015<Color> f2603;
   public final C0015<Color> f2604;
   public final C0015<Color> f2605;
   public final C0015<Color> f2606;
   public final C0015<Color> f2607;
   public static boolean f2608 = (boolean)((C0304.f2613 | 735536) + ~(C0304.f2613 & 735536) + 1 ^ -1717994628);
   public static boolean f2609 = (boolean)((C0304.f2613 | 570653) + ~(C0304.f2613 & 570653) + 1 ^ -1717897391);
   public final C0066 f2610;
   public final Map<C0164, Long> f2611;
   public boolean f2612;
   public static int f2613 = w.a<"B">(6453895560300290682L, 257832362129977838L);

   public C0304() {
      super("Chams", "Wallhack on entities.", C1045.f3174);
      w.a<"B">(this, 242859112966675773L);
      this.f2610 = C0066.m0745();
      this.f2611 = new HashMap<>();
      w.a<"Û">(this.f2596, "PopMode", 275243698516531804L);
      w.a<"Û">(this.f2605, "ShineColor", 275243698516531804L);
      w.a<"Û">(this.f2585, "Static", C0508.f2371, 381268910042652120L);
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = 200
   )
   public void m0994(C1357 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2584, 174312564406604366L), 354697271520518137L)) {
         this.f2610.m0749(class_5596.field_27382, class_290.field_1585);
      }

      int var2 = w.a<"Û">(
                  (Integer)w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 266195410219308853L
                     ),
                     142580699129741492L
                  ),
                  260981171345819427L
               )
               > ((f2613 | 131165) + ~(f2613 & 131165) + 1 ^ -1718599070)
            && w.a<"Û">(this, 193843530903226791L)
         ? (f2613 | 601452) + ~(f2613 & 601452) + 1 ^ -1717866719
         : (f2613 | 67822) + ~(f2613 & 67822) + 1 ^ -1718400350;
      float var3 = var2 != 0
         ? w.a<"B">((f2613 | 726535) + ~(f2613 & 726535) + 1 ^ -645240968, 349057757755238323L)
         : w.a<"B">((f2613 | 718875) + ~(f2613 & 718875) + 1 ^ -1508328873, 349057757755238323L);
      w.a<"B">(289559736568000957L);
      w.a<"B">(334906003413585207L);
      w.a<"B">(
         w.a<"B">((f2613 | 709638) + ~(f2613 & 709638) + 1 ^ -1508338102, 349057757755238323L),
         w.a<"B">((f2613 | 340494) + ~(f2613 & 340494) + 1 ^ 1405284290, 349057757755238323L) * var3,
         324302720421378167L
      );
      Iterator var4 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
         191661729848227466L
      );

      while (w.a<"Û">(var4, 333900474771661065L)) {
         class_1297 var5 = (class_1297)w.a<"Û">(var4, 192468336863492695L);
         if (w.a<"Û">(this, var5, 198472233930925619L)) {
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f2581, 174312564406604366L), 354697271520518137L)
               && w.a<"Û">((Boolean)w.a<"Û">(this.f2582, 174312564406604366L), 354697271520518137L)
               && !w.a<"Û">(norender, var5, 195334440411848481L)
               && w.a<"Û">((Integer)w.a<"Û">(this.f2583, 174312564406604366L), 260981171345819427L) > 0) {
               this.f2612 = (boolean)((f2613 | 443808) + ~(f2613 & 443808) + 1 ^ -1718319123);
               w.a<"B">(
                  w.a<"B">((f2613 | 197259) + ~(f2613 & 197259) + 1 ^ -1508818745, 349057757755238323L),
                  w.a<"B">((f2613 | 683241) + ~(f2613 & 683241) + 1 ^ -1508364635, 349057757755238323L),
                  w.a<"B">((f2613 | 221375) + ~(f2613 & 221375) + 1 ^ -1508826381, 349057757755238323L),
                  (float)w.a<"Û">((Integer)w.a<"Û">(this.f2583, 174312564406604366L), 260981171345819427L)
                     / w.a<"B">((f2613 | 964589) + ~(f2613 & 964589) + 1 ^ -615189087, 349057757755238323L),
                  338561931007909111L
               );
               C0094.f4640
                  .m1911(
                     var5,
                     w.a<"Û">(var1, 332657398031159950L),
                     w.a<"Û">(var1, 173269294235887931L),
                     w.a<"Û">(
                        w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 307206842868879895L),
                        224491904139370894L
                     )
                  );
               this.f2612 = (boolean)((f2613 | 901374) + ~(f2613 & 901374) + 1 ^ -1717599566);
            }

            if (w.a<"Û">((Boolean)w.a<"Û">(this.f2584, 174312564406604366L), 354697271520518137L)) {
               f2608 = (boolean)((f2613 | 119628) + ~(f2613 & 119628) + 1 ^ -1718382335);
               w.a<"B">(
                  w.a<"B">((f2613 | 348798) + ~(f2613 & 348798) + 1 ^ -1508437966, 349057757755238323L),
                  w.a<"B">((f2613 | 695412) + ~(f2613 & 695412) + 1 ^ -1508319688, 349057757755238323L),
                  w.a<"B">((f2613 | 945162) + ~(f2613 & 945162) + 1 ^ -1508102586, 349057757755238323L),
                  w.a<"B">((f2613 | 747877) + ~(f2613 & 747877) + 1 ^ -1508299991, 349057757755238323L),
                  338561931007909111L
               );
               w.a<"Û">(w.a<"Û">(var1, 173269294235887931L), 156066167197700274L);
               C0094.m1915(w.a<"Û">(var1, 173269294235887931L));
               C0094.f4640
                  .m1911(
                     var5,
                     w.a<"Û">(var1, 332657398031159950L),
                     w.a<"Û">(var1, 173269294235887931L),
                     w.a<"Û">(
                        w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 307206842868879895L),
                        224491904139370894L
                     )
                  );
               w.a<"Û">(w.a<"Û">(var1, 173269294235887931L), 250771500943331132L);
               f2608 = (boolean)((f2613 | 742245) + ~(f2613 & 742245) + 1 ^ -1718021847);
            }
         }
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2581, 174312564406604366L), 354697271520518137L)
         && w.a<"Û">((Boolean)w.a<"Û">(this.f2582, 174312564406604366L), 354697271520518137L)) {
         w.a<"B">(
            w.a<"B">((f2613 | 434165) + ~(f2613 & 434165) + 1 ^ -1508581959, 349057757755238323L),
            w.a<"B">((f2613 | 956765) + ~(f2613 & 956765) + 1 ^ -1508058351, 349057757755238323L),
            w.a<"B">((f2613 | 319303) + ~(f2613 & 319303) + 1 ^ -1508467445, 349057757755238323L),
            (float)w.a<"Û">((Integer)w.a<"Û">(this.f2583, 174312564406604366L), 260981171345819427L)
               / w.a<"B">((f2613 | 262120) + ~(f2613 & 262120) + 1 ^ -614875740, 349057757755238323L),
            338561931007909111L
         );
         w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 307206842868879895L),
               224491904139370894L
            ),
            170217939166473161L
         );
         w.a<"B">(
            w.a<"B">((f2613 | 686066) + ~(f2613 & 686066) + 1 ^ -1508362818, 349057757755238323L),
            w.a<"B">((f2613 | 860254) + ~(f2613 & 860254) + 1 ^ -1507892718, 349057757755238323L),
            w.a<"B">((f2613 | 588944) + ~(f2613 & 588944) + 1 ^ -1508196644, 349057757755238323L),
            w.a<"B">((f2613 | 940030) + ~(f2613 & 940030) + 1 ^ -1508108878, 349057757755238323L),
            338561931007909111L
         );
      }

      w.a<"B">(245388548687201220L);
      w.a<"B">(
         w.a<"B">((f2613 | 675463) + ~(f2613 & 675463) + 1 ^ -1508373301, 349057757755238323L),
         w.a<"B">((f2613 | 481808) + ~(f2613 & 481808) + 1 ^ -742357028, 349057757755238323L) * var3,
         324302720421378167L
      );
      w.a<"B">(131668795728369880L);
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = -1000
   )
   public void m0995(C1358 var1) {
      C0297.m2461((double)w.a<"Û">((Float)w.a<"Û">(this.f2579, 174312564406604366L), 149784643039979208L));
      Iterator var2 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
         191661729848227466L
      );

      while (w.a<"Û">(var2, 333900474771661065L)) {
         class_1297 var3 = (class_1297)w.a<"Û">(var2, 192468336863492695L);
         if (w.a<"Û">(this, var3, 198472233930925619L)
            && w.a<"Û">((C0386)w.a<"Û">(w.a<"Û">(this, var3, 205986135341804820L), 174312564406604366L), 217404197188623911L)) {
            w.a<"Û">(
               (C0386)w.a<"Û">(w.a<"Û">(this, var3, 205986135341804820L), 174312564406604366L),
               this,
               var3,
               w.a<"Û">(var1, 173269294235887931L),
               197781378511456562L
            );
         }
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2594, 174312564406604366L), 354697271520518137L)) {
         synchronized (this.f2611) {
            w.a<"Û">(
               w.a<"Û">(this.f2611, 354320704134596920L),
               (Predicate<Entry>)var1x -> (boolean)((float)w.a<"Û">((Long)w.a<"Û">(var1x, 196870340575900401L), 151184307344636838L)
                           + w.a<"Û">((Float)w.a<"Û">(this.f2599, 174312564406604366L), 149784643039979208L)
                              * w.a<"B">((f2613 | 492647) + ~(f2613 & 492647) + 1 ^ -571488725, 349057757755238323L)
                        < (float)w.a<"B">(223409559795593705L)
                     ? (f2613 | 150466) + ~(f2613 & 150466) + 1 ^ -1718613617
                     : (f2613 | 441120) + ~(f2613 & 441120) + 1 ^ -1718290068),
               271448142827029127L
            );
            w.a<"Û">(
               this.f2611,
               (BiConsumer<C0164, Long>)(var2x, var3x) -> {
                  float var4x = w.a<"B">((f2613 | 285325) + ~(f2613 & 285325) + 1 ^ -1508501311, 349057757755238323L)
                     - w.a<"B">(
                        (float)(w.a<"B">(223409559795593705L) - w.a<"Û">(var3x, 151184307344636838L))
                           / (
                              w.a<"Û">((Float)w.a<"Û">(this.f2599, 174312564406604366L), 149784643039979208L)
                                 * w.a<"B">((f2613 | 944513) + ~(f2613 & 944513) + 1 ^ -572118067, 349057757755238323L)
                           ),
                        0.0F,
                        w.a<"B">((f2613 | 999982) + ~(f2613 & 999982) + 1 ^ -1508048798, 349057757755238323L),
                        131506059371757968L
                     );
                  w.a<"Û">(
                     var2x,
                     w.a<"Û">(var2x, 221307500733600686L),
                     w.a<"Û">(var2x, 269407682147271259L).field_1351
                        + (double)(
                           (w.a<"B">((f2613 | 380654) + ~(f2613 & 380654) + 1 ^ -1508406110, 349057757755238323L) - var4x)
                              * w.a<"Û">((Float)w.a<"Û">(this.f2600, 174312564406604366L), 149784643039979208L)
                        ),
                     w.a<"Û">(var2x, 179963978076169272L),
                     360036365017127015L
                  );
                  Color[] var5 = w.a<"Û">((C0076)w.a<"Û">(this.f2596, 174312564406604366L), this, 114633939362447540L);
                  C0297.m2453(
                     C0152.m3474(
                        var5[(f2613 | 111781) + ~(f2613 & 111781) + 1 ^ -1718356247],
                        (float)w.a<"Û">(var5[(f2613 | 559761) + ~(f2613 & 559761) + 1 ^ -1717909283], 245270953955453918L)
                           / w.a<"B">((f2613 | 38930) + ~(f2613 & 38930) + 1 ^ -621946274, 349057757755238323L)
                           * var4x
                     ),
                     C0152.m3474(
                        var5[(f2613 | 67537) + ~(f2613 & 67537) + 1 ^ -1718401636],
                        (float)w.a<"Û">(var5[(f2613 | 900717) + ~(f2613 & 900717) + 1 ^ -1717568480], 245270953955453918L)
                           / w.a<"B">((f2613 | 500663) + ~(f2613 & 500663) + 1 ^ -622140933, 349057757755238323L)
                           * var4x
                     )
                  );
                  C0297.m2456(w.a<"Û">(var1, 173269294235887931L), var2x);
               },
               316328768057134350L
            );
         }
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2582, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 307206842868879895L),
               224491904139370894L
            ),
            170217939166473161L
         );
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2584, 174312564406604366L), 354697271520518137L)) {
         double var9 = w.a<"Û">(
            (Double)w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 261991321583580780L),
               142580699129741492L
            ),
            287934447355057060L
         );
         double var4 = w.a<"Û">(
            (Double)w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 384701863441497590L),
               142580699129741492L
            ),
            287934447355057060L
         );
         w.a<"Û">(
            (C0229)w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 261991321583580780L
            ),
            w.a<"B">(w.a<"Û">((Float)w.a<"Û">(this.f2585, 174312564406604366L), 197282747409042340L), 165155940100814265L),
            355260527379810339L
         );
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 384701863441497590L),
            w.a<"B">(w.a<"Û">((Float)w.a<"Û">(this.f2586, 174312564406604366L), 197282747409042340L), 165155940100814265L),
            231232450300995026L
         );
         Color var6 = (Color)w.a<"Û">(this.f2605, 174312564406604366L);
         w.a<"B">(156169517863121162L);
         f2609 = (boolean)((f2613 | 726205) + ~(f2613 & 726205) + 1 ^ -1718003984);
         w.a<"Û">(w.a<"B">(262390444630492460L), 140312910998756546L);
         w.a<"Û">(
            w.a<"Û">(w.a<"Û">(w.a<"B">(249781506980689257L), 212007125412436034L), f2573, 117952533399137933L),
            (boolean)((f2613 | 680670) + ~(f2613 & 680670) + 1 ^ -1718083437),
            (boolean)((f2613 | 113543) + ~(f2613 & 113543) + 1 ^ -1718355509),
            310918076993443686L
         );
         w.a<"B">((f2613 | 49358) + ~(f2613 & 49358) + 1 ^ -1718451582, f2573, 271900140776288940L);
         w.a<"B">(
            (float)w.a<"Û">(var6, 239609820066095028L) / w.a<"B">((f2613 | 519358) + ~(f2613 & 519358) + 1 ^ -622153998, 349057757755238323L),
            (float)w.a<"Û">(var6, 340797987757289690L) / w.a<"B">((f2613 | 619515) + ~(f2613 & 619515) + 1 ^ -622579273, 349057757755238323L),
            (float)w.a<"Û">(var6, 212499208735578764L) / w.a<"B">((f2613 | 503375) + ~(f2613 & 503375) + 1 ^ -622138365, 349057757755238323L),
            w.a<"B">((f2613 | 288504) + ~(f2613 & 288504) + 1 ^ -1508498252, 349057757755238323L),
            338561931007909111L
         );
         w.a<"B">(312684551270353896L);
         this.f2610.m0752();
         w.a<"B">(207660790260164364L);
         w.a<"Û">(w.a<"B">(262390444630492460L), 164018200043501956L);
         w.a<"B">(
            w.a<"B">((f2613 | 242007) + ~(f2613 & 242007) + 1 ^ -1508773093, 349057757755238323L),
            w.a<"B">((f2613 | 622724) + ~(f2613 & 622724) + 1 ^ -1508130104, 349057757755238323L),
            w.a<"B">((f2613 | 30179) + ~(f2613 & 30179) + 1 ^ -1508755537, 349057757755238323L),
            w.a<"B">((f2613 | 460307) + ~(f2613 & 460307) + 1 ^ -1508555681, 349057757755238323L),
            338561931007909111L
         );
         f2609 = (boolean)((f2613 | 237757) + ~(f2613 & 237757) + 1 ^ -1718492431);
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 261991321583580780L),
            w.a<"B">(var9, 165155940100814265L),
            231232450300995026L
         );
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 384701863441497590L),
            w.a<"B">(var4, 165155940100814265L),
            231232450300995026L
         );
      }
   }

   @C1027
   public void m0996(C1173 var1) {
      if (!C0789.f1299) {
         if (!w.a<"Û">((Boolean)w.a<"Û">(this.f2581, 174312564406604366L), 354697271520518137L)
            && w.a<"Û">(this, w.a<"Û">(var1, 243083146846457705L), 198472233930925619L)
            && !this.f2612) {
            w.a<"Û">(var1, 385440235371820560L);
         }
      }
   }

   @C1027
   public void m0997(C0144 var1) {
      if (w.a<"Û">(this, w.a<"Û">(var1, 202310744921482589L), 198472233930925619L)) {
         w.a<"Û">(var1, (f2613 | 476148) + ~(f2613 & 476148) + 1 ^ -1721433784, 265444003839251524L);
      }
   }

   @C1027
   public void m0998(C0043 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2594, 174312564406604366L), 354697271520518137L)
         && (w.a<"Û">(var1, 187242426083527986L) != C0044.f0881 || w.a<"Û">((Boolean)w.a<"Û">(this.f2595, 174312564406604366L), 354697271520518137L))) {
         class_1657 var2 = w.a<"Û">(var1, 222309759014267063L);
         if (var2 != m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724) {
            C0164 var3 = new C0164(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687);
            w.a<"Û">(var3, var2, 224394324517681089L);
            var3.field_42108.field_42111 = var3.field_42108.field_42111 * w.a<"B">((f2613 | 306740) + ~(f2613 & 306740) + 1 ^ -644420488, 349057757755238323L);
            if (!w.a<"Û">((Boolean)w.a<"Û">(this.f2597, 174312564406604366L), 354697271520518137L)) {
               var3.field_42108.field_42111 = 0.0F;
               var3.field_42108.field_42110 = 0.0F;
               var3.field_42108.field_42109 = 0.0F;
            } else if (w.a<"Û">((Boolean)w.a<"Û">(this.f2598, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(var3, (boolean)((f2613 | 214197) + ~(f2613 & 214197) + 1 ^ -1718548744), 118236784157611872L);
               var3.field_6251 = 0.0F;
               var3.field_42108.field_42110 = (float)(
                  w.a<"B">(329795338200638383L)
                        * w.a<"B">(((long)f2613 | 536844L) + ~((long)f2613 & 536844L) + 1L ^ -4605380979700632768L, 317139102743630955L)
                     + w.a<"B">(((long)f2613 | 722323L) + ~((long)f2613 & 722323L) + 1L ^ -4596373780445968417L, 317139102743630955L)
               );
               var3.field_42108.field_42111 = 0.0F;
            }

            synchronized (this.f2611) {
               w.a<"Û">(this.f2611, var3, w.a<"B">(w.a<"B">(223409559795593705L), 279131300036783447L), 265103749380408799L);
            }
         }
      }
   }

   public boolean m0999(class_1297 var1) {
      if (w.a<"B">(192396213886669201L)) {
         return (boolean)((f2613 | 616792) + ~(f2613 & 616792) + 1 ^ -1717884140);
      } else {
         int var2;
         try {
            var2 = w.a<"B">(w.a<"Û">(var1, 225708705569795011L), 132682894836608805L)
                  && !(
                     w.a<"Û">(
                           w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773,
                                 202182323384413167L
                              ),
                              133466035608991790L
                           ),
                           w.a<"Û">(var1, 360959056130751432L),
                           180844654503832142L
                        )
                        > (double)w.a<"Û">((Integer)w.a<"Û">(this.f2576, 174312564406604366L), 260981171345819427L)
                  )
               ? (f2613 | 155665) + ~(f2613 & 155665) + 1 ^ -1718607267
               : (f2613 | 707183) + ~(f2613 & 707183) + 1 ^ -1718056926;
         } catch (Exception var4) {
            return (boolean)((f2613 | 455366) + ~(f2613 & 455366) + 1 ^ -1718308726);
         }

         if (var2 != 0) {
            return (boolean)((f2613 | 8491) + ~(f2613 & 8491) + 1 ^ -1718459545);
         } else if (w.a<"B">(var1, 236526568069354406L)) {
            return (boolean)((f2613 | 563865) + ~(f2613 & 563865) + 1 ^ -1717905195);
         } else if (var1 instanceof class_1511 var5) {
            return (boolean)(w.a<"B">(223409559795593705L) - w.a<"Û">((C0074)var5, 327376334090301521L)
                     > (long)w.a<"B">(w.a<"Û">(C0933.f1416, 337906300250345140L), (f2613 | 236947) + ~(f2613 & 236947) + 1 ^ -1718493203, 250328644894878425L)
                  && var5.field_6012 < ((f2613 | 58914) + ~(f2613 & 58914) + 1 ^ -1718442908)
                  && w.a<"Û">(f2574, 314537768572362865L)
                  && w.a<"Û">((Boolean)w.a<"Û">(f2574.f4770, 174312564406604366L), 354697271520518137L)
                  && w.a<"Û">((C0074)var5, 300632897406028685L)
               ? (f2613 | 275660) + ~(f2613 & 275660) + 1 ^ -1718192512
               : w.a<"Û">((C1029)w.a<"Û">(this.f2593, 174312564406604366L), 379432860096435297L));
         } else if (var1 instanceof class_1657) {
            int var3 = !w.a<"Û">(f2575, 314537768572362865L)
                  && w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 143691430875225825L
                     )
                     == class_5498.field_26664
               ? (f2613 | 628680) + ~(f2613 & 628680) + 1 ^ -1717840508
               : (f2613 | 926134) + ~(f2613 & 926134) + 1 ^ -1717804037;
            if (var1 != m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724) {
               return w.a<"Û">((C1029)w.a<"Û">(this.f2591, 174312564406604366L), 379432860096435297L);
            } else {
               return (boolean)(w.a<"Û">((C1029)w.a<"Û">(this.f2592, 174312564406604366L), 379432860096435297L) && var3 != 0
                  ? (f2613 | 873746) + ~(f2613 & 873746) + 1 ^ -1717627041
                  : (f2613 | 498872) + ~(f2613 & 498872) + 1 ^ -1718231308);
            }
         } else {
            return (boolean)((!(var1 instanceof class_1296) || !w.a<"Û">((C1029)w.a<"Û">(this.f2589, 174312564406604366L), 379432860096435297L))
                  && (!(var1 instanceof class_1569) || !w.a<"Û">((C1029)w.a<"Û">(this.f2590, 174312564406604366L), 379432860096435297L))
               ? (f2613 | 737319) + ~(f2613 & 737319) + 1 ^ -1718025621
               : (f2613 | 737551) + ~(f2613 & 737551) + 1 ^ -1718025406);
         }
      }
   }

   public float m1000(class_1297 var1) {
      float var2 = (float)w.a<"Û">((Integer)w.a<"Û">(this.f2578, 174312564406604366L), 260981171345819427L)
         / w.a<"B">((f2613 | 701871) + ~(f2613 & 701871) + 1 ^ -615450653, 349057757755238323L);
      double var3 = w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L),
               133466035608991790L
            ),
            w.a<"Û">(var1, 360959056130751432L),
            180844654503832142L
         )
         / (double)w.a<"Û">((Integer)w.a<"Û">(this.f2576, 174312564406604366L), 260981171345819427L);
      var3 -= (double)var2;
      return (float)(
         w.a<"B">(((long)f2613 | 125927L) + ~((long)f2613 & 125927L) + 1L ^ -4607182420518393429L, 317139102743630955L)
            - w.a<"B">(
               var3 / (double)(w.a<"B">((f2613 | 771525) + ~(f2613 & 771525) + 1 ^ -1508276343, 349057757755238323L) - var2),
               0.0,
               w.a<"B">(((long)f2613 | 70114L) + ~((long)f2613 & 70114L) + 1L ^ -4607182420518415442L, 317139102743630955L),
               318037245528159060L
            )
      );
   }

   public boolean m1001(class_1297 var1) {
      return (boolean)(w.a<"Û">(this, 314537768572362865L) && w.a<"Û">((Boolean)w.a<"Û">(this.f2582, 174312564406604366L), 354697271520518137L)
         ? w.a<"Û">(this, var1, 198472233930925619L)
         : (f2613 | 983681) + ~(f2613 & 983681) + 1 ^ -1717747507);
   }

   public boolean m1002(class_1297 var1) {
      int var2 = !w.a<"Û">((C0386)w.a<"Û">(w.a<"Û">(this, var1, 205986135341804820L), 174312564406604366L), 217404197188623911L)
            && var1 != m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
         ? (f2613 | 388204) + ~(f2613 & 388204) + 1 ^ -1718112736
         : (f2613 | 380918) + ~(f2613 & 380918) + 1 ^ -1718121029;
      return (boolean)(w.a<"Û">(this, 314537768572362865L)
            && var2 != 0
            && w.a<"Û">((Boolean)w.a<"Û">(this.f2584, 174312564406604366L), 354697271520518137L)
            && f2608
         ? (f2613 | 227592) + ~(f2613 & 227592) + 1 ^ -1718535355
         : (f2613 | 564131) + ~(f2613 & 564131) + 1 ^ -1717904913);
   }

   public boolean m1003() {
      float var1 = w.a<"B">((f2613 | 205356) + ~(f2613 & 205356) + 1 ^ -1492583942, 349057757755238323L);
      class_243 var2 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 270398306108537951L
      );
      class_2338 var3 = w.a<"B">(var2, 274163478939689086L);
      class_238 var4 = w.a<"B">(var2, (double)var1, (double)var1, (double)var1, 143694487255612937L);
      return (boolean)(!w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               var4,
               139239989421000095L
            )
            && w.a<"Û">(
               w.a<"Û">(
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var3, 310987074049434965L
                  ),
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  var3,
                  127692959363775057L
               ),
               125999939138686596L
            )
         ? (f2613 | 283639) + ~(f2613 & 283639) + 1 ^ -1718218310
         : (f2613 | 882106) + ~(f2613 & 882106) + 1 ^ -1717618698);
   }

   public boolean m1004() {
      return w.a<"Û">(animations, 347945687323500132L);
   }

   public C0066 m1005() {
      return this.f2610;
   }

   public C0015<? extends C0386> m1006(class_1297 var1) {
      if (var1 == m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724) {
         return this.f2592;
      } else if (var1 instanceof class_1511) {
         return this.f2593;
      } else if (var1 instanceof class_1657) {
         return this.f2591;
      } else {
         return var1 instanceof class_1296 ? this.f2589 : this.f2590;
      }
   }

   public static String l1CxD5gvFteaNIs5JOn3KFojZJmZawc1CxexS48ftNbdSgQDuggGmhqfIIl33vNO0fz0Gy7fNqJoPko2tfp3vmJsRdEzXeWothZp(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
