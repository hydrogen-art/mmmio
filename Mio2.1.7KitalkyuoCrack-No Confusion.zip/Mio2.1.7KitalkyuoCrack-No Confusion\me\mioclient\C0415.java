package me.mioclient;

import java.util.function.Predicate;

public class C0415 implements Predicate {
   public C0551 f2355;

   public C0415(C0551 var1) {
      this.f2355 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2355.f1766, 174312564406604366L) == C0552.f3875;
   }
}
