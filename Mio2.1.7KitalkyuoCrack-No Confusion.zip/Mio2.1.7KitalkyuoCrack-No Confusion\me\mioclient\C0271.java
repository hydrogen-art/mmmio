package me.mioclient;

import java.util.function.Predicate;

public class C0271 implements Predicate {
   public C0879 f0752;

   public C0271(C0879 var1) {
      this.f0752 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0752.f3757, 254992554122318132L) && w.a<"Û">(this.f0752.f3761, 254992554122318132L);
   }
}
