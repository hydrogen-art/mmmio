package me.mioclient;

import java.awt.Color;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;

public final class C0499 implements C0045 {
   public final class_2338 f0584;
   public float f0585;
   public float f0586;
   public static int f0587 = w.a<"B">(3491377913389948163L, 257832362129977838L);

   public C0499(class_2338 var1) {
      this.f0584 = var1;
   }

   public void m2333(C0846 var1, C1355 var2) {
      class_265 var3 = w.a<"Û">(
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, this.f0584, 310987074049434965L
         ),
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
         this.f0584,
         385368692334192390L
      );
      if (!w.a<"Û">(var3, 125999939138686596L) && w.a<"B">(this.f0584, 168455243775731585L)) {
         float var4 = w.a<"Û">(this, 343186167934641497L);
         Color[] var5 = w.a<"Û">((C1057)w.a<"Û">(var1.f5220, 174312564406604366L), var1, var4, 272924681178886662L);
         class_238 var6 = w.a<"Û">(
            w.a<"Û">((C0608)w.a<"Û">(var1.f5217, 174312564406604366L), var1, w.a<"Û">(var3, 153037909352617834L), var4, 358705470540832686L),
            this.f0584,
            252103202185457587L
         );
         w.a<"B">(w.a<"Û">(var2, 173269294235887931L), var6, var5[(f0587 | 399471) + ~(f0587 & 399471) + 1 ^ 861741734], 246072095578695914L);
         C0485.m3219(
            w.a<"Û">(var2, 173269294235887931L),
            var6,
            var5[(f0587 | 105236) + ~(f0587 & 105236) + 1 ^ 861577692],
            w.a<"Û">((Float)w.a<"Û">(var1.f5216, 174312564406604366L), 149784643039979208L)
         );
      }
   }

   public class_2338 m2334() {
      return this.f0584;
   }

   public float m2335() {
      return w.a<"B">(
         w.a<"B">(C0094.m1872(), this.f0585, this.f0586, 286181508181077551L),
         0.0F,
         w.a<"B">((f0587 | 845643) + ~(f0587 & 845643) + 1 ^ 215473538, 349057757755238323L),
         131506059371757968L
      );
   }

   public void m2336(float var1) {
      w.a<"Û">(this, this.f0586 + var1, 134841348724945829L);
   }

   public void m2337(float var1) {
      this.f0585 = this.f0586;
      this.f0586 = var1;
   }
}
