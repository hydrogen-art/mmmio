package me.mioclient;

import java.util.function.Predicate;

public class C0387 implements Predicate {
   public C0023 f1382;

   public C0387(C0023 var1) {
      this.f1382 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1382.f2135, 254992554122318132L);
   }
}
