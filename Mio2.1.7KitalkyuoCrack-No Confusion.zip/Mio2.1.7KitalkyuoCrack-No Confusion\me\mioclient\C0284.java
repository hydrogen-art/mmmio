package me.mioclient;

import java.util.List;
import net.minecraft.class_437;
import net.minecraft.class_5684;

public class C0284 extends C1180 {
   public static int f2902;
   public static int f2903;
   public final class_437 f2904;
   public List<class_5684> f2905;
   public int f2906;
   public int f2907;

   public C0284(class_437 var1, List<class_5684> var2, int var3, int var4, int var5, int var6) {
      this.f2904 = var1;
      this.f2905 = var2;
      this.f2906 = var3;
      this.f2907 = var4;
      f2902 = var5;
      f2903 = var6;
   }

   public class_437 m1129() {
      return this.f2904;
   }

   public List<class_5684> m1130() {
      return this.f2905;
   }

   public void m1131(List<class_5684> var1) {
      this.f2905 = var1;
   }

   public int getX() {
      return this.f2906;
   }

   public void setX(int var1) {
      this.f2906 = var1;
   }

   public int getY() {
      return this.f2907;
   }

   public void setY(int var1) {
      this.f2907 = var1;
   }
}
