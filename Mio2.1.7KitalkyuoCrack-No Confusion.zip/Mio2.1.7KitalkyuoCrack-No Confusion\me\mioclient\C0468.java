package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0468 implements C0196 {
   f0254("None"),
   f0255("Coordinates"),
   f0256("Distance");

   public final String f0257;

   public C0468(String var3) {
      this.f0257 = var3;
   }

   @Override
   public String getName() {
      return this.f0257;
   }

   public static String jmLVxRKR6hZdg5vtxMOTQw0U0Qwo1KYbYCAk3cVsFHcIyJHabUKUp8c9IKG5BtLppI6XUPZG9B5pq6XMs0WU9CZO1D4Mkd8QCX99(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
