package me.mioclient;

public interface C0229<T> {
   void forceSetValue(T var1);
}
