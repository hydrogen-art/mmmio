package me.mioclient;

import java.util.function.Predicate;

public class C0167 implements Predicate {
   public C1161 f4037;

   public C0167(C1161 var1) {
      this.f4037 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4037.f1185, 254992554122318132L);
   }
}
