package me.mioclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.invoke.MethodHandles.Lookup;
import java.nio.file.Path;
import java.util.List;
import net.minecraft.class_332;

public class C0162 extends C1214 {
   public final C1283 f3355 = new C1283(this);
   public final C1067 f3356 = new C1067(this);
   public C0430 f3357 = C0430.f2563;
   public final C0072 f3358 = new C0072();
   public static int f3359 = -636948494;

   public C0162() {
      this.m$$NyWixwImaKsyW0dcb2KbV8bn1anduTL2X2EF9bCfVGTGs2KkolWT9HHn5A2p4KTdCgUbJH7iTTkD0jcvqjI80ZPFaDgjDpZ3X.add(this.f3355);
      this.f3356
         .setX(
            this.f3355.getX()
               + this.f3355.m$$fflPpLK5osDVqiqMnbnd1wDffTgUKEhqaDWBTJUWQBRqttOjrxUceY3INsNSXYadgjgeXXWqNHG2k7GaJEwtDaXiRDaRtP0vM()
               + ((f3359 | 694007) + ~(f3359 & 694007) + 1 ^ -637372154)
         );
      this.m$$NyWixwImaKsyW0dcb2KbV8bn1anduTL2X2EF9bCfVGTGs2KkolWT9HHn5A2p4KTdCgUbJH7iTTkD0jcvqjI80ZPFaDgjDpZ3X.add(this.f3356);
   }

   @Override
   public void m2369(class_332 var1, int var2, int var3, float var4) {
      this.f3358
         .m0793(
            (boolean)(!m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1569()
               ? (f3359 | 561666) + ~(f3359 & 561666) + 1 ^ -637501967
               : (f3359 | 132919) + ~(f3359 & 132919) + 1 ^ -636819259),
            ((long)f3359 | 747875L) + ~((long)f3359 & 747875L) + 1L ^ -637303189L
         );
      float var5 = this.f3358.m0795();
      if (var5 != 0.0F) {
         RenderSystem.setShaderColor(
            Float.intBitsToFloat((f3359 | 195249) + ~(f3359 & 195249) + 1 ^ -443935421),
            Float.intBitsToFloat((f3359 | 886129) + ~(f3359 & 886129) + 1 ^ -444241277),
            Float.intBitsToFloat((f3359 | 860056) + ~(f3359 & 860056) + 1 ^ -444206998),
            Float.intBitsToFloat((f3359 | 601880) + ~(f3359 & 601880) + 1 ^ -448675606) * var5
         );
         var1.method_25300(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1772,
            "Drop preset files here",
            var1.method_51421() / ((f3359 | 442745) + ~(f3359 & 442745) + 1 ^ -636604791),
            var1.method_51443() / ((f3359 | 152137) + ~(f3359 & 152137) + 1 ^ -636830279),
            (f3359 | 407537) + ~(f3359 & 407537) + 1 ^ 636561404
         );
         RenderSystem.setShaderColor(
            Float.intBitsToFloat((f3359 | 522622) + ~(f3359 & 522622) + 1 ^ -443607412),
            Float.intBitsToFloat((f3359 | 518405) + ~(f3359 & 518405) + 1 ^ -443611401),
            Float.intBitsToFloat((f3359 | 529984) + ~(f3359 & 529984) + 1 ^ -444532302),
            Float.intBitsToFloat((f3359 | 22712) + ~(f3359 & 22712) + 1 ^ -444025014)
         );
      }
   }

   public void method_29638(List<Path> var1) {
      C0140.m1544(this, var1);
   }

   public C1283 m3428() {
      return this.f3355;
   }

   public C1067 m3429() {
      return this.f3356;
   }

   public C0430 m3430() {
      return this.f3357;
   }

   public void m3431(C0430 var1) {
      this.f3357 = var1;
   }

   static {
      long var10000 = 1013836526404588451L;
   }

   public static String UXb2lkKUsmB8BDgHjBw5UhpZwMZh9ObAQFIn1vfP2kViGOIztFP3lk8VtEEG3Oz3NEIS5sC8ZaYxzfH7VAA7JJSvwvAcWjHVKvwu(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
