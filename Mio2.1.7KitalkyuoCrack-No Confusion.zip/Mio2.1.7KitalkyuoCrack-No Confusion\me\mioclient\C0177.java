package me.mioclient;

import java.util.function.Predicate;

public class C0177 implements Predicate {
   public C0846 f4152;

   public C0177(C0846 var1) {
      this.f4152 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4152.f5201, 254992554122318132L);
   }
}
