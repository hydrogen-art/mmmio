package me.mioclient;

import me.mioclient.mixin.ducks.DuckHandledScreen;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterInit;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_476;
import net.minecraft.class_495;
import net.minecraft.class_4185.class_7840;

class C0335 implements C0045, AfterInit {
   public final C0124 f0119;
   public static int f0120 = w.a<"B">(7370003516000031862L, 257832362129977838L);

   public C0335(C0124 var1) {
      this.f0119 = var1;
   }

   public void afterInit(class_310 var1, class_437 var2, int var3, int var4) {
      if ((var2 instanceof class_476 || var2 instanceof class_495)
         && w.a<"Û">(this.f0119, 314537768572362865L)
         && w.a<"Û">((Boolean)w.a<"Û">(this.f0119.f3121, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(this.f0119, null, 258560417229111111L);
         int var5 = C1074.f4546;
         int var6 = (var2.field_22789 - ((DuckHandledScreen)var2).getBgWidth()) / ((f0120 | 875141) + ~(f0120 & 875141) + 1 ^ -523898375)
            - var5
            - ((f0120 | 124911) + ~(f0120 & 124911) + 1 ^ -523678573);
         int var7 = (var2.field_22790 - ((DuckHandledScreen)var2).getBgHeight()) / ((f0120 | 521286) + ~(f0120 & 521286) + 1 ^ -523280582);
         C0367[] var8 = w.a<"B">(307391040112460169L);
         int var9 = var8.length;

         for (int var10 = (f0120 | 28178) + ~(f0120 & 28178) + 1 ^ -523713172; var10 < var9; var10++) {
            C0367 var11 = var8[var10];
            class_7840 var12 = new class_7840(
               w.a<"B">(w.a<"Û">(var11, 306676248180475751L), 228465064790135899L),
               var3x -> {
                  if (var11 == w.a<"Û">(this.f0119, 365296738509531384L)) {
                     w.a<"Û">(
                        C0933.f1433,
                        (Runnable)() -> w.a<"Û">(var2, null, 301952039078103102L),
                        (f0120 | 653562) + ~(f0120 & 653562) + 1 ^ -524201084,
                        122889728173745617L
                     );
                     w.a<"Û">(this.f0119, null, 258560417229111111L);
                  } else {
                     w.a<"Û">(this.f0119, var11, 258560417229111111L);
                  }
               }
            );
            w.a<"Û">(var12, var6, var7, var5, (f0120 | 58897) + ~(f0120 & 58897) + 1 ^ -523743904, 191529098886278469L);
            var7 += 17;
            w.a<"Û">(w.a<"B">(var2, 170713423127557209L), w.a<"Û">(var12, 170005571445768438L), 276802003864609490L);
         }
      }
   }
}
