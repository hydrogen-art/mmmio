package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Calendar;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

public class C0455 extends C1266 {
   public final C0015<C0456> f1851;
   public final C0015<Color> f1852;
   public final C0015<Integer> f1853;
   public final C0015<Boolean> f1854;
   public final C0015<Boolean> f1855;
   public final C0015<Float> f1856;
   public final C0015<Boolean> f1857;
   public final C0015<C0457> f1858;
   public final C0015<Boolean> f1859;
   public final C0015<Float> f1860;
   public double f1861;
   public static int f1862 = w.a<"B">(1721501116963490722L, 257832362129977838L);

   public C0455() {
      super("Ambience", "Changes several ambient things.", C1045.f3174);
      w.a<"B">(this, 242859112966675773L);
      w.a<"Û">(
         this.f1853,
         (Runnable)() -> {
            if (w.a<"Û">(this.f1851, 174312564406604366L) == C0456.f0071
               && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687 != null) {
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1769, 326576940325645247L);
            }
         },
         276217487236498440L
      );
      w.a<"Û">(
         this.f1851,
         (Runnable)() -> {
            if (!w.a<"Û">(this, 205492958615326489L)) {
               if (w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                     class_1294.field_5925,
                     176223852645644080L
                  )
                  && w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                           class_1294.field_5925,
                           169566341115889972L
                        ),
                        148721469287305317L
                     )
                     == ((f1862 | 564224) + ~(f1862 & 564224) + 1 ^ -1530818734)) {
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                     class_1294.field_5925,
                     195374158210254086L
                  );
               }

               if (w.a<"Û">(this.f1851, 174312564406604366L) != C0456.f0070) {
                  w.a<"Û">(
                     (C0229)w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 294404620180308423L
                     ),
                     w.a<"B">(this.f1861, 165155940100814265L),
                     355260527379810339L
                  );
               }
            }
         },
         276217487236498440L
      );
      w.a<"Û">(this, (boolean)((f1862 | 446839) + ~(f1862 & 446839) + 1 ^ -1529888159), 135570431627433065L);
   }

   @Override
   public void onEnable() {
      this.f1861 = w.a<"Û">(
         (Double)w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 294404620180308423L),
            142580699129741492L
         ),
         287934447355057060L
      );
   }

   @Override
   public void onDisable() {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_1294.field_5925,
            195374158210254086L
         );
      }

      w.a<"Û">(
         (C0229)w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 294404620180308423L),
         w.a<"B">(this.f1861, 165155940100814265L),
         355260527379810339L
      );
   }

   @Override
   public void onToggle() {
      if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1769 != null) {
         if (w.a<"Û">(this.f1851, 174312564406604366L) == C0456.f0071 || w.a<"Û">(this.f1851, 174312564406604366L) == C0456.f0069) {
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1769, 326576940325645247L);
         }
      }
   }

   @C1027
   public void m2769(C0612 var1) {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f1854, 174312564406604366L), 354697271520518137L)) {
            long var2 = w.a<"Û">(this, 386435540193529510L);
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var2, 228331155661955054L);
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var2, 322258448298212803L);
         }

         if (w.a<"Û">(this.f1851, 174312564406604366L) == C0456.f0070) {
            w.a<"Û">(
               (C0229)w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 294404620180308423L
               ),
               w.a<"B">(w.a<"B">(((long)f1862 | 769805L) + ~((long)f1862 & 769805L) + 1L ^ -4652007310371935205L, 317139102743630955L), 165155940100814265L),
               355260527379810339L
            );
         } else if (w.a<"Û">(this.f1851, 174312564406604366L) == C0456.f0072
            && !w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               class_1294.field_5925,
               176223852645644080L
            )) {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               new class_1293(
                  class_1294.field_5925, (f1862 | 96751) + ~(f1862 & 96751) + 1 ^ 1530369286, (f1862 | 679284) + ~(f1862 & 679284) + 1 ^ -1530704346
               ),
               149961931577169591L
            );
         }
      }
   }

   public long m2770() {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1855, 174312564406604366L), 354697271520518137L)) {
         Calendar var1 = w.a<"B">(129456123720773690L);
         return (long)(
            (
                     (float)w.a<"Û">(var1, (f1862 | 852018) + ~(f1862 & 852018) + 1 ^ -1530653905, 182625407687507202L)
                        + (float)w.a<"Û">(var1, (f1862 | 628249) + ~(f1862 & 628249) + 1 ^ -1530886909, 182625407687507202L)
                           / w.a<"B">((f1862 | 861868) + ~(f1862 & 861868) + 1 ^ -424397382, 349057757755238323L)
                  )
                  * w.a<"B">((f1862 | 273393) + ~(f1862 & 273393) + 1 ^ -524863257, 349057757755238323L)
               + w.a<"B">((f1862 | 39802) + ~(f1862 & 39802) + 1 ^ -498784148, 349057757755238323L)
         );
      } else {
         return (long)(
            w.a<"Û">((Float)w.a<"Û">(this.f1856, 174312564406604366L), 149784643039979208L)
                  * w.a<"B">((f1862 | 660169) + ~(f1862 & 660169) + 1 ^ -524746273, 349057757755238323L)
               + w.a<"B">((f1862 | 908242) + ~(f1862 & 908242) + 1 ^ -498571068, 349057757755238323L)
         );
      }
   }

   public boolean m2771() {
      return (boolean)(w.a<"Û">(this, 314537768572362865L)
            && w.a<"Û">((Boolean)w.a<"Û">(this.f1857, 174312564406604366L), 354697271520518137L)
            && w.a<"Û">((Boolean)w.a<"Û">(this.f1859, 174312564406604366L), 354697271520518137L)
         ? (f1862 | 62137) + ~(f1862 & 62137) + 1 ^ -1530273362
         : (f1862 | 264223) + ~(f1862 & 264223) + 1 ^ -1530062071);
   }

   public static String oQ7FopLJJvhAZEto0ukjEQhVWbgIqoNpXibpo1DIdVopYj3hhHcExYm0ijY3V4o0nm0vrYAwFDQVMBrP5cxGF1WIe0iZm2QbLsDa(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
