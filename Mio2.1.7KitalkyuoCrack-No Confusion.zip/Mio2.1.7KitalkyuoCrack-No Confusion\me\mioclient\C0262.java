package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1748;
import net.minecraft.class_1799;
import net.minecraft.class_2244;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_3965;
import net.minecraft.class_2350.class_2353;

public final class C0262 extends C1266 {
   public static final C0303 f0480 = C0933.f1409.m2696(C0303.class);
   public final C0015<Boolean> f0481;
   public final C0015<Integer> f0482;
   public final C0015<Float> f0483;
   public final C0015<Boolean> f0484;
   public final C0015<Boolean> f0485;
   public final C0015<Boolean> f0486;
   public final C0015<Boolean> f0487;
   public final C0015<Boolean> f0488;
   public final C0015<Integer> f0489;
   public final C0015<Float> f0490;
   public final C0015<Boolean> f0491;
   public final C0015<Boolean> f0492;
   public final C0015<Boolean> f0493;
   public final C0015<Integer> f0494;
   public final C0015<Boolean> f0495;
   public final C0015<Integer> f0496;
   public final C0015<Boolean> f0497;
   public final C0015<Color> f0498;
   public final C0015<Color> f0499;
   public final C0015<Boolean> f0500;
   public final C0015<Float> f0501;
   public final C0015<Boolean> f0502;
   public final C0015<Float> f0503;
   public final C0015<Float> f0504;
   public final C0015<Boolean> f0505;
   public final C1182 f0506;
   public final C0995 f0507;
   public final C0083 f0508;
   public final C0083 f0509;
   public class_1657 f0510;
   public C0654 f0511;
   public class_2338 f0512;
   public static int f0513 = w.a<"B">(191937272209842514L, 257832362129977838L);

   public C0262() {
      super(
         "BedAura",
         new C1002().m2591(String.valueOf(class_124.field_1061)).m2593("Blows your enemies up using beds. \n\u0001Doesn't work in the overworld."),
         C1045.f3172
      );
      w.a<"B">(this, 242859112966675773L);
      this.f0506 = new C1182(this);
      this.f0507 = new C0995(this);
      this.f0508 = new C0083();
      this.f0509 = new C0083();
      w.a<"Û">(
         C0933.f1430,
         new C0122(
            this,
            this.f0498,
            this.f0499,
            () -> w.a<"B">(w.a<"B">((f0513 | 215661) + ~(f0513 & 215661) + 1 ^ 1645199020, 349057757755238323L), 243402859552372891L),
            this.f0501,
            () -> w.a<"B">((boolean)((f0513 | 388249) + ~(f0513 & 388249) + 1 ^ 1569265752), 320330632857389983L),
            this.f0500,
            (f0513 | 887120) + ~(f0513 & 887120) + 1 ^ 1568767609
         ),
         215636623669649177L
      );
      w.a<"Û">(this.f0483, "PlaceRange", 275243698516531804L);
      w.a<"Û">(this.f0490, "BreakRange", 275243698516531804L);
      w.a<"Û">(this.f0482, "PlaceDelay", 275243698516531804L);
      w.a<"Û">(this.f0489, "BreakDelay", 275243698516531804L);
   }

   @Override
   public String getInfo() {
      return this.f0510 == null ? null : w.a<"Û">(w.a<"Û">(this.f0510, 138826997201410603L), 211085733983653208L);
   }

   @C1027
   public void m2308(C0153 var1) {
      this.f0510 = w.a<"Û">(this, 190513141513271059L);
      if (this.f0510 == null) {
         this.f0511 = null;
      } else {
         this.f0511 = w.a<"Û">(this.f0506, this.f0510, 224873082813521960L);
         this.f0512 = w.a<"Û">(this.f0507, this.f0510, 286743945422350082L);
      }

      if (this.f0511 != null) {
         w.a<"Û">(this, 376429304833184989L);
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f0488, 174312564406604366L), 354697271520518137L) && w.a<"Û">(this, this.f0509, this.f0489, 263442627233432614L)) {
            w.a<"Û">(this, this.f0512, 228276118407161925L);
         }

         if (w.a<"Û">((Boolean)w.a<"Û">(this.f0481, 174312564406604366L), 354697271520518137L) && w.a<"Û">(this, this.f0508, this.f0482, 263442627233432614L)) {
            w.a<"Û">(this, this.f0511, 214839066233390504L);
         }
      }
   }

   public class_1657 m2309() {
      class_1657 var1 = null;
      float var2 = w.a<"B">((f0513 | 326027) + ~(f0513 & 326027) + 1 ^ 441139914, 349057757755238323L);
      Iterator var3 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 188438576288929642L),
         341496865259068134L
      );

      while (w.a<"Û">(var3, 333900474771661065L)) {
         class_1657 var4 = (class_1657)w.a<"Û">(var3, 192468336863492695L);
         if (var4 != m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
            && !w.a<"Û">(C0933.f1417, var4, 241036547861815495L)
            && (double)var2
               > w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 270398306108537951L),
                  w.a<"Û">(var4, 359920018220808632L),
                  180844654503832142L
               )) {
            var1 = var4;
            var2 = (float)w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 270398306108537951L),
               w.a<"Û">(var4, 359920018220808632L),
               180844654503832142L
            );
         }
      }

      return var1;
   }

   public void m2310(C0654 var1) {
      int var2 = w.a<"B">((Predicate<class_1799>)var0 -> w.a<"Û">(var0, 222207108884875224L) instanceof class_1748, 344867982687893969L);
      int var3 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545;
      if (var2 != ((f0513 | 238017) + ~(f0513 & 238017) + 1 ^ -1569674497)) {
         w.a<"B">(var2, 357260035653160004L);
         w.a<"Û">(this, var1, 345876164529877915L);
         w.a<"B">(var3, 357260035653160004L);
      }
   }

   public void m2311(C0654 var1) {
      if (var1 != null) {
         if (w.a<"B">(w.a<"Û">(var1, 165425264355301486L), (boolean)((f0513 | 287814) + ~(f0513 & 287814) + 1 ^ 1569230982), 242496856158723858L)) {
            float[] var2;
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f0485, 174312564406604366L), 354697271520518137L)) {
               var2 = w.a<"B">(w.a<"Û">(w.a<"Û">(var1, 212860591170552419L), 378186176745654896L), 213766782372904553L);
            } else {
               var2 = w.a<"B">(
                  w.a<"Û">(w.a<"Û">(var1, 165425264355301486L), 229561253177300454L),
                  w.a<"Û">(w.a<"Û">(var1, 238634760332492667L), 229561253177300454L),
                  372402139461912970L
               );
            }

            w.a<"Û">(C0933.f1412, var2, (f0513 | 731498) + ~(f0513 & 731498) + 1 ^ 1569184863, 236731835237641613L);
            class_3965 var3 = w.a<"Û">(var1, 212860591170552419L);
            w.a<"Û">(C0933.f1429, (Runnable)() -> w.a<"B">(class_1268.field_5808, var3, 364787408257838011L), 244962080870372939L);
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               class_1268.field_5808,
               356560492913773202L
            );
            class_238 var4 = w.a<"B">(w.a<"Û">(var1, 165425264355301486L), w.a<"Û">(var1, 238634760332492667L), 222871699420036567L);
            var4 = w.a<"Û">(
               var4,
               var4.field_1322 + w.a<"B">(((long)f0513 | 556224L) + ~((long)f0513 & 556224L) + 1L ^ 4603241770695034881L, 317139102743630955L),
               182030847371476974L
            );
            var4 = w.a<"Û">(
               var4, w.a<"B">(((long)f0513 | 287704L) + ~((long)f0513 & 287704L) + 1L ^ 4566758108185532185L, 317139102743630955L), 130605157384247280L
            );
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f0497, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(C0933.f1430, this, var4, 317866513404830971L);
            }

            if (w.a<"Û">((Boolean)w.a<"Û">(this.f0492, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(
                  C0933.f1429,
                  (Runnable)() -> {
                     class_2350 var2x = w.a<"Û">(this, w.a<"Û">(var1, 165425264355301486L), class_2350.field_11036, 374546498147112766L);
                     class_3965 var3x = new class_3965(
                        w.a<"Û">(w.a<"Û">(var1, 165425264355301486L), 229561253177300454L),
                        var2x,
                        w.a<"Û">(var1, 165425264355301486L),
                        (boolean)((f0513 | 879950) + ~(f0513 & 879950) + 1 ^ 1568774543)
                     );
                     w.a<"B">(class_1268.field_5808, var3x, 364787408257838011L);
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                        class_1268.field_5808,
                        356560492913773202L
                     );
                  },
                  225173080095298218L
               );
            }

            w.a<"Û">(this.f0508, 387780412884547639L);
         }
      }
   }

   public void m2312(class_2338 var1) {
      if (var1 != null) {
         class_2350 var2 = w.a<"Û">(this, var1, class_2350.field_11036, 374546498147112766L);
         class_3965 var3 = new class_3965(w.a<"Û">(var1, 229561253177300454L), var2, var1, (boolean)((f0513 | 550174) + ~(f0513 & 550174) + 1 ^ 1568969183));
         w.a<"Û">(
            C0933.f1429,
            (Runnable)() -> {
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  class_1268.field_5808,
                  var3,
                  353197595888970100L
               );
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  class_1268.field_5808,
                  356560492913773202L
               );
            },
            225173080095298218L
         );
         Iterator var4 = w.a<"Û">(class_2353.field_11062, 287411357280723181L);

         while (w.a<"Û">(var4, 333900474771661065L)) {
            class_2350 var5 = (class_2350)w.a<"Û">(var4, 192468336863492695L);
            class_2338 var6 = w.a<"Û">(var1, var5, 361576458954219689L);
            if (w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var6, 310987074049434965L
               ),
               152622786059621427L
            ) instanceof class_2244) {
               w.a<"Û">(C0933.f1436, var6, 128038255970895463L);
               break;
            }
         }

         w.a<"Û">(C0933.f1436, var1, 128038255970895463L);
         w.a<"Û">(this.f0509, 387780412884547639L);
      }
   }

   public void m2313() {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0495, 174312564406604366L), 354697271520518137L)) {
         int var1 = w.a<"Û">((Integer)w.a<"Û">(this.f0496, 174312564406604366L), 260981171345819427L) - ((f0513 | 298529) + ~(f0513 & 298529) + 1 ^ 1569225441);
         class_1799 var2 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
            var1,
            386860178278302175L
         );
         if (!(w.a<"Û">(var2, 222207108884875224L) instanceof class_1748)) {
            int var3 = w.a<"B">(
               (Predicate<class_1799>)var0 -> w.a<"Û">(var0, 222207108884875224L) instanceof class_1748,
               (boolean)((f0513 | 762453) + ~(f0513 & 762453) + 1 ^ 1569150613),
               155900307420311747L
            );
            if (var3 != ((f0513 | 343826) + ~(f0513 & 343826) + 1 ^ -1569311700)) {
               w.a<"B">(var3, w.a<"B">(var1, 117367628897531893L), 259189609675737615L);
            }
         }
      }
   }

   public class_2350 m2314(class_2338 var1, class_2350 var2) {
      List var3 = w.a<"B">(var1, 239126559569481376L);
      if (!w.a<"Û">(var3, 284469716622774448L)) {
         w.a<"Û">(var3, 190855132863596333L);
      }

      return var2;
   }

   public boolean m2315(class_2338 var1, class_2742 var2) {
      class_2680 var3 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var1, 310987074049434965L
      );
      return (boolean)(w.a<"Û">(var3, 152622786059621427L) instanceof class_2244 && w.a<"Û">(var3, class_2244.field_9967, 241837761123994827L) == var2
         ? (f0513 | 533781) + ~(f0513 & 533781) + 1 ^ 1568985557
         : (f0513 | 295300) + ~(f0513 & 295300) + 1 ^ 1569224005);
   }

   public boolean m2316(C0083 var1, C0015<Integer> var2) {
      float var3 = w.a<"Û">((Boolean)w.a<"Û">(this.f0491, 174312564406604366L), 354697271520518137L)
         ? w.a<"Û">(C0933.f1416, 329491062951172765L)
         : w.a<"B">((f0513 | 210428) + ~(f0513 & 210428) + 1 ^ 1645199677, 349057757755238323L);
      return w.a<"Û">(
         var1,
         (long)(
            (float)(
                  (((long)f0513 | 421059L) + ~((long)f0513 & 421059L) + 1L ^ 1569364016L)
                     * (long)w.a<"Û">((Integer)w.a<"Û">(var2, 174312564406604366L), 260981171345819427L)
               )
               * var3
         ),
         309642602085515378L
      );
   }

   public class_238 m2317(class_1309 var1) {
      if (var1 instanceof class_1657 var2 && w.a<"Û">((Boolean)w.a<"Û">(this.f0493, 174312564406604366L), 354697271520518137L)) {
         return w.a<"Û">(C0933.f1426, var2, w.a<"Û">((Integer)w.a<"Û">(this.f0494, 174312564406604366L), 260981171345819427L), 323742496459143110L);
      }

      return w.a<"Û">(var1, 381939097272295099L);
   }

   public static String A861r2WZle3jUCljRaRkov5pEBRgZDR8y1RtqQVICLgRVAKUIsYHAdQw39XJh15DNu4iLU1HtHTXDTiAjEknz8ymLS1tbOklFH9a(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
