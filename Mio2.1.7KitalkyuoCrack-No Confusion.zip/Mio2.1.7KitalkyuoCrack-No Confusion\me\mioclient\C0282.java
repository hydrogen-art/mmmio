package me.mioclient;

import java.util.function.Predicate;

public class C0282 implements Predicate {
   public C0309 f0779;

   public C0282(C0309 var1) {
      this.f0779 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0779.f3401, 174312564406604366L) != C0312.f0220 || w.a<"Û">(this.f0779.f3400, 174312564406604366L) != C0310.f1937;
   }
}
