package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3965;
import net.minecraft.class_742;

public class C0340 extends C1266 {
   public static final C0535 f2159 = C0933.f1409.m2696(C0535.class);
   public final C0015<C0562> f2160;
   public final C0015<Float> f2161;
   public final C0015<Integer> f2162;
   public final C0015<Integer> f2163;
   public final C0015<Boolean> f2164;
   public final C0015<Boolean> f2165;
   public final C0015<Boolean> f2166;
   public final C0015<Boolean> f2167;
   public final C0015<Color> f2168;
   public final C0015<Color> f2169;
   public final C0015<Float> f2170;
   public final C0015<Boolean> f2171;
   public final C0015<Float> f2172;
   public final C0083 f2173;
   public static int f2174 = w.a<"B">(5566428302446887182L, 257832362129977838L);

   public C0340() {
      super("AntiPhase", "Prevents your enemies from pearl-phasing into nearest block.", C1045.f3172);
      w.a<"B">(this, 242859112966675773L);
      this.f2173 = new C0083();
      w.a<"Û">(
         C0933.f1430,
         new C0122(
            this,
            this.f2168,
            this.f2169,
            this.f2170,
            this.f2172,
            () -> w.a<"B">((boolean)((f2174 | 952831) + ~(f2174 & 952831) + 1 ^ 1869446328), 320330632857389983L),
            this.f2171,
            (f2174 | 654068) + ~(f2174 & 654068) + 1 ^ 1869221488
         ),
         215636623669649177L
      );
   }

   @C1027
   public void m0912(C0153 var1) {
      if (w.a<"Û">(this.f2173, (long)w.a<"Û">((Integer)w.a<"Û">(this.f2162, 174312564406604366L), 260981171345819427L), 146861306852483676L)
         && !w.a<"Û">(f2159, 314413203568818693L)) {
         int var2 = (f2174 | 177641) + ~(f2174 & 177641) + 1 ^ 1868644527;
         Iterator var3 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 188438576288929642L),
            341496865259068134L
         );

         while (w.a<"Û">(var3, 333900474771661065L)) {
            class_742 var4 = (class_742)w.a<"Û">(var3, 192468336863492695L);
            if (w.a<"Û">(this, var4, 138284207586846561L)) {
               C0725 var5 = w.a<"Û">(w.a<"Û">(this, 179467839751486897L), this, var4, 239783264721246271L);
               if (var5 != null) {
                  if (w.a<"Û">(this, var5, 249611537686853316L)) {
                     if (w.a<"Û">((Boolean)w.a<"Û">(this.f2165, 174312564406604366L), 354697271520518137L)) {
                        float[] var6 = w.a<"B">(w.a<"Û">(var5, 350472241332229716L), 213766782372904553L);
                        w.a<"Û">(C0933.f1412, var6, (f2174 | 213470) + ~(f2174 & 213470) + 1 ^ 1868608641, 236731835237641613L);
                     }

                     if (w.a<"Û">((Boolean)w.a<"Û">(this.f2167, 174312564406604366L), 354697271520518137L)) {
                        w.a<"Û">(C0933.f1430, this, w.a<"Û">(var5, 309735875667105070L), 317866513404830971L);
                     }

                     var2++;
                  }

                  if (var2 >= w.a<"Û">((Integer)w.a<"Û">(this.f2163, 174312564406604366L), 260981171345819427L)) {
                     break;
                  }
               }
            }
         }
      }
   }

   public boolean m0913(C0725 var1) {
      class_1792 var2 = w.a<"Û">((C0562)w.a<"Û">(this.f2160, 174312564406604366L), 201496153559581520L);
      int var3 = w.a<"B">(var2, 113439863899466963L);
      int var4 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545;
      if (var3 == ((f2174 | 895300) + ~(f2174 & 895300) + 1 ^ -1869503491)) {
         return (boolean)((f2174 | 954003) + ~(f2174 & 954003) + 1 ^ 1869446101);
      } else {
         w.a<"B">(var3, 357260035653160004L);
         class_3965 var5 = new class_3965(
            w.a<"Û">(var1, 350472241332229716L),
            w.a<"Û">(var1, 327981151163484871L),
            w.a<"Û">(var1, 205613596059609402L),
            (boolean)((f2174 | 553075) + ~(f2174 & 553075) + 1 ^ 1869317429)
         );
         w.a<"Û">(C0933.f1429, (Runnable)() -> w.a<"B">(class_1268.field_5808, var5, 364787408257838011L), 244962080870372939L);
         w.a<"B">(class_1268.field_5808, 183891258734353801L);
         w.a<"B">(var4, 357260035653160004L);
         return (boolean)((f2174 | 330773) + ~(f2174 & 330773) + 1 ^ 1869019474);
      }
   }

   public boolean m0914(class_1657 var1) {
      if (!w.a<"Û">(var1, 270173151359011193L)
         || m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724 == var1
         || w.a<"Û">(var1, 217295983416778904L)) {
         return (boolean)((f2174 | 559235) + ~(f2174 & 559235) + 1 ^ 1869315525);
      } else if (w.a<"Û">(C0933.f1417, var1, 241036547861815495L)) {
         return (boolean)((f2174 | 47536) + ~(f2174 & 47536) + 1 ^ 1868778742);
      } else if (w.a<"Û">(w.a<"B">(var1, 306837952283953468L), 266558347116709042L) != ((f2174 | 84736) + ~(f2174 & 84736) + 1 ^ 1868742215)) {
         return (boolean)((f2174 | 681211) + ~(f2174 & 681211) + 1 ^ 1869189565);
      } else if (w.a<"Û">(this, w.a<"B">(var1, 185161616837346565L), 329448186293542069L)) {
         return (boolean)((f2174 | 559844) + ~(f2174 & 559844) + 1 ^ 1869316002);
      } else if (!w.a<"B">(var1, 130756052256592378L)) {
         return (boolean)((f2174 | 728457) + ~(f2174 & 728457) + 1 ^ 1869146319);
      } else if (w.a<"Û">((Boolean)w.a<"Û">(this.f2166, 174312564406604366L), 354697271520518137L)
         && w.a<"Û">(w.a<"Û">(var1, 224997102751365724L), 328102654916935210L)
            <= w.a<"B">(((long)f2174 | 748513L) + ~((long)f2174 & 748513L) + 1L ^ 4607182420669144743L, 317139102743630955L)) {
         return (boolean)((f2174 | 847294) + ~(f2174 & 847294) + 1 ^ 1869551864);
      } else {
         return (boolean)(w.a<"Û">(
                  var1, m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 239897481044291124L
               )
               <= w.a<"Û">((Float)w.a<"Û">(this.f2161, 174312564406604366L), 149784643039979208L)
            ? (f2174 | 42967) + ~(f2174 & 42967) + 1 ^ 1868780176
            : (f2174 | 880806) + ~(f2174 & 880806) + 1 ^ 1869514208);
      }
   }

   public boolean m0915(class_2338 var1) {
      class_238 var2 = new class_238(var1);
      Iterator var3 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
         191661729848227466L
      );

      while (w.a<"Û">(var3, 333900474771661065L)) {
         class_1297 var4 = (class_1297)w.a<"Û">(var3, 192468336863492695L);
         if (var4 instanceof class_1533 && w.a<"Û">(w.a<"Û">(var4, 225708705569795011L), var2, 133676266014519719L)) {
            return (boolean)((f2174 | 824968) + ~(f2174 & 824968) + 1 ^ 1869571023);
         }
      }

      return (boolean)((f2174 | 963106) + ~(f2174 & 963106) + 1 ^ 1869432676);
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public C0998 m0916() {
      return (C0998)(switch (<unrepresentable>.f2340[w.a<"Û">((C0562)w.a<"Û">(this.f2160, 174312564406604366L), 261689331505236218L)]) {
         case 1 -> new C0445();
         case 2 -> new C0537();
         case 3 -> new C0173();
         case 4 -> new C0504();
         default -> throw new MatchException(null, null);
      });
   }

   public static String HrMmcE5M4fKFBnPYAaNaa6if7X7KHKWp6I79tCkVzuvrdJx5kGrIULzZWVvacRrUiBJGlTRH9eY9gqOVMMYhpuewh7ErY0tfjKH1(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
