package me.mioclient;

import java.util.function.Predicate;

public class C0398 implements Predicate {
   public C0671 f0970;

   public C0398(C0671 var1) {
      this.f0970 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0970.f4651, 174312564406604366L) == C0672.f4559;
   }
}
