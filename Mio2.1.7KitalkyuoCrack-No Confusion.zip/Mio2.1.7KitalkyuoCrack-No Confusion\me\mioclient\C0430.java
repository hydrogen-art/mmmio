package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles.Lookup;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Predicate;

public enum C0430 implements C0196, C0997 {
   f2563("Modules") {
      @Override
      public JsonElement toJson() {
         JsonObject var1 = new JsonObject();
         w.a<"Û">(this, var1, 127603036517976658L);
         Iterator var2 = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

         while (w.a<"Û">(var2, 333900474771661065L)) {
            C1266 var3 = (C1266)w.a<"Û">(var2, 192468336863492695L);
            if (!(var3 instanceof C0601) && !(var3 instanceof C0719)) {
               JsonObject var4 = new JsonObject();
               w.a<"Û">(var4, "enabled", w.a<"B">(w.a<"Û">(var3, 314537768572362865L), 320330632857389983L), 133079996608652196L);
               JsonObject var5 = new JsonObject();
               Iterator var6 = w.a<"Û">(w.a<"Û">(var3, 359176775407045966L), 341496865259068134L);

               while (w.a<"Û">(var6, 333900474771661065L)) {
                  C0015 var7 = (C0015)w.a<"Û">(var6, 192468336863492695L);
                  if (!(var7 instanceof C1118) && !w.a<"Û">(var7, 196897786122219351L) && !w.a<"Û">(var7, 220951769143407106L)) {
                     w.a<"Û">(var5, w.a<"Û">(var7, 375063696801642121L), w.a<"Û">(var7, 387226737920718941L), 130151082343781043L);
                  }
               }

               if (!w.a<"B">(var5, 315391762572328805L)) {
                  w.a<"Û">(var4, "settings", var5, 130151082343781043L);
               }

               w.a<"Û">(var1, w.a<"Û">(var3, 123401924173496230L), var4, 130151082343781043L);
            }
         }

         return var1;
      }

      @Override
      public void fromJson(JsonElement var1) {
         w.a<"Û">(C0514.f0079, w.a<"Û">(var1, 322749330123725882L), 378558773887887177L);
         super.fromJson(var1);
      }

      public static String V0ZZCAcPQqic0oxd6FT3T3dqNcjrBImDOrNRvoiCfDhwrKcibKR5CsMOrFKNODBGJkBytqQtdOLJyJjDHmUXs4K447Smw5UXUFmz(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   },
   f2564("Binds") {
      @Override
      public JsonElement toJson() {
         JsonObject var1 = new JsonObject();
         w.a<"Û">(this, var1, 127603036517976658L);
         Iterator var2 = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

         while (w.a<"Û">(var2, 333900474771661065L)) {
            C1266 var3 = (C1266)w.a<"Û">(var2, 192468336863492695L);
            JsonObject var4 = new JsonObject();
            w.a<"Û">(var4, "key", w.a<"B">(w.a<"Û">(w.a<"Û">(var3, 299774196298174789L), 351828820835781238L), 367942141483020029L), 216400695711138006L);
            w.a<"Û">(
               var4,
               "state",
               w.a<"Û">(w.a<"Û">(w.a<"Û">(w.a<"Û">(var3, 299774196298174789L), 298459350812887843L), 185473300821533709L), 308826267231227763L),
               179792809915938270L
            );
            w.a<"Û">(var4, "mouse", w.a<"B">(w.a<"Û">(w.a<"Û">(var3, 299774196298174789L), 291175998333163099L), 320330632857389983L), 133079996608652196L);
            w.a<"Û">(var1, w.a<"Û">(var3, 123401924173496230L), var4, 130151082343781043L);
         }

         return var1;
      }

      @Override
      public void fromJson(JsonElement var1) {
         w.a<"Û">(C0514.f0079, w.a<"Û">(var1, 322749330123725882L), 328318989810568814L);
         super.fromJson(var1);
      }

      public static String yJ0UBHgc2NEKQPumRKuMoiUMGLRV8KJ9Q7uF3TTg5JEDpoxyyDed8hcbEE4WDaiORcbCjx84JQhHcRbTBFr4CNlCznRFJWscFNK0(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   },
   f2565("Colors") {
      @Override
      public JsonElement toJson() {
         JsonObject var1 = new JsonObject();
         w.a<"Û">(this, var1, 127603036517976658L);
         Iterator var2 = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

         while (w.a<"Û">(var2, 333900474771661065L)) {
            C1266 var3 = (C1266)w.a<"Û">(var2, 192468336863492695L);
            JsonObject var4 = new JsonObject();
            JsonObject var5 = new JsonObject();
            Iterator var6 = w.a<"Û">(w.a<"Û">(var3, 359176775407045966L), 341496865259068134L);

            while (w.a<"Û">(var6, 333900474771661065L)) {
               C0015 var7 = (C0015)w.a<"Û">(var6, 192468336863492695L);
               if (var7 instanceof C1118 && !w.a<"Û">(var7, 220951769143407106L)) {
                  w.a<"Û">(var5, w.a<"Û">(var7, 375063696801642121L), w.a<"Û">(var7, 387226737920718941L), 130151082343781043L);
               }
            }

            w.a<"Û">(var4, "settings", var5, 130151082343781043L);
            if (!w.a<"B">(var4, 315391762572328805L)) {
               w.a<"Û">(var1, w.a<"Û">(var3, 123401924173496230L), var4, 130151082343781043L);
            }
         }

         return var1;
      }

      @Override
      public void fromJson(JsonElement var1) {
         w.a<"Û">(C0514.f0079, w.a<"Û">(var1, 322749330123725882L), (Predicate<C1266>)var0 -> false, 121041249828321204L);
         super.fromJson(var1);
      }

      public static String y8UiZrSJhAjYrZeNos5EsVrIwT3E6oVCQTOrIowoXbdnZPOgKMGFpy3pVupso7ZCk5DzYy3OXyTqe9zDsjFaO8tYyWCNeYUH7uaB(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   },
   f2566("Visuals") {
      public static final Set<Class<? extends C1266>> f1722 = new HashSet<>(
         w.a<"B">(C0879.class, C0719.class, C1323.class, C0818.class, C0602.class, 135271995355708459L)
      );

      @Override
      public JsonElement toJson() {
         JsonObject var1 = new JsonObject();
         w.a<"Û">(this, var1, 127603036517976658L);
         Iterator var2 = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

         while (w.a<"Û">(var2, 333900474771661065L)) {
            C1266 var3 = (C1266)w.a<"Û">(var2, 192468336863492695L);
            JsonObject var4 = new JsonObject();
            boolean var5 = w.a<"Û">(this, var3, 177151439780726748L);
            if (var5) {
               w.a<"Û">(var4, "enabled", w.a<"B">(w.a<"Û">(var3, 314537768572362865L), 320330632857389983L), 133079996608652196L);
            }

            JsonObject var6 = new JsonObject();
            Iterator var7 = w.a<"Û">(w.a<"Û">(var3, 359176775407045966L), 341496865259068134L);

            while (w.a<"Û">(var7, 333900474771661065L)) {
               C0015 var8 = (C0015)w.a<"Û">(var7, 192468336863492695L);
               if (!w.a<"Û">(var8, 220951769143407106L) && (var8 instanceof C1118 || var5)) {
                  w.a<"Û">(var6, w.a<"Û">(var8, 375063696801642121L), w.a<"Û">(var8, 387226737920718941L), 130151082343781043L);
               }
            }

            w.a<"Û">(var4, "settings", var6, 130151082343781043L);
            if (!w.a<"B">(var4, 315391762572328805L)) {
               w.a<"Û">(var1, w.a<"Û">(var3, 123401924173496230L), var4, 130151082343781043L);
            }
         }

         return var1;
      }

      @Override
      public void fromJson(JsonElement var1) {
         w.a<"Û">(C0514.f0079, w.a<"Û">(var1, 322749330123725882L), this::m0731, 121041249828321204L);
         super.fromJson(var1);
      }

      public boolean m0731(C1266 var1) {
         if (var1 instanceof C0601) {
            return true;
         } else {
            return w.a<"Û">(f1722, var1.getClass(), 338145669613544495L)
               ? true
               : w.a<"Û">(var1, 244872541992280135L) == C1045.f3174 || w.a<"Û">(var1, 244872541992280135L) == C1045.f3179;
         }
      }

      public static String iypuZsv9AFFZX0YOxcuAdPOi9KX7cSfUAaHmiVHWawAhvJ5bvzQ3QaLhXibTXdsWIF2my9dvObEmoaSqvCzDOKH6f0qB54OKgYbU(
         Lookup var0, String var1, Class var2, int var3
      ) {
         return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
      }
   },
   f2567("Macro") {
      @Override
      public JsonElement toJson() {
         return w.a<"Û">(C0933.f1421, 330800528984724593L);
      }

      @Override
      public void fromJson(JsonElement var1) {
         synchronized ((List)w.a<"Û">(C0933.f1421, 268370374673263607L)) {
            w.a<"Û">((List)w.a<"Û">(C0933.f1421, 268370374673263607L), 140901994866995976L);
            w.a<"Û">(C0933.f1421, var1, 179035010098517214L);
         }
      }
   },
   f2568("All") {
      @Override
      public JsonElement toJson() {
         return w.a<"Û">(w.a<"Û">(C0933.f1413, 181055702030744503L), 322749330123725882L);
      }
   };

   public final String f2569;
   public final Path f2570;

   public C0430(String var3) {
      this.f2569 = var3;
      this.f2570 = w.a<"Û">(C1165.f0525, w.a<"Û">(var3, 308826267231227763L), 208803259736780592L);
   }

   public Path m3142() {
      return this.f2570;
   }

   public static C0430 m3143(String var0) {
      for (C0430 var4 : w.a<"B">(340007981035209094L)) {
         if (w.a<"Û">(w.a<"Û">(var4, 237166505487588322L), var0, 307662238383225114L)) {
            return var4;
         }
      }

      return null;
   }

   @Override
   public String getName() {
      return this.f2569;
   }

   @Override
   public void fromJson(JsonElement var1) {
      w.a<"Û">(C0933.f1413, var1, 369675286814625117L);
   }

   public void m3144(JsonObject var1) {
      w.a<"Û">(var1, "client", "mio-fabric", 179792809915938270L);
      w.a<"Û">(var1, "category", w.a<"Û">(w.a<"Û">(this, 237166505487588322L), Locale.ROOT, 149330587742400121L), 179792809915938270L);
   }

   public static String w5PCNQONyE8mLNqwfyBLENjuUxDJ48C7sV2em4IcWstZPV4tS4tE6GYUySZMXV7mevlT2rWO5I4AvDZZe2CNCGsSJjcww8FKLxgB(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
