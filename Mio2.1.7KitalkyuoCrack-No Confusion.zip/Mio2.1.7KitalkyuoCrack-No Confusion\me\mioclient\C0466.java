package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0466 implements C0196 {
   f3596("None"),
   f3597("Simple"),
   f3598("Complex"),
   f3599("Both");

   public final String f3600;

   public C0466(String var3) {
      this.f3600 = var3;
   }

   @Override
   public String getName() {
      return this.f3600;
   }

   public static String C10KQa7onfrNF0rR5sRxZQdVjpZForyXQhLMfRfzrO6cYWJgnfZdudWtdfi3lLrFs60SYPTZIAgMO6sexeLbq7ajBfrNY8UimCoZ(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
