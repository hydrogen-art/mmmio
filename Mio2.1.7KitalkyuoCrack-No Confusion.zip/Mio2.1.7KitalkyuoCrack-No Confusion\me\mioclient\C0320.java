package me.mioclient;

import java.util.function.Predicate;

public class C0320 implements Predicate {
   public C0602 f5047;

   public C0320(C0602 var1) {
      this.f5047 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f5047.f3974, 254992554122318132L);
   }
}
