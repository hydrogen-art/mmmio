package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_9334;

public class C0452 extends C1266 {
   public static final C0493 f0085 = C0933.f1409.m2696(C0493.class);
   public final C0015<Integer> f0086;
   public final C0015<Integer> f0087;
   public final C0015<Boolean> f0088;
   public final C0015<Integer> f0089;
   public final C0015<Boolean> f0090;
   public final C0015<Float> f0091;
   public final C0015<Boolean> f0092;
   public final C0015<Float> f0093;
   public final C0083 f0094;
   public final C0083 f0095;
   public final C0083 f0096;
   public boolean f0097;
   public int f0098;
   public final C0907 f0099;
   public static int f0100 = w.a<"B">(3646046318449640948L, 257832362129977838L);

   public C0452() {
      super("Mainhand", "Auto totem for main hand.", C1045.f3172);
      w.a<"B">(this, 242859112966675773L);
      this.f0094 = new C0083();
      this.f0095 = new C0083();
      this.f0096 = new C0083();
      this.f0099 = new C0907() {
         public static int f3026 = w.a<"B">(4214142732055657197L, 257832362129977838L);

         @Override
         public boolean m1211() {
            return (boolean)(w.a<"Û">((Boolean)w.a<"Û">(C0452.this.f0090, 174312564406604366L), 354697271520518137L)
                  && w.a<"Û">((Boolean)w.a<"Û">(C0452.this.f0088, 174312564406604366L), 354697271520518137L)
               ? (f3026 | 960908) + ~(f3026 & 960908) + 1 ^ 879350483
               : (f3026 | 217335) + ~(f3026 & 217335) + 1 ^ 878980009);
         }
      };
      w.a<"Û">(this.f0089, "SwapDelay", 275243698516531804L);
   }

   @Override
   public void onEnable() {
      this.f0098 = (f0100 | 402323) + ~(f0100 & 402323) + 1 ^ 229167186;
   }

   @Override
   public String getInfo() {
      int var1 = w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L)
                     .field_7547,
                  254602599683321059L
               ),
               (Predicate<class_1799>)var1x -> (boolean)(w.a<"Û">(var1x, 222207108884875224L) == w.a<"Û">(this, 163641631675544849L)
                     ? (f0100 | 118254) + ~(f0100 & 118254) + 1 ^ -229588527
                     : (f0100 | 547604) + ~(f0100 & 547604) + 1 ^ -229026006),
               287370376266094532L
            ),
            class_1799::method_7947,
            189770009826906455L
         ),
         188736301400376121L
      );
      return w.a<"B">(var1, 140572902764040146L);
   }

   @C1027
   public void m2168(C0816 var1) {
      int var2 = w.a<"B">(w.a<"Û">(var1, 300389461640657860L), 320703344154791174L)
            && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 341620216578473814L)
            && !w.a<"Û">(f0085, 314537768572362865L)
         ? (f0100 | 390573) + ~(f0100 & 390573) + 1 ^ -229312110
         : (f0100 | 382730) + ~(f0100 & 382730) + 1 ^ -229319884;
      if (var2 != 0 && !w.a<"Û">(var1, 228050418011231981L)) {
         w.a<"Û">(this.f0096, 387780412884547639L);
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = 100
   )
   public void m2169(C0878 var1) {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         this.f0097 = w.a<"Û">(var1, 267634796547971322L);
         w.a<"Û">(this.f0099, 118455394783698079L);
         if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512
            == m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7498) {
            w.a<"Û">(this, 381012872136127771L);
            class_1792 var2 = w.a<"Û">(this, 163641631675544849L);
            if (var2
               != w.a<"Û">(
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
                     ),
                     w.a<"Û">(this, 143079085821296673L),
                     386860178278302175L
                  ),
                  222207108884875224L
               )) {
               if (w.a<"Û">(
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512,
                     121341052621301599L
                  ),
                  330190014994709712L
               )) {
                  w.a<"Û">(this, var2, 202169056452805868L);
               }
            }
         }
      }
   }

   public void m2170(class_1792 var1) {
      int var2 = w.a<"B">(
         (Predicate<class_1799>)var1x -> w.a<"Û">(var1x, var1, 282470456889867724L),
         (boolean)((f0100 | 423187) + ~(f0100 & 423187) + 1 ^ -229148372),
         155900307420311747L
      );
      if (this.f0098 != ((f0100 | 444761) + ~(f0100 & 444761) + 1 ^ 229128856)
         && w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
               this.f0098,
               386860178278302175L
            ),
            var1,
            282470456889867724L
         )
         && var2 != ((f0100 | 319074) + ~(f0100 & 319074) + 1 ^ 229256611)) {
         var2 = this.f0098;
      }

      if (var2 != ((f0100 | 403929) + ~(f0100 & 403929) + 1 ^ 229169688)) {
         if (var2
            < w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512.field_7761,
               281692963295227694L
            )) {
            class_1799 var3 = w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512,
                  var2,
                  246529961808014541L
               ),
               204138723689318293L
            );
            if (!w.a<"Û">(var3, class_9334.field_50075, 130182657201466113L) || this.f0097) {
               if (w.a<"Û">(this.f0094, (long)w.a<"Û">((Integer)w.a<"Û">(this.f0087, 174312564406604366L), 260981171345819427L), 146861306852483676L)
                  && w.a<"Û">(this.f0096, ((long)f0100 | 339479L) + ~((long)f0100 & 339479L) + 1L ^ -229367071L, 309642602085515378L)) {
                  w.a<"B">(var2, w.a<"Û">(this, 143079085821296673L), 259189609675737615L);
                  this.f0098 = var2;
               }

               if (w.a<"B">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690.field_1904,
                     310715252881621742L
                  )
                  && w.a<"Û">(var3, class_9334.field_50075, 130182657201466113L)) {
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                     class_1268.field_5810,
                     114543782118481187L
                  );
               }
            }
         }
      }
   }

   public void m2171() {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0088, 174312564406604366L), 354697271520518137L)) {
         class_1792 var1 = w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
               w.a<"Û">(this, 143079085821296673L),
               386860178278302175L
            ),
            222207108884875224L
         );
         if (var1 == class_1802.field_8288
            && (
               !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 367966343301975358L)
                  || w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 137331122518345133L
                     )
                     != class_1268.field_5808
            )) {
            if ((
                  w.a<"Û">(this.f0099, 174051086148639301L)
                     || w.a<"B">(346651574723755238L) <= w.a<"Û">((Float)w.a<"Û">(this.f0091, 174312564406604366L), 149784643039979208L)
               )
               && w.a<"Û">(this.f0095, (long)w.a<"Û">((Integer)w.a<"Û">(this.f0089, 174312564406604366L), 260981171345819427L), 146861306852483676L)) {
               w.a<"B">(w.a<"Û">(this, 143079085821296673L), 279757124141714355L);
            }
         }
      }
   }

   public class_1792 m2172() {
      int var1 = !w.a<"B">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1765, 320703344154791174L)
            || w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 341620216578473814L)
            || w.a<"Û">(f0085, 314537768572362865L)
            || w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 367966343301975358L)
               && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 137331122518345133L)
                  == class_1268.field_5808
               && w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L),
                  class_9334.field_50075,
                  130182657201466113L
               )
         ? (f0100 | 189523) + ~(f0100 & 189523) + 1 ^ -229382035
         : (f0100 | 170061) + ~(f0100 & 170061) + 1 ^ -229403534;
      int var2 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545;
      return var2 == w.a<"Û">(this, 143079085821296673L)
            && w.a<"Û">((Boolean)w.a<"Û">(this.f0092, 174312564406604366L), 354697271520518137L)
            && w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690.field_1904, 262940020655803083L
            )
            && w.a<"Û">(this, 117274773180378971L)
            && var1 == 0
            && w.a<"B">(346651574723755238L) >= w.a<"Û">((Float)w.a<"Û">(this.f0093, 174312564406604366L), 149784643039979208L)
         ? class_1802.field_8367
         : class_1802.field_8288;
   }

   public boolean m2173() {
      class_1799 var1 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L
      );
      if (w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 159396947398056288L),
         class_9334.field_50075,
         130182657201466113L
      )) {
         return (boolean)((f0100 | 999471) + ~(f0100 & 999471) + 1 ^ -228701167);
      } else {
         return (boolean)(!w.a<"Û">(var1, class_1802.field_8288, 282470456889867724L) && !w.a<"Û">(var1, class_1802.field_8367, 282470456889867724L)
            ? (f0100 | 435230) + ~(f0100 & 435230) + 1 ^ -229136352
            : (f0100 | 881865) + ~(f0100 & 881865) + 1 ^ -228820746);
      }
   }

   public int m2174() {
      return w.a<"Û">((Integer)w.a<"Û">(this.f0086, 174312564406604366L), 260981171345819427L) - ((f0100 | 85278) + ~(f0100 & 85278) + 1 ^ -229621471);
   }

   public static String N5M1x0Q51tAV3aleUueUzoW7k3OgYifQ8snXTMDGEBnlUSOgB1lh2oNhp8viAhdh9GGHRH6ZQrjBTorsRx0xviKzLwVsh1EKmG2V(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
