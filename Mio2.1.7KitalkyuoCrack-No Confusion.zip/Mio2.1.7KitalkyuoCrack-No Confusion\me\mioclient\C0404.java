package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2661;
import net.minecraft.class_2838;
import net.minecraft.class_4325;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_642;

public class C0404 extends C1266 {
   public static final String[] f1651;
   public final C0083 f1652 = new C0083();
   public boolean f1653;
   public boolean f1654;
   public final C0015<Boolean> f1655;
   public static int f1656 = w.a<"B">(8137013584374217301L, 257832362129977838L);

   public C0404() {
      super("IllegalDisconnect", "Makes you disconnect via sending invalid packets so you don't stay logged onto the server.", C1045.f3177);
      w.a<"B">(this, 242859112966675773L);
   }

   @C1027
   public void m2726(C0330 var1) {
      if (this.f1653 && w.a<"Û">(this.f1652, ((long)f1656 | 996185L) + ~((long)f1656 & 996185L) + 1L ^ 435598293L, 309642602085515378L) || this.f1654) {
         w.a<"B">(151327328506222727L);
         this.f1653 = (boolean)((f1656 | 750473) + ~(f1656 & 750473) + 1 ^ 435351789);
         this.f1654 = (boolean)((f1656 | 416466) + ~(f1656 & 416466) + 1 ^ 436197814);
      }
   }

   @C1027
   public void m2727(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2661 && this.f1653) {
         this.f1654 = (boolean)((f1656 | 53838) + ~(f1656 & 53838) + 1 ^ 435769643);
      }
   }

   public void m2728() {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1655, 174312564406604366L), 354697271520518137L) && w.a<"B">(110949539905229901L)) {
         w.a<"B">(151327328506222727L);
      } else {
         w.a<"B">(163001575677976185L);
         this.f1653 = (boolean)((f1656 | 11203) + ~(f1656 & 11203) + 1 ^ 435792038);
         w.a<"Û">(this.f1652, 387780412884547639L);
      }
   }

   public static void m2729() {
      w.a<"B">(new class_2838((f1656 | 489695) + ~(f1656 & 489695) + 1 ^ -436140988), 384821682750494902L);
   }

   public static void m2730() {
      if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724 != null
         && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687 != null) {
         class_642 var0 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 302273445978732799L);
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 362470601343962792L);
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 309356591012113187L);
         class_442 var1 = new class_442();
         if (var0 != null && w.a<"Û">(var0, 134963918446646904L)) {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, new class_4325(var1), 304438186446504550L
            );
         } else {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, new class_500(var1), 304438186446504550L
            );
         }
      }
   }

   public static boolean m2731() {
      String var0 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944, 239081674629979353L
      );
      if (var0 == null) {
         var0 = "";
      }

      String[] var1 = f1651;
      int var2 = var1.length;

      for (int var3 = (f1656 | 577047) + ~(f1656 & 577047) + 1 ^ 435244403; var3 < var2; var3++) {
         String var4 = var1[var3];
         if (w.a<"Û">(var0, var4, 160084314699716367L)) {
            return (boolean)((f1656 | 504848) + ~(f1656 & 504848) + 1 ^ 436090741);
         }
      }

      return (boolean)((f1656 | 691286) + ~(f1656 & 691286) + 1 ^ 435359538);
   }

   static {
      String[] var10000 = new String[(f1656 | 185093) + ~(f1656 & 185093) + 1 ^ 435900512];
      var10000[(f1656 | 298883) + ~(f1656 & 298883) + 1 ^ 436014311] = "ZenithProxy";
      f1651 = var10000;
   }

   public static String ZK85hm07tHWdz86vfVkimpDW1o5eIpLWwthjDk27Ly3EIX7HC4JotiB0MLkcFf8f1WeT7X967hMARbvp10lrF9i8cZgtwpSCeMEO(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
