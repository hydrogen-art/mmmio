package me.mioclient;

import java.util.function.Predicate;

public class C0234 implements Predicate {
   public C1051 f0843;

   public C0234(C1051 var1) {
      this.f0843 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0843.f0312, 254992554122318132L);
   }
}
