package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1829;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_742;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public class C0145 extends C1266 {
   public final C0015<Float> f3800;
   public final C0015<Float> f3801;
   public final C0015<Float> f3802;
   public final C0015<Boolean> f3803;
   public final C0015<Boolean> f3804;
   public final C0015<Boolean> f3805;
   public final C0015<Boolean> f3806;
   public final C0015<Boolean> f3807;
   public class_742 f3808;
   public static int f3809 = w.a<"B">(98271336987415704L, 257832362129977838L);

   public C0145() {
      super("AimAssist", "Helps you aiming at players.", C1045.f3172);
      w.a<"B">(this, 242859112966675773L);
   }

   @C1027
   public void m3570(C1358 var1) {
      if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 == null) {
         if (w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L),
               222207108884875224L
            ) instanceof class_1743
            || w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L),
               222207108884875224L
            ) instanceof class_1829
            || !w.a<"Û">((Boolean)w.a<"Û">(this.f3803, 174312564406604366L), 354697271520518137L)) {
            if (this.f3808 == null || !w.a<"Û">((Boolean)w.a<"Û">(this.f3805, 174312564406604366L), 354697271520518137L)) {
               this.f3808 = (class_742)w.a<"Û">(
                  w.a<"Û">(
                     w.a<"Û">(
                        w.a<"Û">(
                           w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                                 188438576288929642L
                              ),
                              110814793610710346L
                           ),
                           w.a<"B">(
                              (Function<class_742, Float>)var0 -> w.a<"B">(
                                    w.a<"Û">(
                                       m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                       var0,
                                       274649721728910700L
                                    ),
                                    243402859552372891L
                                 ),
                              224107444354928270L
                           ),
                           267272267864878514L
                        ),
                        this::m3571,
                        287370376266094532L
                     ),
                     169842024635180775L
                  ),
                  null,
                  237682386832069967L
               );
            }

            if (!w.a<"Û">(this, this.f3808, 160309289509609054L)) {
               this.f3808 = null;
            } else if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1692 != this.f3808) {
               if (w.a<"Û">((Boolean)w.a<"Û">(this.f3807, 174312564406604366L), 354697271520518137L)) {
                  float[] var2 = w.a<"B">(w.a<"Û">(w.a<"Û">(this.f3808, 378503396612854214L), 376895844755266015L), 213766782372904553L);
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                     var2[(f3809 | 748439) + ~(f3809 & 748439) + 1 ^ 664397540],
                     368221038918368764L
                  );
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                     var2[(f3809 | 33025) + ~(f3809 & 33025) + 1 ^ 663882867],
                     209955992115144040L
                  );
               } else {
                  double var5 = w.a<"B">(this.f3808, 368675336598992950L);
                  if (var5 > w.a<"B">(((long)f3809 | 337171L) + ~((long)f3809 & 337171L) + 1L ^ 4607182419464267872L, 317139102743630955L)
                     || var5 < w.a<"B">(-4616189618054758400L, 317139102743630955L)) {
                     float var4 = (float)(
                        var5
                           * (double)w.a<"Û">((Float)w.a<"Û">(this.f3801, 174312564406604366L), 149784643039979208L)
                           * w.a<"B">(((long)f3809 | 397118L) + ~((long)f3809 & 397118L) + 1L ^ 4576918229839282765L, 317139102743630955L)
                     );
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                        w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                              C0094.m1872(),
                              111737428835766792L
                           )
                           - var4,
                        368221038918368764L
                     );
                  }
               }
            }
         }
      }
   }

   public boolean m3571(class_1297 var1) {
      return (boolean)(var1 instanceof class_1657
            && var1 != m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
            && w.a<"Û">(var1, 133372882497935473L)
            && (!w.a<"Û">((Boolean)w.a<"Û">(this.f3804, 174312564406604366L), 354697271520518137L) || !w.a<"Û">(var1, 173883959121097721L))
            && w.a<"B">(var1, (double)w.a<"Û">((Float)w.a<"Û">(this.f3802, 174312564406604366L), 149784643039979208L), 168057120568091641L)
            && w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, var1, 274649721728910700L
               )
               <= w.a<"Û">((Float)w.a<"Û">(this.f3800, 174312564406604366L), 149784643039979208L)
            && (
               !w.a<"Û">((Boolean)w.a<"Û">(this.f3806, 174312564406604366L), 354697271520518137L)
                  || !w.a<"Û">(C0933.f1417, w.a<"Û">(w.a<"Û">((class_1657)var1, 138826997201410603L), 211085733983653208L), 225253295937045434L)
            )
            && w.a<"Û">(this, var1, 192597326778622397L)
         ? (f3809 | 174833) + ~(f3809 & 174833) + 1 ^ 663758723
         : (f3809 | 865361) + ~(f3809 & 865361) + 1 ^ 664779042);
   }

   public boolean m3572(class_1297 var1) {
      class_243 var2 = new class_243(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L),
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L)
            + (double)w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 325475311210298956L
            ),
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L)
      );
      class_243 var3 = new class_243(w.a<"Û">(var1, 232310121460392074L), w.a<"Û">(var1, 113892722580447470L), w.a<"Û">(var1, 204214536009510197L));
      if (w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
               new class_3959(
                  var2,
                  var3,
                  class_3960.field_17558,
                  class_242.field_1348,
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
               ),
               146985274835351625L
            ),
            189274766630417875L
         )
         == class_240.field_1333) {
         return (boolean)((f3809 | 751553) + ~(f3809 & 751553) + 1 ^ 664402611);
      } else {
         class_243 var4 = new class_243(
            w.a<"Û">(var1, 232310121460392074L),
            w.a<"Û">(var1, 113892722580447470L) + (double)w.a<"Û">(var1, 148101198818647701L),
            w.a<"Û">(var1, 204214536009510197L)
         );
         return (boolean)(w.a<"Û">(
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                     new class_3959(
                        var2,
                        var4,
                        class_3960.field_17558,
                        class_242.field_1348,
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
                     ),
                     146985274835351625L
                  ),
                  189274766630417875L
               )
               == class_240.field_1333
            ? (f3809 | 368589) + ~(f3809 & 368589) + 1 ^ 664212159
            : (f3809 | 733496) + ~(f3809 & 733496) + 1 ^ 664386635);
      }
   }

   public static double m3573(class_1297 var0) {
      return (
               (double)(
                        w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                              C0094.m1872(),
                              111737428835766792L
                           )
                           - w.a<"B">(var0, 344017412859751495L)
                     )
                     % (double)C1074.f4548
                  + w.a<"B">(((long)f3809 | 826071L) + ~((long)f3809 & 826071L) + 1L ^ 4647961106715645860L, 317139102743630955L)
            )
            % (double)C1074.f4548
         - w.a<"B">(((long)f3809 | 939704L) + ~((long)f3809 & 939704L) + 1L ^ 4640537204204821451L, 317139102743630955L);
   }

   public static boolean m3574(class_1297 var0, double var1) {
      var1 = (double)((float)(var1 * C1074.f4550));
      double var3 = (
               (double)(
                        w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                              C0094.m1872(),
                              111737428835766792L
                           )
                           - w.a<"B">(var0, 344017412859751495L)
                     )
                     % (double)C1074.f4548
                  + w.a<"B">(((long)f3809 | 49306L) + ~((long)f3809 & 49306L) + 1L ^ 4647961106714873321L, 317139102743630955L)
            )
            % (double)C1074.f4548
         - w.a<"B">(((long)f3809 | 953301L) + ~((long)f3809 & 953301L) + 1L ^ 4640537204204766886L, 317139102743630955L);
      return (boolean)((!(var3 > 0.0) || !(var3 < var1)) && (!(-var1 < var3) || !(var3 < 0.0))
         ? (f3809 | 528382) + ~(f3809 & 528382) + 1 ^ 664437389
         : (f3809 | 481552) + ~(f3809 & 481552) + 1 ^ 664130658);
   }

   public static float m3575(class_1297 var0) {
      double var1 = w.a<"Û">(var0, 232310121460392074L)
         - w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L);
      double var3 = w.a<"Û">(var0, 204214536009510197L)
         - w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L);
      double var5 = w.a<"B">(var1, var3, 370151239157781531L)
         * w.a<"B">(((long)f3809 | 341760L) + ~((long)f3809 & 341760L) + 1L ^ 4633260482005832592L, 317139102743630955L);
      return (float)(var5 * w.a<"B">(-4616189618054758400L, 317139102743630955L));
   }

   public static String HJktOqYZMJBtlKmeNPe4IXkExbnzuudPmXsZndW2vgioHKZM5EdSygn0kQPd3GlEjX6UHwVgBuwSc1A3LgI3uWGa0tr7AhJ7Mpe1(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
