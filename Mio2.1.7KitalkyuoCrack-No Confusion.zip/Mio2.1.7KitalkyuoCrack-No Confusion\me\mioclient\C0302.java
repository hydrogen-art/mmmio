package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_304;
import net.minecraft.class_3675.class_306;
import net.minecraft.class_3675.class_307;

public class C0302 implements C0045 {
   public static int f1916 = w.a<"B">(4010060990589247511L, 257832362129977838L);

   public static String m0803(C1088 var0) {
      return w.a<"B">(w.a<"Û">(var0, 351828820835781238L), w.a<"Û">(var0, 291175998333163099L), 257767192109484343L);
   }

   public static String m0804(int var0, boolean var1) {
      if (var0 < 0) {
         return "NONE";
      } else {
         return var1
            ? new C1002().m2578(var0).m2593("MOUSE\u0001")
            : w.a<"Û">(
               w.a<"Û">(
                  w.a<"Û">(
                     w.a<"Û">(w.a<"B">(var0, (f1916 | 824287) + ~(f1916 & 824287) + 1 ^ -1726083851, 175867427169626250L), 312457226999331692L),
                     "key.keyboard.",
                     "",
                     302211762549064959L
                  ),
                  ".",
                  "_",
                  328425598364162988L
               ),
               298005080521964688L
            );
      }
   }

   public static boolean m0805(C1088 var0) {
      return w.a<"Û">(var0, 291175998333163099L)
         ? w.a<"B">(w.a<"Û">(var0, 351828820835781238L), 320254626790549447L)
         : w.a<"B">(w.a<"Û">(var0, 351828820835781238L), 220357761788284834L);
   }

   public static boolean m0806(class_304 var0) {
      class_306 var1 = var0.field_1655;
      return w.a<"Û">(var1, 156609361012485732L) == class_307.field_1672
         ? w.a<"B">(w.a<"Û">(var1, 125480955942613089L), 320254626790549447L)
         : w.a<"B">(w.a<"Û">(var1, 125480955942613089L), 220357761788284834L);
   }

   public static boolean m0807(int var0) {
      return (boolean)(w.a<"B">(
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
                  357688778031378998L
               ),
               var0,
               198847444250927818L
            )
            == ((f1916 | 408274) + ~(f1916 & 408274) + 1 ^ -1726700039)
         ? (f1916 | 822245) + ~(f1916 & 822245) + 1 ^ -1726081842
         : (f1916 | 409901) + ~(f1916 & 409901) + 1 ^ -1726685689);
   }

   public static boolean m0808(int var0) {
      return (boolean)(w.a<"B">(
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
                  357688778031378998L
               ),
               var0,
               310841729015824326L
            )
            == ((f1916 | 946696) + ~(f1916 & 946696) + 1 ^ -1726157533)
         ? (f1916 | 643161) + ~(f1916 & 643161) + 1 ^ -1726263438
         : (f1916 | 350190) + ~(f1916 & 350190) + 1 ^ -1726494524);
   }

   public static boolean m0809() {
      return (boolean)(w.a<"B">(
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
                  357688778031378998L
               ),
               (f1916 | 308771) + ~(f1916 & 308771) + 1 ^ -1726601124,
               198847444250927818L
            )
            == ((f1916 | 512234) + ~(f1916 & 512234) + 1 ^ -1726656575)
         ? (f1916 | 871326) + ~(f1916 & 871326) + 1 ^ -1725967179
         : (f1916 | 285700) + ~(f1916 & 285700) + 1 ^ -1726561490);
   }

   public static boolean m0810() {
      return (boolean)(w.a<"B">(
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
                  357688778031378998L
               ),
               (f1916 | 724617) + ~(f1916 & 724617) + 1 ^ -1726377737,
               198847444250927818L
            )
            == ((f1916 | 276245) + ~(f1916 & 276245) + 1 ^ -1726568386)
         ? (f1916 | 86908) + ~(f1916 & 86908) + 1 ^ -1726755753
         : (f1916 | 849513) + ~(f1916 & 849513) + 1 ^ -1726060221);
   }

   public static boolean m0811() {
      return (boolean)(w.a<"B">(
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
                  357688778031378998L
               ),
               (f1916 | 568269) + ~(f1916 & 568269) + 1 ^ -1726335567,
               198847444250927818L
            )
            == ((f1916 | 268546) + ~(f1916 & 268546) + 1 ^ -1726577111)
         ? (f1916 | 125530) + ~(f1916 & 125530) + 1 ^ -1726777999
         : (f1916 | 642958) + ~(f1916 & 642958) + 1 ^ -1726263132);
   }

   public static String qU0SDGcCiIMnrF5vodSidTp6RtHmnTGIijL8O9HA6sKoZ96e3ram42z5YqOxFB4uZ6losJOULAWXDquZ7vxEZawjAtSXzInxbzbg(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
