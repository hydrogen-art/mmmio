package me.mioclient;

import java.util.function.Predicate;

public class C0150 implements Predicate {
   public C0018 f0591;

   public C0150(C0018 var1) {
      this.f0591 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0591.f4095, 174312564406604366L) == C0020.f0357;
   }
}
