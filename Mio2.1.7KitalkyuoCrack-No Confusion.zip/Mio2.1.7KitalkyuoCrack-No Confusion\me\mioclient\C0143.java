package me.mioclient;

import java.util.function.Predicate;

public class C0143 implements Predicate {
   public C0879 f4872;

   public C0143(C0879 var1) {
      this.f4872 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4872.f3764, 254992554122318132L);
   }
}
