package me.mioclient;

import net.minecraft.class_437;

public final class C0259 extends C0257 {
   public C0259(class_437 var1, class_437 var2) {
      super(var1, var2);
   }
}
