package me.mioclient;

public class C0487 extends C1180 {
   public String f2984;

   public C0487(String var1) {
      this.f2984 = var1;
   }

   public String m1205() {
      return this.f2984;
   }

   public void m1206(String var1) {
      this.f2984 = var1;
   }
}
