package me.mioclient;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.invoke.MethodHandles.Lookup;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;

public class C0176 {
   public static int f3112 = w.a<"B">(8313612897807554552L, 257832362129977838L);

   public static Path m3305(Path var0, String... var1) {
      if (w.a<"Û">(w.a<"Û">(var0, 318068064568792515L), 317839649527142638L)) {
         return var0;
      } else {
         String[] var2 = var1;
         int var3 = var1.length;

         for (int var4 = (f3112 | 424393) + ~(f3112 & 424393) + 1 ^ 298501549; var4 < var3; var4++) {
            String var5 = var2[var4];
            String var6 = new C1002().m2591(var5).m2591(var0.toString()).m2593("\u0001\u0001");
            Path var7 = w.a<"B">(var6, new String[(f3112 | 579387) + ~(f3112 & 579387) + 1 ^ 298085215], 277843452267691271L);
            if (w.a<"Û">(w.a<"Û">(var7, 318068064568792515L), 317839649527142638L)) {
               return var7;
            }
         }

         return var0;
      }
   }

   public static void m3306(Path var0, String var1) {
      w.a<"B">(var0, w.a<"Û">(var1, StandardCharsets.UTF_8, 330169314896052399L), 146599005179503313L);
   }

   public static void m3307(Path var0, byte[] var1) {
      FileOutputStream var2 = null;

      try {
         var2 = new FileOutputStream(w.a<"Û">(var0, 318068064568792515L));
         w.a<"Û">(var2, var1, 232230478254759155L);
         w.a<"Û">(var2, 233266160820828686L);
      } finally {
         if (var2 != null) {
            try {
               w.a<"Û">(var2, 233266160820828686L);
            } catch (Exception var9) {
            }
         }
      }
   }

   public static byte[] m3308(Path var0) {
      FileInputStream var1 = null;
      B var2 = null;

      try {
         var1 = new FileInputStream(w.a<"Û">(var0, 318068064568792515L));
         var2 = w.a<"Û">(var1, 379992344969390718L);
      } finally {
         if (var1 != null) {
            try {
               w.a<"Û">(var1, 270924840618669086L);
            } catch (Exception var9) {
            }
         }
      }

      return (byte[])var2;
   }

   public static String m3309(Path var0) {
      return new String(w.a<"B">(var0, 151569379125095176L), StandardCharsets.UTF_8);
   }

   public static String mtOPxWVuI1JwEVEb009pfvxD6wBLEXAjeF78tSuZEfdxRLhzXzJw1CbZKb1gOq3lU2fyqq1x5R37f7WqK84h8h4rKrIO9AJI99v3(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
