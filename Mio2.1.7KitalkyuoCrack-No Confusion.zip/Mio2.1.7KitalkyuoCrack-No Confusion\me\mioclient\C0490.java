package me.mioclient;

public record C0490() {
   public final int f3726;
   public final int f3727;
   public static int f3728 = w.a<"B">(6007391701239092373L, 257832362129977838L);

   public C0490(int var1, int var2) {
      this.f3726 = var1;
      this.f3727 = var2;
   }

   public double m1548(C0490 var1) {
      return w.a<"B">(
            (double)(this.f3726 - var1.f3726),
            w.a<"B">(((long)f3728 | 121142L) + ~((long)f3728 & 121142L) + 1L ^ 4611686018948233015L, 317139102743630955L),
            293138351106450517L
         )
         + w.a<"B">(
            (double)(this.f3727 - var1.f3727),
            w.a<"B">(((long)f3728 | 117796L) + ~((long)f3728 & 117796L) + 1L ^ 4611686018948227621L, 317139102743630955L),
            293138351106450517L
         );
   }

   public double m1549(C0490 var1) {
      return w.a<"B">(w.a<"Û">(this, var1, 351139086407903379L), 372068007575431175L);
   }

   public C0490 m1550(C0490 var1) {
      return new C0490(this.f3726 + var1.f3726, this.f3727 + var1.f3727);
   }

   public int m1551() {
      return this.f3726;
   }

   public int m1552() {
      return this.f3727;
   }
}
