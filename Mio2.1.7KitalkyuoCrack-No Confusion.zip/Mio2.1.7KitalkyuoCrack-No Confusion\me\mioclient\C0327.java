package me.mioclient;

import java.util.function.Predicate;

public class C0327 implements Predicate {
   public C0366 f4020;

   public C0327(C0366 var1) {
      this.f4020 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4020.f3251, 254992554122318132L);
   }
}
