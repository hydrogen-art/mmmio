package me.mioclient;

import net.minecraft.class_1297;
import net.minecraft.class_4587;

public class C0338 extends C1180 {
   public final class_4587 f5092;
   public final class_1297 f5093;

   public C0338(class_4587 var1, class_1297 var2) {
      this.f5092 = var1;
      this.f5093 = var2;
   }

   public class_4587 m2076() {
      return this.f5092;
   }

   public class_1297 m2077() {
      return this.f5093;
   }
}
