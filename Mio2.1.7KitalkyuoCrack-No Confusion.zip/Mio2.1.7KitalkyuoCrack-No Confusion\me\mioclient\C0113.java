package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1451;
import net.minecraft.class_1453;
import net.minecraft.class_1493;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;

public class C0113 extends C1266 {
   public final C0015<C0114> f1040;
   public final C0015<Float> f1041;
   public final C0015<Integer> f1042;
   public final C0015<Float> f1043;
   public final C0015<Boolean> f1044;
   public final C0015<Boolean> f1045;
   public final C0015<Boolean> f1046;
   public final C0015<Boolean> f1047;
   public final C0015<Boolean> f1048;
   public final C0083 f1049;
   public static int f1050 = w.a<"B">(6599652306708015043L, 257832362129977838L);

   public C0113() {
      super("AutoTame", "Automatically interacts with tame-able entities.", C1045.f3176);
      w.a<"B">(this, 242859112966675773L);
      this.f1049 = new C0083();
   }

   @C1027
   public void m0512(C1095 var1) {
      if (w.a<"Û">(var1, 336212328865671254L) != C0277.f4215) {
         if (w.a<"Û">(
            this.f1049, (double)w.a<"Û">((Float)w.a<"Û">(this.f1043, 174312564406604366L), 149784643039979208L), TimeUnit.SECONDS, 215737872562411156L
         )) {
            int var2 = (f1050 | 520843) + ~(f1050 & 520843) + 1 ^ -1844653231;
            Iterator var3 = w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
               191661729848227466L
            );

            while (w.a<"Û">(var3, 333900474771661065L)) {
               class_1297 var4 = (class_1297)w.a<"Û">(var3, 192468336863492695L);
               if (var4 instanceof class_1321) {
                  class_1321 var5 = (class_1321)var4;
                  if (w.a<"Û">(this, var5, 382816328295158198L)
                     && w.a<"Û">(
                           var4,
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                           239298884281641152L
                        )
                        <= w.a<"Û">((Float)w.a<"Û">(this.f1041, 174312564406604366L), 149784643039979208L)) {
                     class_243 var6 = w.a<"Û">((C0114)w.a<"Û">(this.f1040, 174312564406604366L), var5, 146508911124667883L);
                     if (var6 != null) {
                        var2++;
                        if (w.a<"Û">((Boolean)w.a<"Û">(this.f1044, 174312564406604366L), 354697271520518137L)) {
                           w.a<"Û">(var1, w.a<"B">(var6, 213766782372904553L), 260052617773785522L);
                        }

                        if (var2 >= w.a<"Û">((Integer)w.a<"Û">(this.f1042, 174312564406604366L), 260981171345819427L)) {
                           break;
                        }
                     }
                  }
               }
            }

            w.a<"Û">(this.f1049, 387780412884547639L);
         }
      }
   }

   public boolean m0513(class_1321 var1) {
      return (boolean)((!(var1 instanceof class_1451) || !w.a<"Û">((Boolean)w.a<"Û">(this.f1047, 174312564406604366L), 354697271520518137L))
            && (!(var1 instanceof class_1493) || !w.a<"Û">((Boolean)w.a<"Û">(this.f1046, 174312564406604366L), 354697271520518137L))
            && (!(var1 instanceof class_1453) || !w.a<"Û">((Boolean)w.a<"Û">(this.f1048, 174312564406604366L), 354697271520518137L))
         ? (f1050 | 510978) + ~(f1050 & 510978) + 1 ^ -1844646440
         : (f1050 | 749670) + ~(f1050 & 749670) + 1 ^ -1845472835);
   }

   public static Predicate<class_1799> m0514(class_1321 var0) {
      if (var0 instanceof class_1493) {
         return var0x -> w.a<"Û">(var0x, class_1802.field_8606, 282470456889867724L);
      } else if (var0 instanceof class_1453) {
         return var0x -> w.a<"Û">(
               w.a<"B">(class_1802.field_8317, class_1802.field_46250, class_1802.field_46249, class_1802.field_8309, 319034520487861803L),
               w.a<"Û">(var0x, 222207108884875224L),
               144617673607550225L
            );
      } else {
         w.a<"B">(var0, 131918113315390561L);
         return var0::method_6481;
      }
   }

   public static String a99jRGYfjsD0xs4gygUcQolI50ijrFgx7QlqLon1mNOqxl0HhnAcwMBVxXP1yl9UTwURfmQ2kbfbKDV9VQEI3hO5nunovFgVxEWC(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
