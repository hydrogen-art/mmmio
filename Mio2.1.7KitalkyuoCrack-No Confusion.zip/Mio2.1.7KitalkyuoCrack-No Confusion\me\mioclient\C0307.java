package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public class C0307 extends C1266 {
   public static int f1940 = w.a<"B">(4966187228166551334L, 257832362129977838L);

   public C0307() {
      super("NoJumpDelay", "Removes the jumping delay when sprint-jumping.", C1045.f3175);
   }

   public static String zsIJovKmaDzqCgd4erLO9tZJRNqr1uQBeosTe8S5D0xcXn7wnrABsLX9QZuwc0oYp0EjP53E2a7VLMWChiVbpFkuf2h0kkjq0Rb3(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
