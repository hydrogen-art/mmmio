package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_746;

public class C0285 extends C1266 {
   public final C0015<Boolean> f1456;
   public final C0015<Boolean> f1457;
   public final C0015<Boolean> f1458;
   public final C0015<Boolean> f1459;
   public final C0015<Float> f1460;
   public final C0015<Boolean> f1461;
   public static int f1462 = w.a<"B">(366876628630124083L, 257832362129977838L);

   public C0285() {
      super("SelfWeb", "Places a cobweb at your feet.", C1045.f3172);
      w.a<"B">(this, 242859112966675773L);
   }

   @C1027
   public void m0605(C0153 var1) {
      class_1297 var2 = w.a<"Û">(this, this.f1460, 259085342390804439L);
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1459, 174312564406604366L), 354697271520518137L)) {
         if (var2 != null) {
            w.a<"Û">(this, var1, 157928180511238753L);
         }
      } else {
         w.a<"Û">(this, var1, 157928180511238753L);
      }
   }

   public void m0606(C0153 var1) {
      if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 179114946195012748L)
         && (w.a<"Û">(C0933.f1419, 149866353757505195L) || !w.a<"Û">((Boolean)w.a<"Û">(this.f1458, 174312564406604366L), 354697271520518137L))) {
         class_2338 var2 = w.a<"B">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L),
            274163478939689086L
         );
         class_2680 var3 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var2, 310987074049434965L
         );
         if (w.a<"Û">(var3, 289106033197017315L)
            && !w.a<"Û">(var3, 172852136856151051L)
            && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)) {
            int var4 = w.a<"B">(class_1802.field_8786, 113439863899466963L);
            int var5 = w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
               )
               .field_7545;
            if (var4 == ((f1462 | 311294) + ~(f1462 & 311294) + 1 ^ 2047395987)) {
               w.a<"B">(
                  w.a<"Û">(w.a<"B">(w.a<"Û">(this, 248211090350577353L), 228465064790135899L), " is out of blocks!", 194629304146735395L),
                  w.a<"B">((f1462 | 919197) + ~(f1462 & 919197) + 1 ^ 2046980593, 289296048454852994L),
                  C0639.f3880,
                  211469761772001922L
               );
               w.a<"Û">(this, 155417974908982175L);
            } else {
               class_2350 var6 = w.a<"B">(var2, 128710894506339948L);
               if (var6 != null) {
                  w.a<"B">(var4, 279757124141714355L);
                  class_238 var7 = w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L
                  );
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                     new class_238(0.0, 0.0, 0.0, 0.0, 0.0, 0.0),
                     191239946377421760L
                  );
                  w.a<"B">(var2, var6, (boolean)((f1462 | 702009) + ~(f1462 & 702009) + 1 ^ -2047263061), class_1268.field_5808, 360863021140479360L);
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, var7, 191239946377421760L
                  );
                  w.a<"B">(var5, 279757124141714355L);
                  if (w.a<"Û">((Boolean)w.a<"Û">(this.f1456, 174312564406604366L), 354697271520518137L)) {
                     C1071 var10000 = C0933.f1412;
                     float[] var10001 = new float[(f1462 | 153725) + ~(f1462 & 153725) + 1 ^ -2047749907];
                     var10001[(f1462 | 484414) + ~(f1462 & 484414) + 1 ^ -2047546196] = w.a<"Û">(var1, 322783360730409578L);
                     var10001[(f1462 | 354415) + ~(f1462 & 354415) + 1 ^ -2047418116] = (float)C1074.f4547;
                     w.a<"Û">(var10000, var10001, (f1462 | 374397) + ~(f1462 & 374397) + 1 ^ -2047459606, 236731835237641613L);
                  }

                  if (w.a<"Û">((Boolean)w.a<"Û">(this.f1457, 174312564406604366L), 354697271520518137L)) {
                     w.a<"Û">(this, 155417974908982175L);
                  }
               }
            }
         }
      }
   }

   public class_1297 m0607(C0015<Float> var1) {
      Stream var10000 = w.a<"Û">(
         w.a<"B">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
               181298136528682717L
            ),
            (boolean)((f1462 | 310258) + ~(f1462 & 310258) + 1 ^ -2047397024),
            216516081985823573L
         ),
         (Predicate<class_1297>)var2 -> (boolean)(var2
                     != m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
                  && w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                        var2,
                        274649721728910700L
                     )
                     <= w.a<"Û">((Float)w.a<"Û">(var1, 174312564406604366L), 149784643039979208L)
                  && w.a<"Û">(this, var2, 142237363966664775L)
                  && var2 instanceof class_1657
                  && !w.a<"Û">(C0933.f1417, w.a<"Û">(w.a<"Û">(var2, 291295238331520790L), 286788181028845103L), 225253295937045434L)
                  && w.a<"Û">(var2, 133372882497935473L)
               ? (f1462 | 549980) + ~(f1462 & 549980) + 1 ^ -2047087409
               : (f1462 | 367908) + ~(f1462 & 367908) + 1 ^ -2047470154),
         287370376266094532L
      );
      class_746 var10001 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724;
      w.a<"B">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 131918113315390561L);
      return (class_1297)w.a<"Û">(w.a<"Û">(var10000, w.a<"B">(var10001::method_5858, 224107444354928270L), 234479002390850050L), null, 237682386832069967L);
   }

   public boolean m0608(class_1297 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1461, 174312564406604366L), 354697271520518137L)) {
         return (boolean)(w.a<"Û">(var1, 113892722580447470L)
               >= w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L)
            ? (f1462 | 807228) + ~(f1462 & 807228) + 1 ^ -2046830161
            : (f1462 | 457096) + ~(f1462 & 457096) + 1 ^ -2047512294);
      } else {
         return (boolean)(w.a<"Û">(var1, 113892722580447470L)
               > w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L)
            ? (f1462 | 417139) + ~(f1462 & 417139) + 1 ^ -2047486496
            : (f1462 | 973895) + ~(f1462 & 973895) + 1 ^ -2046995243);
      }
   }

   public static String rlxMtqN7VCZWRHWdfxs52RXU87MZSPxBVNjU16iTvuOXRQq6XHDLVvMTBTUXggqUdtKcKF9tRW5itlEHEwtvJ7HbQqXdLgO3j29u(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
