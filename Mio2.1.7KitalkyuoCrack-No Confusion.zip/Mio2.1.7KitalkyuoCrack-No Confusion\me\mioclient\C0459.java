package me.mioclient;

import me.mioclient.mixin.ducks.DuckEndCrystalEntityRenderer;
import net.minecraft.class_1511;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_892;
import org.joml.Quaternionf;

public class C0459 implements C0967<class_1511> {
   public static C1055 ac = C0933.f1409.m2696(C1055.class);
   public static C0038 animations = C0933.f1409.m2696(C0038.class);
   public static final float f1907 = (float)Math.sin(Math.PI / 4);
   public final Quaternionf f1908 = new Quaternionf();
   public class_1511 last;

   public void m0799(class_1511 var1, float var2, class_4587 var3) {
      this.last = var1;
      C0550 var4 = new C0550(var3, C0595.f4921);
      DuckEndCrystalEntityRenderer var5 = (DuckEndCrystalEntityRenderer)class_310.method_1551().method_1561().method_3953(var1);
      var3.method_22903();
      float var6 = class_892.method_23155(var1, var2);
      float var7 = ((float)var1.field_7034 + var2) * 3.0F;
      var3.method_22905(2.0F * this.m0800(), 2.0F * this.m0800(), 2.0F * this.m0800());
      var3.method_22904(0.0, -C1074.f4550, 0.0);
      if (var1.method_6836() && !animations.m0706()) {
         C0297.m2458(var4, var5.mio$getBottom());
      }

      var3.method_22907(class_7833.field_40716.rotationDegrees(var7 * this.m0801()));
      var3.method_46416(0.0F, 1.5F + var6 / 2.0F, 0.0F);
      var3.method_22907(this.f1908.setAngleAxis((float) (Math.PI / 3), f1907, 0.0F, f1907));
      if (!animations.m0704()) {
         C0297.m2458(var4, var5.mio$getFrame());
      }

      var3.method_22905(0.875F, 0.875F, 0.875F);
      var3.method_22907(this.f1908.setAngleAxis((float) (Math.PI / 3), f1907, 0.0F, f1907));
      var3.method_22907(class_7833.field_40716.rotationDegrees(var7 * this.m0801()));
      if (!animations.m0703()) {
         C0297.m2458(var4, var5.mio$getFrame());
      }

      var3.method_22909();
   }

   public float m0800() {
      return animations.isToggled() && animations.f1660.getValue() ? animations.f1663.getValue() : 1.0F;
   }

   public float m0801() {
      if (this.last.field_6012 < 10 && ac.isToggled() && ac.f4770.getValue() && ((C0074)this.last).isMioAttacked()) {
         return 1.5F;
      } else {
         return animations.isToggled() && animations.f1660.getValue() ? animations.f1662.getValue() : 1.0F;
      }
   }
}
