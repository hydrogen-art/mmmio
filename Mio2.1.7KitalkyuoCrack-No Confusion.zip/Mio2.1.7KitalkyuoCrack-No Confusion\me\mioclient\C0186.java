package me.mioclient;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

public class C0186 implements ArgumentType<Boolean> {
   public static final Collection<String> f0558;
   public final C0240 f0559;
   public static int f0560 = w.a<"B">(6713844031520683156L, 257832362129977838L);

   public C0186(C0240 var1) {
      this.f0559 = var1;
   }

   public static C0186 bool(C0240 var0) {
      return new C0186(var0);
   }

   public static boolean getBool(CommandContext<?> var0, String var1) {
      return w.a<"Û">((Boolean)w.a<"Û">(var0, var1, Boolean.class, 275658406246533271L), 354697271520518137L);
   }

   public Boolean parse(StringReader var1) {
      String var2 = w.a<"Û">(var1, 269296760635713865L);
      if (var2.equals("0") || w.a<"Û">(var2, "false", 307662238383225114L)) {
         return w.a<"B">((boolean)((f0560 | 545204) + ~(f0560 & 545204) + 1 ^ -631031252), 320330632857389983L);
      } else if (var2.equals("1") || w.a<"Û">(var2, "true", 307662238383225114L)) {
         return w.a<"B">((boolean)((f0560 | 563982) + ~(f0560 & 563982) + 1 ^ -630984553), 320330632857389983L);
      } else if (w.a<"Û">(var2, "toggle", 307662238383225114L)) {
         return w.a<"B">(
            (boolean)(!w.a<"Û">((Boolean)w.a<"Û">(this.f0559, 174312564406604366L), 354697271520518137L)
               ? (f0560 | 967422) + ~(f0560 & 967422) + 1 ^ -630871705
               : (f0560 | 428506) + ~(f0560 & 428506) + 1 ^ -630332862),
            320330632857389983L
         );
      } else {
         throw w.a<"Û">(w.a<"Û">(CommandSyntaxException.BUILT_IN_EXCEPTIONS, 305669652289525048L), var1, var2, 180063344590253798L);
      }
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> var1, SuggestionsBuilder var2) {
      if (w.a<"Û">("true", w.a<"Û">(var2, 281397661160232021L), 339063961306778534L)) {
         w.a<"Û">(var2, "true", 199735903588157119L);
      }

      if (w.a<"Û">("false", w.a<"Û">(var2, 281397661160232021L), 339063961306778534L)) {
         w.a<"Û">(var2, "false", 199735903588157119L);
      }

      if (w.a<"Û">("toggle", w.a<"Û">(var2, 281397661160232021L), 339063961306778534L)) {
         w.a<"Û">(var2, "toggle", 199735903588157119L);
      }

      return w.a<"Û">(var2, 135487642270960168L);
   }

   public Collection<String> getExamples() {
      return f0558;
   }

   static {
      String[] var10000 = new String[(f0560 | 310484) + ~(f0560 & 310484) + 1 ^ -630204593];
      var10000[(f0560 | 467823) + ~(f0560 & 467823) + 1 ^ -630437641] = "true";
      var10000[(f0560 | 991574) + ~(f0560 & 991574) + 1 ^ -630961457] = "false";
      var10000[(f0560 | 570708) + ~(f0560 & 570708) + 1 ^ -630989106] = "toggle";
      f0558 = w.a<"B">(var10000, 333698250403385986L);
   }

   public static String W7JdQ3JUx3Xdb2nIvaZA9ub6iTiBbRjPrKXbGPUCDILVGeSR9QD2yGEDt0SfoyE3uQIcvz5rvcpHYwHqOPCtLlx5VWdElwMaHnEN(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
