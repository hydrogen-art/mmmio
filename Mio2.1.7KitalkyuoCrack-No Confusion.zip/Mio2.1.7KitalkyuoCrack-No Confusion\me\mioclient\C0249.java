package me.mioclient;

public final class C0249 extends C1180 {
   public final C1108 f3138;

   public C0249(C1108 var1) {
      this.f3138 = var1;
   }

   public C1108 m3338() {
      return this.f3138;
   }
}
