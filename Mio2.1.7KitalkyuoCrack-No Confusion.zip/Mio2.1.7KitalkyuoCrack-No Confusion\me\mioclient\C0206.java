package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2172;

public final class C0206 extends C0219 {
   public static int f3851 = w.a<"B">(399603681458729220L, 257832362129977838L);

   public C0206() {
      super("print");
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         (LiteralArgumentBuilder)w.a<"Û">(
            var1,
            w.a<"Û">(
               w.a<"B">("message", w.a<"B">(260998554108144903L), 191188367299315725L),
               (Command)var0 -> {
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1705, 294062101267071896L
                     ),
                     w.a<"B">((String)w.a<"Û">(var0, "message", String.class, 275658406246533271L), 273107254583785490L),
                     w.a<"B">(
                        (int)(
                           w.a<"B">(329795338200638383L)
                              * w.a<"B">(((long)f3851 | 220871L) + ~((long)f3851 & 220871L) + 1L ^ 4666723172842650765L, 317139102743630955L)
                        ),
                        289296048454852994L
                     ),
                     C0638.f2944,
                     276276156953453063L
                  );
                  return (f3851 | 683472) + ~(f3851 & 683472) + 1 ^ 374837147;
               },
               368995281709124746L
            ),
            289819728773344295L
         ),
         (Command)var0 -> {
            w.a<"B">(
               w.a<"B">("Please enter a message to print.", 228465064790135899L),
               w.a<"B">((f3851 | 630092) + ~(f3851 & 630092) + 1 ^ -374636295, 289296048454852994L),
               C0639.f3882,
               211469761772001922L
            );
            return (f3851 | 444846) + ~(f3851 & 444846) + 1 ^ 375073765;
         },
         286944572020109927L
      );
   }

   public static String vnjvrINnCpVHpffitJ7sSGKaXD6ju262Y21tGaHcH3obO9HxSkkdBmuQi474IH3tl13HkBTb6D9JqQ7PmN8YEJrW7E2jdFX5mmL0(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
