package me.mioclient;

import java.util.Iterator;
import net.minecraft.class_238;
import net.minecraft.class_742;

public class C0528 extends C0649 {
   public static int f4972 = w.a<"B">(2839621426266979291L, 257832362129977838L);

   public C0528(C0657 var1) {
      super(var1);
   }

   @Override
   public boolean m0272(C0572 var1) {
      Iterator var2 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 188438576288929642L),
         341496865259068134L
      );

      while (w.a<"Û">(var2, 333900474771661065L)) {
         class_742 var3 = (class_742)w.a<"Û">(var2, 192468336863492695L);
         if (!w.a<"Û">(
               (Boolean)w.a<"Û">(
                  this.m$$RwMG42j5f8LE2ptmIE0RfpsvEwCVyVN4fjg4GRo6sXxcDUvOvF3cNCwzebqXQrUmSCwrHhLDddzyc2QFF6t68shoK7VvxekeI.f4861, 174312564406604366L
               ),
               354697271520518137L
            )
            || w.a<"B">(var3, 130756052256592378L)) {
            class_238 var4 = w.a<"Û">(
                  (Boolean)w.a<"Û">(
                     this.m$$RwMG42j5f8LE2ptmIE0RfpsvEwCVyVN4fjg4GRo6sXxcDUvOvF3cNCwzebqXQrUmSCwrHhLDddzyc2QFF6t68shoK7VvxekeI.f4864, 174312564406604366L
                  ),
                  354697271520518137L
               )
               ? w.a<"Û">(
                  C0933.f1426,
                  var3,
                  w.a<"B">(
                     var3, this.m$$RwMG42j5f8LE2ptmIE0RfpsvEwCVyVN4fjg4GRo6sXxcDUvOvF3cNCwzebqXQrUmSCwrHhLDddzyc2QFF6t68shoK7VvxekeI.f4865, 246801299647070016L
                  ),
                  323742496459143110L
               )
               : w.a<"B">(var3, 129205818283773035L);
            int var5 = w.a<"B">(var3, 282320709208602225L)
                  && !w.a<"B">(var3, w.a<"Û">(w.a<"Û">(var1, 291940820831714374L), 229561253177300454L), 272159985293103090L)
               ? (f4972 | 314217) + ~(f4972 & 314217) + 1 ^ -1261659738
               : (f4972 | 409301) + ~(f4972 & 409301) + 1 ^ -1261540325;
            if (!(
                  w.a<"B">(w.a<"Û">(w.a<"Û">(var1, 291940820831714374L), 229561253177300454L), w.a<"B">(var4, 351265736671775343L), 342075947093997425L)
                     > w.a<"Û">(
                        (Float)w.a<"Û">(
                           this.m$$RwMG42j5f8LE2ptmIE0RfpsvEwCVyVN4fjg4GRo6sXxcDUvOvF3cNCwzebqXQrUmSCwrHhLDddzyc2QFF6t68shoK7VvxekeI.f4856, 174312564406604366L
                        ),
                        149784643039979208L
                     )
               )
               && !(w.a<"Û">(var3, 281558727827589522L) <= (double)w.a<"Û">(w.a<"Û">(var1, 291940820831714374L), 171752333823210875L))
               && !(
                  var4.field_1322 - (double)w.a<"Û">(w.a<"Û">(var1, 291940820831714374L), 171752333823210875L)
                     > w.a<"B">(((long)f4972 | 88217L) + ~((long)f4972 & 88217L) + 1L ^ -4616189619316651434L, 317139102743630955L)
               )
               && !w.a<"Û">(var3, 332781860382497538L)
               && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724 != var3
               && !w.a<"Û">(C0933.f1417, w.a<"Û">(w.a<"Û">(var3, 249088553220199978L), 211085733983653208L), 225253295937045434L)
               && !w.a<"Û">(C0933.f1419, w.a<"B">(w.a<"Û">(var3, 244358896227796891L), 274163478939689086L), 244811264617537130L)
               && var5 != 0
               && (
                  !w.a<"Û">(
                        (Boolean)w.a<"Û">(
                           this.m$$RwMG42j5f8LE2ptmIE0RfpsvEwCVyVN4fjg4GRo6sXxcDUvOvF3cNCwzebqXQrUmSCwrHhLDddzyc2QFF6t68shoK7VvxekeI.f4860, 174312564406604366L
                        ),
                        354697271520518137L
                     )
                     || w.a<"Û">(
                        C0933.f1419,
                        w.a<"B">(
                           w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                              114479647550158442L
                           ),
                           274163478939689086L
                        ),
                        244811264617537130L
                     )
                     || !(
                        w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 114479647550158442L
                              ),
                              w.a<"Û">(w.a<"Û">(var1, 291940820831714374L), 229561253177300454L),
                              180844654503832142L
                           )
                           < w.a<"B">(((long)f4972 | 758814L) + ~((long)f4972 & 758814L) + 1L ^ -4611686019689625903L, 317139102743630955L)
                     )
               )) {
               return super.m0272(var1);
            }
         }
      }

      return (boolean)((f4972 | 834389) + ~(f4972 & 834389) + 1 ^ -1262163558);
   }
}
