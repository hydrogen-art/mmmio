package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_22;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_5684;
import net.minecraft.class_757;
import net.minecraft.class_9209;
import net.minecraft.class_4597.class_4598;

public record C0443() implements C0045, class_5684 {
   public final int f3487;
   public final class_22 f3488;
   public static final class_2960 f3489 = w.a<"B">("textures/map/map_background.png", 353986064610202245L);
   public static int f3490 = w.a<"B">(2898991859624752995L, 257832362129977838L);

   public C0443(int var1, class_22 var2) {
      this.f3487 = var1;
      this.f3488 = var2;
   }

   public int method_32661() {
      return (f3490 | 357303) + ~(f3490 & 357303) + 1 ^ -431683343;
   }

   public int method_32664(class_327 var1) {
      return (f3490 | 8191) + ~(f3490 & 8191) + 1 ^ -431987525;
   }

   public void method_32666(class_327 var1, int var2, int var3, class_332 var4) {
      class_4587 var5 = w.a<"Û">(var4, 138110712227765901L);
      w.a<"Û">(var5, 156066167197700274L);
      w.a<"Û">(var5, (float)var2, (float)var3, 0.0F, 202980495898708244L);
      w.a<"Û">(
         var5,
         w.a<"B">((f3490 | 23198) + ~(f3490 & 23198) + 1 ^ -645914186, 349057757755238323L),
         w.a<"B">((f3490 | 10770) + ~(f3490 & 10770) + 1 ^ -645902022, 349057757755238323L),
         0.0F,
         338733048864940183L
      );
      w.a<"Û">(
         var5,
         w.a<"B">((f3490 | 313114) + ~(f3490 & 313114) + 1 ^ -640369614, 349057757755238323L),
         w.a<"B">((f3490 | 248363) + ~(f3490 & 248363) + 1 ^ -640438013, 349057757755238323L),
         0.0F,
         338733048864940183L
      );
      w.a<"B">(class_757::method_34542, 355523013159401593L);
      w.a<"Û">(
         var4,
         f3489,
         (f3490 | 394369) + ~(f3490 & 394369) + 1 ^ -431587415,
         (f3490 | 134161) + ~(f3490 & 134161) + 1 ^ -431851719,
         (f3490 | 702975) + ~(f3490 & 702975) + 1 ^ -431308073,
         0.0F,
         0.0F,
         (f3490 | 407197) + ~(f3490 & 407197) + 1 ^ -431600139,
         (f3490 | 415927) + ~(f3490 & 415927) + 1 ^ -431610913,
         (f3490 | 697549) + ~(f3490 & 697549) + 1 ^ -431300699,
         (f3490 | 747568) + ~(f3490 & 747568) + 1 ^ -431287464,
         120239753931519585L
      );
      w.a<"Û">(var5, 250771500943331132L);
      class_4598 var6 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 307206842868879895L),
         224491904139370894L
      );
      w.a<"Û">(var5, 156066167197700274L);
      w.a<"Û">(var5, (float)var2, (float)var3, 0.0F, 202980495898708244L);
      w.a<"Û">(
         var5,
         w.a<"B">((f3490 | 183008) + ~(f3490 & 183008) + 1 ^ -654134840, 349057757755238323L),
         w.a<"B">((f3490 | 544039) + ~(f3490 & 544039) + 1 ^ -653773297, 349057757755238323L),
         0.0F,
         338733048864940183L
      );
      w.a<"Û">(
         var5,
         w.a<"B">((f3490 | 129279) + ~(f3490 & 129279) + 1 ^ -1488878633, 349057757755238323L),
         w.a<"B">((f3490 | 666733) + ~(f3490 & 666733) + 1 ^ -1488300219, 349057757755238323L),
         0.0F,
         202980495898708244L
      );
      w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 354950059416276860L),
         var5,
         var6,
         new class_9209(this.f3487),
         this.f3488,
         (boolean)((f3490 | 724104) + ~(f3490 & 724104) + 1 ^ -431261792),
         (f3490 | 109178) + ~(f3490 & 109178) + 1 ^ -424554078,
         366934685359118058L
      );
      w.a<"Û">(var6, 170217939166473161L);
      w.a<"Û">(var5, 250771500943331132L);
   }

   public int m1435() {
      return this.f3487;
   }

   public class_22 m1436() {
      return this.f3488;
   }

   public static String hscHlGNgWirzH8cJJHnn4OJDMHQDCZB4H6t6qSg6JZ8X4ZH0c0MTiRNLPsy4FH740EyPqkk1eYp1XsqWHf3EIcysCs7Dexkdh4gK(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
