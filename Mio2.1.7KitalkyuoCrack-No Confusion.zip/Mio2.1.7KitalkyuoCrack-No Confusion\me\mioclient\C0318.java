package me.mioclient;

import java.util.function.Predicate;

public class C0318 implements Predicate {
   public C0427 f5075;

   public C0318(C0427 var1) {
      this.f5075 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f5075.f2755, 254992554122318132L);
   }
}
