package me.mioclient;

import java.util.function.Predicate;

public class C0382 implements Predicate {
   public C0936 f3864;

   public C0382(C0936 var1) {
      this.f3864 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3864.f1802, 254992554122318132L);
   }
}
