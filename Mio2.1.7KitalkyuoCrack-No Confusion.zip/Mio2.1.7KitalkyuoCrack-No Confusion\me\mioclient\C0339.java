package me.mioclient;

import java.util.function.Predicate;

public class C0339 implements Predicate {
   public C0797 f1486;

   public C0339(C0797 var1) {
      this.f1486 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1486.f3045, 174312564406604366L) != C0798.f1453;
   }
}
