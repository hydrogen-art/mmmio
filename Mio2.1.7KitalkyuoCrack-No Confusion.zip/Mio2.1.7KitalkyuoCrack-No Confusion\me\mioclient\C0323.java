package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0323 {
   f0542,
   f0543;

   public static String hvCxYxmlyIb3Roz3ffHOtr8tYgxdnRp0G5p67MQkG9WnJwV3cEiNAR1QHJ1F6i1Rh3tXov4LIA6wXXlxor6TidWKu53JXyMi4L0v(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
