package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.function.Predicate;
import net.minecraft.class_1747;
import net.minecraft.class_2189;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_4587;
import net.minecraft.class_239.class_240;

public class C0278 extends C1266 {
   public static final C0553 reach = C0933.f1409.m2696(C0553.class);
   public final C0015<Boolean> f3491;
   public final C0015<Boolean> f3492;
   public final C0015<Float> f3493;
   public final C0015<Color> f3494;
   public final C0015<Color> f3495;
   public static int f3496 = w.a<"B">(2963980897956588675L, 257832362129977838L);

   public C0278() {
      C1045 var10003 = C1045.f3174;
      String[] var10004 = new String[(f3496 | 169911) + ~(f3496 & 169911) + 1 ^ 20520538];
      var10004[(f3496 | 66050) + ~(f3496 & 66050) + 1 ^ 20614126] = "blockhighlight";
      super("Highlight", "Highlights the block you're looking at.", var10003, var10004);
      w.a<"B">(this, 242859112966675773L);
      w.a<"Û">(this, (boolean)((f3496 | 173265) + ~(f3496 & 173265) + 1 ^ 20524349), 135570431627433065L);
      w.a<"Û">(
         this.f3492,
         (Predicate<Boolean>)var0 -> (boolean)(!w.a<"Û">(reach, 314537768572362865L)
                  || !w.a<"Û">((Boolean)w.a<"Û">(reach.f3503, 174312564406604366L), 354697271520518137L)
                     && !w.a<"Û">((Boolean)w.a<"Û">(reach.f3506, 174312564406604366L), 354697271520518137L)
               ? (f3496 | 651398) + ~(f3496 & 651398) + 1 ^ 20085098
               : (f3496 | 219773) + ~(f3496 & 219773) + 1 ^ 20501392),
         235935633196277017L
      );
   }

   @C1027
   public void m1437(C0086 var1) {
      if (!w.a<"Û">(this, 146410166794218751L)) {
         w.a<"Û">(var1, 385440235371820560L);
      }
   }

   @C1027
   public void m1438(C1358 var1) {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         class_2338 var2 = w.a<"Û">(this, 310281518405687600L);
         if (var2 != null) {
            class_2680 var3 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var2, 310987074049434965L
            );
            if (w.a<"Û">(this, 385657982431979132L) || !(w.a<"Û">(var3, 152622786059621427L) instanceof class_2189)) {
               class_265 var4 = w.a<"Û">(
                  var3,
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  var2,
                  385368692334192390L
               );
               if (w.a<"Û">(var4, 125999939138686596L)) {
                  if (w.a<"Û">(this, 385657982431979132L)) {
                     w.a<"Û">(
                        this, w.a<"Û">(var1, 173269294235887931L), w.a<"Û">(w.a<"B">(109752698088366295L), 153037909352617834L), var2, 309925081499083106L
                     );
                  }
               } else if (!w.a<"Û">(this, 146410166794218751L)) {
                  if (w.a<"Û">((Boolean)w.a<"Û">(this.f3491, 174312564406604366L), 354697271520518137L)) {
                     Iterator var5 = w.a<"Û">(w.a<"Û">(var4, 353497208615209733L), 341496865259068134L);

                     while (w.a<"Û">(var5, 333900474771661065L)) {
                        class_238 var6 = (class_238)w.a<"Û">(var5, 192468336863492695L);
                        w.a<"Û">(this, w.a<"Û">(var1, 173269294235887931L), var6, var2, 309925081499083106L);
                     }
                  } else {
                     w.a<"Û">(this, w.a<"Û">(var1, 173269294235887931L), w.a<"Û">(var4, 153037909352617834L), var2, 309925081499083106L);
                  }
               }
            }
         }
      }
   }

   public class_2338 m1439() {
      if (w.a<"Û">(reach, 314537768572362865L) && w.a<"Û">((Boolean)w.a<"Û">(reach.f3504, 174312564406604366L), 354697271520518137L)) {
         class_3965 var1 = w.a<"Û">(reach, 225813780145499720L);
         if (var1 != null && w.a<"Û">(var1, 189274766630417875L) != class_240.field_1333 && w.a<"Û">(var1, 318588572047519347L) != null) {
            return w.a<"Û">(w.a<"Û">(reach, 225813780145499720L), 318588572047519347L);
         }
      }

      if (!w.a<"Û">(this, 385657982431979132L)) {
         if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1765 instanceof class_3965 var4
            && w.a<"Û">(var4, 189274766630417875L) != class_240.field_1333) {
            return w.a<"Û">(var4, 318588572047519347L);
         }

         return null;
      } else {
         return w.a<"B">(375397465817807250L) instanceof class_3965 var2 ? w.a<"Û">(var2, 318588572047519347L) : null;
      }
   }

   public void m1440(class_4587 var1, class_238 var2, class_2338 var3) {
      w.a<"B">(
         var1,
         w.a<"Û">(
            w.a<"Û">(var2, var3, 252103202185457587L),
            w.a<"B">(((long)f3496 | 613731L) + ~((long)f3496 & 613731L) + 1L ^ 4566758108558490995L, 317139102743630955L),
            130605157384247280L
         ),
         (Color)w.a<"Û">(this.f3495, 174312564406604366L),
         246072095578695914L
      );
      C0485.m3219(
         var1,
         w.a<"Û">(
            w.a<"Û">(var2, var3, 252103202185457587L),
            w.a<"B">(((long)f3496 | 633179L) + ~((long)f3496 & 633179L) + 1L ^ 4566758108558494027L, 317139102743630955L),
            130605157384247280L
         ),
         (Color)w.a<"Û">(this.f3494, 174312564406604366L),
         w.a<"Û">((Float)w.a<"Û">(this.f3493, 174312564406604366L), 149784643039979208L)
      );
   }

   public boolean m1441() {
      return (boolean)(!w.a<"Û">(reach, 314537768572362865L)
            || !w.a<"Û">((Boolean)w.a<"Û">(reach.f3506, 174312564406604366L), 354697271520518137L)
            || !(
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L
                     ),
                     222207108884875224L
                  ) instanceof class_1747
               )
               && !(
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 159396947398056288L
                     ),
                     222207108884875224L
                  ) instanceof class_1747
               )
         ? (f3496 | 987287) + ~(f3496 & 987287) + 1 ^ 20224379
         : (f3496 | 663200) + ~(f3496 & 663200) + 1 ^ 20027213);
   }

   public boolean m1442() {
      return (boolean)(w.a<"Û">((Boolean)w.a<"Û">(this.f3492, 174312564406604366L), 354697271520518137L) && w.a<"Û">(this.f3492, 140659502048675535L)
         ? (f3496 | 119371) + ~(f3496 & 119371) + 1 ^ 20601766
         : (f3496 | 412802) + ~(f3496 & 412802) + 1 ^ 20825454);
   }

   public static String sZCcutuApxuNsclLfC1jT1PTJSE9bT77EZNZEXVMIiCCgUV4UKcwPNV7WjIXwgsXkERsm5TPsPmVzG7Q8LMtkMIKNkdTNgztNgiM(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
