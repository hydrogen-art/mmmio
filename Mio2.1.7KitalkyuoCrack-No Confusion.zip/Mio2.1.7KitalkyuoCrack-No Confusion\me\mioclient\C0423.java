package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Comparator;
import java.util.function.Function;
import java.util.function.ToIntFunction;
import net.minecraft.class_1934;
import net.minecraft.class_268;
import net.minecraft.class_640;

public class C0423 extends C1266 {
   public final C0015<C0424> f2185;
   public final C0015<Float> f2186;
   public final C0015<Boolean> f2187;
   public final C0015<Boolean> f2188;
   public final C0015<Color> f2189;
   public final C0015<Boolean> f2190;
   public final C0015<Boolean> f2191;
   public final C0015<C0425> f2192;
   public final C0015<Boolean> f2193;
   public static int f2194 = w.a<"B">(103269075064658376L, 257832362129977838L);

   public C0423() {
      super("ExtraTab", "Allows you to customize your TAB-screen.", C1045.f3173);
      w.a<"B">(this, 242859112966675773L);
      w.a<"Û">(this, (boolean)((f2194 | 187136) + ~(f2194 & 187136) + 1 ^ -1204842207), 135570431627433065L);
   }

   public float m0919() {
      return !w.a<"Û">(this, 314537768572362865L)
         ? w.a<"B">((f2194 | 98362) + ~(f2194 & 98362) + 1 ^ -2018719205, 349057757755238323L)
         : w.a<"Û">((Float)w.a<"Û">(this.f2186, 174312564406604366L), 149784643039979208L);
   }

   public int m0920(class_640 var1) {
      return switch (w.a<"Û">((C0425)w.a<"Û">(this.f2192, 174312564406604366L), 379677435939838738L)) {
         case 0 -> (f2194 | 226007) + ~(f2194 & 226007) + 1 ^ -1204930314;
         case 1 -> {
            C0720 var2 = w.a<"Û">(C0933.f1417, w.a<"Û">(w.a<"Û">(var1, 340696059510910540L), 211085733983653208L), 338925027459788934L);
            int var3 = (f2194 | 632998) + ~(f2194 & 632998) + 1 ^ -1205542265;
            if (var2 == C0720.f3464) {
               var3 = (f2194 | 395915) + ~(f2194 & 395915) + 1 ^ 1205124949;
            }

            if (var2 == C0720.f3465) {
               var3 = (f2194 | 580450) + ~(f2194 & 580450) + 1 ^ 1205497533;
            }

            yield var3;
         }
         case 2 -> -w.a<"Û">(var1, 227266915151442255L);
         case 3 -> -w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1772,
         w.a<"Û">(w.a<"Û">(var1, 340696059510910540L), 211085733983653208L),
         366050800015082133L
      );
         default -> throw new MatchException(null, null);
      };
   }

   public Comparator<class_640> m0921() {
      Comparator var1 = w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(
               w.a<"B">(
                  (ToIntFunction<class_640>)var1x -> {
                     int var2 = w.a<"Û">(var1x, 271747475127381436L) == class_1934.field_9219
                        ? (f2194 | 156466) + ~(f2194 & 156466) + 1 ^ -1204868846
                        : (f2194 | 451153) + ~(f2194 & 451153) + 1 ^ -1205098384;
                     if (w.a<"Û">((Boolean)w.a<"Û">(this.f2193, 174312564406604366L), 354697271520518137L)) {
                        var2 *= (f2194 | 182392) + ~(f2194 & 182392) + 1 ^ 1204845990;
                     }

                     return var2;
                  },
                  161433660684442653L
               ),
               (Function<class_640, String>)var0 -> (String)w.a<"B">(w.a<"Û">(var0, 122124766663913184L), class_268::method_1197, "", 248957437296347991L),
               200625359586468451L
            ),
            (Function<class_640, Integer>)var1x -> w.a<"B">(w.a<"Û">(this, var1x, 282149444823111366L), 367942141483020029L),
            200625359586468451L
         ),
         (Function<class_640, String>)var0 -> w.a<"Û">(w.a<"Û">(var0, 340696059510910540L), 211085733983653208L),
         String::compareToIgnoreCase,
         195512105111839473L
      );
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2193, 174312564406604366L), 354697271520518137L)) {
         var1 = w.a<"Û">(var1, 109701421162438395L);
      }

      return var1;
   }

   public static String RA0H4zVJpTOJEUfeXg1sfjwQ3vx3AUrFnjF42RnZGHLT7xejAFq0Ia45nEqwHfb7MMVKcjVRUYYaVtktfmCWOPCOXVfiAh4l5NfA(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
