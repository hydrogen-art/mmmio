package me.mioclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_332;

public class C0482 extends C1214 implements C0045 {
   public static final List<C0294> f1516 = Collections.synchronizedList(new ArrayList<>());
   public static final C0826 f1517 = new C0826();
   public final C0600 f1518 = new C0600();
   public final C0614 f1519;
   public boolean f1520;
   public float f1521;
   public float f1522;
   public float f1523;
   public float f1524;
   public static int f1525 = -684455309;

   public C0482() {
      this.f1519 = new C0614(
         Float.intBitsToFloat((f1525 | 67920) + ~(f1525 & 67920) + 1 ^ -1758133469), (boolean)((f1525 | 236105) + ~(f1525 & 236105) + 1 ^ -684224453)
      );
      C0860[] var1 = C0860.values();
      int var2 = var1.length;

      for (int var3 = (f1525 | 367337) + ~(f1525 & 367337) + 1 ^ -684617574; var3 < var2; var3++) {
         C0860 var4 = var1[var3];
         f1516.add(new C0294(var4));
      }

      C0623 var5 = new C0623(C1045.f3179);
      var5.m0234().sort(Comparator.comparing(var0 -> var0 instanceof C0914 var1x ? var1x.m2431().getName() : ""));
      var5.m0240();
      var5.setX((f1525 | 821406) + ~(f1525 & 821406) + 1 ^ -684162376);
      var5.setY((f1525 | 246099) + ~(f1525 & 246099) + 1 ^ -684209366);
      this.m$$NyWixwImaKsyW0dcb2KbV8bn1anduTL2X2EF9bCfVGTGs2KkolWT9HHn5A2p4KTdCgUbJH7iTTkD0jcvqjI80ZPFaDgjDpZ3X.add(var5);
   }

   @Override
   public void method_25394(class_332 var1, int var2, int var3, float var4) {
      RenderSystem.setShaderColor(
         Float.intBitsToFloat((f1525 | 864042) + ~(f1525 & 864042) + 1 ^ -390519463),
         Float.intBitsToFloat((f1525 | 199904) + ~(f1525 & 199904) + 1 ^ -390658413),
         Float.intBitsToFloat((f1525 | 323080) + ~(f1525 & 323080) + 1 ^ -391060357),
         this.m$$zKed0weSqqmjXSLKU1GIzHnlkAdiudOuUSRkoPTdeD6JMwx1fBcBqYzRgIRogRF8pOAQ6Q1ZchWvcrZU9l2QdkPJZ4MH7nJM1()
      );
      f1517.m0039((boolean)((f1525 | 245868) + ~(f1525 & 245868) + 1 ^ -684209633));
      this.f1523 = (float)var2;
      this.f1524 = (float)var3;
      float var5 = (float)var1.method_51421() / Float.intBitsToFloat((f1525 | 666695) + ~(f1525 & 666695) + 1 ^ -1757534668);
      float var6 = (float)var1.method_51443() / Float.intBitsToFloat((f1525 | 49967) + ~(f1525 & 49967) + 1 ^ -1758148260);
      Color var7 = C0152.m3474(
         Color.white,
         RenderSystem.getShaderColor()[(f1525 | 220715) + ~(f1525 & 220715) + 1 ^ -684239781]
            * Float.intBitsToFloat((f1525 | 848392) + ~(f1525 & 848392) + 1 ^ -369871690)
      );
      C0438.m3962(
         var1.method_51448(),
         var5 - Float.intBitsToFloat((f1525 | 182585) + ~(f1525 & 182585) + 1 ^ -399064246),
         0.0F,
         var5 + Float.intBitsToFloat((f1525 | 763599) + ~(f1525 & 763599) + 1 ^ -398480196),
         var6 * Float.intBitsToFloat((f1525 | 254739) + ~(f1525 & 254739) + 1 ^ -1757943456),
         var7
      );
      C0438.m3962(
         var1.method_51448(),
         0.0F,
         var6 - Float.intBitsToFloat((f1525 | 251193) + ~(f1525 & 251193) + 1 ^ -398991542),
         var5 - Float.intBitsToFloat((f1525 | 810729) + ~(f1525 & 810729) + 1 ^ -398961510),
         var6 + Float.intBitsToFloat((f1525 | 846336) + ~(f1525 & 846336) + 1 ^ -398925709),
         var7
      );
      C0438.m3962(
         var1.method_51448(),
         var5 + Float.intBitsToFloat((f1525 | 459992) + ~(f1525 & 459992) + 1 ^ -399307093),
         var6 - Float.intBitsToFloat((f1525 | 138531) + ~(f1525 & 138531) + 1 ^ -399108272),
         var5 * Float.intBitsToFloat((f1525 | 63320) + ~(f1525 & 63320) + 1 ^ -1758134997),
         var6 + Float.intBitsToFloat((f1525 | 118939) + ~(f1525 & 118939) + 1 ^ -399123736),
         var7
      );
      this.f1518.m0716(var1, var2, var3, var4);
      this.m0632(var1, (double)var2, (double)var3);
      if (this.f1520) {
         C0294 var8 = this.m0633(C0860.f2181);
         C1092 var9 = var8.m2286().m1204();
         float[] var10 = var9.m2952();
         var9.m2946(
            Math.max(0.0F, Math.min((float)var1.method_51421() - var10[(f1525 | 935796) + ~(f1525 & 935796) + 1 ^ -684045049], (float)var2 - this.f1521)),
            (boolean)((f1525 | 91012) + ~(f1525 & 91012) + 1 ^ -684365322)
         );
         var9.m2949(
            Math.max(0.0F, Math.min((float)var1.method_51443() - var10[(f1525 | 913120) + ~(f1525 & 913120) + 1 ^ -684071790], (float)var3 - this.f1522)),
            (boolean)((f1525 | 844510) + ~(f1525 & 844510) + 1 ^ -684136276)
         );
         var9.m2961();
         if (Math.abs(
               var9.m2944()
                  + var10[(f1525 | 41147) + ~(f1525 & 41147) + 1 ^ -684414264] / Float.intBitsToFloat((f1525 | 231911) + ~(f1525 & 231911) + 1 ^ -1757969516)
                  - var5
            )
            <= Float.intBitsToFloat((f1525 | 816929) + ~(f1525 & 816929) + 1 ^ -1751614126)) {
            float var11 = var5
               - var10[(f1525 | 389749) + ~(f1525 & 389749) + 1 ^ -684591098] / Float.intBitsToFloat((f1525 | 325542) + ~(f1525 & 325542) + 1 ^ -1758396971);
            var9.m2946(var11, (boolean)((f1525 | 261454) + ~(f1525 & 261454) + 1 ^ -684198084));
            this.m0636(
               var1,
               (double)var11 - Double.longBitsToDouble(((long)f1525 | 63225L) + ~((long)f1525 & 63225L) + 1L ^ -4602678819857040246L),
               (boolean)((f1525 | 469762) + ~(f1525 & 469762) + 1 ^ -684514960)
            );
            this.m0636(
               var1,
               (double)(var11 + var10[(f1525 | 626760) + ~(f1525 & 626760) + 1 ^ -683828677]),
               (boolean)((f1525 | 465321) + ~(f1525 & 465321) + 1 ^ -684518437)
            );
         }

         if (Math.abs(
               var9.m2947()
                  + var10[(f1525 | 942832) + ~(f1525 & 942832) + 1 ^ -684038014] / Float.intBitsToFloat((f1525 | 836922) + ~(f1525 & 836922) + 1 ^ -1757884599)
                  - var6
            )
            <= Float.intBitsToFloat((f1525 | 758008) + ~(f1525 & 758008) + 1 ^ -1751147893)) {
            float var13 = var6
               - var10[(f1525 | 515282) + ~(f1525 & 515282) + 1 ^ -684468576] / Float.intBitsToFloat((f1525 | 310812) + ~(f1525 & 310812) + 1 ^ -1758415761);
            var9.m2949(var13, (boolean)((f1525 | 869545) + ~(f1525 & 869545) + 1 ^ -684110117));
            this.m0636(
               var1,
               (double)var13 - Double.longBitsToDouble(((long)f1525 | 43061L) + ~((long)f1525 & 43061L) + 1L ^ -4602678819857063354L),
               (boolean)((f1525 | 674525) + ~(f1525 & 674525) + 1 ^ -683786066)
            );
            this.m0636(
               var1,
               (double)(var13 + var10[(f1525 | 243824) + ~(f1525 & 243824) + 1 ^ -684215806]),
               (boolean)((f1525 | 168867) + ~(f1525 & 168867) + 1 ^ -684287536)
            );
         }
      }

      float var12 = this.f1519.m2325();
      this.f1519.m2328(f1517.m0038());
      if (f1517.m0038() || (double)var12 > Double.longBitsToDouble(((long)f1525 | 700928L) + ~((long)f1525 & 700928L) + 1L ^ -4591870180465368599L)) {
         C0498.f4738
            .m3889(
               var1,
               f1517.m0032(),
               f1517.m0036()
                  + Float.intBitsToFloat((f1525 | 189910) + ~(f1525 & 189910) + 1 ^ -1776881755)
                     * (Float.intBitsToFloat((f1525 | 479596) + ~(f1525 & 479596) + 1 ^ -390898913) - var12)
                     * (float)f1517.m0034(),
               f1517.m0037(),
               C0152.m3473(Color.white, (int)(var12 * Float.intBitsToFloat((f1525 | 998984) + ~(f1525 & 998984) + 1 ^ -1807469509)))
            );
      }

      super.method_25394(var1, var2, var3, var4);
   }

   @Override
   public boolean method_25402(double var1, double var3, int var5) {
      C0848 var6 = null;

      for (C0294 var8 : f1516) {
         for (int var9 = var8.m2286().size() - ((f1525 | 232549) + ~(f1525 & 232549) + 1 ^ -684227049); var9 >= 0; var9--) {
            C1092 var10 = var8.m2286().get(var9);
            if (var10.m2956() && var5 == 0 && var6 == null) {
               if (var10 instanceof C0024) {
                  C0024 var11 = (C0024)var10;
                  if (var11.m1076(var1, var3)) {
                     continue;
                  }
               }

               if (var10.m0011(var1, var3)) {
                  var6 = new C0848<>(var8.m2285(), var10);
                  this.f1521 = (float)((int)(var1 - (double)var10.m2944()));
                  this.f1522 = (float)((int)(var3 - (double)var10.m2947()));
                  this.f1520 = (boolean)((f1525 | 521693) + ~(f1525 & 521693) + 1 ^ -684458065);
                  var10.m2950((boolean)((f1525 | 697342) + ~(f1525 & 697342) + 1 ^ -683759220));
               }
            }
         }
      }

      if (var6 != null) {
         this.m0633((C0860)var6.m3994()).m2286().remove(var6.m3995());
         this.m0633(C0860.f2181).m2286().addLast((C1092)var6.m3995());
         ((C1092)var6.m3995()).m2955(C0860.f2181);
      } else {
         this.f1518.m0717(var1, var3, var5);
      }

      return super.method_25402(var1, var3, var5);
   }

   @Override
   public boolean method_25406(double var1, double var3, int var5) {
      this.f1518.m0718(var1, var3, var5);
      if (this.f1520) {
         this.f1520 = (boolean)((f1525 | 640270) + ~(f1525 & 640270) + 1 ^ -683815043);
         C0294 var6 = this.m0633(C0860.f2181);
         C1092 var7 = var6.m2286().m1204();
         var7.m2950((boolean)((f1525 | 296406) + ~(f1525 & 296406) + 1 ^ -684683355));
         var6.m2286().remove(var7);

         for (C0294 var9 : f1516) {
            for (C1092 var11 : var9.m2286()) {
               if (var11.m2962().m3520(var7.m2962())) {
                  this.m0633(var9.m2285()).m2286().addLast(var7);
                  var7.m2955(var9.m2285());
                  return (boolean)((f1525 | 871812) + ~(f1525 & 871812) + 1 ^ -684111882);
               }
            }
         }

         C0860[] var12 = C0860.values();
         int var13 = var12.length;

         for (int var14 = (f1525 | 437880) + ~(f1525 & 437880) + 1 ^ -684547061; var14 < var13; var14++) {
            C0860 var15 = var12[var14];
            if (var15.m2886().m3520(var7.m2962().m3521(Float.intBitsToFloat((f1525 | 297901) + ~(f1525 & 297901) + 1 ^ -1752137250)))) {
               this.m0633(var15).m2286().addLast(var7);
               var7.m2955(var15);
               return (boolean)((f1525 | 722965) + ~(f1525 & 722965) + 1 ^ -683736473);
            }
         }
      }

      return super.method_25406(var1, var3, var5);
   }

   @Override
   public boolean method_25404(int var1, int var2, int var3) {
      int var4 = (f1525 | 423409) + ~(f1525 & 423409) + 1 ^ -684556414;

      for (C1244 var6 : this.m$$NyWixwImaKsyW0dcb2KbV8bn1anduTL2X2EF9bCfVGTGs2KkolWT9HHn5A2p4KTdCgUbJH7iTTkD0jcvqjI80ZPFaDgjDpZ3X) {
         if (var6.m0011((double)this.f1523, (double)this.f1524)) {
            var4 = (f1525 | 415665) + ~(f1525 & 415665) + 1 ^ -684565053;
            break;
         }
      }

      if (var4 == 0) {
         C1092 var7 = this.m0635();
         C0490 var8 = this.m0639(var1);
         if (var8 != null && var7 != null && var7.m2956()) {
            var7.m2946(var7.m2944() + (float)var8.m1551(), (boolean)((f1525 | 788218) + ~(f1525 & 788218) + 1 ^ -684192632));
            var7.m2949(var7.m2947() + (float)var8.m1552(), (boolean)((f1525 | 618830) + ~(f1525 & 618830) + 1 ^ -683836612));
            var7.m2961();
         } else {
            switch (var1) {
               case 73:
                  if (!(C0933.m2652().m3733() instanceof C0243)) {
                     this.m0634(C0860.f2178, C0860.f2179);
                     this.m0634(C0860.f2176, C0860.f2177);
                  }
                  break;
               case 259:
               case 261:
                  if (var7 != null && var7.m2956()) {
                     var7.m2963()
                        .m$$v7t3qFE5OPisRuO5GqORIzqnQ79t1TctlmTzMmpho63GM98Dsqh3L3DbOsychSqBEACGbXbQCE7zwQAPdqx2yd4r1KwAf9ApE(
                           (boolean)((f1525 | 824875) + ~(f1525 & 824875) + 1 ^ -684155816)
                        );
                  }
            }
         }
      }

      return super.method_25404(var1, var2, var3);
   }

   @Override
   public boolean method_25401(double var1, double var3, double var5, double var7) {
      return super.method_25401(var1, var3, var5, var7);
   }

   @Override
   public void method_25419() {
      super.method_25419();
      if (this.f1520) {
         this.m0633(C0860.f2181).m2286().m1204().m2950((boolean)((f1525 | 802142) + ~(f1525 & 802142) + 1 ^ -684181715));
         this.f1520 = (boolean)((f1525 | 959383) + ~(f1525 & 959383) + 1 ^ -684021276);
      }
   }

   public void m0628(C0860 var1, C1092 var2) {
      this.m0633(var1).m2286().add(var2);
   }

   public void m0629(C1092 var1) {
      this.m0628(C0860.f2181, var1);
   }

   public void m0630(C1092 var1) {
      for (C0294 var3 : this.m0631()) {
         if (var3.m2286().remove(var1)) {
            return;
         }
      }
   }

   public List<C0294> m0631() {
      return f1516;
   }

   public void m0632(class_332 var1, double var2, double var4) {
      for (C0294 var7 : this.m0631()) {
         var7.m0001(var1, var1.method_51448(), var2, var4);
      }

      C0438.m3968();
   }

   public C0294 m0633(C0860 var1) {
      for (C0294 var3 : this.m0631()) {
         if (var3.m2285() == var1) {
            return var3;
         }
      }

      return null;
   }

   public void m0634(C0860 var1, C0860 var2) {
      C0294 var3 = this.m0633(var1);
      C0294 var4 = this.m0633(var2);
      ArrayList var5 = new ArrayList<>(var3.m2286());
      var3.m2286().clear();

      for (C1092 var7 : var4.m2286()) {
         var3.m2286().add(var7);
      }

      var4.m2286().clear();

      for (C1092 var9 : var5) {
         var4.m2286().add(var9);
      }
   }

   public C1092 m0635() {
      for (C0294 var2 : f1516) {
         for (C1092 var4 : var2.m2286()) {
            if (var4.m0011((double)this.f1523, (double)this.f1524)) {
               return var4;
            }
         }
      }

      return null;
   }

   public void m0636(class_332 var1, double var2, boolean var4) {
      float var5 = (float)var2;
      if (var4) {
         C0438.m3962(
            var1.method_51448(),
            var5,
            0.0F,
            var5 + Float.intBitsToFloat((f1525 | 326090) + ~(f1525 & 326090) + 1 ^ -399445063),
            (float)var1.method_51443(),
            Color.yellow
         );
      } else {
         C0438.m3962(
            var1.method_51448(),
            0.0F,
            var5,
            (float)var1.method_51421(),
            var5 + Float.intBitsToFloat((f1525 | 811526) + ~(f1525 & 811526) + 1 ^ -398956427),
            Color.yellow
         );
      }
   }

   @Override
   public void m0637(class_332 var1) {
   }

   @Override
   public boolean m0638() {
      return (boolean)((f1525 | 844688) + ~(f1525 & 844688) + 1 ^ -684135965);
   }

   public C0490 m0639(int var1) {
      return switch (var1) {
         case 262 -> new C0490((f1525 | 13281) + ~(f1525 & 13281) + 1 ^ -684443245, (f1525 | 237024) + ~(f1525 & 237024) + 1 ^ -684222573);
         case 263 -> new C0490((f1525 | 541564) + ~(f1525 & 541564) + 1 ^ 683914992, (f1525 | 898687) + ~(f1525 & 898687) + 1 ^ -684082164);
         case 264 -> new C0490((f1525 | 261376) + ~(f1525 & 261376) + 1 ^ -684198029, (f1525 | 585258) + ~(f1525 & 585258) + 1 ^ -683875240);
         case 265 -> new C0490((f1525 | 106853) + ~(f1525 & 106853) + 1 ^ -684348650, (f1525 | 785290) + ~(f1525 & 785290) + 1 ^ 683675142);
         default -> null;
      };
   }

   static {
      long var10000 = 6117925869843901241L;
   }
}
