package me.mioclient;

import io.netty.channel.ChannelHandlerContext;
import java.io.DataInputStream;
import java.lang.invoke.MethodHandles.Lookup;

public class C0355 implements C0636 {
   public String[] f0605;
   public static int f0606 = w.a<"B">(1381637013499862654L, 257832362129977838L);

   public C0355() {
   }

   public C0355(String[] var1) {
      this.f0605 = var1;
   }

   @Override
   public void m0326(ChannelHandlerContext var1) {
      String var2 = w.a<"B">(", ", this.f0605, 110705165577156239L);
      Object[] var10001 = new Object[(f0606 | 839130) + ~(f0606 & 839130) + 1 ^ 638565397];
      var10001[(f0606 | 218416) + ~(f0606 & 218416) + 1 ^ 637543677] = w.a<"B">(this.f0605.length, 367942141483020029L);
      var10001[(f0606 | 598446) + ~(f0606 & 598446) + 1 ^ 638210146] = var2;
      String var3 = w.a<"Û">("%d online players: %s", var10001, 259257223839993282L);
      w.a<"B">(w.a<"B">(var3, 228465064790135899L), w.a<"B">(w.a<"Û">(var3, 342985361154189862L), 289296048454852994L), 241936116971186271L);
   }

   public C0355 m0327(byte[] var1) {
      DataInputStream var2 = w.a<"Û">(this, var1, 275887650587447605L);
      int var3 = w.a<"Û">(var2, 385128449716077832L);
      C0355 var4 = new C0355();
      var4.f0605 = new String[var3];

      for (int var5 = (f0606 | 532031) + ~(f0606 & 532031) + 1 ^ 638283762; var5 < var3; var5++) {
         var4.f0605[var5] = w.a<"Û">(var2, 324739747070342739L);
      }

      return var4;
   }

   @Override
   public byte[] m0328() {
      C0637 var1 = w.a<"Û">(this, 261799195248173705L);
      w.a<"Û">(var1, this.f0605.length, 354906622322711927L);
      String[] var2 = this.f0605;
      int var3 = var2.length;

      for (int var4 = (f0606 | 539911) + ~(f0606 & 539911) + 1 ^ 638274762; var4 < var3; var4++) {
         String var5 = var2[var4];
         w.a<"Û">(var1, var5, 380341140178659597L);
      }

      return w.a<"Û">(var1, 127233360143812789L);
   }

   @Override
   public short m0329() {
      return (short)((f0606 | 690621) + ~(f0606 & 690621) + 1 ^ 638187635);
   }

   public static String BN9UFDyOILgaeEAcwcm7ro9xxP0770DnVzR2CubRDr8XCw0sYrK9rExrZ4R4oiDDKw9u0bxHZCBODEiRlzO5cc0mLTTbQbBus3VG(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
