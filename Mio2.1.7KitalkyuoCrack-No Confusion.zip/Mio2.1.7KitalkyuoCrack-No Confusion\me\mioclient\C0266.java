package me.mioclient;

import java.util.function.Predicate;

public class C0266 implements Predicate {
   public C1051 f4906;

   public C0266(C1051 var1) {
      this.f4906 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4906.f0312, 254992554122318132L);
   }
}
