package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_7923;

public class C0379 implements C0997 {
   public final C0275<class_1792> f3153;
   public static int f3154 = w.a<"B">(8840820394781665812L, 257832362129977838L);

   public C0379() {
      this.f3153 = new C0275<>("Items", class_7923.field_41178);
   }

   @Override
   public JsonElement toJson() {
      JsonObject var1 = new JsonObject();
      w.a<"Û">(var1, "items", w.a<"Û">(this.f3153, 361063213142073698L), 130151082343781043L);
      return var1;
   }

   @Override
   public void fromJson(JsonElement var1) {
      if (var1 instanceof JsonObject var2 && w.a<"Û">(var2, "items", 314399812765309162L)) {
         w.a<"Û">(this.f3153, w.a<"Û">(var2, "items", 268791691692763549L), 273668855420156616L);
      }
   }

   @Override
   public String getConfigName() {
      return "glint.json";
   }

   public C0275<class_1792> m1306() {
      return this.f3153;
   }

   public static boolean m1307(class_1792 var0) {
      return (boolean)(C0933.f1442 == null
         ? (f3154 | 285654) + ~(f3154 & 285654) + 1 ^ -1824394120
         : w.a<"Û">((Set)w.a<"Û">(C0933.f1442.f3153, 174312564406604366L), var0, 338145669613544495L));
   }

   public static String l9OQhsxngIsiImRUJgn9ife96iTeAMACvV5yVWRswXq9WzbOh6LMY9HPAgk0SOM71sJh5LvfkURXbwwUNtbixGvbW9wp87fcOes4(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
