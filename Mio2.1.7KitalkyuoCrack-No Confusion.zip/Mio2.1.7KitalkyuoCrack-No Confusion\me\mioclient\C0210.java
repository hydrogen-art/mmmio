package me.mioclient;

import java.util.function.Predicate;

public class C0210 implements Predicate {
   public C0455 f2572;

   public C0210(C0455 var1) {
      this.f2572 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2572.f1854, 254992554122318132L) && !w.a<"Û">((Boolean)w.a<"Û">(this.f2572.f1855, 174312564406604366L), 354697271520518137L);
   }
}
