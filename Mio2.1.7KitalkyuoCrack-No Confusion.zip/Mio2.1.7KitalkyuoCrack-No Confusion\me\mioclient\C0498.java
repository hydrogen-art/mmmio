package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_327.class_6415;

public class C0498 implements C0045 {
   public static final C0568 nameprotect = C0933.f1409.m2696(C0568.class);
   public static final C0498 f4738 = new C0498();
   public static int f4739 = 0;
   public C0462 f4740;

   public static String m3882(Object var0) {
      return Character.toUpperCase(var0.toString().charAt(0)) + var0.toString().toLowerCase().substring(1);
   }

   public static boolean m3883(String var0, char var1) {
      for (int var2 = 0; var2 < var0.length(); var2++) {
         if (var0.charAt(var2) == var1) {
            return true;
         }
      }

      return false;
   }

   public C0462 m3884() {
      if (this.f4740 == null) {
         this.f4740 = this.m3886();
      }

      return this.f4740;
   }

   public void m3885(C0462 var1) {
      if (var1 != null) {
         this.f4740 = var1;
         System.gc();
      }
   }

   public C0462 m3886() {
      C0719 var1 = C0719.f0592;
      return C0462.m1941(var1.f0595.getValue(), var1.f0599.getValue(), var1.f0596.getValue());
   }

   public void m3887(class_332 var1, String var2, float var3, float var4, Color var5) {
      this.m3888(var1, class_2561.method_30163(var2), var3, var4, var5);
   }

   public void m3888(class_332 var1, class_2561 var2, float var3, float var4, Color var5) {
      if (C0719.f0592.isToggled()) {
         this.m3884().m1948(var1.method_51448(), var2.method_30937(), var3, var4, var5.hashCode(), false);
      } else {
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1772
            .method_30882(
               var2,
               (float)((int)var3),
               (float)((int)var4),
               var5.hashCode(),
               false,
               var1.method_51448().method_23760().method_23761(),
               this.m3884().m1959(),
               class_6415.field_33993,
               0,
               15728880
            );
      }
   }

   public void m3889(class_332 var1, String var2, float var3, float var4, Color var5) {
      this.m3890(var1, class_2561.method_30163(var2), var3, var4, var5);
   }

   public void m3890(class_332 var1, class_2561 var2, float var3, float var4, Color var5) {
      if (C0719.f0592.isToggled()) {
         this.m3884().m1948(var1.method_51448(), var2.method_30937(), var3, var4, var5.hashCode(), true);
      } else {
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1772
            .method_30882(
               var2,
               (float)((int)var3),
               (float)((int)var4),
               var5.hashCode(),
               true,
               var1.method_51448().method_23760().method_23761(),
               this.m3884().m1959(),
               class_6415.field_33993,
               0,
               15728880
            );
      }
   }

   public void m3891(class_332 var1, String var2, float var3, float var4, float var5, Color var6) {
      this.m3892(var1, class_2561.method_30163(var2), var3, var4, var5, var6);
   }

   public void m3892(class_332 var1, class_2561 var2, float var3, float var4, float var5, Color var6) {
      var1.method_51448().method_22903();
      var1.method_51448().method_22905(var5, var5, var5);
      this.m3888(var1, var2, var3 / var5, var4 / var5, var6);
      var1.method_51448().method_22905(1.0F / var5, 1.0F / var5, 1.0F / var5);
      var1.method_51448().method_22909();
   }

   public void m3893(class_332 var1, String var2, float var3, float var4, float var5, Color var6) {
      this.m3894(var1, class_2561.method_30163(var2), var3, var4, var5, var6);
   }

   public void m3894(class_332 var1, class_2561 var2, float var3, float var4, float var5, Color var6) {
      var1.method_51448().method_22903();
      var1.method_51448().method_22905(var5, var5, var5);
      this.m3890(var1, var2, var3 / var5, var4 / var5, var6);
      var1.method_51448().method_22905(1.0F / var5, 1.0F / var5, 1.0F / var5);
      var1.method_51448().method_22909();
   }

   public void m3895() {
      this.m3884().m1957();
   }

   public float m3896(String var1) {
      if (nameprotect.isToggled() && !this.m$$QSJDJukVNkVpoDbHworbeKprufjrUbbBOk9KeDyg7xkpE4AcInW0gzx8GwjH93eOVI5SFHbL1FLXN7XV7Q0DZ98iNdThnIBHx()) {
         var1 = var1.replace(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.method_5477().getString(),
            nameprotect.f4598.getValue()
         );
      }

      return C0719.f0592.isToggled()
         ? (float)this.m3884().m1955(var1)
         : (float)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1772.method_1727(var1);
   }

   public int m3897() {
      if (C0719.f0592.isToggled()) {
         return this.m3884().m1954() - 1;
      } else {
         return m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1772 == null ? 9 : 9;
      }
   }

   public static int m3898() {
      return C0719.f0592.f0600.getValue();
   }

   public static float m3899() {
      return C0719.f0592.f0601.getValue();
   }

   public static int m3900() {
      return C0719.f0592.f0602.getValue();
   }

   public static void m3901(int var0) {
      f4739 = var0;
   }

   public static int m3902() {
      return f4739;
   }

   public static String m3903(String var0) {
      return var0.replaceAll("[^a-zA-Z0-9.\\-]", "_");
   }

   public static String n8z5WlO5PcFX8RtslSHiCpeHQfLNzSuFsZm5bhe20pJAMpd5S9oF6UF4UO92ZV3eGybMbOpZJaWU2H0N1KQA7FG00Y1IQ3NFKWN0(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
