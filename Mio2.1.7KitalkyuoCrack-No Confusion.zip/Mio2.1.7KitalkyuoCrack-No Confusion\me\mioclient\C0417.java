package me.mioclient;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;

public class C0417<T extends Enum<T>> implements ArgumentType<T> {
   public final Class<T> f0291;
   public final String f0292;
   public static int f0293 = w.a<"B">(5999066347523334273L, 257832362129977838L);

   public C0417(Class<T> var1) {
      this(var1, "Enum");
   }

   public C0417(Class<T> var1, String var2) {
      this.f0291 = var1;
      this.f0292 = var2;
   }

   public T parse(StringReader var1) {
      String var2 = w.a<"Û">(var1, 269296760635713865L);
      Enum[] var3 = (Enum[])w.a<"Û">(this.f0291, 144334009663342992L);
      int var4 = var3.length;

      for (int var5 = (f0293 | 917108) + ~(f0293 & 917108) + 1 ^ 732590741; var5 < var4; var5++) {
         Enum var6 = var3[var5];
         if (w.a<"Û">(w.a<"Û">(this, var6, 194423569801234801L), var2, 307662238383225114L)) {
            return (T)var6;
         }
      }

      throw w.a<"Û">(new DynamicCommandExceptionType(var1x -> {
         Object[] var10001 = new Object[(f0293 | 568995) + ~(f0293 & 568995) + 1 ^ 732897856];
         var10001[(f0293 | 100063) + ~(f0293 & 100063) + 1 ^ 732301886] = this.f0292;
         var10001[(f0293 | 785380) + ~(f0293 & 785380) + 1 ^ 732722948] = var1x;
         return w.a<"B">(w.a<"B">("%s %s doesn't exist", var10001, 223779026484277040L), 228465064790135899L);
      }), var2, 303734573678124276L);
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> var1, SuggestionsBuilder var2) {
      return w.a<"B">(
         w.a<"Û">(w.a<"B">((Enum[])w.a<"Û">(this.f0291, 144334009663342992L), 131523343736437369L), this::name, 141209812120559377L), var2, 379722968704725371L
      );
   }

   public String name(T var1) {
      return var1 instanceof C0196
         ? w.a<"Û">((C0196)var1, 352801181599163784L)
         : w.a<"Û">(w.a<"Û">(var1, 235224272799028434L), Locale.ROOT, 149330587742400121L);
   }

   public static String xBVgsit1RfhwEJXiUnDOBSNw914nk2AgQqLCIpI0fL406Ki28LuKIrNSVepTwdHdHeQ9oQ4xBTarGQI6LlMEQd048KCOOZilWE0W(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
