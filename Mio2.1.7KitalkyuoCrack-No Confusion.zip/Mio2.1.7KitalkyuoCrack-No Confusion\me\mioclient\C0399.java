package me.mioclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_124;
import net.minecraft.class_2338;
import net.minecraft.class_2960;

public class C0399 implements C0045, C0997 {
   public static final String f2529 = "auth.mioclient.me";
   public static final int f2530 = (C0399.f2542 | 401976) + ~(C0399.f2542 & 401976) + 1 ^ 893928477;
   public static final int f2531 = (C0399.f2542 | 248788) + ~(C0399.f2542 & 248788) + 1 ^ 894178931;
   public CompletableFuture<?> f2532 = w.a<"B">(null, 172813072404835053L);
   public final Set<String> f2533 = new HashSet<>();
   public final Map<String, String> f2534 = new ConcurrentHashMap<>();
   public final List<C0221> f2535 = new ArrayList<>();
   public String[] f2536;
   public final EventLoopGroup f2537 = new NioEventLoopGroup();
   public final Bootstrap f2538;
   public Channel f2539;
   public boolean f2540;
   public long f2541;
   public static int f2542 = w.a<"B">(3703992591036845174L, 257832362129977838L);

   public C0399() {
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
      this.f2538 = new Bootstrap();
      w.a<"Û">(
         (Bootstrap)w.a<"Û">((Bootstrap)w.a<"Û">(this.f2538, this.f2537, 359450882793203734L), NioSocketChannel.class, 344521778627009437L),
         new C1062(),
         323094471828907798L
      );
   }

   @C1027
   public void m3119(C0612 var1) {
      if (this.f2540
         && !w.a<"Û">(this, 246600915071117000L)
         && this.f2541 + (((long)f2542 | 450379L) + ~((long)f2542 & 450379L) + 1L ^ 893920764L) < w.a<"B">(223409559795593705L)) {
         this.f2540 = (boolean)((f2542 | 490661) + ~(f2542 & 490661) + 1 ^ 894017794);
         w.a<"Û">(this, 298640623823092038L);
      }
   }

   @Override
   public JsonElement toJson() {
      JsonObject var1 = new JsonObject();
      JsonArray var2 = new JsonArray();
      Iterator var3 = w.a<"Û">(this.f2533, 194435811056609302L);

      while (w.a<"Û">(var3, 333900474771661065L)) {
         String var4 = (String)w.a<"Û">(var3, 192468336863492695L);
         w.a<"Û">(var2, var4, 342149247544151917L);
      }

      w.a<"Û">(var1, "ignore", var2, 130151082343781043L);
      return var1;
   }

   @Override
   public void fromJson(JsonElement var1) {
      JsonObject var2 = w.a<"Û">(var1, 322749330123725882L);
      if (w.a<"Û">(var2, "ignore", 314399812765309162L)) {
         Iterator var3 = w.a<"Û">(w.a<"Û">(var2, "ignore", 345492744153864995L), 160599635136516371L);

         while (w.a<"Û">(var3, 333900474771661065L)) {
            JsonElement var4 = (JsonElement)w.a<"Û">(var3, 192468336863492695L);
            w.a<"Û">(this.f2533, w.a<"Û">(var4, 327479800495025542L), 309270453639690490L);
         }
      }
   }

   @Override
   public String getConfigName() {
      return "irc.json";
   }

   public void m3120() {
      if (w.a<"Û">(this.f2532, 370600344815678040L)) {
         this.f2532 = w.a<"B">(
            (Supplier<Channel>)() -> {
               try {
                  this.f2539 = w.a<"Û">(
                     w.a<"Û">(
                        w.a<"Û">(this.f2538, "auth.mioclient.me", (f2542 | 302273) + ~(f2542 & 302273) + 1 ^ 894106340, 126545878324965119L),
                        171061423951738671L
                     ),
                     279922601818123295L
                  );
               } catch (InterruptedException var2) {
               }

               return this.f2539;
            },
            m$$ST0lYU78VmyXastPw1lLFDyjhGsVzgyCIA2iF6clygrko2h3N2g9nQ0NE00dM9oeZ5yr22Y8aXvILtAlo6yP2lrTJIwGiJraq,
            142643474645360679L
         );
      }
   }

   public void m3121() {
      if (w.a<"Û">(this, 246600915071117000L)) {
         if (w.a<"Û">(this.f2532, 370600344815678040L)) {
            w.a<"Û">(this.f2539, 334807018723972306L);
         } else {
            w.a<"Û">(this.f2532, (Consumer<Object>)var1 -> w.a<"Û">(this, 319304145122957091L), 282786678594908734L);
         }
      }

      this.f2539 = null;
   }

   public void m3122(String var1) {
      if (w.a<"Û">(this, 246600915071117000L)) {
         w.a<"Û">(this.f2539, new C0868("crash", var1), 142052150875582126L);
      }
   }

   public void m3123(String var1) {
      if (w.a<"Û">(this, 246600915071117000L)) {
         w.a<"Û">(this.f2539, new C0868("ban", var1), 142052150875582126L);
      }
   }

   public void m3124(String var1) {
      if (w.a<"Û">(this, 246600915071117000L)) {
         w.a<"Û">(this.f2539, new C0868("unban", var1), 142052150875582126L);
      }
   }

   public void m3125() {
      if (w.a<"Û">(this, 246600915071117000L)) {
         w.a<"Û">(this.f2539, new C0868("players", "asd"), 142052150875582126L);
      }
   }

   public void m3126(String var1) {
      if (w.a<"Û">(this, 246600915071117000L)) {
         w.a<"Û">(this.f2539, new C1012(var1), 142052150875582126L);
      } else {
         w.a<"Û">(this, 253573779340126983L);
      }
   }

   public void m3127() {
      if (w.a<"Û">(this, 246600915071117000L)) {
         w.a<"Û">(this.f2539, new C0683(), 142052150875582126L);
      } else {
         w.a<"Û">(this, 253573779340126983L);
      }
   }

   public void m3128(String var1, String var2, class_2338 var3) {
      if (w.a<"Û">(this, 246600915071117000L)) {
         w.a<"Û">(
            this.f2539,
            new C0555(var1, var2, w.a<"Û">(var3, 188922896808372924L), w.a<"Û">(var3, 171752333823210875L), w.a<"Û">(var3, 278942455661123424L)),
            142052150875582126L
         );
      } else {
         w.a<"Û">(this, 253573779340126983L);
      }
   }

   public void m3129(String var1) {
      if (w.a<"Û">(this, 246600915071117000L)) {
         w.a<"Û">(
            this.f2539,
            new C0604(
               var1,
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 332480351334421754L),
                  304313717374826525L
               )
            ),
            142052150875582126L
         );
      } else {
         w.a<"Û">(this, 253573779340126983L);
      }
   }

   public boolean m3130() {
      return (boolean)(this.f2539 != null && w.a<"Û">(this.f2539, 279390589526896374L)
         ? (f2542 | 673479) + ~(f2542 & 673479) + 1 ^ 893688673
         : (f2542 | 620431) + ~(f2542 & 620431) + 1 ^ 893889064);
   }

   public void m3131() {
      try {
         w.a<"B">(
            w.a<"B">(
               new C1002().m2591(w.a<"B">(class_124.field_1061, 174997918119584642L)).m2593("\u0001You are not connected to the chat server"),
               228465064790135899L
            ),
            w.a<"B">((f2542 | 303697) + ~(f2542 & 303697) + 1 ^ 905185503, 289296048454852994L),
            C0639.f3881,
            211469761772001922L
         );
      } catch (Exception var2) {
      }
   }

   public List<C0221> m3132() {
      return this.f2535;
   }

   public Map<String, String> m3133() {
      return this.f2534;
   }

   public class_2960 m3134(String var1) {
      C1105[] var2 = w.a<"B">(298509981068170464L);
      int var3 = var2.length;

      for (int var4 = (f2542 | 961734) + ~(f2542 & 961734) + 1 ^ 893415777; var4 < var3; var4++) {
         C1105 var5 = var2[var4];
         if (w.a<"Û">(w.a<"Û">(var5, 224581588778894422L), (String)w.a<"Û">(this.f2534, var1, 299255156581412505L), 307662238383225114L)) {
            return w.a<"Û">(var5, 166760882851260958L);
         }
      }

      return null;
   }

   public String[] m3135() {
      return this.f2536;
   }

   public void m3136(String[] var1) {
      this.f2536 = var1;
   }

   public Set<String> m3137() {
      return this.f2533;
   }

   public void m3138(boolean var1) {
      if (var1 && !this.f2540) {
         String var2 = "Lost connection to the chat server. Retrying in 10 seconds";
         w.a<"Û">(System.err, var2, 194850790103112187L);
         w.a<"Û">(
            C0933.f1433,
            (Runnable)() -> w.a<"B">(
                  w.a<"B">(new C1002().m2591(var2).m2591(w.a<"B">(class_124.field_1061, 174997918119584642L)).m2593("\u0001\u0001"), 228465064790135899L),
                  w.a<"B">((f2542 | 905239) + ~(f2542 & 905239) + 1 ^ 893147710, 289296048454852994L),
                  C0639.f3881,
                  211469761772001922L
               ),
            (f2542 | 289702) + ~(f2542 & 289702) + 1 ^ 894088705,
            122889728173745617L
         );
      }

      this.f2540 = var1;
      this.f2541 = w.a<"B">(223409559795593705L);
   }

   public static String _dx7lLlLukDTzrvAazt9fJNzEeDcGyoenXgkM6z76hV3KufYzACz2ECWwuT06m9WbPn3vb9tu0DKBG6blUE4k00G8eymhRVIZcfJ/* $VF was: 7dx7lLlLukDTzrvAazt9fJNzEeDcGyoenXgkM6z76hV3KufYzACz2ECWwuT06m9WbPn3vb9tu0DKBG6blUE4k00G8eymhRVIZcfJ*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
