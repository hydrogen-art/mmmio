package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.BiConsumer;
import java.util.function.UnaryOperator;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2586;
import net.minecraft.class_2604;
import net.minecraft.class_2625;
import net.minecraft.class_5250;
import net.minecraft.class_742;
import net.minecraft.class_2568.class_5247;

public class C0481 extends C1266 {
   public static final int f1023 = -w.a<"B">(w.a<"Û">("EnderPearl", 342985361154189862L), 345794447433752364L);
   public final C0015<Boolean> f1024;
   public final C0015<Boolean> f1025;
   public final C0015<Boolean> f1026;
   public final C0015<Boolean> f1027;
   public final C0015<Boolean> f1028;
   public final C0015<Boolean> f1029;
   public final C0015<Boolean> f1030;
   public final C0015<Boolean> f1031;
   public final C0015<Boolean> f1032;
   public final C0015<Boolean> f1033;
   public final C0015<Boolean> f1034;
   public final C0015<C1348> f1035;
   public final C0015<Float> f1036;
   public final ArrayList<String> f1037;
   public final ArrayList<String> f1038;
   public static int f1039 = w.a<"B">(4397522360246094922L, 257832362129977838L);

   public C0481() {
      super("VisualRange", "Informs you of players who enter/leave your visual range.", C1045.f3173);
      w.a<"B">(this, 242859112966675773L);
      this.f1037 = new ArrayList<>();
      this.f1038 = new ArrayList<>();
      w.a<"Û">(this, (boolean)((f1039 | 330661) + ~(f1039 & 330661) + 1 ^ -1112862023), 135570431627433065L);
   }

   @Override
   public void onDisable() {
      w.a<"Û">(this.f1037, 333375574688283011L);
      w.a<"Û">(this.f1038, 333375574688283011L);
   }

   @C1027
   public void m0498(C0612 var1) {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         w.a<"Û">(this.f1038, 333375574688283011L);

         try {
            Iterator var2 = w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 188438576288929642L),
               341496865259068134L
            );

            while (w.a<"Û">(var2, 333900474771661065L)) {
               class_742 var3 = (class_742)w.a<"Û">(var2, 192468336863492695L);
               if (!w.a<"Û">(var3, 315491136764910072L)
                     .equals(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 325699207128272228L
                        )
                     )
                  && w.a<"Û">(this, var3, 373879745061249282L)) {
                  w.a<"Û">(this.f1038, w.a<"Û">(w.a<"Û">(var3, 315491136764910072L), 286788181028845103L), 359987172538212680L);
               }
            }

            if (!this.f1037.equals(this.f1038)) {
               var2 = w.a<"Û">(this.f1038, 126222552728889968L);

               while (w.a<"Û">(var2, 333900474771661065L)) {
                  String var10 = (String)w.a<"Û">(var2, 192468336863492695L);
                  if (!w.a<"Û">(this.f1037, var10, 326765426701481412L) && w.a<"Û">((Boolean)w.a<"Û">(this.f1024, 174312564406604366L), 354697271520518137L)) {
                     Color var4 = w.a<"Û">(C0933.f1417, var10, Color.WHITE, 342655978625678444L);
                     Object[] var10001 = new Object[(f1039 | 284889) + ~(f1039 & 284889) + 1 ^ -1112915513];
                     var10001[(f1039 | 751942) + ~(f1039 & 751942) + 1 ^ -1113235366] = var10;
                     var10001[(f1039 | 579488) + ~(f1039 & 579488) + 1 ^ -1113141571] = class_124.field_1068;
                     String var5 = w.a<"Û">("%s%s entered visual range.", var10001, 259257223839993282L);
                     class_5250 var6 = w.a<"Û">(
                        w.a<"B">(var5, 228465064790135899L),
                        (UnaryOperator)var1x -> w.a<"Û">(var1x, w.a<"Û">(var4, 301840407077149108L), 349393047474482868L),
                        165931758622126162L
                     );
                     w.a<"B">(
                        var6,
                        w.a<"B">(
                           w.a<"B">(w.a<"Û">(var10, 342985361154189862L), 345794447433752364L)
                              * ((f1039 | 18779) + ~(f1039 & 18779) + 1 ^ 1112649656)
                              / ((f1039 | 947520) + ~(f1039 & 947520) + 1 ^ -1113559970),
                           289296048454852994L
                        ),
                        C0639.f3881,
                        211469761772001922L
                     );
                     if (!w.a<"Û">(C0933.f1417, var10, 225253295937045434L) && w.a<"Û">(C0933.f1417, var10, 195246088273626771L)
                        || !w.a<"Û">((Boolean)w.a<"Û">(this.f1034, 174312564406604366L), 354697271520518137L)) {
                        w.a<"Û">(this, 354041557650849468L);
                     }
                  }
               }

               var2 = w.a<"Û">(this.f1037, 126222552728889968L);

               while (w.a<"Û">(var2, 333900474771661065L)) {
                  String var11 = (String)w.a<"Û">(var2, 192468336863492695L);
                  if (!w.a<"Û">(this.f1038, var11, 326765426701481412L) && w.a<"Û">((Boolean)w.a<"Û">(this.f1025, 174312564406604366L), 354697271520518137L)) {
                     Color var12 = w.a<"Û">(C0933.f1417, var11, Color.WHITE, 342655978625678444L);
                     Object[] var15 = new Object[(f1039 | 14610) + ~(f1039 & 14610) + 1 ^ -1112662004];
                     var15[(f1039 | 377480) + ~(f1039 & 377480) + 1 ^ -1112810604] = var11;
                     var15[(f1039 | 530359) + ~(f1039 & 530359) + 1 ^ -1113190742] = class_124.field_1068;
                     String var13 = w.a<"Û">("%s%s left visual range.", var15, 259257223839993282L);
                     class_5250 var14 = w.a<"Û">(
                        w.a<"B">(var13, 228465064790135899L),
                        (UnaryOperator)var1x -> w.a<"Û">(var1x, w.a<"Û">(var12, 301840407077149108L), 349393047474482868L),
                        165931758622126162L
                     );
                     w.a<"B">(
                        var14,
                        w.a<"B">(
                           w.a<"B">(w.a<"Û">(var11, 342985361154189862L), 345794447433752364L)
                              * ((f1039 | 512688) + ~(f1039 & 512688) + 1 ^ 1112945747)
                              / ((f1039 | 587251) + ~(f1039 & 587251) + 1 ^ -1113133843),
                           289296048454852994L
                        ),
                        C0639.f3882,
                        211469761772001922L
                     );
                  }
               }

               w.a<"Û">(this.f1037, 333375574688283011L);
               w.a<"Û">(this.f1037, this.f1038, 136357625560498462L);
            }
         } catch (Exception var7) {
         }
      }
   }

   @C1027
   public void m0499(C0785 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1031, 174312564406604366L), 354697271520518137L)) {
         AtomicBoolean var2 = new AtomicBoolean((boolean)((f1039 | 736128) + ~(f1039 & 736128) + 1 ^ -1113251172));
         w.a<"Û">(
            w.a<"Û">(w.a<"Û">(var1, 387642137083103624L), 289417256228043774L),
            (BiConsumer<class_2338, class_2586>)(var1x, var2x) -> {
               if (var2x instanceof class_2625 var3) {
                  int var4 = -w.a<"B">(w.a<"Û">(var1x, 209150815352643326L), 345794447433752364L);
                  class_5250 var5 = w.a<"B">("Found a sign: ", 228465064790135899L);
                  int var6 = (f1039 | 268146) + ~(f1039 & 268146) + 1 ^ -1112928657;
                  class_2561[] var7 = w.a<"Û">(
                     w.a<"Û">(var3, 119169074098149009L), (boolean)((f1039 | 147717) + ~(f1039 & 147717) + 1 ^ -1112778727), 284858606299522445L
                  );
                  int var8 = var7.length;

                  for (int var9 = (f1039 | 248002) + ~(f1039 & 248002) + 1 ^ -1112682018; var9 < var8; var9++) {
                     class_2561 var10 = var7[var9];
                     if (!w.a<"Û">(w.a<"B">(w.a<"Û">(var10, 286788181028845103L), 222815525246781378L), 268441564659141224L)) {
                        w.a<"Û">(var5, var10, 267862536496645581L);
                        w.a<"Û">(var5, " ", 194629304146735395L);
                        var6 = (f1039 | 510334) + ~(f1039 & 510334) + 1 ^ -1112944542;
                     }
                  }

                  if (var6 != 0) {
                     w.a<"Û">(var5, "<empty>", 194629304146735395L);
                  }

                  w.a<"Û">(var5, (UnaryOperator)var0x -> w.a<"Û">(var0x, class_124.field_1068, 152778664851569676L), 165931758622126162L);
                  Object[] var10001 = new Object[(f1039 | 510224) + ~(f1039 & 510224) + 1 ^ -1112944625];
                  var10001[(f1039 | 303175) + ~(f1039 & 303175) + 1 ^ -1112884901] = w.a<"B">(w.a<"Û">(var1x, 188922896808372924L), 367942141483020029L);
                  var10001[(f1039 | 795081) + ~(f1039 & 795081) + 1 ^ -1113442092] = w.a<"B">(w.a<"Û">(var1x, 171752333823210875L), 367942141483020029L);
                  var10001[(f1039 | 360203) + ~(f1039 & 360203) + 1 ^ -1112840683] = w.a<"B">(w.a<"Û">(var1x, 278942455661123424L), 367942141483020029L);
                  String var11 = w.a<"Û">("%d, %d, %d", var10001, 259257223839993282L);
                  class_5250 var12 = w.a<"B">(new C1002().m2591(var11).m2593("at \u0001"), 228465064790135899L);
                  class_2568 var13 = new class_2568(class_5247.field_24342, var12);
                  w.a<"Û">(var5, (UnaryOperator)var1xx -> w.a<"Û">(var1xx, var13, 120979910123777007L), 165931758622126162L);
                  w.a<"Û">(
                     var5,
                     (UnaryOperator)var1xx -> w.a<"Û">(
                           var1xx,
                           w.a<"B">(new C1002().m2591(w.a<"Û">(var11, ",", "", 328425598364162988L)).m2593("highlight \u0001"), 337816707317760730L),
                           291578796023597487L
                        ),
                     165931758622126162L
                  );
                  w.a<"B">(var5, w.a<"B">(var4, 289296048454852994L), 241936116971186271L);
                  w.a<"Û">(var2, (boolean)((f1039 | 276348) + ~(f1039 & 276348) + 1 ^ -1112920479), 378016260982040195L);
               }
            },
            316328768057134350L
         );
         if (w.a<"Û">(var2, 248424813730317294L)) {
            w.a<"Û">(this, 354041557650849468L);
         }
      }
   }

   @C1027
   public void m0500(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2604 var2
         && w.a<"Û">(var2, 353809255235785168L) == class_1299.field_6082
         && w.a<"Û">((Boolean)w.a<"Û">(this.f1032, 174312564406604366L), 354697271520518137L)) {
         class_5250 var6 = w.a<"B">("Ender Pearl entered visual range.", 228465064790135899L);
         Object[] var10001 = new Object[(f1039 | 6737) + ~(f1039 & 6737) + 1 ^ -1112669362];
         var10001[(f1039 | 49310) + ~(f1039 & 49310) + 1 ^ -1112614526] = w.a<"B">(w.a<"Û">(var2, 180182980834797487L), 165155940100814265L);
         var10001[(f1039 | 458617) + ~(f1039 & 458617) + 1 ^ -1113004444] = w.a<"B">(w.a<"Û">(var2, 350612975000976430L), 165155940100814265L);
         var10001[(f1039 | 485590) + ~(f1039 & 485590) + 1 ^ -1112968760] = w.a<"B">(w.a<"Û">(var2, 193879592482149874L), 165155940100814265L);
         String var4 = w.a<"Û">("%.0f, %.0f, %.0f", var10001, 259257223839993282L);
         class_5250 var5 = w.a<"B">(new C1002().m2591(var4).m2593("at \u0001"), 228465064790135899L);
         w.a<"Û">(var6, (UnaryOperator)var1x -> w.a<"Û">(var1x, new class_2568(class_5247.field_24342, var5), 120979910123777007L), 165931758622126162L);
         w.a<"Û">(
            var6,
            (UnaryOperator)var1x -> w.a<"Û">(
                  var1x,
                  w.a<"B">(new C1002().m2591(w.a<"Û">(var4, ",", "", 328425598364162988L)).m2593("highlight \u0001"), 337816707317760730L),
                  291578796023597487L
               ),
            165931758622126162L
         );
         w.a<"B">(var6, w.a<"B">(f1023, 289296048454852994L), C0639.f3881, 211469761772001922L);
         w.a<"Û">(this, 354041557650849468L);
      }
   }

   public boolean m0501(class_1657 var1) {
      if (!w.a<"B">(var1, 130756052256592378L)) {
         return w.a<"Û">((Boolean)w.a<"Û">(this.f1030, 174312564406604366L), 354697271520518137L);
      } else if (w.a<"Û">(C0933.f1417, var1, 241036547861815495L)) {
         return w.a<"Û">((Boolean)w.a<"Û">(this.f1028, 174312564406604366L), 354697271520518137L);
      } else {
         return w.a<"Û">(C0933.f1417, var1, 331571300069254198L)
            ? w.a<"Û">((Boolean)w.a<"Û">(this.f1029, 174312564406604366L), 354697271520518137L)
            : w.a<"Û">((Boolean)w.a<"Û">(this.f1027, 174312564406604366L), 354697271520518137L);
      }
   }

   @C1027
   public void m0502(C0190 var1) {
      w.a<"Û">(this.f1037, 333375574688283011L);
      w.a<"Û">(this.f1038, 333375574688283011L);
   }

   public void m0503() {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1033, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(
            w.a<"Û">(C0933.f1420, (C1348)w.a<"Û">(this.f1035, 174312564406604366L), 371338236536096699L),
            w.a<"Û">((Float)w.a<"Û">(this.f1036, 174312564406604366L), 149784643039979208L),
            212279982900710395L
         );
      }
   }

   public static String _NiI5A26rMM1nvh0GuDX2fw6zGBzTFuatXk7HUX7eFqySfamHZBdWtTtrgiSDub2UuAhZMJheudXT4NXfgc7l7AfmZeVRLp1GNyL/* $VF was: 1NiI5A26rMM1nvh0GuDX2fw6zGBzTFuatXk7HUX7eFqySfamHZBdWtTtrgiSDub2UuAhZMJheudXT4NXfgc7l7AfmZeVRLp1GNyL*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
