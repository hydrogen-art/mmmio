package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0421 implements C0196 {
   f2356("None"),
   f2357("Normal"),
   f2358("Silent");

   public final String f2359;

   public C0421(String var3) {
      this.f2359 = var3;
   }

   @Override
   public String getName() {
      return this.f2359;
   }

   public static String OJShVVwOQJFqpnkQa0o154qQ0vlaChaqDQ9PPRpOr35dC3R7as4QyxIuCfzFSEEMWGx2FLo5qkTZybY87ncXpuI1yIzau4iZGTwU(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
