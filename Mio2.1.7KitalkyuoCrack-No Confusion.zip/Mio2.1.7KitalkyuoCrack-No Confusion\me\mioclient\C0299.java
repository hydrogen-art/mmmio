package me.mioclient;

import net.minecraft.class_2828;

public final class C0299 implements C0045 {
   public static boolean f4137;
   public static C1194 f4138 = C0933.f1409.m2696(C1194.class);
   public final C1179 f4139;
   public int f4140;
   public static int f4141 = w.a<"B">(7420909304561583194L, 257832362129977838L);

   public C0299(C1179 var1) {
      this.f4139 = var1;
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   @C1027
   public void m3720(C0612 var1) {
      if (!w.a<"Û">(this, 275328565679393972L)) {
         this.f4140 = w.a<"B">(
            w.a<"Û">((Integer)w.a<"Û">(f4138.f1168, 174312564406604366L), 260981171345819427L),
            this.f4140 = this.f4140 + ((f4141 | 135293) + ~(f4141 & 135293) + 1 ^ 1647664149),
            244670932612973720L
         );
      }
   }

   @C1027
   public void m3721(C0132 var1) {
      if (w.a<"Û">(this, 275328565679393972L) && this.f4140 != 0) {
         if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2828 && f4137 || w.a<"Û">(f4138, 314537768572362865L)) {
            this.f4140 = w.a<"B">(
               (f4141 | 637233) + ~(f4141 & 637233) + 1 ^ 1648293208,
               this.f4140 = this.f4140 - ((f4141 | 364187) + ~(f4141 & 364187) + 1 ^ 1647493875),
               250328644894878425L
            );
         }
      }
   }

   public boolean m3722() {
      if (this.f4140 > 0
         && w.a<"Û">(this, 275328565679393972L)
         && w.a<"Û">((Boolean)w.a<"Û">(this.f4139.f1259, 174312564406604366L), 354697271520518137L)
         && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)
         && w.a<"Û">(C0933.f1429, 202655309853842506L) > ((f4141 | 44103) + ~(f4141 & 44103) + 1 ^ 1647829039)) {
         w.a<"Û">(C0933.f1431, this.f4139, (float)w.a<"Û">((Integer)w.a<"Û">(f4138.f1167, 174312564406604366L), 260981171345819427L), 371685643619254063L);
         return (boolean)((f4141 | 537894) + ~(f4141 & 537894) + 1 ^ 1648326990);
      } else {
         return (boolean)((f4141 | 276128) + ~(f4141 & 276128) + 1 ^ 1647540937);
      }
   }

   public boolean m3723() {
      return (boolean)(w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L),
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6014,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6036,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_5969,
               145073102115949444L
            )
            > 0.0
         ? (f4141 | 343462) + ~(f4141 & 343462) + 1 ^ 1647473102
         : (f4141 | 620997) + ~(f4141 & 620997) + 1 ^ 1648244140);
   }
}
