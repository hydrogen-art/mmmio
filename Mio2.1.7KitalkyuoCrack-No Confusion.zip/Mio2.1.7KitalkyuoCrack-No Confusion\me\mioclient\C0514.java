package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;
import java.util.Map.Entry;
import java.util.function.Predicate;

public class C0514 {
   public static final C0514 f0079 = new C0514();
   public static int f0080 = w.a<"B">(6976153124424868238L, 257832362129977838L);

   public void m2164(JsonObject var1) {
      Iterator var2 = w.a<"Û">(w.a<"Û">(w.a<"Û">(var1, 274534791465332761L), 269526036007691028L), 277715502174036685L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         JsonElement var3 = (JsonElement)w.a<"Û">(var2, 192468336863492695L);
         if (var3 instanceof JsonObject) {
            JsonObject var4 = (JsonObject)var3;
            w.a<"Û">(var4, "key", 123031262139480692L);
            if (w.a<"Û">(var4, "settings", 314399812765309162L)) {
               JsonElement var5 = w.a<"Û">(var4, "settings", 268791691692763549L);
               if (w.a<"Û">(var5, 266361156733738545L)) {
                  ArrayList var6 = new ArrayList();
                  Iterator var7 = w.a<"Û">(
                     w.a<"Û">(w.a<"Û">(w.a<"Û">(var5, 322749330123725882L), 274534791465332761L), 354320704134596920L), 194435811056609302L
                  );

                  while (w.a<"Û">(var7, 333900474771661065L)) {
                     Entry var8 = (Entry)w.a<"Û">(var7, 192468336863492695L);
                     if (w.a<"Û">((JsonElement)w.a<"Û">(var8, 196870340575900401L), 266361156733738545L)) {
                        w.a<"Û">(var6, (String)w.a<"Û">(var8, 141740301999341859L), 276802003864609490L);
                     }
                  }

                  var7 = w.a<"Û">(var6, 341496865259068134L);

                  while (w.a<"Û">(var7, 333900474771661065L)) {
                     String var10 = (String)w.a<"Û">(var7, 192468336863492695L);
                     w.a<"Û">(w.a<"Û">(var5, 322749330123725882L), var10, 123031262139480692L);
                  }
               }
            }
         }
      }
   }

   public void m2165(JsonObject var1, Predicate<C1266> var2) {
      Iterator var3 = w.a<"Û">(w.a<"Û">(w.a<"Û">(var1, 274534791465332761L), 344909330910693100L), 194435811056609302L);

      while (w.a<"Û">(var3, 333900474771661065L)) {
         String var4 = (String)w.a<"Û">(var3, 192468336863492695L);
         JsonElement var6 = w.a<"Û">(var1, var4, 268791691692763549L);
         if (var6 instanceof JsonObject) {
            JsonObject var5 = (JsonObject)var6;
            Optional var12 = w.a<"Û">(C0933.f1413, (Predicate<C1266>)var1x -> w.a<"Û">(var1x, 123401924173496230L).equals(var4), 120632717548688135L);
            if (!w.a<"Û">(var12, 334854191428563747L)) {
               boolean var7 = w.a<"Û">(var2, (C1266)w.a<"Û">(var12, 145495104118328881L), 258912813308304151L);
               if (!var7) {
                  w.a<"Û">(var5, "enabled", 123031262139480692L);
               }

               w.a<"Û">(var5, "key", 123031262139480692L);
               if (w.a<"Û">(var5, "settings", 314399812765309162L)) {
                  JsonElement var8 = w.a<"Û">(var5, "settings", 268791691692763549L);
                  if (w.a<"Û">(var8, 266361156733738545L)) {
                     ArrayList var9 = new ArrayList();
                     Iterator var10 = w.a<"Û">(
                        w.a<"Û">(w.a<"Û">(w.a<"Û">(var8, 322749330123725882L), 274534791465332761L), 354320704134596920L), 194435811056609302L
                     );

                     while (w.a<"Û">(var10, 333900474771661065L)) {
                        Entry var11 = (Entry)w.a<"Û">(var10, 192468336863492695L);
                        if (var7) {
                           break;
                        }

                        if (!w.a<"Û">((JsonElement)w.a<"Û">(var11, 196870340575900401L), 266361156733738545L)) {
                           w.a<"Û">(var9, (String)w.a<"Û">(var11, 141740301999341859L), 276802003864609490L);
                        }
                     }

                     var10 = w.a<"Û">(var9, 341496865259068134L);

                     while (w.a<"Û">(var10, 333900474771661065L)) {
                        String var14 = (String)w.a<"Û">(var10, 192468336863492695L);
                        w.a<"Û">(w.a<"Û">(var8, 322749330123725882L), var14, 123031262139480692L);
                     }
                  }
               }
            }
         }
      }
   }

   public void m2166(JsonObject var1) {
      Iterator var2 = w.a<"Û">(w.a<"Û">(w.a<"Û">(var1, 274534791465332761L), 269526036007691028L), 277715502174036685L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         JsonElement var3 = (JsonElement)w.a<"Û">(var2, 192468336863492695L);
         if (var3 instanceof JsonObject var4) {
            w.a<"Û">(var4, "enabled", 123031262139480692L);
            w.a<"Û">(var4, "settings", 123031262139480692L);
         }
      }
   }

   public static String _t6W8YvS4nyCLrg32MO3n3V5IlFRzIcW8umSxxE0obvKyv1esvEwjVOhmRKEGp2XaRKyzy0iSsg9A5OtvHcuH8Zik6rS84fjloxz/* $VF was: 4t6W8YvS4nyCLrg32MO3n3V5IlFRzIcW8umSxxE0obvKyv1esvEwjVOhmRKEGp2XaRKyzy0iSsg9A5OtvHcuH8Zik6rS84fjloxz*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
