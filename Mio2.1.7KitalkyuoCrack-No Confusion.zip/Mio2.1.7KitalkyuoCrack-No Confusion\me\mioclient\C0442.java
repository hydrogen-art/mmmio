package me.mioclient;

import java.awt.Color;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class C0442 extends C1092 {
   public final List<? extends C1050> f3579;
   public static int f3580 = 1953393085;

   public C0442(C0601 var1, C1050 var2) {
      this(var1, Collections.singletonList(var2));
   }

   public C0442(C0601 var1, List<? extends C1050> var2) {
      super(var1);
      this.f3579 = var2;
   }

   @Override
   public void m0001(class_332 var1, class_4587 var2, double var3, double var5) {
      super.m0001(var1, var2, var3, var5);
      float var7 = this.m$$blr6ebdKP2LGUjKUyCocrLjr1i2vXOWt5PQpAh6RXbTMoUxdoDzspWG00c0Gq9Uu7M1QQqX8SCtCwVNAAJzxn7j5DwakEGmqi(
         (float)this.m$$xdvvw3zUfaxk5zyR1LuOyULP1ncsBH0Jp7Rg4gVMI1b0GhMBLMGdWDzO5FqEI2nDnNORyLVYlZg5A0VP0jSXwr08L1rXIE9mU()
      );

      for (C1050 var9 : this.f3579) {
         var2.method_22903();
         float var10 = var9.m0846();
         var10 = (float)class_3532.method_15350(
            Double.longBitsToDouble(((long)f3580 | 255242L) + ~((long)f3580 & 255242L) + 1L ^ 4607182420753353911L)
               - Math.pow(
                  (double)(Float.intBitsToFloat((f3580 | 754811) + ~(f3580 & 754811) + 1 ^ 1273359814) - var10),
                  Double.longBitsToDouble(((long)f3580 | 95831L) + ~((long)f3580 & 95831L) + 1L ^ 4616189620008198122L)
               ),
            0.0,
            Double.longBitsToDouble(((long)f3580 | 445825L) + ~((long)f3580 & 445825L) + 1L ^ 4607182420753032252L)
         );
         Color var11 = this.m1487(var7, var9);
         float var12 = var9.f1956.m2325();
         float var13 = var12 * (Float.intBitsToFloat((f3580 | 301342) + ~(f3580 & 301342) + 1 ^ 1273688227) - var10);
         var2.method_46416(
            this.m$$J2vzM8tQUBrnhaeKEn3DxUerUo4kacrUdDTRM1r3mFATql9KhDgfHJG2ByRVpE90B80rUuwwEfsf8CaPgH20dmAlh9qcZ4zRK(var12)
               - var13 * (float)this.m$$qup8XqTAFgknPhQwMHMkVJVJiKxfWq4Wy0xCYEO0pilW70JbVKEZgNGmfi81aJ2v9LVJH6QKgPxjZhsZSpjMxa22W7Vw4ydn8(),
            var7,
            0.0F
         );
         var9.m0844(var1, 0.0F, 0.0F, var11);
         if (var10 != 0.0F) {
            var7 += (
                  (float)this.m$$xdvvw3zUfaxk5zyR1LuOyULP1ncsBH0Jp7Rg4gVMI1b0GhMBLMGdWDzO5FqEI2nDnNORyLVYlZg5A0VP0jSXwr08L1rXIE9mU() * var10
                     + Float.intBitsToFloat((f3580 | 712368) + ~(f3580 & 712368) + 1 ^ 1273280269)
               )
               * (float)this.m$$jpYIY2cdfHue6qtvxQd2wZJNbmuBTFBerE3xA4HeCXfNIDvLbFbnbtHVlqwPE91T6gyJXuQlQoPAsmxDatBwNm66YRYG1L6t7();
         }

         var2.method_22909();
      }
   }

   @Override
   public float[] m1073() {
      float var1 = 0.0F;
      float var2 = 0.0F;

      for (C1050 var4 : this.f3579) {
         var4.m0845();
         if (var4.m0846() != 0.0F) {
            float var5 = var4.m0846();
            var5 = (float)class_3532.method_15350(
               Double.longBitsToDouble(((long)f3580 | 5076L) + ~((long)f3580 & 5076L) + 1L ^ 4607182420753414761L)
                  - Math.pow(
                     (double)(Float.intBitsToFloat((f3580 | 695051) + ~(f3580 & 695051) + 1 ^ 1273295542) - var5),
                     Double.longBitsToDouble(((long)f3580 | 109662L) + ~((long)f3580 & 109662L) + 1L ^ 4616189620008240611L)
                  ),
               0.0,
               Double.longBitsToDouble(((long)f3580 | 19637L) + ~((long)f3580 & 19637L) + 1L ^ 4607182420753392904L)
            );
            float var6 = C0498.f4738.m3896(var4.m0847().getString());
            var1 += (float)this.m$$xdvvw3zUfaxk5zyR1LuOyULP1ncsBH0Jp7Rg4gVMI1b0GhMBLMGdWDzO5FqEI2nDnNORyLVYlZg5A0VP0jSXwr08L1rXIE9mU() * var5
               + Float.intBitsToFloat((f3580 | 659235) + ~(f3580 & 659235) + 1 ^ 1273259678);
            if (var6 > var2) {
               var2 = var6;
            }
         }
      }

      if (!m$$pKAlAHlut5QYTZu8DvqT5VzS9Xa0uVrkPAk4yJDRfk6MjQbn4aOFybrtSVXm9xiJTiOYHuUl6wATNXz9MGA1Dezfp5o5FWC7Z && var2 == 0.0F) {
         var2 = Float.intBitsToFloat((f3580 | 513228) + ~(f3580 & 513228) + 1 ^ 908180849);
         var1 = (float)this.m$$xdvvw3zUfaxk5zyR1LuOyULP1ncsBH0Jp7Rg4gVMI1b0GhMBLMGdWDzO5FqEI2nDnNORyLVYlZg5A0VP0jSXwr08L1rXIE9mU();
      }

      float[] var10000 = new float[(f3580 | 750414) + ~(f3580 & 750414) + 1 ^ 1952783089];
      var10000[(f3580 | 474585) + ~(f3580 & 474585) + 1 ^ 1953059940] = var2;
      var10000[(f3580 | 426301) + ~(f3580 & 426301) + 1 ^ 1953032321] = var1;
      return var10000;
   }

   public List<? extends C1050> m1486() {
      return this.f3579;
   }

   public Color m1487(float var1, C1050 var2) {
      return this.m$$5A06gZj2dsph0f9cXKvj8epziI0fcqRkJo7UqoMuOreVQZNCp519kmHqqLBtI2Y6PvI4f5F9teEN3bzlthtsJA0DeNZJu8qk0.m3244(var1);
   }

   static {
      long var10000 = 3310498175977713600L;
   }
}
