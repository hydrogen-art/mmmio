package me.mioclient;

import java.util.function.Predicate;

public class C0505 implements Predicate {
   public C0936 f4907;

   public C0505(C0936 var1) {
      this.f4907 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4907.f1817, 254992554122318132L);
   }
}
