package me.mioclient;

import java.util.function.Predicate;

public class C0530 implements Predicate {
   public C0309 f4019;

   public C0530(C0309 var1) {
      this.f4019 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4019.f3405, 254992554122318132L);
   }
}
