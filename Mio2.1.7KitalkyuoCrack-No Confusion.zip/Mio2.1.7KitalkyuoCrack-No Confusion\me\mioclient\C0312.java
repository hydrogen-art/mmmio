package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0312 implements C0196 {
   f0218("Normal"),
   f0219("SwapBack"),
   f0220("Silent");

   public final String f0221;

   public C0312(String var3) {
      this.f0221 = var3;
   }

   @Override
   public String getName() {
      return this.f0221;
   }

   public static String TfCeXeHklpJUuJEw0vL47yxJ5GcJEAWybDfm6V2XUfff1YUjFBu2t8x0YSi4ha1w7Ld4gdGCOvphECIIKADJ8OiuEygPgzpqS7TL(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
