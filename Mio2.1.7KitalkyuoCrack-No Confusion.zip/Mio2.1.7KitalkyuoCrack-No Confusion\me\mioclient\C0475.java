package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2172;
import net.minecraft.class_238;
import net.minecraft.class_243;

public class C0475 extends C0219 {
   public static final Color f3995 = new Color(
      (C0475.f3997 | 902479) + ~(C0475.f3997 & 902479) + 1 ^ -933488675,
      (C0475.f3997 | 129310) + ~(C0475.f3997 & 129310) + 1 ^ -934270093,
      (C0475.f3997 | 925544) + ~(C0475.f3997 & 925544) + 1 ^ -933245691,
      (C0475.f3997 | 187772) + ~(C0475.f3997 & 187772) + 1 ^ -934080663
   );
   public static final Color f3996 = new Color(
      (C0475.f3997 | 339025) + ~(C0475.f3997 & 339025) + 1 ^ -933953988,
      (C0475.f3997 | 949173) + ~(C0475.f3997 & 949173) + 1 ^ -933254696,
      (C0475.f3997 | 833894) + ~(C0475.f3997 & 833894) + 1 ^ -933401845,
      (C0475.f3997 | 272850) + ~(C0475.f3997 & 272850) + 1 ^ -933889089
   );
   public static int f3997 = w.a<"B">(408786363563733127L, 257832362129977838L);

   public C0475() {
      super("highlight");
      w.a<"Û">(
         C0933.f1430,
         new C0122(
            this,
            () -> f3995,
            () -> f3996,
            () -> w.a<"B">(w.a<"B">((f3997 | 585472) + ~(f3997 & 585472) + 1 ^ -136757907, 349057757755238323L), 243402859552372891L),
            () -> w.a<"B">(w.a<"B">((f3997 | 855096) + ~(f3997 & 855096) + 1 ^ -1996693931, 349057757755238323L), 243402859552372891L),
            () -> w.a<"B">((boolean)((f3997 | 754535) + ~(f3997 & 754535) + 1 ^ -933605109), 320330632857389983L),
            () -> w.a<"B">((boolean)((f3997 | 808447) + ~(f3997 & 808447) + 1 ^ -933394541), 320330632857389983L),
            (f3997 | 167984) + ~(f3997 & 167984) + 1 ^ -934067787
         ),
         215636623669649177L
      );
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         var1,
         w.a<"Û">(
            (RequiredArgumentBuilder)w.a<"Û">(
               w.a<"B">("pos", new C0589(), 191188367299315725L),
               w.a<"Û">(
                  w.a<"B">("beam", 233839479830701924L),
                  (Command)var1x -> {
                     class_243 var2 = (class_243)w.a<"Û">(var1x, "pos", class_243.class, 275658406246533271L);
                     class_238 var3 = w.a<"B">(
                        var2,
                        w.a<"B">(((long)f3997 | 272615L) + ~((long)f3997 & 272615L) + 1L ^ -4598175220479165814L, 317139102743630955L),
                        w.a<"B">(((long)f3997 | 136792L) + ~((long)f3997 & 136792L) + 1L ^ -4598175220479310795L, 317139102743630955L),
                        w.a<"B">(((long)f3997 | 793502L) + ~((long)f3997 & 793502L) + 1L ^ -4598175220478653965L, 317139102743630955L),
                        143694487255612937L
                     );
                     var3 = w.a<"Û">(
                        w.a<"Û">(
                           var3,
                           (double)w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                              290783177543878799L
                           ),
                           182030847371476974L
                        ),
                        (double)w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 296776091267530333L
                        ),
                        136195098838741599L
                     );
                     w.a<"Û">(C0933.f1430, this, var3, 317866513404830971L);
                     return (f3997 | 550147) + ~(f3997 & 550147) + 1 ^ -933644433;
                  },
                  286944572020109927L
               ),
               364326416200407929L
            ),
            (Command)var1x -> {
               class_243 var2 = (class_243)w.a<"Û">(var1x, "pos", class_243.class, 275658406246533271L);
               class_238 var3 = w.a<"B">(
                  var2,
                  w.a<"B">(((long)f3997 | 543535L) + ~((long)f3997 & 543535L) + 1L ^ -4598175220478928574L, 317139102743630955L),
                  w.a<"B">(((long)f3997 | 117938L) + ~((long)f3997 & 117938L) + 1L ^ -4598175220479549729L, 317139102743630955L),
                  w.a<"B">(((long)f3997 | 90150L) + ~((long)f3997 & 90150L) + 1L ^ -4598175220479511989L, 317139102743630955L),
                  143694487255612937L
               );
               w.a<"Û">(C0933.f1430, this, var3, 317866513404830971L);
               return (f3997 | 251045) + ~(f3997 & 251045) + 1 ^ -934148407;
            },
            368995281709124746L
         ),
         289819728773344295L
      );
   }

   public static String h1sBl8vmeGTUy4KS50gHWhveQm84z3JGiyiX5B5QhHaAhu5WZX1TIoLnuP52QNnwulKonyuM7F0UZIh05xVBqgtQPKv0q4PFoLhk(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
