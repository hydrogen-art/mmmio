package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.lang.invoke.MethodHandles.Lookup;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_437;

public class C0140 extends C1214 {
   public final C1244 f3717 = new C1244("Category");
   public final class_437 f3718;
   public static int f3719 = -2064700398;

   public C0140(class_437 var1, Path var2) {
      this.f3718 = var1;
      this.f3717.m0234().add(new C0711(this.f3717, new C1002().m2591(this.m1541(var2)).m2593("Preset: \u0001")));
      C0430 var3 = this.m1543(var2);
      if (var3 != null) {
         this.f3717.m0244(new C0469(this.f3717, "Import", () -> this.m1542(var2, var3)));
      } else {
         C0430[] var4 = C0430.values();
         int var5 = var4.length;

         for (int var6 = (f3719 | 916969) + ~(f3719 & 916969) + 1 ^ -2065509893; var6 < var5; var6++) {
            C0430 var7 = var4[var6];
            this.f3717.m0244(new C0469(this.f3717, C0391.m3982(var7), () -> this.m1542(var2, var7)));
         }
      }

      this.f3717.m0244(new C0469(this.f3717, "Cancel", this::m1540));
      this.m$$9aB6sO5vkthBEU5EK6PqwDAXEuNQSibDyo4phdKl0K461AGPhyt87clCvCxq8yxvsd88Jl5acPfF1UDX0VBM0dA7JXohLkjpQ().add(this.f3717);
   }

   @Override
   public void m1540() {
      m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1507(this.f3718);
   }

   public String m1541(Path var1) {
      return var1.toFile().getName().replace(".json", "");
   }

   public void m1542(Path var1, C0430 var2) {
      String var3 = var1.toFile().getName();

      try {
         Files.copy(var1, var2.m3142().resolve(var3));
      } catch (IOException var5) {
         var5.printStackTrace();
      }

      C0933.f1411.m0283(var2).m0292();
      m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1507(this.f3718);
   }

   public C0430 m1543(Path var1) {
      Object var2 = null;

      try {
         var2 = Files.readString(var1);
         JsonElement var3 = JsonParser.parseString((String)var2);
         if (!var3.isJsonObject()) {
            return null;
         } else {
            JsonObject var4 = var3.getAsJsonObject();
            if (!var4.has("category")) {
               return null;
            } else {
               String var5 = var4.get("category").getAsString();
               return C0430.m3143(var5);
            }
         }
      } catch (IOException var6) {
         return null;
      }
   }

   public static boolean m1544(class_437 var0, List<Path> var1) {
      ArrayList var2 = new ArrayList();
      var1.stream().filter(var0x -> var0x.toString().endsWith(".json")).forEach(var2::add);
      if (var2.size() != ((f3719 | 800941) + ~(f3719 & 800941) + 1 ^ -2065492802)) {
         return (boolean)((f3719 | 861695) + ~(f3719 & 861695) + 1 ^ -2065561107);
      } else {
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1507(
            new C0140(var0, (Path)var2.getFirst())
         );
         return (boolean)((f3719 | 466416) + ~(f3719 & 466416) + 1 ^ -2065157661);
      }
   }

   static {
      long var10000 = 110343145593252740L;
   }

   public static String P6SL0kLS7K5blWX0HEDohKmBzeFhiwTzxSZ79uTzzOLgxExXdR4DYQ7wCLOdpgKz1orSXkILjoXZ8I3RCNJFetqFNm1Y9F43rGBM(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
