package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.io.IOException;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2172;

public final class C0527 extends C0219 {
   public static int f1564 = w.a<"B">(7256521730331014907L, 257832362129977838L);

   public C0527() {
      super("folder");
      String[] var10001 = new String[(f1564 | 521463) + ~(f1564 & 521463) + 1 ^ 1127920345];
      var10001[(f1564 | 440550) + ~(f1564 & 440550) + 1 ^ 1128005321] = "openfolder";
      w.a<"Û">(this, var10001, 219242751041471617L);
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(var1, (Command)var0 -> {
         try {
            w.a<"Û">(w.a<"B">(375285768771221481L), w.a<"Û">(C1165.f0524, 318068064568792515L), 115278521232594143L);
         } catch (IOException var2) {
            w.a<"Û">(var2, 167072644850519245L);
         }

         return (f1564 | 85093) + ~(f1564 & 85093) + 1 ^ 1128008267;
      }, 286944572020109927L);
   }

   public static String _44v9DU6zzZ0o4RCa7ycDtAWxbMfOXKNlCPGbRiPjBgDmlAklqvJmviOQRwlQqZaoYmBBJFqGIGnP0uG5FFKeiTeqMovsf36Jpt5/* $VF was: 144v9DU6zzZ0o4RCa7ycDtAWxbMfOXKNlCPGbRiPjBgDmlAklqvJmviOQRwlQqZaoYmBBJFqGIGnP0uG5FFKeiTeqMovsf36Jpt5*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
