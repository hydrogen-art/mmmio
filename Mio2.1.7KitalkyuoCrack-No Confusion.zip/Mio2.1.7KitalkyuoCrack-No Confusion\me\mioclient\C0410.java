package me.mioclient;

import java.util.function.Predicate;

public class C0410 implements Predicate {
   public C0671 f1362;

   public C0410(C0671 var1) {
      this.f1362 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1362.f4651, 174312564406604366L) == C0672.f4562;
   }
}
