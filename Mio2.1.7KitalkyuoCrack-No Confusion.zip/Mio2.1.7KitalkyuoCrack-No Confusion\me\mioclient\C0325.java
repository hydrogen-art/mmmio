package me.mioclient;

import net.minecraft.class_1291;
import net.minecraft.class_6880;

public class C0325 extends C1180 {
   public final class_6880<class_1291> f3446;

   public C0325(class_6880<class_1291> var1) {
      this.f3446 = var1;
   }

   public class_6880<class_1291> m3463() {
      return this.f3446;
   }
}
