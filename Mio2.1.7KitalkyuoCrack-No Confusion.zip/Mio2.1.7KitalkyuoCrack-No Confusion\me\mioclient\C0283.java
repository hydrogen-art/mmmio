package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.io.IOException;
import java.lang.invoke.MethodHandles.Lookup;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public final class C0283 extends C0219 {
   public static int f3137 = w.a<"B">(7651209039122848022L, 257832362129977838L);

   public C0283() {
      super("preset");
      String[] var10001 = new String[(f3137 | 866253) + ~(f3137 & 866253) + 1 ^ 633661769];
      var10001[(f3137 | 508243) + ~(f3137 & 508243) + 1 ^ 634265557] = "config";
      var10001[(f3137 | 880146) + ~(f3137 & 880146) + 1 ^ 633647253] = "cfg";
      w.a<"Û">(this, var10001, 219242751041471617L);
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         (LiteralArgumentBuilder)w.a<"Û">(
            (LiteralArgumentBuilder)w.a<"Û">(
               var1,
               w.a<"Û">(
                  (RequiredArgumentBuilder)w.a<"Û">(
                     (RequiredArgumentBuilder)w.a<"Û">(
                        (RequiredArgumentBuilder)w.a<"Û">(
                           (RequiredArgumentBuilder)w.a<"Û">(
                              (RequiredArgumentBuilder)w.a<"Û">(
                                 w.a<"B">("category", new C0652(), 191188367299315725L),
                                 w.a<"Û">(
                                    w.a<"B">("save", 233839479830701924L),
                                    w.a<"Û">(
                                       w.a<"B">("preset", w.a<"B">(147271288244807063L), 191188367299315725L),
                                       (Command)var0 -> {
                                          String var1x = (String)w.a<"Û">(var0, "preset", String.class, 275658406246533271L);
                                          C1063 var2 = w.a<"B">(var0, "category", 119366582752243058L);

                                          try {
                                             w.a<"Û">(var2, var1x, 190429318031903099L);
                                          } catch (IOException var4) {
                                             w.a<"Û">(var4, 167072644850519245L);
                                          }

                                          w.a<"B">(
                                             w.a<"B">(new C1002().m2591(var1x).m2593("Preset \u0001 has been saved."), 228465064790135899L),
                                             w.a<"B">((f3137 | 246649) + ~(f3137 & 246649) + 1 ^ -634002944, 289296048454852994L),
                                             241936116971186271L
                                          );
                                          return (f3137 | 225858) + ~(f3137 & 225858) + 1 ^ 634039493;
                                       },
                                       368995281709124746L
                                    ),
                                    289819728773344295L
                                 ),
                                 364326416200407929L
                              ),
                              w.a<"Û">(
                                 w.a<"B">("delete", 233839479830701924L),
                                 w.a<"Û">(
                                    w.a<"B">("preset", new C0861(), 191188367299315725L),
                                    (Command)var0 -> {
                                       C1039 var1x = w.a<"B">(var0, "category", "preset", 302800873028247643L);
                                       C1063 var2 = w.a<"B">(var0, "category", 119366582752243058L);
                                       w.a<"Û">(var2, w.a<"Û">(var1x, 348008890037149423L), 338865136836756548L);
                                       w.a<"B">(
                                          w.a<"B">(
                                             new C1002().m2591(w.a<"Û">(var1x, 348008890037149423L)).m2593("Preset \u0001 has been deleted."),
                                             228465064790135899L
                                          ),
                                          w.a<"B">((f3137 | 91122) + ~(f3137 & 91122) + 1 ^ -633912693, 289296048454852994L),
                                          241936116971186271L
                                       );
                                       return (f3137 | 448699) + ~(f3137 & 448699) + 1 ^ 634324540;
                                    },
                                    368995281709124746L
                                 ),
                                 289819728773344295L
                              ),
                              364326416200407929L
                           ),
                           w.a<"Û">(
                              w.a<"B">("rename", 233839479830701924L),
                              w.a<"Û">(
                                 w.a<"B">("preset", new C0861(), 191188367299315725L),
                                 w.a<"Û">(
                                    w.a<"B">("name", w.a<"B">(147271288244807063L), 191188367299315725L),
                                    (Command)var0 -> {
                                       C1039 var1x = w.a<"B">(var0, "category", "preset", 302800873028247643L);
                                       C1063 var2 = w.a<"B">(var0, "category", 119366582752243058L);
                                       w.a<"Û">(
                                          var2,
                                          w.a<"Û">(var1x, 348008890037149423L),
                                          (String)w.a<"Û">(var0, "name", String.class, 275658406246533271L),
                                          214555622936117431L
                                       );
                                       w.a<"B">(
                                          w.a<"B">(
                                             new C1002()
                                                .m2591((String)w.a<"Û">(var0, "name", String.class, 275658406246533271L))
                                                .m2591(w.a<"Û">(var1x, 348008890037149423L))
                                                .m2593("The name of \u0001 has been set to \u0001."),
                                             228465064790135899L
                                          ),
                                          w.a<"B">((f3137 | 243134) + ~(f3137 & 243134) + 1 ^ -634022713, 289296048454852994L),
                                          241936116971186271L
                                       );
                                       return (f3137 | 410796) + ~(f3137 & 410796) + 1 ^ 634362411;
                                    },
                                    368995281709124746L
                                 ),
                                 364326416200407929L
                              ),
                              289819728773344295L
                           ),
                           364326416200407929L
                        ),
                        w.a<"Û">(
                           w.a<"B">("load", 233839479830701924L),
                           w.a<"Û">(
                              w.a<"B">("preset", new C0861(), 191188367299315725L),
                              (Command)var1x -> {
                                 w.a<"Û">(w.a<"Û">(C0933.f1411, 189952305487564127L), 202669694409874491L);
                                 C0430 var2 = (C0430)w.a<"Û">(var1x, "category", C0430.class, 275658406246533271L);
                                 C1039 var3 = w.a<"B">(var1x, "category", "preset", 302800873028247643L);
                                 C1063 var4 = w.a<"B">(var1x, "category", 119366582752243058L);
                                 w.a<"Û">(var4, 144584665041950994L);
                                 w.a<"Û">(var4, w.a<"Û">(var3, 348008890037149423L), 234401029717440555L);
                                 w.a<"B">(
                                    w.a<"B">(
                                       new C1002().m2591(w.a<"Û">(var3, 348008890037149423L)).m2593("Preset \u0001 has been loaded."), 228465064790135899L
                                    ),
                                    w.a<"B">((f3137 | 667743) + ~(f3137 & 667743) + 1 ^ -633597658, 289296048454852994L),
                                    241936116971186271L
                                 );
                                 if (var2 == C0430.f2568) {
                                    w.a<"Û">(this, this::m3322, 122279747764383364L);
                                 }

                                 return (f3137 | 240688) + ~(f3137 & 240688) + 1 ^ 634024631;
                              },
                              368995281709124746L
                           ),
                           289819728773344295L
                        ),
                        364326416200407929L
                     ),
                     w.a<"Û">(
                        w.a<"B">("specific", 233839479830701924L),
                        w.a<"Û">(
                           (RequiredArgumentBuilder)w.a<"Û">(
                              w.a<"B">("preset", new C0861(), 191188367299315725L),
                              w.a<"Û">(
                                 w.a<"B">("module_category", new C0417<>(C1045.class, "Category"), 191188367299315725L),
                                 (Command)var1x -> {
                                    w.a<"Û">(w.a<"Û">(C0933.f1411, 189952305487564127L), 202669694409874491L);
                                    C1039 var2 = w.a<"B">(var1x, "category", "preset", 302800873028247643L);
                                    C1063 var3 = w.a<"B">(var1x, "category", 119366582752243058L);
                                    C1045 var4 = (C1045)w.a<"Û">(var1x, "module_category", C1045.class, 275658406246533271L);
                                    w.a<"Û">(var3, 144584665041950994L);
                                    w.a<"Û">(
                                       this,
                                       var2,
                                       (Predicate<C1266>)var1xx -> (boolean)(w.a<"Û">(var1xx, 244872541992280135L) == var4
                                             ? (f3137 | 785104) + ~(f3137 & 785104) + 1 ^ 633480279
                                             : (f3137 | 370646) + ~(f3137 & 370646) + 1 ^ 634157392),
                                       300060766169326984L
                                    );
                                    w.a<"B">(
                                       w.a<"B">(
                                          new C1002()
                                             .m2591(w.a<"Û">(var4, 127516526000099593L))
                                             .m2591(w.a<"Û">(var2, 348008890037149423L))
                                             .m2593("Preset \u0001 for \u0001 has been loaded."),
                                          228465064790135899L
                                       ),
                                       w.a<"B">((f3137 | 861267) + ~(f3137 & 861267) + 1 ^ -633666262, 289296048454852994L),
                                       241936116971186271L
                                    );
                                    return (f3137 | 885482) + ~(f3137 & 885482) + 1 ^ 633625709;
                                 },
                                 368995281709124746L
                              ),
                              364326416200407929L
                           ),
                           w.a<"Û">(
                              w.a<"B">("modules", new C0512(new C1036()), 191188367299315725L),
                              (Command)var1x -> {
                                 w.a<"Û">(w.a<"Û">(C0933.f1411, 189952305487564127L), 202669694409874491L);
                                 C1039 var2 = w.a<"B">(var1x, "category", "preset", 302800873028247643L);
                                 C1063 var3 = w.a<"B">(var1x, "category", 119366582752243058L);
                                 Set var4 = (Set)w.a<"Û">(
                                    w.a<"Û">(
                                       w.a<"Û">((List)w.a<"Û">(var1x, "modules", List.class, 275658406246533271L), 110814793610710346L),
                                       Object::getClass,
                                       141209812120559377L
                                    ),
                                    w.a<"B">(337714158670628805L),
                                    185878351305311015L
                                 );
                                 w.a<"Û">(var3, 144584665041950994L);
                                 Predicate var5 = var1xx -> w.a<"Û">(var4, var1xx.getClass(), 338145669613544495L);
                                 w.a<"Û">(this, var2, var5, 300060766169326984L);
                                 w.a<"B">(
                                    w.a<"B">(
                                       new C1002()
                                          .m2591(w.a<"Û">(this, var5, 200241977080800996L))
                                          .m2591(w.a<"Û">(var2, 348008890037149423L))
                                          .m2593("Preset \u0001 for \u0001 has been loaded."),
                                       228465064790135899L
                                    ),
                                    w.a<"B">((f3137 | 112626) + ~(f3137 & 112626) + 1 ^ -633891189, 289296048454852994L),
                                    241936116971186271L
                                 );
                                 return (f3137 | 825009) + ~(f3137 & 825009) + 1 ^ 633686070;
                              },
                              368995281709124746L
                           ),
                           364326416200407929L
                        ),
                        289819728773344295L
                     ),
                     364326416200407929L
                  ),
                  w.a<"Û">(
                     w.a<"B">("list", 233839479830701924L),
                     (Command)var0 -> {
                        C1063 var1x = w.a<"B">(var0, "category", 119366582752243058L);
                        w.a<"B">(
                           w.a<"Û">(
                              w.a<"Û">(
                                 w.a<"B">("Preset list: ", 228465064790135899L),
                                 w.a<"B">(
                                    w.a<"Û">(var1x, 268370374673263607L),
                                    (Function<C1039, class_2561>)var0x -> w.a<"B">(w.a<"Û">(var0x, 348008890037149423L), 228465064790135899L),
                                    179763761551956616L
                                 ),
                                 267862536496645581L
                              ),
                              ".",
                              194629304146735395L
                           ),
                           w.a<"B">((f3137 | 398900) + ~(f3137 & 398900) + 1 ^ -634374323, 289296048454852994L),
                           241936116971186271L
                        );
                        return (f3137 | 144526) + ~(f3137 & 144526) + 1 ^ 634120713;
                     },
                     286944572020109927L
                  ),
                  364326416200407929L
               ),
               289819728773344295L
            ),
            w.a<"Û">(
               w.a<"B">("export", 233839479830701924L),
               w.a<"Û">(
                  w.a<"B">("module", new C1036(), 191188367299315725L),
                  (Command)var0 -> {
                     C1266 var1x = (C1266)w.a<"Û">(var0, "module", C1266.class, 275658406246533271L);
                     JsonObject var2 = w.a<"Û">(w.a<"Û">(var1x, 330994760695067988L), 322749330123725882L);
                     w.a<"Û">(var2, "bind", 123031262139480692L);
                     w.a<"Û">(var2, "toggled", 123031262139480692L);
                     w.a<"Û">(var2, "key", 123031262139480692L);
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1774,
                        w.a<"Û">(
                           w.a<"B">(234753990477286496L),
                           w.a<"Û">(w.a<"Û">(var2, 243476962473991891L), StandardCharsets.UTF_8, 330169314896052399L),
                           306394323573235298L
                        ),
                        194738086810821242L
                     );
                     w.a<"B">(
                        w.a<"Û">(
                           w.a<"Û">(
                              w.a<"B">("Successfully copied ", 228465064790135899L),
                              w.a<"Û">(w.a<"B">(w.a<"Û">(var1x, 248211090350577353L), 228465064790135899L), class_124.field_1080, 173336747796326302L),
                              267862536496645581L
                           ),
                           " config to your clipboard",
                           194629304146735395L
                        ),
                        w.a<"B">((f3137 | 30107) + ~(f3137 & 30107) + 1 ^ -633973534, 289296048454852994L),
                        241936116971186271L
                     );
                     return (f3137 | 781953) + ~(f3137 & 781953) + 1 ^ 633483270;
                  },
                  368995281709124746L
               ),
               289819728773344295L
            ),
            289819728773344295L
         ),
         w.a<"Û">(
            w.a<"B">("import", 233839479830701924L),
            w.a<"Û">(
               w.a<"B">("module", new C1036(), 191188367299315725L),
               (Command)var0 -> {
                  C1266 var1x = (C1266)w.a<"Û">(var0, "module", C1266.class, 275658406246533271L);

                  try {
                     String var2 = new String(
                        w.a<"Û">(
                           w.a<"B">(197341362638442655L),
                           w.a<"Û">(
                              w.a<"Û">(
                                 w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1774,
                                    259334602046439493L
                                 ),
                                 252583459449976237L
                              ),
                              "\n",
                              "",
                              328425598364162988L
                           ),
                           308648804392947926L
                        )
                     );
                     w.a<"Û">(var1x, w.a<"B">(var2, 360179252972467592L), 221340337294098988L);
                     w.a<"B">(
                        w.a<"Û">(
                           w.a<"Û">(
                              w.a<"B">("Successfully loaded ", 228465064790135899L),
                              w.a<"Û">(w.a<"B">(w.a<"Û">(var1x, 248211090350577353L), 228465064790135899L), class_124.field_1080, 173336747796326302L),
                              267862536496645581L
                           ),
                           " config from your clipboard",
                           194629304146735395L
                        ),
                        w.a<"B">((f3137 | 954539) + ~(f3137 & 954539) + 1 ^ -633818670, 289296048454852994L),
                        241936116971186271L
                     );
                  } catch (Exception var4) {
                     class_5250 var3 = w.a<"Û">(
                        w.a<"Û">(
                           w.a<"B">("Failed to load ", 228465064790135899L),
                           w.a<"Û">(w.a<"B">(w.a<"Û">(var1x, 248211090350577353L), 228465064790135899L), class_124.field_1080, 173336747796326302L),
                           267862536496645581L
                        ),
                        " config",
                        194629304146735395L
                     );
                     if (w.a<"Û">(
                        w.a<"Û">(w.a<"Û">(var4, 172502519648458560L)[(f3137 | 499338) + ~(f3137 & 499338) + 1 ^ 634273804], 263625677869614936L),
                        "Base64",
                        160084314699716367L
                     )) {
                        var3 = w.a<"Û">(var3, " due to invalid input", 194629304146735395L);
                     } else {
                        var3 = w.a<"Û">(var3, " due to an unknown reason", 194629304146735395L);
                     }

                     w.a<"B">(var3, w.a<"B">((f3137 | 101257) + ~(f3137 & 101257) + 1 ^ -633885968, 289296048454852994L), C0639.f3881, 211469761772001922L);
                     w.a<"Û">(var4, 277292852406578821L);
                  }

                  return (f3137 | 106015) + ~(f3137 & 106015) + 1 ^ 633880728;
               },
               368995281709124746L
            ),
            289819728773344295L
         ),
         289819728773344295L
      );
      w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"B">("restore", 233839479830701924L),
            (Command)var0 -> {
               JsonElement var1x = w.a<"Û">(w.a<"Û">(C0933.f1411, 189952305487564127L), 163231422915531009L);
               if (var1x == null) {
                  return (f3137 | 35253) + ~(f3137 & 35253) + 1 ^ 633952050;
               } else {
                  w.a<"Û">(C0430.f2568, var1x, 184620458326486974L);
                  w.a<"B">(
                     w.a<"B">("Restored previous preset.", 228465064790135899L),
                     w.a<"B">((f3137 | 801081) + ~(f3137 & 801081) + 1 ^ -633726912, 289296048454852994L),
                     241936116971186271L
                  );
                  return (f3137 | 239383) + ~(f3137 & 239383) + 1 ^ 634026384;
               }
            },
            286944572020109927L
         ),
         289819728773344295L
      );
      w.a<"Û">(
         var1,
         (Command)var1x -> {
            w.a<"Û">(
               this,
               (Runnable)() -> w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, new C0162(), 304438186446504550L
                  ),
               122279747764383364L
            );
            return (f3137 | 413640) + ~(f3137 & 413640) + 1 ^ 634360143;
         },
         286944572020109927L
      );
   }

   public void m3320(C1039 var1, Predicate<C1266> var2) {
      Iterator var3 = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

      while (w.a<"Û">(var3, 333900474771661065L)) {
         C1266 var4 = (C1266)w.a<"Û">(var3, 192468336863492695L);
         if (!(var4 instanceof C0601) && w.a<"Û">(var2, var4, 258912813308304151L)) {
            try {
               w.a<"Û">(
                  var4,
                  w.a<"Û">(w.a<"Û">(w.a<"Û">(var1, 181370596178913050L), 320559966341340006L), w.a<"Û">(var4, 123401924173496230L), 268791691692763549L),
                  221340337294098988L
               );
            } catch (Exception var6) {
            }
         }
      }
   }

   public String m3321(Predicate<C1266> var1) {
      return (String)w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 110814793610710346L), var1, 287370376266094532L),
            C0502::getName,
            141209812120559377L
         ),
         w.a<"B">(", ", 223985416319567874L),
         185878351305311015L
      );
   }

   public void m3322() {
      class_5250 var1 = w.a<"B">(151712998973257886L);
      w.a<"Û">(var1, "Preset binds: ", 194629304146735395L);
      Iterator var2 = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         C1266 var3 = (C1266)w.a<"Û">(var2, 192468336863492695L);
         C1088 var4 = w.a<"Û">(var3, 299774196298174789L);
         if (!w.a<"Û">(var4, 118751751324366372L)) {
            w.a<"Û">(var1, "\n", 194629304146735395L);
            w.a<"Û">(var1, w.a<"Û">(var3, 248211090350577353L), 194629304146735395L);
            w.a<"Û">(var1, " - ", 194629304146735395L);
            w.a<"Û">(var1, w.a<"Û">(var4, 338391653860412648L), 194629304146735395L);
            w.a<"Û">(var1, " ", 194629304146735395L);
            w.a<"Û">(var1, w.a<"B">(w.a<"Û">(w.a<"Û">(var4, 298459350812887843L), 148386175155036532L), 183649478845493670L), 267862536496645581L);
         }
      }

      w.a<"B">(var1, (f3137 | 488816) + ~(f3137 & 488816) + 1 ^ -634301432, 243580424214754541L);
   }

   public static String MFEHbwqUCg0FbEeM0OCfOqfC196g9p4juSEPdaPj88TowbidosSTJyTGF9vF21Blvy1gzibIktNx0szSsx78rq7RiFTQ7UdTfOrJ(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
