package me.mioclient;

import java.util.function.Predicate;

public class C0388 implements Predicate {
   public C1141 f2468;

   public C0388(C1141 var1) {
      this.f2468 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">((Boolean)w.a<"Û">(this.f2468.f0441, 174312564406604366L), 354697271520518137L);
   }
}
