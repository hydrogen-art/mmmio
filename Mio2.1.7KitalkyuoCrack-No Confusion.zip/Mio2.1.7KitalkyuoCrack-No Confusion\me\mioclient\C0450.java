package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_1744;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1811;
import net.minecraft.class_1842;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_6880;
import net.minecraft.class_742;
import net.minecraft.class_2846.class_2847;

public class C0450 extends C1266 {
   public static final AtomicBoolean f2924 = new AtomicBoolean();
   public final C0015<Boolean> f2925;
   public final C0015<Float> f2926;
   public final C0015<Integer> f2927;
   public final Map<class_1291, Long> f2928;
   public final C0083 f2929;
   public int f2930;
   public class_1842 f2931;
   public static int f2932 = w.a<"B">(7508857190194338309L, 257832362129977838L);

   public C0450() {
      C1045 var10003 = C1045.f3172;
      String[] var10004 = new String[(f2932 | 472970) + ~(f2932 & 472970) + 1 ^ 1425993617];
      var10004[(f2932 | 596124) + ~(f2932 & 596124) + 1 ^ 1425064070] = "projectiles";
      super("Arrows", "Will swap between effect arrows in your inventory.", var10003, var10004);
      w.a<"B">(this, 242859112966675773L);
      this.f2928 = new HashMap<>();
      this.f2929 = new C0083();
   }

   @Override
   public void onEnable() {
      if (w.a<"Û">(f2924, 248424813730317294L)) {
         w.a<"Û">(this, 155417974908982175L);
      }
   }

   @C1027
   public void m1144(C0068 var1) {
      class_1657 var2 = w.a<"Û">(this, 255498411881151009L);
      class_1268 var3 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 137331122518345133L
      );
      if (var3 != null
         && w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, var3, 116318201500984113L),
            222207108884875224L
         ) instanceof class_1811) {
         if (var2 == null
            || this.f2930 != ((f2932 | 28460) + ~(f2932 & 28460) + 1 ^ -1425651511)
               && w.a<"Û">(
                     this,
                     w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
                        ),
                        this.f2930,
                        386860178278302175L
                     ),
                     var2,
                     331199810787620600L
                  )
                  > 0) {
            if (w.a<"Û">(this.f2929, ((long)f2932 | 793815L) + ~((long)f2932 & 793815L) + 1L ^ 1425392895L, 309642602085515378L)) {
               for (int var8 = (f2932 | 82694) + ~(f2932 & 82694) + 1 ^ 1425578780;
                  var8
                     < w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
                        ),
                        338465858754043645L
                     );
                  var8++
               ) {
                  class_1799 var5 = w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
                     ),
                     var8,
                     386860178278302175L
                  );
                  if (w.a<"Û">(var5, 222207108884875224L) instanceof class_1744) {
                     if (var8 != this.f2930) {
                        w.a<"Û">(this.f2929, 387780412884547639L);
                        w.a<"Û">(C0933.f1425, (boolean)((f2932 | 824650) + ~(f2932 & 824650) + 1 ^ 1425362257), 113777871216199699L);
                        w.a<"B">(w.a<"B">(this.f2930, 117367628897531893L), w.a<"B">(var8, 117367628897531893L), 238771771368340878L);
                        w.a<"Û">(C0933.f1425, (boolean)((f2932 | 960194) + ~(f2932 & 960194) + 1 ^ 1425506008), 113777871216199699L);
                        this.f2930 = (f2932 | 967091) + ~(f2932 & 967091) + 1 ^ -1425480106;
                     }

                     if (this.f2931 != null) {
                        Iterator var6 = w.a<"Û">(w.a<"Û">(this.f2931, 231151615269804154L), 341496865259068134L);

                        while (w.a<"Û">(var6, 333900474771661065L)) {
                           class_1293 var7 = (class_1293)w.a<"Û">(var6, 192468336863492695L);
                           w.a<"Û">(
                              this.f2928,
                              (class_1291)w.a<"Û">(w.a<"Û">(var7, 277230852474459461L), 138403591895517822L),
                              w.a<"B">(w.a<"B">(223409559795593705L), 279131300036783447L),
                              121875332790264405L
                           );
                        }
                     }
                     break;
                  }
               }
            }
         } else {
            int var4 = w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
               )
               .field_7545;
            w.a<"B">(
               (var4 + ((f2932 | 26351) + ~(f2932 & 26351) + 1 ^ 1425653492)) % ((f2932 | 661793) + ~(f2932 & 661793) + 1 ^ 1425260850), 279757124141714355L
            );
            w.a<"B">(class_2847.field_12974, class_2338.field_10980, class_2350.field_11033, 282456429933142666L);
            w.a<"B">(var4, 279757124141714355L);
            w.a<"Û">(var1, 385440235371820560L);
         }
      }
   }

   @C1027
   public void m1145(C0591 var1) {
      if (w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L),
         222207108884875224L
      ) instanceof class_1811) {
         Object var2 = w.a<"Û">(this, 255498411881151009L);
         if (var2 == null) {
            var2 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724;
         }

         w.a<"Û">(
            w.a<"Û">(this.f2928, 354320704134596920L),
            (Predicate<Entry>)var0 -> (boolean)(w.a<"Û">((Long)w.a<"Û">(var0, 196870340575900401L), 151184307344636838L)
                        + (((long)f2932 | 871897L) + ~((long)f2932 & 871897L) + 1L ^ 1425315629L)
                     < w.a<"B">(223409559795593705L)
                  ? (f2932 | 205633) + ~(f2932 & 205633) + 1 ^ 1425734490
                  : (f2932 | 526729) + ~(f2932 & 526729) + 1 ^ 1425133971),
            271448142827029127L
         );
         int var3 = (f2932 | 600984) + ~(f2932 & 600984) + 1 ^ -1425077123;
         int var4 = (f2932 | 309603) + ~(f2932 & 309603) + 1 ^ -1425891706;

         for (int var5 = (f2932 | 245781) + ~(f2932 & 245781) + 1 ^ 1425676303;
            var5
               < w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
                  338465858754043645L
               );
            var5++
         ) {
            class_1799 var6 = w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
               var5,
               386860178278302175L
            );
            int var7 = w.a<"Û">(this, var6, var2, 331199810787620600L);
            if (var7 >= 0 && var7 > var3) {
               var4 = var5;
               var3 = var7;
            }
         }

         this.f2930 = var4;
         if (this.f2930 != ((f2932 | 355018) + ~(f2932 & 355018) + 1 ^ -1425846993)) {
            this.f2931 = w.a<"B">(
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
                  this.f2930,
                  386860178278302175L
               ),
               335189960187017228L
            );
         }
      }
   }

   @C1027
   public void m1146(C0153 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2925, 174312564406604366L), 354697271520518137L)) {
         if (this.f2930 == ((f2932 | 309640) + ~(f2932 & 309640) + 1 ^ -1425891731)
            || w.a<"Û">(
                  this,
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
                     ),
                     this.f2930,
                     386860178278302175L
                  ),
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  331199810787620600L
               )
               <= 0) {
            w.a<"Û">(this, 155417974908982175L);
            return;
         }

         w.a<"Û">(this, 262655895509487995L);
      }
   }

   public class_1657 m1147() {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2925, 174312564406604366L), 354697271520518137L)) {
         return m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724;
      } else if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 218194352988080011L)
         < w.a<"B">((f2932 | 524074) + ~(f2932 & 524074) + 1 ^ -1772869840, 349057757755238323L)) {
         return m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724;
      } else {
         class_742 var1 = null;
         double var2 = w.a<"B">(((long)f2932 | 545004L) + ~((long)f2932 & 545004L) + 1L ^ 5183643169844201718L, 317139102743630955L);
         Iterator var4 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 188438576288929642L),
            341496865259068134L
         );

         while (w.a<"Û">(var4, 333900474771661065L)) {
            class_742 var5 = (class_742)w.a<"Û">(var4, 192468336863492695L);
            if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724 != var5
               && !w.a<"Û">(C0933.f1417, var5, 241036547861815495L)) {
               float[] var6 = w.a<"B">(var5, 227058158510945889L);
               float var7 = w.a<"B">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L
                     ),
                     var6[(f2932 | 578831) + ~(f2932 & 578831) + 1 ^ 1425083669],
                     123679565561004181L
                  )
                  - w.a<"Û">(w.a<"Û">(var5, w.a<"Û">(var5, 382173282342459288L), 182498984908079684L), 294083010930340024L)
                     * w.a<"B">((f2932 | 370120) + ~(f2932 & 370120) + 1 ^ 1811709394, 349057757755238323L);
               float var8 = w.a<"B">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 218194352988080011L
                     ),
                     var6[(f2932 | 267676) + ~(f2932 & 267676) + 1 ^ 1425919367],
                     123679565561004181L
                  )
                  - w.a<"Û">(w.a<"Û">(var5, w.a<"Û">(var5, 382173282342459288L), 182498984908079684L), 189150736338288119L)
                     * w.a<"B">((f2932 | 217224) + ~(f2932 & 217224) + 1 ^ 1811581074, 349057757755238323L);
               if (!(var7 > w.a<"Û">((Float)w.a<"Û">(this.f2926, 174312564406604366L), 149784643039979208L))
                  && !(var8 > w.a<"Û">((Float)w.a<"Û">(this.f2926, 174312564406604366L), 149784643039979208L))) {
                  double var9 = w.a<"B">((double)var7, (double)var8, 263950649710151907L);
                  if (var9 < var2) {
                     var1 = var5;
                     var2 = var9;
                  }
               }
            }
         }

         return var1;
      }
   }

   public int m1148(class_1799 var1, Object var2) {
      if (w.a<"Û">(var1, 222207108884875224L) instanceof class_1744 && var2 instanceof class_1657 var3) {
         class_1842 var4 = w.a<"B">(var1, 335189960187017228L);
         int var5 = var3 != m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
               && !w.a<"Û">(C0933.f1417, var3, 241036547861815495L)
            ? (f2932 | 192344) + ~(f2932 & 192344) + 1 ^ 1425749826
            : (f2932 | 304622) + ~(f2932 & 304622) + 1 ^ 1425898997;
         int var6 = (f2932 | 900167) + ~(f2932 & 900167) + 1 ^ 1425302621;
         if (w.a<"Û">(w.a<"Û">(var4, 231151615269804154L), 284469716622774448L)) {
            var6 = var5 != 0 ? (f2932 | 556074) + ~(f2932 & 556074) + 1 ^ -1425122353 : (f2932 | 808457) + ~(f2932 & 808457) + 1 ^ 1425378834;
         }

         Iterator var7 = w.a<"Û">(w.a<"Û">(var4, 231151615269804154L), 341496865259068134L);

         while (w.a<"Û">(var7, 333900474771661065L)) {
            class_1293 var8 = (class_1293)w.a<"Û">(var7, 192468336863492695L);
            class_6880 var9 = w.a<"Û">(var8, 277230852474459461L);
            int var10 = w.a<"Û">(var3, var9, 352496321745804167L);
            if (var10 != 0) {
               class_1293 var11 = w.a<"Û">(var3, var9, 346414444173546423L);
               float var12 = w.a<"Û">((C1333)var11, 225054663914504519L);
               if (var12 * w.a<"B">((f2932 | 245743) + ~(f2932 & 245743) + 1 ^ 372402165, 349057757755238323L)
                  < (float)w.a<"Û">((Integer)w.a<"Û">(this.f2927, 174312564406604366L), 260981171345819427L)) {
                  var10 = (f2932 | 196306) + ~(f2932 & 196306) + 1 ^ 1425745608;
               }
            }

            if (var10 == 0 && !w.a<"Û">(this.f2928, w.a<"Û">(var9, 138403591895517822L), 325824999980124721L)) {
               class_1291 var13 = (class_1291)w.a<"Û">(var9, 138403591895517822L);
               int var14 = (!w.a<"Û">(var13, 231778842262062627L) ? w.a<"Û">(var8, 148721469287305317L) : (f2932 | 299377) + ~(f2932 & 299377) + 1 ^ 1425885547)
                  + ((f2932 | 809787) + ~(f2932 & 809787) + 1 ^ 1425376032);
               if (w.a<"Û">(this, var9, 132456198901316859L) != var5) {
                  var14 *= (f2932 | 486571) + ~(f2932 & 486571) + 1 ^ -1425978546;
               }

               var6 += var14;
            }
         }

         return var6;
      } else {
         return (f2932 | 375964) + ~(f2932 & 375964) + 1 ^ -1425826951;
      }
   }

   public boolean m1149(class_6880<class_1291> var1) {
      return (boolean)(var1 == class_1294.field_5906
         ? (f2932 | 122148) + ~(f2932 & 122148) + 1 ^ 1425540414
         : w.a<"Û">((class_1291)w.a<"Û">(var1, 138403591895517822L), 360588761504528268L));
   }

   public void m1150() {
      int var1 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545;
      int var2 = w.a<"B">(class_1802.field_8102, 113439863899466963L);
      C1071 var10000 = C0933.f1412;
      float[] var10001 = new float[(f2932 | 870012) + ~(f2932 & 870012) + 1 ^ 1425317476];
      var10001[(f2932 | 277335) + ~(f2932 & 277335) + 1 ^ 1425924941] = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L
      );
      var10001[(f2932 | 461778) + ~(f2932 & 461778) + 1 ^ 1425986505] = w.a<"B">((f2932 | 896490) + ~(f2932 & 896490) + 1 ^ -1774160400, 349057757755238323L);
      w.a<"Û">(var10000, var10001, (f2932 | 994441) + ~(f2932 & 994441) + 1 ^ 1425471348, 236731835237641613L);
      if (var2 != ((f2932 | 385473) + ~(f2932 & 385473) + 1 ^ -1425816028)
         && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 367966343301975358L)) {
         w.a<"B">(var2, 357260035653160004L);
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_1268.field_5808,
            114543782118481187L
         );
         if (!w.a<"Û">(f2924, 248424813730317294L)) {
            w.a<"Û">(f2924, (boolean)((f2932 | 232264) + ~(f2932 & 232264) + 1 ^ 1425691475), 378016260982040195L);
            w.a<"Û">(
               C0933.f1433,
               (Runnable)() -> {
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                     148256105639741402L
                  );
                  w.a<"B">(var1, 357260035653160004L);
                  w.a<"Û">(f2924, (boolean)((f2932 | 309607) + ~(f2932 & 309607) + 1 ^ 1425891709), 378016260982040195L);
                  w.a<"Û">(this, 155417974908982175L);
               },
               (f2932 | 927625) + ~(f2932 & 927625) + 1 ^ 1425538960,
               122889728173745617L
            );
         }
      }
   }

   public static String xCmBzO1KMVivClUt2KqfKtVzEx4MKPPWBUMSIcuplWU5mlJldrT4fS8z6N32OE1nzYbCBFKHMrnYHgdfE0pnSO0F3XzjhWvkOfzk(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
