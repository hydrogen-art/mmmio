package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

public enum C0139 implements C0045, C0196 {
   f4244("Fast", new class_243(C1074.f4550, C1074.f4550, C1074.f4550)),
   f4245("X2", new class_243(C1074.f4550, 0.05, C1074.f4550), new class_243(C1074.f4550, 1.0, C1074.f4550)),
   f4246("X4", new class_243(0.05, 0.05, 0.05), new class_243(0.05, 0.05, 0.95), new class_243(0.95, 0.05, 0.05), new class_243(0.95, 0.05, 0.95)),
   f4247(
      "X8",
      new class_243(0.05, 0.05, 0.05),
      new class_243(0.05, 0.05, 0.95),
      new class_243(0.05, 0.95, 0.05),
      new class_243(0.05, 0.95, 0.95),
      new class_243(0.95, 0.05, 0.05),
      new class_243(0.95, 0.05, 0.95),
      new class_243(0.95, 0.95, 0.05),
      new class_243(0.95, 0.95, 0.95)
   );

   public final List<class_243> f4248 = new ArrayList<>();
   public final String f4249;

   public C0139(String var3, class_243... var4) {
      this.f4249 = var3;
      w.a<"Û">(this.f4248, w.a<"B">(var4, 333698250403385986L), 271623032661790232L);
   }

   public List<class_243> m3763() {
      return this.f4248;
   }

   public List<class_243> m3764(class_2338 var1) {
      return (List<class_243>)w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(w.a<"Û">(this, 255547389120156913L), 110814793610710346L),
            (Function<class_243, class_243>)var2 -> {
               var2 = w.a<"Û">(var2, w.a<"B">(var1, 250673775726706964L), 300445064978294627L);
               return this == f4246
                     && w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 263969240386481316L
                        )
                        > (double)(w.a<"Û">(var1, 171752333823210875L) + 1)
                  ? w.a<"Û">(var2, 0.0, 0.9, 0.0, 215037093685651073L)
                  : var2;
            },
            141209812120559377L
         ),
         w.a<"B">(237074135112251105L),
         185878351305311015L
      );
   }

   public List<class_243> m3765(class_2338 var1, class_2350 var2) {
      ArrayList var3 = new ArrayList();
      Iterator var4 = w.a<"Û">(this.f4248, 341496865259068134L);

      while (w.a<"Û">(var4, 333900474771661065L)) {
         class_243 var5 = (class_243)w.a<"Û">(var4, 192468336863492695L);
         if (!w.a<"Û">(this, w.a<"Û">(var2, 361365819009133215L), (int)var5.field_1352, 374631596150328571L)
            && !w.a<"Û">(this, w.a<"Û">(var2, 170412212309900917L), (int)var5.field_1351, 374631596150328571L)
            && !w.a<"Û">(this, w.a<"Û">(var2, 131942042434017638L), (int)var5.field_1350, 374631596150328571L)) {
            w.a<"Û">(var3, w.a<"Û">(var5, w.a<"B">(var1, 250673775726706964L), 300445064978294627L), 276802003864609490L);
         }
      }

      return var3;
   }

   public boolean m3766(int var1, int var2) {
      return (var1 | ~var2) == 1;
   }

   @Override
   public String getName() {
      return this.f4249;
   }

   public static String OCAfusWuw4TbjPZl6xZqT2xPqVMXPxqeUdsAc54SZIyozNCyRf1d01ANlbD0At82gy17yvjpvWnUkKi0eZBXqfSeh4mkHVAXGGpc(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
