package me.mioclient;

import java.util.function.Predicate;

public class C0180 implements Predicate {
   public C1093 f2342;

   public C0180(C1093 var1) {
      this.f2342 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2342.f2667, 254992554122318132L);
   }
}
