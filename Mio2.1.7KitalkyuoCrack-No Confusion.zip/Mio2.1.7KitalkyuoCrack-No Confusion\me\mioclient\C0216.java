package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1923;

public class C0216 extends C1266 {
   public final C0015<Color> f3156;
   public final C0015<Color> f3157;
   public final C0015<Float> f3158;
   public final C0015<Integer> f3159;
   public final C0015<Integer> f3160;
   public static int f3161 = w.a<"B">(538506708440047202L, 257832362129977838L);

   public C0216() {
      super("Borders", "Shows region borders on your screen.", C1045.f3174);
      w.a<"B">(this, 242859112966675773L);
      w.a<"Û">(this.f3160, "~", C0508.f2371, 381268910042652120L);
   }

   @C1027
   public void m1308(C1358 var1) {
      if (w.a<"Û">((Color)w.a<"Û">(this.f3156, 174312564406604366L), 245270953955453918L) != 0) {
         w.a<"Û">(
            w.a<"Û">(this, 370851384675273111L),
            w.a<"Û">(var1, 173269294235887931L),
            (Color)w.a<"Û">(this.f3156, 174312564406604366L),
            w.a<"Û">((Integer)w.a<"Û">(this.f3160, 174312564406604366L), 260981171345819427L),
            w.a<"Û">((Float)w.a<"Û">(this.f3158, 174312564406604366L), 149784643039979208L),
            312612869857259101L
         );
      }

      if (w.a<"Û">((Color)w.a<"Û">(this.f3157, 174312564406604366L), 245270953955453918L) != 0) {
         w.a<"Û">(
            w.a<"Û">(this, 263782108975266470L),
            w.a<"Û">(var1, 173269294235887931L),
            (Color)w.a<"Û">(this.f3157, 174312564406604366L),
            w.a<"Û">((Integer)w.a<"Û">(this.f3160, 174312564406604366L), 260981171345819427L),
            w.a<"Û">((Float)w.a<"Û">(this.f3158, 174312564406604366L), 149784643039979208L),
            312612869857259101L
         );
      }
   }

   public C0217 m1309() {
      class_1923 var1 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 255985208769192509L
      );
      return new C0217(w.a<"Û">(var1, 385764854994384473L), w.a<"Û">(var1, 364025584559716488L), (f3161 | 201078) + ~(f3161 & 201078) + 1 ^ -1554800075);
   }

   public C0217 m1310() {
      int var1 = ((f3161 | 868923) + ~(f3161 & 868923) + 1 ^ -1554124312)
         * (((f3161 | 754044) + ~(f3161 & 754044) + 1 ^ -1554304466) << w.a<"Û">((Integer)w.a<"Û">(this.f3159, 174312564406604366L), 260981171345819427L));
      int var2 = w.a<"B">(
         (
               (double)w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 374644056988281545L
                  )
                  + w.a<"B">(((long)f3161 | 964473L) + ~((long)f3161 & 964473L) + 1L ^ -4634204018118360022L, 317139102743630955L)
            )
            / (double)var1,
         333273847000622169L
      );
      int var3 = w.a<"B">(
         (
               (double)w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 312390719114445221L
                  )
                  + w.a<"B">(((long)f3161 | 335021L) + ~((long)f3161 & 335021L) + 1L ^ -4634204018118905858L, 317139102743630955L)
            )
            / (double)var1,
         333273847000622169L
      );
      int var4 = var2 * var1 + var1 / ((f3161 | 185580) + ~(f3161 & 185580) + 1 ^ -1554880579) - ((f3161 | 346397) + ~(f3161 & 346397) + 1 ^ -1554646514);
      int var5 = var3 * var1 + var1 / ((f3161 | 120215) + ~(f3161 & 120215) + 1 ^ -1554946362) - ((f3161 | 251140) + ~(f3161 & 251140) + 1 ^ -1554815465);
      return new C0217(var4, var5, var1);
   }

   public static String _rHHzRspBim7mY38oHW7IdKITFSPJqnFn0onrdgOX6egXjC4XCp12g92S3hBpVPNaEdisOAAJRW9WSpB5JYnOKooR1cbk0J3RWdn/* $VF was: 5rHHzRspBim7mY38oHW7IdKITFSPJqnFn0onrdgOX6egXjC4XCp12g92S3hBpVPNaEdisOAAJRW9WSpB5JYnOKooR1cbk0J3RWdn*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
