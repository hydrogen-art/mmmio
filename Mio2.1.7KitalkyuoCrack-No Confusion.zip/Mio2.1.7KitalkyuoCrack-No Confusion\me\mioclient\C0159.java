package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import net.minecraft.class_744;
import net.minecraft.class_2828.class_2830;
import net.minecraft.class_2846.class_2847;

public class C0159 extends C1266 {
   public static final C0345 f5293 = C0933.f1409.m2696(C0345.class);
   public static final C1121 f5294 = C0933.f1409.m2696(C1121.class);
   public static final C0846 f5295 = C0933.f1409.m2696(C0846.class);
   public final C0015<C0160> f5296;
   public final C0015<Boolean> f5297;
   public final C0015<Double> f5298;
   public final C0015<Boolean> f5299;
   public final C0015<Boolean> f5300;
   public final C0015<Boolean> f5301;
   public final C0015<Boolean> f5302;
   public final C0015<Boolean> f5303;
   public final C0083 f5304;
   public final C0083 f5305;
   public int f5306;
   public class_243 f5307;
   public static int f5308 = w.a<"B">(5760857231569273944L, 257832362129977838L);

   public C0159() {
      super("Phase", "Phases you into blocks.", C1045.f3177);
      w.a<"B">(this, 242859112966675773L);
      this.f5304 = new C0083();
      this.f5305 = new C0083();
   }

   @Override
   public void onEnable() {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         w.a<"Û">(this.f5304, -1L, 167864214448769242L);
         if (w.a<"Û">(this.f5296, 174312564406604366L) == C0160.f4389 && !w.a<"Û">((Boolean)w.a<"Û">(this.f5297, 174312564406604366L), 354697271520518137L)) {
            w.a<"Û">(
               this,
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L),
               315711698178898210L
            );
            w.a<"Û">(this, 155417974908982175L);
         }
      }
   }

   @Override
   public String getInfo() {
      return w.a<"Û">((C0160)w.a<"Û">(this.f5296, 174312564406604366L), 383187108771097793L);
   }

   @C1027
   public void m4092(C0612 var1) {
      if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)
         && !w.a<"Û">(C0933.f1429, 253189061091329172L)) {
         w.a<"Û">(this, 219424730437685481L);
      } else {
         this.f5306 = this.f5306 + ((f5308 | 466625) + ~(f5308 & 466625) + 1 ^ -1931414452);
      }
   }

   @C1027
   public void m4093(C0591 var1) {
      if (w.a<"Û">(this.f5296, 174312564406604366L) == C0160.f4389
         && w.a<"Û">((Boolean)w.a<"Û">(this.f5297, 174312564406604366L), 354697271520518137L)
         && w.a<"Û">(this.f5305, w.a<"Û">((Double)w.a<"Û">(this.f5298, 174312564406604366L), 287934447355057060L), TimeUnit.SECONDS, 215737872562411156L)) {
         if (!w.a<"Û">(f5294, 314537768572362865L)) {
            if (w.a<"Û">(f5293, 291728366122999264L)
               || w.a<"Û">(f5293, 119633580786107485L)
               || !w.a<"Û">(f5293, 314537768572362865L)
               || w.a<"Û">(f5293.f0369, 174312564406604366L) != C0347.f1909 && w.a<"Û">(f5293.f0369, 174312564406604366L) != C0347.f1910) {
               double[] var2 = w.a<"B">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L),
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913,
                  w.a<"B">(((long)f5308 | 552522L) + ~((long)f5308 & 552522L) + 1L ^ -4611686020357847866L, 317139102743630955L),
                  108620803423508722L
               );
               class_243 var3 = w.a<"B">(
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L
                     ),
                     var2[(f5308 | 687076) + ~(f5308 & 687076) + 1 ^ -1930587800],
                     0.0,
                     var2[(f5308 | 647755) + ~(f5308 & 647755) + 1 ^ -1930557242],
                     215037093685651073L
                  ),
                  new class_238(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L
                     )
                  ),
                  126254311642297136L
               );
               int var4 = w.a<"B">(
                     w.a<"B">(
                        var3,
                        new class_243(
                           w.a<"B">(
                                 w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                    268094392877253824L
                                 ),
                                 143282796194555966L
                              )
                              + w.a<"B">(((long)f5308 | 398410L) + ~((long)f5308 & 398410L) + 1L ^ -4602678821103993146L, 317139102743630955L),
                           0.0,
                           w.a<"B">(
                                 w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                    310441135103619165L
                                 ),
                                 143282796194555966L
                              )
                              + w.a<"B">(((long)f5308 | 607793L) + ~((long)f5308 & 607793L) + 1L ^ -4602678821103162179L, 317139102743630955L)
                        ),
                        372402139461912970L
                     )[(f5308 | 484117) + ~(f5308 & 484117) + 1 ^ -1931441767],
                     292355722995856317L
                  )
                  + ((f5308 | 604562) + ~(f5308 & 604562) + 1 ^ -1930505302);
               if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_5976
                  && this.f5307 != var3
                  && this.f5306 >= ((f5308 | 212925) + ~(f5308 & 212925) + 1 ^ -1931160268)) {
                  w.a<"Û">(this, (float)var4, 315711698178898210L);
                  this.f5307 = var3;
                  w.a<"Û">(this.f5305, 387780412884547639L);
               } else {
                  this.f5307 = null;
               }
            }
         }
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = 9999
   )
   public void m4094(C0153 var1) {
      if (!w.a<"Û">((Boolean)w.a<"Û">(this.f5300, 174312564406604366L), 354697271520518137L)
         || m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_5976
            && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)) {
         if (w.a<"Û">(this.f5296, 174312564406604366L) == C0160.f4388) {
            if (!w.a<"B">(334351836397688550L)) {
               int var2 = w.a<"B">(class_1802.field_8634, 113439863899466963L);
               int var3 = w.a<"B">(class_1802.field_8634, 261845468269893067L);
               int var4 = w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
                  )
                  .field_7545;
               float[] var5 = w.a<"Û">(this, 236499256341118289L);
               if (var3 == ((f5308 | 666267) + ~(f5308 & 666267) + 1 ^ 1930575848)) {
                  w.a<"Û">(this, 155417974908982175L);
               } else {
                  boolean var6 = w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                        w.a<"B">(155039566109854826L),
                        310987074049434965L
                     ),
                     class_2246.field_9983,
                     272812080270536171L
                  );
                  if (var6) {
                     var5[(f5308 | 779161) + ~(f5308 & 779161) + 1 ^ -1930688236] = w.a<"B">(
                        (f5308 | 413655) + ~(f5308 & 413655) + 1 ^ -834558629, 349057757755238323L
                     );
                  }

                  if (w.a<"B">(w.a<"B">(155039566109854826L), 192665225182956164L)
                     && !var6
                     && !w.a<"B">(w.a<"Û">(w.a<"B">(155039566109854826L), 286357605983762592L), 192665225182956164L)) {
                     if (!w.a<"Û">((Boolean)w.a<"Û">(this.f5300, 174312564406604366L), 354697271520518137L)) {
                        w.a<"Û">(this, 155417974908982175L);
                     }
                  } else if (!w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 280878730833668412L
                     )
                     || w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L
                     )
                     || !(
                        w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 214921524804283555L
                              ),
                              292829928904272542L
                           )
                           > 0.0
                     )) {
                     if (w.a<"Û">(
                        this.f5304,
                        (long)(
                           w.a<"B">((f5308 | 929490) + ~(f5308 & 929490) + 1 ^ -929840034, 349057757755238323L) / w.a<"Û">(C0933.f1416, 329491062951172765L)
                        ),
                        309642602085515378L
                     )) {
                        int var7 = var2 == ((f5308 | 621406) + ~(f5308 & 621406) + 1 ^ 1930522157)
                           ? (f5308 | 283194) + ~(f5308 & 283194) + 1 ^ -1931233097
                           : (f5308 | 44231) + ~(f5308 & 44231) + 1 ^ -1931000245;
                        if (w.a<"Û">((Boolean)w.a<"Û">(this.f5301, 174312564406604366L), 354697271520518137L)) {
                           w.a<"B">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 299721818904416994L
                              ),
                              (f5308 | 637647) + ~(f5308 & 637647) + 1 ^ -1930538941,
                              259879800301833065L
                           );
                           Iterator var8 = w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                                 156655948167432853L
                              ),
                              191661729848227466L
                           );

                           while (w.a<"Û">(var8, 333900474771661065L)) {
                              class_1297 var9 = (class_1297)w.a<"Û">(var8, 192468336863492695L);
                              if (var9 instanceof class_1533
                                 && w.a<"Û">(
                                    w.a<"Û">(var9, 225708705569795011L),
                                    new class_238(
                                       w.a<"Û">(
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                          299721818904416994L
                                       )
                                    ),
                                    133676266014519719L
                                 )) {
                                 w.a<"B">(w.a<"Û">(var9, 137614607914618029L), 194280799834061379L);
                                 w.a<"B">(class_1268.field_5808, 183891258734353801L);
                              }
                           }

                           w.a<"Û">(
                              this,
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 299721818904416994L
                              ),
                              126617839838898487L
                           );
                        }

                        w.a<"Û">(this, var5[(f5308 | 804486) + ~(f5308 & 804486) + 1 ^ -1930712054], 108665954081812290L);
                        w.a<"Û">(this, (boolean)var7, 373045359635236413L);
                        w.a<"Û">(this, var7 != 0 ? var3 : var2, (boolean)var7, 160446245310788132L);
                        w.a<"B">(
                           class_1268.field_5808,
                           var5[(f5308 | 596617) + ~(f5308 & 596617) + 1 ^ -1930498043],
                           var5[(f5308 | 800230) + ~(f5308 & 800230) + 1 ^ -1930698901],
                           344266418215090618L
                        );
                        w.a<"B">(class_1268.field_5808, 183891258734353801L);
                        w.a<"Û">(this, var7 != 0 ? var3 : var4, (boolean)var7, 160446245310788132L);
                        if (!w.a<"Û">((Boolean)w.a<"Û">(this.f5303, 174312564406604366L), 354697271520518137L)) {
                           w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
                              new class_2830(
                                 w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                    268094392877253824L
                                 ),
                                 w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                    358934561846661819L
                                 ),
                                 w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                    310441135103619165L
                                 ),
                                 var5[(f5308 | 533316) + ~(f5308 & 533316) + 1 ^ -1930442296],
                                 var5[(f5308 | 321864) + ~(f5308 & 321864) + 1 ^ -1931279419],
                                 w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                    120447883516886953L
                                 )
                              ),
                              125787698683892978L
                           );
                        }

                        w.a<"Û">(this.f5304, 387780412884547639L);
                        if (!w.a<"Û">((Boolean)w.a<"Û">(this.f5300, 174312564406604366L), 354697271520518137L)) {
                           w.a<"Û">(this, 155417974908982175L);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public void m4095(float var1) {
      double var2 = w.a<"B">(w.a<"B">((double)(var1 + (float)C1074.f4547), 175389272199548133L), 266524427586034326L);
      double var4 = w.a<"B">(w.a<"B">((double)(var1 + (float)C1074.f4547), 175389272199548133L), 230683255727203842L);
      double var6 = w.a<"B">(((long)f5308 | 876931L) + ~((long)f5308 & 876931L) + 1L ^ -4487126256972069067L, 317139102743630955L);
      w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L)
            + var6 * var2,
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L),
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L)
            + var6 * var4,
         267135527332903540L
      );
      w.a<"B">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L)
            + var6 * var2,
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L),
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L)
            + var6 * var4,
         (boolean)((f5308 | 811932) + ~(f5308 & 811932) + 1 ^ -1930721007),
         302397094711434985L
      );
   }

   public void m4096(boolean var1) {
      if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)
         && w.a<"Û">((Boolean)w.a<"Û">(this.f5299, 174312564406604366L), 354697271520518137L)) {
         int var2 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
            )
            .field_7545;
         int var3 = w.a<"B">(
            (Predicate<class_1799>)var0 -> (boolean)(!(w.a<"Û">(var0, 222207108884875224L) instanceof class_1747)
                     && w.a<"Û">(var0, 222207108884875224L) != class_1802.field_8301
                  ? (f5308 | 662758) + ~(f5308 & 662758) + 1 ^ -1930561942
                  : (f5308 | 390916) + ~(f5308 & 390916) + 1 ^ -1931338359),
            344867982687893969L
         );
         class_1792[] var10000 = new class_1792[(f5308 | 941971) + ~(f5308 & 941971) + 1 ^ -1930840803];
         var10000[(f5308 | 119447) + ~(f5308 & 119447) + 1 ^ -1931069413] = class_1802.field_8884;
         var10000[(f5308 | 751174) + ~(f5308 & 751174) + 1 ^ -1930650421] = class_1802.field_8814;
         int var4 = w.a<"B">(var10000, 316378340591725282L);
         if (var4 != ((f5308 | 984198) + ~(f5308 & 984198) + 1 ^ 1930891765)) {
            var3 = var4;
         }

         w.a<"B">(var3, 279757124141714355L);
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_1268.field_5808,
            new class_3965(
               w.a<"Û">(w.a<"Û">(w.a<"B">(155039566109854826L), 210046241258394501L), 229561253177300454L),
               class_2350.field_11036,
               w.a<"Û">(w.a<"B">(155039566109854826L), 210046241258394501L),
               (boolean)((f5308 | 207484) + ~(f5308 & 207484) + 1 ^ -1931165456)
            ),
            353197595888970100L
         );
         if (var1) {
            w.a<"B">(var2, 279757124141714355L);
         }
      }
   }

   public void m4097(float var1) {
      if (w.a<"B">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 301123027323221411L)
         && w.a<"Û">((Boolean)w.a<"Û">(this.f5302, 174312564406604366L), 354697271520518137L)
         && !(
            w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L),
                  328102654916935210L
               )
               < w.a<"B">(((long)f5308 | 923807L) + ~((long)f5308 & 923807L) + 1L ^ -4607182420730842605L, 317139102743630955L)
         )) {
         double var2 = w.a<"B">(w.a<"B">((double)(var1 + (float)C1074.f4547), 175389272199548133L), 266524427586034326L)
            * w.a<"B">(((long)f5308 | 676074L) + ~((long)f5308 & 676074L) + 1L ^ -4604930620916909466L, 317139102743630955L);
         double var4 = w.a<"B">(w.a<"B">((double)(var1 + (float)C1074.f4547), 175389272199548133L), 230683255727203842L)
            * w.a<"B">(((long)f5308 | 305300L) + ~((long)f5308 & 305300L) + 1L ^ -4604930620917595624L, 317139102743630955L);
         int var6 = w.a<"B">(class_1802.field_8281, 113439863899466963L);
         int var7 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
            )
            .field_7545;
         class_2338 var8 = w.a<"B">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L),
               var2,
               0.0,
               var4,
               215037093685651073L
            ),
            274163478939689086L
         );
         class_2350 var9 = w.a<"B">(var8, (boolean)((f5308 | 634966) + ~(f5308 & 634966) + 1 ^ -1930536229), 310756169772890262L);
         float[] var10 = w.a<"B">(w.a<"Û">(var8, 229561253177300454L), var9, 130733282910283802L);
         if (w.a<"B">(w.a<"Û">(var8, 210046241258394501L), 146808546012046015L)) {
            if (w.a<"B">(var8, (boolean)((f5308 | 396774) + ~(f5308 & 396774) + 1 ^ -1931352213), 242496856158723858L)
               && var9 != null
               && var6 != ((f5308 | 697570) + ~(f5308 & 697570) + 1 ^ 1930604945)) {
               w.a<"B">(var6, 279757124141714355L);
               w.a<"B">(var8, var9, (boolean)((f5308 | 462441) + ~(f5308 & 462441) + 1 ^ -1931418395), class_1268.field_5808, 360863021140479360L);
               w.a<"B">(class_1268.field_5808, 183891258734353801L);
               w.a<"B">(var7, 279757124141714355L);
               w.a<"Û">(C0933.f1412, var10, (f5308 | 133510) + ~(f5308 & 133510) + 1 ^ -1931091202, 236731835237641613L);
            }
         }
      }
   }

   public void m4098(class_2338 var1) {
      class_2680 var2 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var1, 310987074049434965L
      );
      class_1799 var3 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L
      );
      double var4 = w.a<"B">(var3, var2, (boolean)((f5308 | 581165) + ~(f5308 & 581165) + 1 ^ -1930480480), 195091013375914783L);
      if (w.a<"Û">(
            var2, m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var1, 326308817442494788L
         )
         == 0.0F) {
         var4 = w.a<"B">(((long)f5308 | 815276L) + ~((long)f5308 & 815276L) + 1L ^ -4607182420730734048L, 317139102743630955L);
      }

      if (!w.a<"Û">(
            w.a<"Û">(
               var2, m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var1, 127692959363775057L
            ),
            125999939138686596L
         )
         && var4 >= w.a<"B">(((long)f5308 | 729970L) + ~((long)f5308 & 729970L) + 1L ^ -4607182420730656258L, 317139102743630955L)) {
         w.a<"Û">(f5295, 285323678202896902L);
         w.a<"B">(
            class_2847.field_12968,
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
            class_2350.field_11036,
            282456429933142666L
         );
         w.a<"B">(
            class_2847.field_12973,
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
            class_2350.field_11036,
            282456429933142666L
         );
      }
   }

   public void m4099(int var1, boolean var2) {
      if (var2) {
         w.a<"B">(var1, 209502932342608419L);
      } else {
         w.a<"B">(var1, 279757124141714355L);
      }
   }

   public float[] m4100() {
      double[] var1 = w.a<"Û">(this, 256689363562397176L);
      class_243 var2 = w.a<"B">(
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L),
            var1[(f5308 | 453868) + ~(f5308 & 453868) + 1 ^ -1931409824],
            0.0,
            var1[(f5308 | 499473) + ~(f5308 & 499473) + 1 ^ -1931446884],
            215037093685651073L
         ),
         new class_238(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L)
         ),
         126254311642297136L
      );
      int var3 = w.a<"B">(
            w.a<"B">(
               var2,
               new class_243(
                  w.a<"B">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L
                        ),
                        143282796194555966L
                     )
                     + w.a<"B">(((long)f5308 | 125492L) + ~((long)f5308 & 125492L) + 1L ^ -4602678821103730504L, 317139102743630955L),
                  0.0,
                  w.a<"B">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L
                        ),
                        143282796194555966L
                     )
                     + w.a<"B">(((long)f5308 | 656024L) + ~((long)f5308 & 656024L) + 1L ^ -4602678821103212524L, 317139102743630955L)
               ),
               372402139461912970L
            )[(f5308 | 707884) + ~(f5308 & 707884) + 1 ^ -1930614880],
            292355722995856317L
         )
         + ((f5308 | 372877) + ~(f5308 & 372877) + 1 ^ -1931322699);
      int var4 = w.a<"B">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L)
                  - w.a<"B">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L
                     ),
                     143282796194555966L
                  ),
               230886300607664670L
            )
            > w.a<"B">(((long)f5308 | 345529L) + ~((long)f5308 & 345529L) + 1L ^ -4591870181424548177L, 317139102743630955L)
         ? (f5308 | 273149) + ~(f5308 & 273149) + 1 ^ -1931231120
         : (f5308 | 807877) + ~(f5308 & 807877) + 1 ^ -1930708663;
      float[] var10000 = new float[(f5308 | 522530) + ~(f5308 & 522530) + 1 ^ -1931471956];
      var10000[(f5308 | 363532) + ~(f5308 & 363532) + 1 ^ -1931319680] = (float)var3;
      var10000[(f5308 | 664635) + ~(f5308 & 664635) + 1 ^ -1930572106] = var4 != 0
         ? w.a<"B">((f5308 | 487796) + ~(f5308 & 487796) + 1 ^ -834495496, 349057757755238323L)
         : w.a<"B">((f5308 | 298458) + ~(f5308 & 298458) + 1 ^ -834050218, 349057757755238323L);
      return var10000;
   }

   public double[] m4101() {
      class_744 var1 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913;
      float var2 = var1.field_3905;
      if (w.a<"Û">(w.a<"Û">(var1, 293686825814000020L), 116121810924933779L) == 0.0F) {
         var1.field_3905 = w.a<"B">((f5308 | 602644) + ~(f5308 & 602644) + 1 ^ -1284581224, 349057757755238323L);
      }

      double[] var3 = w.a<"B">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L),
         var1,
         w.a<"B">(((long)f5308 | 292000L) + ~((long)f5308 & 292000L) + 1L ^ -4611686020358627796L, 317139102743630955L),
         108620803423508722L
      );
      var1.field_3905 = var2;
      return var3;
   }

   public void m4102() {
      this.f5306 = (f5308 | 465031) + ~(f5308 & 465031) + 1 ^ -1931415029;
   }

   public static String SB1wWCziQfVvC8kV61JfLtuaKxhthNqHJodXhBCBYxeaRt0mNR4nK8xn55ePKfqefbUVMKbfWcV5LiuyTHVTyawZgzqjgsMAbBpL(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
