package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0424 implements C0196 {
   f4153("Vanilla"),
   f4154("Text"),
   f4155("None");

   public final String f4156;

   public C0424(String var3) {
      this.f4156 = var3;
   }

   @Override
   public String getName() {
      return this.f4156;
   }

   public static String lnBMQXWHSg3xIdV79IrhQXNV6YuKJHy2hpYvkcHHsd9OrTDgb4SZ3CMQWHIgS06LMBYvHRTzNuCtmEonxEhy23Q7bNroetKWC73Z(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
