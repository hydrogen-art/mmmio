package me.mioclient;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;

public final class C0460 {
   public static final Set<class_2248> f1059 = new HashSet<>(
      w.a<"B">(
         class_2246.field_28411,
         class_2246.field_27159,
         class_2246.field_27120,
         class_2246.field_37576,
         class_2246.field_28678,
         class_2246.field_28673,
         class_2246.field_28675,
         class_2246.field_37551,
         class_2246.field_37546,
         110859688247076228L
      )
   );
   public static final Set<class_2248> f1060 = new HashSet<>(
      w.a<"B">(
         class_2246.field_22109,
         class_2246.field_23077,
         class_2246.field_22091,
         class_2246.field_23985,
         class_2246.field_22090,
         class_2246.field_22120,
         class_2246.field_22113,
         class_2246.field_23869,
         344577215600294546L
      )
   );
   public static int f1061 = w.a<"B">(3986576315460774278L, 257832362129977838L);
}
