package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public class C0204 extends C1266 {
   public final C0015<Float> f0607;
   public static int f0608 = w.a<"B">(1577796378171854931L, 257832362129977838L);

   public C0204() {
      super("AutoReconnect", "Reconnects to the server automatically if you get kicked.", C1045.f3173);
      w.a<"B">(this, 242859112966675773L);
      w.a<"Û">(this, (boolean)((f0608 | 845279) + ~(f0608 & 845279) + 1 ^ -1839457104), 135570431627433065L);
   }

   public static String _I5GfgyoxWwufaG6m1LNIyV4HxyECV8SafD00QhfZosMWG5Vhbc7Pokfv1nioXDX0BiZJS5wOVbE6Qubp12AwKoxqKxiTpsOuGBo/* $VF was: 7I5GfgyoxWwufaG6m1LNIyV4HxyECV8SafD00QhfZosMWG5Vhbc7Pokfv1nioXDX0BiZJS5wOVbE6Qubp12AwKoxqKxiTpsOuGBo*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
