package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1268;
import net.minecraft.class_1776;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_9334;
import net.minecraft.class_9463;

public class C0493 extends C1266 {
   public final C0015<C0494> f1055;
   public final C0015<Boolean> f1056;
   public boolean f1057;
   public static int f1058 = w.a<"B">(8106024926857668592L, 257832362129977838L);

   public C0493() {
      super("NoInteract", "Prevents you from interacting with tile entities.", C1045.f3176);
      w.a<"B">(this, 242859112966675773L);
   }

   public static boolean m0517(class_1799 var0) {
      return (boolean)(!w.a<"Û">(var0, class_9334.field_50075, 130182657201466113L)
            && !(w.a<"Û">(var0, 222207108884875224L) instanceof class_1776)
            && !(w.a<"Û">(var0, 222207108884875224L) instanceof class_9463)
            && !(w.a<"Û">(var0, 222207108884875224L) instanceof class_1811)
         ? (f1058 | 308211) + ~(f1058 & 308211) + 1 ^ -1069076534
         : (f1058 | 721269) + ~(f1058 & 721269) + 1 ^ -1068982963);
   }

   public static class_1268 m0518() {
      class_1799 var0 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L
      );
      class_1799 var1 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 159396947398056288L
      );
      return !w.a<"B">(var0, 198057371937849500L) && w.a<"B">(var1, 198057371937849500L) ? class_1268.field_5810 : class_1268.field_5808;
   }

   public boolean m0519(class_1799 var1, class_2338 var2) {
      if (w.a<"Û">(this, 314537768572362865L)
         && (!w.a<"Û">((Boolean)w.a<"Û">(this.f1056, 174312564406604366L), 354697271520518137L) || w.a<"Û">(var1, class_9334.field_50075, 130182657201466113L))
         )
       {
         class_2680 var3 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var2, 310987074049434965L
         );
         if (w.a<"Û">(var3, class_2246.field_10535, 272812080270536171L)) {
            return (boolean)((f1058 | 891266) + ~(f1058 & 891266) + 1 ^ -1068628550);
         } else {
            return (boolean)(w.a<"Û">(var3, 129674450347345694L) && !(w.a<"Û">(var3, 152622786059621427L) instanceof class_2244)
               ? (f1058 | 297636) + ~(f1058 & 297636) + 1 ^ -1069082980
               : (f1058 | 92588) + ~(f1058 & 92588) + 1 ^ -1069353579);
         }
      } else {
         return (boolean)((f1058 | 667527) + ~(f1058 & 667527) + 1 ^ -1068911682);
      }
   }

   public static String QZWYrISRxMjqOihVyCbo6H8RlCxnEngZ9bffbqanelQ4V8p6ZobwaMKde5ujWt7oOSYC5rPBFBIQgqa9YfSEEhSJYEwH2TCd8PYq(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
