package me.mioclient;

import java.util.function.Predicate;

public class C0305 implements Predicate {
   public C0942 f4448;

   public C0305(C0942 var1) {
      this.f4448 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">((Boolean)w.a<"Û">(this.f4448.f4486, 174312564406604366L), 354697271520518137L);
   }
}
