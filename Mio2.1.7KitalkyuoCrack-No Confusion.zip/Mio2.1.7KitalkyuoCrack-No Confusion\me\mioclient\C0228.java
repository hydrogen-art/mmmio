package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.Predicate;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_332;

public class C0228 extends C0601 {
   public final C0015<Boolean> f3560;
   public static int f3561 = w.a<"B">(5989506288045233741L, 257832362129977838L);

   public C0228() {
      super("Totems");
      this.f3560 = w.a<"Û">(
         this, new C0240("White", w.a<"B">((boolean)((f3561 | 331255) + ~(f3561 & 331255) + 1 ^ 1430397800), 320330632857389983L)), 192839886211813275L
      );
      this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(new C0024(this));
   }

   @Override
   public void m0562(class_332 var1) {
      class_1799 var2 = new class_1799(
         class_1802.field_8288, w.a<"B">((Predicate<class_1799>)var0 -> w.a<"Û">(var0, class_1802.field_8288, 282470456889867724L), 165027638849964207L)
      );
      if (w.a<"Û">(var2, 144154955567765793L) != 0) {
         w.a<"Û">(var1, var2, (f3561 | 985431) + ~(f3561 & 985431) + 1 ^ 1430792136, (f3561 | 226098) + ~(f3561 & 226098) + 1 ^ 1430543789, 235588228935023387L);
         if (w.a<"Û">(var2, 144154955567765793L) > ((f3561 | 680400) + ~(f3561 & 680400) + 1 ^ 1431129934)) {
            String var3 = w.a<"B">(w.a<"Û">(var2, 144154955567765793L), 140572902764040146L);
            w.a<"Û">(var1, 268208535981285616L);
            w.a<"Û">(w.a<"Û">(var1, 138110712227765901L), 156066167197700274L);
            w.a<"Û">(
               w.a<"Û">(var1, 138110712227765901L),
               0.0F,
               0.0F,
               w.a<"B">((f3561 | 305042) + ~(f3561 & 305042) + 1 ^ 381257997, 349057757755238323L),
               202980495898708244L
            );
            C0498.f4738
               .m3889(
                  var1,
                  var3,
                  w.a<"B">((f3561 | 878125) + ~(f3561 & 878125) + 1 ^ 348276914, 349057757755238323L) - C0498.f4738.m3896(var3),
                  w.a<"B">((f3561 | 148960) + ~(f3561 & 148960) + 1 ^ 341142399, 349057757755238323L),
                  w.a<"Û">((Boolean)w.a<"Û">(this.f3560, 174312564406604366L), 354697271520518137L)
                     ? Color.white
                     : this.m$$iZnnVBJ17A5YJbakVntJjvhjlzvzt8abld4g7DVpkphruizpxyO31ajNTWEZ2smIjpUa4yekh7iZ7sJESIVA0nApb5M9c0lYC(
                        w.a<"B">((f3561 | 510100) + ~(f3561 & 510100) + 1 ^ 340846091, 349057757755238323L)
                     )
               );
            w.a<"Û">(w.a<"Û">(var1, 138110712227765901L), 250771500943331132L);
         }
      }
   }

   @Override
   public float[] m0563() {
      float[] var10000 = new float[(f3561 | 799545) + ~(f3561 & 799545) + 1 ^ 1430986148];
      var10000[(f3561 | 389863) + ~(f3561 & 389863) + 1 ^ 1430445176] = w.a<"B">((f3561 | 421987) + ~(f3561 & 421987) + 1 ^ 348217084, 349057757755238323L);
      var10000[(f3561 | 144150) + ~(f3561 & 144150) + 1 ^ 1430592904] = w.a<"B">((f3561 | 526322) + ~(f3561 & 526322) + 1 ^ 349120877, 349057757755238323L);
      return var10000;
   }

   public static String _l74piylzL4ozzX6QRDVeu95I94g7ZtIo0QWZtfshx94YyzvO9eDwODxneDDMZZRGVcIfFJMwk7gACbpEq3rFVAwNmg6TlIIfUgt/* $VF was: 1l74piylzL4ozzX6QRDVeu95I94g7ZtIo0QWZtfshx94YyzvO9eDwODxneDDMZZRGVcIfFJMwk7gACbpEq3rFVAwNmg6TlIIfUgt*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
