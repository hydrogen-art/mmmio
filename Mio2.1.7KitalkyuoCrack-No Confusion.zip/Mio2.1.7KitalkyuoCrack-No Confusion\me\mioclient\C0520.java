package me.mioclient;

import java.util.function.Predicate;

public class C0520 implements Predicate {
   public C0657 f0290;

   public C0520(C0657 var1) {
      this.f0290 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0290.f4864, 254992554122318132L);
   }
}
