package me.mioclient;

import net.minecraft.class_276;

public interface C0157 {
   class_276 getFramebuffer();

   void setFramebuffer(class_276 var1);
}
