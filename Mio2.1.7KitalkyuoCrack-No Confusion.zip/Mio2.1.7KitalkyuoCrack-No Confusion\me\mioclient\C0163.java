package me.mioclient;

import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_6880;
import net.minecraft.class_9334;

public class C0163 {
   public static final class_1842 f3293 = new class_1842(new class_1293[(C0163.f3294 | 487975) + ~(C0163.f3294 & 487975) + 1 ^ -1235365904]);
   public static int f3294 = w.a<"B">(8420786635958933773L, 257832362129977838L);

   public static class_1842 m3371(class_1799 var0) {
      class_1844 var1 = (class_1844)w.a<"Û">(var0, class_9334.field_49651, 229970188298775222L);
      if (var1 == null) {
         return f3293;
      } else {
         class_6880 var2 = (class_6880)w.a<"Û">(w.a<"Û">(var1, 215854010357406023L), null, 237682386832069967L);
         return var2 == null ? f3293 : (class_1842)w.a<"Û">(var2, 138403591895517822L);
      }
   }
}
