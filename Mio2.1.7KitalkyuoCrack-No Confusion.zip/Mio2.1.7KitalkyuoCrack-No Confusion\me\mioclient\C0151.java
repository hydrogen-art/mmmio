package me.mioclient;

import baritone.api.Settings.Setting;
import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;

public class C0151 extends C0232 {
   public static final C0303 f0733 = C0933.f1409.m2696(C0303.class);
   public static final C1121 f0734 = C0933.f1409.m2696(C1121.class);
   public static final C1047 f0735 = C0933.f1409.m2696(C1047.class);
   public static C0326 f0736 = C0933.f1409.m2696(C0326.class);
   public static C1168 jesus = C0933.f1409.m2696(C1168.class);
   public final C0015<Boolean> f0737;
   public final C0015<Boolean> f0738;
   public final C0015<Boolean> f0739;
   public final C0015<Boolean> f0740;
   public final C0015<Boolean> f0741;
   public final C0015<Color> f0742;
   public final C0015<Color> f0743;
   public boolean f0744;
   public boolean f0745;
   public static int f0746 = w.a<"B">(7846727056770933813L, 257832362129977838L);

   public C0151() {
      super("Baritone", "Manages baritone settings.", C1045.f3178);
      w.a<"B">(this, 242859112966675773L);
      int var10001 = f0746 | 890670;
      w.a<"B">(368076255256835497L).chatControl.value = w.a<"B">((boolean)(var10001 + ~(f0746 & 890670) + 1 ^ -1874578051), 320330632857389983L);
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   @C1027
   public void m0354(C0330 var1) {
      w.a<"Û">(this, 298148693051910082L);
      w.a<"B">(368076255256835497L).disconnectOnArrival.value = w.a<"Û">(this.f0738, 174312564406604366L);
      w.a<"B">(368076255256835497L).freeLook.value = w.a<"Û">(this.f0737, 174312564406604366L);
      w.a<"B">(368076255256835497L).blockFreeLook.value = w.a<"Û">(this.f0737, 174312564406604366L);
      w.a<"B">(368076255256835497L).elytraFreeLook.value = w.a<"Û">(this.f0737, 174312564406604366L);
      w.a<"B">(368076255256835497L).censorCoordinates.value = w.a<"Û">(this.f0740, 174312564406604366L);
      w.a<"B">(368076255256835497L).censorRanCommands.value = w.a<"Û">(this.f0740, 174312564406604366L);
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0741, 174312564406604366L), 354697271520518137L)) {
         Color var2 = C0152.m3473((Color)w.a<"Û">(this.f0742, 174312564406604366L), (f0746 | 666414) + ~(f0746 & 666414) + 1 ^ -1874622078);
         Color var3 = C0152.m3473((Color)w.a<"Û">(this.f0743, 174312564406604366L), (f0746 | 767455) + ~(f0746 & 767455) + 1 ^ -1874716813);
         w.a<"B">(368076255256835497L).colorBestPathSoFar.value = var2;
         w.a<"B">(368076255256835497L).colorGoalBox.value = var3;
         w.a<"B">(368076255256835497L).colorInvertedGoalBox.value = var3;
         w.a<"B">(368076255256835497L).colorCurrentPath.value = var2;
         w.a<"B">(368076255256835497L).colorMostRecentConsidered.value = var2;
         w.a<"B">(368076255256835497L).colorBlocksToBreak.value = var2;
         w.a<"B">(368076255256835497L).colorBlocksToPlace.value = var2;
         w.a<"B">(368076255256835497L).colorBlocksToWalkInto.value = var2;
         w.a<"B">(368076255256835497L).colorNextPath.value = var2;
         w.a<"B">(368076255256835497L).pathRenderLineWidthPixels.value = w.a<"B">(
            w.a<"B">((f0746 | 359367) + ~(f0746 & 359367) + 1 ^ -1349723756, 349057757755238323L), 243402859552372891L
         );
         w.a<"B">(368076255256835497L).goalRenderLineWidthPixels.value = w.a<"B">(
            w.a<"B">((f0746 | 848528) + ~(f0746 & 848528) + 1 ^ -1350217533, 349057757755238323L), 243402859552372891L
         );
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0739, 174312564406604366L), 354697271520518137L)) {
         w.a<"B">(368076255256835497L).assumeStep.value = w.a<"B">(w.a<"Û">(f0734, 314537768572362865L), 320330632857389983L);
         w.a<"B">(368076255256835497L).assumeExternalAutoTool.value = w.a<"B">(w.a<"Û">(f0735, 314537768572362865L), 320330632857389983L);
         w.a<"B">(368076255256835497L).assumeSafeWalk.value = w.a<"B">(w.a<"Û">(f0736, 314537768572362865L), 320330632857389983L);
         w.a<"B">(368076255256835497L).assumeWalkOnWater.value = w.a<"B">(
            (boolean)(w.a<"Û">(jesus, 314537768572362865L) && w.a<"Û">(jesus, 339128225131496688L)
               ? (f0746 | 807501) + ~(f0746 & 807501) + 1 ^ -1874464737
               : (f0746 | 709193) + ~(f0746 & 709193) + 1 ^ -1874628582),
            320330632857389983L
         );
      }
   }

   public void m0355() {
      Setting var1 = w.a<"B">(368076255256835497L).antiCheatCompatibility;
      boolean var2 = w.a<"Û">(w.a<"Û">(f0733, 132251120046610393L), 289072432747109763L);
      if (var2 != this.f0745) {
         if (var2) {
            this.f0744 = w.a<"Û">((Boolean)var1.value, 354697271520518137L);
         } else {
            var1.value = w.a<"B">(this.f0744, 320330632857389983L);
         }
      } else if (var2) {
         var1.value = w.a<"B">((boolean)((f0746 | 286381) + ~(f0746 & 286381) + 1 ^ -1873937154), 320330632857389983L);
      }

      this.f0745 = var2;
   }

   public static String u2Yqu8iufyoVXwOEAWrV5VDQ8GKZ3pl7tvuFGk3YKuoxKWcl3pHR7wgoeDoLUYPPUp4PAftTTUMnV6LMvU3BmaKs0EwQovkBChb4(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
