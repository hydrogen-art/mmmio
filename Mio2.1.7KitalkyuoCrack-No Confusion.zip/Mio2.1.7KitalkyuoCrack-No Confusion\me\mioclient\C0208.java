package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.tree.CommandNode;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_2639;
import net.minecraft.class_2805;

public final class C0208 extends C0219 {
   public final C0083 stopwatch = new C0083();
   public boolean f0727;
   public static int f0728 = w.a<"B">(4015059953504789933L, 257832362129977838L);

   public C0208() {
      super("plugins");
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         var1,
         (Command)var1x -> {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
               new class_2805((f0728 | 968674) + ~(f0728 & 968674) + 1 ^ -687661308, "/"),
               125787698683892978L
            );
            w.a<"B">(
               w.a<"B">("Fetching plugins...", 228465064790135899L),
               w.a<"B">((f0728 | 811070) + ~(f0728 & 811070) + 1 ^ 687752997, 289296048454852994L),
               241936116971186271L
            );
            w.a<"Û">(this.stopwatch, 387780412884547639L);
            this.f0727 = (boolean)((f0728 | 541036) + ~(f0728 & 541036) + 1 ^ -687498869);
            return (f0728 | 776971) + ~(f0728 & 776971) + 1 ^ -687471636;
         },
         286944572020109927L
      );
   }

   @C1027
   public void m2404(C0133 var1) {
      if (this.f0727) {
         if (w.a<"Û">(this.stopwatch, ((long)f0728 | 36315L) + ~((long)f0728 & 36315L) + 1L ^ -686989691L, 309642602085515378L)) {
            this.f0727 = (boolean)((f0728 | 88626) + ~(f0728 & 88626) + 1 ^ -687045932);
            List var2 = w.a<"Û">(
               w.a<"Û">(
                  w.a<"Û">(
                     w.a<"Û">(
                        w.a<"Û">(
                           w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
                              363385013892818875L
                           ),
                           301709714894402511L
                        ),
                        216184035105636112L
                     ),
                     366567241942811964L
                  ),
                  CommandNode::getName,
                  141209812120559377L
               ),
               325049488880240942L
            );
            if (w.a<"Û">(var2, 284469716622774448L)) {
               w.a<"B">(
                  w.a<"B">("Couldn't get plugins", 228465064790135899L),
                  w.a<"B">((f0728 | 196976) + ~(f0728 & 196976) + 1 ^ 686892651, 289296048454852994L),
                  241936116971186271L
               );
            } else {
               w.a<"B">(
                  w.a<"Û">(this, var2, 209735321642518138L),
                  w.a<"B">((f0728 | 233383) + ~(f0728 & 233383) + 1 ^ 686926012, 289296048454852994L),
                  241936116971186271L
               );
            }
         }

         if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2639 var4) {
            this.f0727 = (boolean)((f0728 | 370921) + ~(f0728 & 370921) + 1 ^ -687312881);
            w.a<"B">(
               w.a<"Û">(
                  this,
                  w.a<"Û">(
                     w.a<"Û">(
                        w.a<"Û">(w.a<"Û">(w.a<"Û">(var4, 367577367180287014L), 315800637343310160L), 110814793610710346L),
                        Suggestion::getText,
                        141209812120559377L
                     ),
                     325049488880240942L
                  ),
                  209735321642518138L
               ),
               w.a<"B">((f0728 | 525165) + ~(f0728 & 525165) + 1 ^ 687481974, 289296048454852994L),
               241936116971186271L
            );
         }
      }
   }

   public class_2561 m2405(Iterable<String> var1) {
      HashSet var2 = new HashSet();
      Iterator var3 = w.a<"Û">(var1, 191661729848227466L);

      while (w.a<"Û">(var3, 333900474771661065L)) {
         String var4 = (String)w.a<"Û">(var3, 192468336863492695L);
         String[] var5 = w.a<"Û">(var4, ":", 369825978071233340L);
         if (var5.length > ((f0728 | 237916) + ~(f0728 & 237916) + 1 ^ -686917189)
            && !w.a<"Û">(var5[(f0728 | 997944) + ~(f0728 & 997944) + 1 ^ -687676706], 226515538076917205L)) {
            w.a<"Û">(var2, var5[(f0728 | 191457) + ~(f0728 & 191457) + 1 ^ -686869753], 309270453639690490L);
         }
      }

      class_2561 var6 = w.a<"B">(
         var2,
         (Function<String, class_2561>)var0 -> w.a<"Û">(
               w.a<"B">(var0, 228465064790135899L),
               (UnaryOperator)var0x -> w.a<"B">(
                     var0x, (Supplier<Integer>)() -> w.a<"B">(w.a<"Û">(C0152.m3468(), 301840407077149108L), 367942141483020029L), 154649488180116735L
                  ),
               165931758622126162L
            ),
         179763761551956616L
      );
      return w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(w.a<"B">(151712998973257886L), "Found plugins [", 194629304146735395L),
               w.a<"Û">(
                  w.a<"B">(w.a<"B">(w.a<"Û">(var2, 266558347116709042L), 140572902764040146L), 228465064790135899L), class_124.field_1080, 173336747796326302L
               ),
               267862536496645581L
            ),
            "]: ",
            194629304146735395L
         ),
         var6,
         267862536496645581L
      );
   }

   public static String _nAbr1cbg2PNxYTQUGAEHN9CLJCu8ICmYdZ7FdTjg00eiihEJiZObzI8ki0q4OUcy2m27gsqViVDC5wJ33kTi10mXTfx2cTtJH0Y/* $VF was: 2nAbr1cbg2PNxYTQUGAEHN9CLJCu8ICmYdZ7FdTjg00eiihEJiZObzI8ki0q4OUcy2m27gsqViVDC5wJ33kTi10mXTfx2cTtJH0Y*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
