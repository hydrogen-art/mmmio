package me.mioclient;

import java.util.function.Predicate;

public class C0289 implements Predicate {
   public C1381 f0967;

   public C0289(C1381 var1) {
      this.f0967 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0967.f3576, 174312564406604366L) == C1382.f2857 || w.a<"Û">(this.f0967.f3576, 174312564406604366L) == C1382.f2858;
   }
}
