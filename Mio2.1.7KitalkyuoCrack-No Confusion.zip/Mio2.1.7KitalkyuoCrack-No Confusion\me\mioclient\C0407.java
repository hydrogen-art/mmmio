package me.mioclient;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_742;

public final class C0407 implements C0045 {
   public final Map<Integer, C0935> f2279 = w.a<"B">(new HashMap(), 297409492390560467L);
   public static int f2280 = w.a<"B">(285822851768710129L, 257832362129977838L);

   public C0407() {
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   @C1027
   public void m0931(C0878 var1) {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         Iterator var2 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 188438576288929642L),
            341496865259068134L
         );

         while (w.a<"Û">(var2, 333900474771661065L)) {
            class_742 var3 = (class_742)w.a<"Û">(var2, 192468336863492695L);
            w.a<"Û">(this.f2279, w.a<"B">(w.a<"Û">(var3, 249493737001487914L), 367942141483020029L), new C0935(var3), 265103749380408799L);
            w.a<"Û">((C0935)w.a<"Û">(this.f2279, w.a<"B">(w.a<"Û">(var3, 249493737001487914L), 367942141483020029L), 299255156581412505L), 271933754806719848L);
         }
      }
   }

   @C1027
   public void m0932(C1041 var1) {
      synchronized (this.f2279) {
         w.a<"Û">(this.f2279, w.a<"B">(w.a<"Û">(var1, 114026181039104081L), 367942141483020029L), 128627855127182569L);
      }
   }

   @C1027
   public void m0933(C0190 var1) {
      w.a<"Û">(this.f2279, 288879253482200997L);
   }

   public synchronized class_238 m0934(class_1657 var1, int var2) {
      if (!w.a<"Û">(this.f2279, w.a<"B">(w.a<"Û">(var1, 137125849867919014L), 367942141483020029L), 325824999980124721L)) {
         return w.a<"Û">(var1, 224997102751365724L);
      } else {
         List var3 = w.a<"Û">(
            (C0935)w.a<"Û">(this.f2279, w.a<"B">(w.a<"Û">(var1, 137125849867919014L), 367942141483020029L), 299255156581412505L), 287273234960999734L
         );
         return w.a<"Û">(var3, 284469716622774448L)
            ? w.a<"Û">(var1, 224997102751365724L)
            : (class_238)w.a<"Û">(
               var3,
               w.a<"B">(var2, w.a<"Û">(var3, 260708190417501501L) - ((f2280 | 743159) + ~(f2280 & 743159) + 1 ^ -1970187439), 244670932612973720L),
               325739049664951543L
            );
      }
   }
}
