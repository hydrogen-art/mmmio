package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_332;

public class C0440 extends C0601 {
   public static C1323 hud = C0933.f1409.m2696(C1323.class);
   public final C0015<Boolean> f3190;
   public final C0015<Boolean> f3191;
   public final C0015<Boolean> f3192;
   public static int f3193 = w.a<"B">(5139023962153913377L, 257832362129977838L);

   public C0440() {
      super("Armor");
      this.f3190 = w.a<"Û">(
         this, new C0240("Durability", w.a<"B">((boolean)((f3193 | 201105) + ~(f3193 & 201105) + 1 ^ 116278535), 320330632857389983L)), 192839886211813275L
      );
      this.f3191 = w.a<"Û">(
         this, new C0240("Percentage", w.a<"B">((boolean)((f3193 | 409517) + ~(f3193 & 409517) + 1 ^ 116091707), 320330632857389983L)), 192839886211813275L
      );
      this.f3192 = w.a<"Û">(
         this, new C0240("BarColor", w.a<"B">((boolean)((f3193 | 676683) + ~(f3193 & 676683) + 1 ^ 115804125), 320330632857389983L)), 192839886211813275L
      );
      this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(new C0024(this) {
         public static int f3595 = w.a<"B">(7015849729324518838L, 257832362129977838L);

         public boolean m1488() {
            return (boolean)((f3595 | 31442) + ~(f3595 & 31442) + 1 ^ 334532029);
         }
      });
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = 1
   )
   public void m1316(C0287 var1) {
      if (w.a<"Û">(hud, 314537768572362865L) || this.m$$gRj7aiBtDUdrULFMRSSNGe3GE4NJYmPLULaW8RoQqkczJRkPf1MnKCjIJUd2eMxM2dCKHKu8Kn8y32QvHMngHVwK1aYsDDolf()) {
         int var2 = w.a<"Û">(w.a<"Û">(var1, 188966319877282483L), 278126331705798914L);
         int var3 = w.a<"Û">(w.a<"Û">(var1, 188966319877282483L), 255161784556182451L);
         int var4 = (f3193 | 630820) + ~(f3193 & 630820) + 1 ^ 115668156;

         for (int var5 = (f3193 | 833604) + ~(f3193 & 833604) + 1 ^ 115469520; var5 >= 0; var5--) {
            class_1799 var6 = (class_1799)w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7548,
               var5,
               315632267894795364L
            );
            if (!w.a<"Û">(var6, 330190014994709712L)) {
               int var7 = w.a<"Û">(this, 234246890594410671L);
               w.a<"Û">(
                  this,
                  w.a<"Û">(var1, 188966319877282483L),
                  var6,
                  var2 / ((f3193 | 698002) + ~(f3193 & 698002) + 1 ^ 115864071) + var4,
                  var3 - var7,
                  284417105933271115L
               );
               if (w.a<"Û">(var6, 263055534152868350L) && w.a<"Û">((Boolean)w.a<"Û">(this.f3190, 174312564406604366L), 354697271520518137L)) {
                  Object[] var10001 = new Object[(f3193 | 302865) + ~(f3193 & 302865) + 1 ^ 115985284];
                  var10001[(f3193 | 130764) + ~(f3193 & 130764) + 1 ^ 116173403] = w.a<"B">(w.a<"B">(var6, 188113691055505329L), 367942141483020029L);
                  var10001[(f3193 | 969568) + ~(f3193 & 969568) + 1 ^ 115580918] = "%";
                  String var8 = w.a<"B">("%d%s", var10001, 223779026484277040L);
                  float var9 = w.a<"Û">(C0719.f0592, 314537768572362865L)
                     ? w.a<"B">((f3193 | 234074) + ~(f3193 & 234074) + 1 ^ 970847742, 349057757755238323L)
                     : w.a<"B">((f3193 | 127972) + ~(f3193 & 127972) + 1 ^ 969589013, 349057757755238323L);
                  if (!w.a<"Û">((Boolean)w.a<"Û">(this.f3191, 174312564406604366L), 354697271520518137L)) {
                     var8 = w.a<"Û">(
                        var8,
                        (f3193 | 411378) + ~(f3193 & 411378) + 1 ^ 116068965,
                        w.a<"Û">(var8, 120891947504160641L) - ((f3193 | 788701) + ~(f3193 & 788701) + 1 ^ 115432523),
                        145614115509746641L
                     );
                     var9 = w.a<"B">((f3193 | 208884) + ~(f3193 & 208884) + 1 ^ 963541859, 349057757755238323L);
                  }

                  float var10 = (float)(var3 - var7)
                     - w.a<"B">((f3193 | 555146) + ~(f3193 & 555146) + 1 ^ 1184243502, 349057757755238323L)
                     - (float)(
                        w.a<"Û">((Boolean)w.a<"Û">(this.f3191, 174312564406604366L), 354697271520518137L)
                           ? (f3193 | 464988) + ~(f3193 & 464988) + 1 ^ 116018379
                           : (f3193 | 175240) + ~(f3193 & 175240) + 1 ^ 116389917
                     );
                  C0498.f4738
                     .m3893(
                        w.a<"Û">(var1, 188966319877282483L),
                        var8,
                        (float)var2 / w.a<"B">((f3193 | 424672) + ~(f3193 & 424672) + 1 ^ 1189817975, 349057757755238323L)
                           + (float)var4
                           + w.a<"B">((f3193 | 537459) + ~(f3193 & 537459) + 1 ^ 1207265252, 349057757755238323L)
                           - C0498.f4738.m3896(var8) * w.a<"B">((f3193 | 608640) + ~(f3193 & 608640) + 1 ^ 971250967, 349057757755238323L) * var9
                           - var9,
                        var10,
                        var9,
                        w.a<"Û">((Boolean)w.a<"Û">(this.f3192, 174312564406604366L), 354697271520518137L)
                           ? new Color(w.a<"Û">(var6, 145291970941669234L), (boolean)((f3193 | 401504) + ~(f3193 & 401504) + 1 ^ 116094199))
                           : this.m$$iZnnVBJ17A5YJbakVntJjvhjlzvzt8abld4g7DVpkphruizpxyO31ajNTWEZ2smIjpUa4yekh7iZ7sJESIVA0nApb5M9c0lYC(var10)
                     );
               }

               var4 += 18;
            }
         }
      }
   }

   @Override
   public void m0562(class_332 var1) {
      super.m0562(var1);
   }

   @Override
   public float[] m0563() {
      float[] var10000 = new float[(f3193 | 425667) + ~(f3193 & 425667) + 1 ^ 116075094];
      var10000[(f3193 | 979372) + ~(f3193 & 979372) + 1 ^ 115582267] = 0.0F;
      var10000[(f3193 | 501992) + ~(f3193 & 501992) + 1 ^ 116063358] = 0.0F;
      return var10000;
   }

   public void m1317(class_332 var1, class_1799 var2, int var3, int var4) {
      w.a<"Û">(var1, var2, var3, var4, 235588228935023387L);
      w.a<"Û">(
         var1,
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1772,
         var2,
         var3,
         var4,
         210949393962591390L
      );
      w.a<"B">(156169517863121162L);
   }

   public int m1318() {
      int var1;
      if ((
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 269996444145053128L)
               || w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 226720109198742809L)
                  != w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 316694783939033125L
                  )
         )
         && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 226720109198742809L) > 0
         && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 218573218456367004L)) {
         var1 = (f3193 | 798375) + ~(f3193 & 798375) + 1 ^ 115440241;
      } else if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 179114946195012748L)
         && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 312103791313807134L) instanceof class_1309 var2
         )
       {
         var1 = (int)(
            (double)C1074.f4546
               + w.a<"B">(
                     (double)(
                        (w.a<"Û">(var2, 208532652696600212L) - w.a<"B">((f3193 | 216736) + ~(f3193 & 216736) + 1 ^ 963516983, 349057757755238323L))
                           / w.a<"B">((f3193 | 783298) + ~(f3193 & 783298) + 1 ^ 1195812693, 349057757755238323L)
                     ),
                     348087577662528735L
                  )
                  * w.a<"B">(((long)f3193 | 822535L) + ~((long)f3193 & 822535L) + 1L ^ 4621819117704436112L, 317139102743630955L)
         );
      } else {
         var1 = ((f3193 | 4652) + ~(f3193 & 4652) + 1 ^ 116213388)
            - (
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 218573218456367004L)
                  ? (f3193 | 642778) + ~(f3193 & 642778) + 1 ^ 115645020
                  : (f3193 | 913635) + ~(f3193 & 913635) + 1 ^ 115385460
            );
      }

      return var1;
   }

   public static String FYfS1oMLOY5MpmQhvAOJWP2wLibzTNTN45u2G5mBLqKHtYxJAkUc7zLD6ElQh4TOFekPgVxlOhhDAUTkokMMsXAFoOunyzasceZo(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
