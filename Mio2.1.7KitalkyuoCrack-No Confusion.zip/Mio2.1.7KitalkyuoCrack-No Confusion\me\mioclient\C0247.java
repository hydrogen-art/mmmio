package me.mioclient;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Predicate;

public class C0247 implements ArgumentType<String>, C0045 {
   public final String f3008;
   public final C1266 f3009;
   public static int f3010 = w.a<"B">(4688694395987242291L, 257832362129977838L);

   public String parse(StringReader var1) {
      String var2 = w.a<"Û">(var1, 375896365896432422L);
      w.a<"Û">(var1, w.a<"Û">(var1, 185662703704259241L), 171934355112443263L);
      return var2;
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> var1, SuggestionsBuilder var2) {
      C0015 var3;
      try {
         var3 = w.a<"B">(var1, this.f3009, this.f3008, 314625662720342166L);
      } catch (Exception var11) {
         return w.a<"B">(189209840766080016L);
      }

      if (var3 instanceof C0240) {
         return w.a<"Û">(w.a<"B">((C0240)var3, 148299402731465440L), var1, var2, 167430866301664660L);
      } else if (var3 instanceof C0495 var4) {
         return w.a<"B">(
            w.a<"Û">(
               w.a<"Û">(
                  w.a<"B">((Enum[])w.a<"Û">(w.a<"Û">((Enum)w.a<"Û">(var4, 231406999951969558L), 135670909312549892L), 144334009663342992L), 131523343736437369L),
                  (Predicate<Enum>)var0 -> (boolean)(!w.a<"B">(var0, 369567614708363881L)
                        ? (f3010 | 194320) + ~(f3010 & 194320) + 1 ^ -572601366
                        : (f3010 | 555069) + ~(f3010 & 555069) + 1 ^ -573291322),
                  287370376266094532L
               ),
               (Function<Enum, String>)var0 -> w.a<"Û">(w.a<"Û">(var0, 235224272799028434L), 308826267231227763L),
               141209812120559377L
            ),
            var2,
            379722968704725371L
         );
      } else if (var3 instanceof C0290 var5) {
         Number var12 = (Number)w.a<"Û">(var5, 174312564406604366L);
         if (w.a<"Û">(w.a<"Û">(var2, 110975976514483618L), 268441564659141224L)) {
            return w.a<"Û">(w.a<"Û">(var2, w.a<"B">(w.a<"Û">(var5, 231406999951969558L), 174997918119584642L), 199735903588157119L), 135487642270960168L);
         } else if (var12 instanceof Float) {
            return w.a<"Û">(
               w.a<"B">(
                  w.a<"Û">((Float)((Number)w.a<"Û">(var5, 282635387798544717L)), 149784643039979208L),
                  w.a<"Û">((Float)((Number)w.a<"Û">(var5, 356267007715237645L)), 149784643039979208L),
                  362246925715839581L
               ),
               var1,
               var2,
               294905677577710544L
            );
         } else {
            return var12 instanceof Double
               ? w.a<"Û">(
                  w.a<"B">(
                     w.a<"Û">((Double)((Number)w.a<"Û">(var5, 282635387798544717L)), 287934447355057060L),
                     w.a<"Û">((Double)((Number)w.a<"Û">(var5, 356267007715237645L)), 287934447355057060L),
                     136407773476455600L
                  ),
                  var1,
                  var2,
                  148965032069766187L
               )
               : w.a<"Û">(
                  w.a<"B">(
                     w.a<"Û">((Integer)((Number)w.a<"Û">(var5, 282635387798544717L)), 260981171345819427L),
                     w.a<"Û">((Integer)((Number)w.a<"Û">(var5, 356267007715237645L)), 260981171345819427L),
                     324061332852535608L
                  ),
                  var1,
                  var2,
                  336727523897973347L
               );
         }
      } else if (var3 instanceof C0298 var6) {
         Collection var8 = w.a<"Û">(var6, 387151966565358222L);
         if (var3 instanceof C0275 var9) {
            C0832 var10 = w.a<"B">(w.a<"Û">(var9, 136685182057298513L), 277528539100350036L);
            if (var10 != C0832.f0759) {
               w.a<"Û">(var8, w.a<"Û">(var10, 243052890278072929L), 149725771377842775L);
            }
         }

         return w.a<"B">(var8, var2, 210234445746591302L);
      } else {
         return var3 instanceof C0011 var7
            ? w.a<"B">(
               w.a<"Û">(
                  w.a<"Û">(w.a<"Û">(C0933.f1420, 348569715387034738L), 218807454277778388L),
                  (Function<C1348, String>)var0 -> new C1002()
                        .m2591(w.a<"Û">(var0, 380852241946877156L))
                        .m2591(w.a<"Û">(var0, 376576959810656411L))
                        .m2593("\u0001:\u0001"),
                  141209812120559377L
               ),
               var2,
               379722968704725371L
            )
            : super.listSuggestions(var1, var2);
      }
   }

   public C0247(C1266 var1, String var2) {
      this.f3008 = var2;
      this.f3009 = var1;
   }

   public static C0247 value(C1266 var0, String var1) {
      return new C0247(var0, var1);
   }

   public static String xig6U1fs2dvpguaqdqcgsXit2sM8SrqmjxPW0gdaUIVkgW3N0B0woLSMc8B3Xv4Em2wczWFJPfpmCaWoK6EOCC0jsURUFSuoC69v(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
