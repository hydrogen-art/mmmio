package me.mioclient;

import java.util.function.Predicate;

public class C0393 implements Predicate {
   public C0159 f1079;

   public C0393(C0159 var1) {
      this.f1079 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1079.f5296, 174312564406604366L) == C0160.f4389;
   }
}
