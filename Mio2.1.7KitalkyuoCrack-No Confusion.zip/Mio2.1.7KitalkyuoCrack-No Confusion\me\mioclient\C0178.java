package me.mioclient;

public record C0178() {
   public final float f3634;
   public final float f3635;
   public final float f3636;
   public final float f3637;
   public static int f3638 = w.a<"B">(760084478210812078L, 257832362129977838L);

   public C0178(float var1, float var2, float var3, float var4) {
      this.f3634 = var1;
      this.f3635 = var2;
      this.f3636 = var3;
      this.f3637 = var4;
   }

   public static C0178 m3516(float var0, float var1, float var2, float var3) {
      return new C0178(var0, var1, var0 + var2, var1 + var3);
   }

   public float m3517() {
      return this.f3636 - this.f3634;
   }

   public float m3518() {
      return this.f3637 - this.f3635;
   }

   public boolean m3519(double var1, double var3) {
      return (boolean)(var1 >= (double)this.f3634 && var1 <= (double)this.f3636 && var3 >= (double)this.f3635 && var3 <= (double)this.f3637
         ? (f3638 | 675896) + ~(f3638 & 675896) + 1 ^ 256345432
         : (f3638 | 593082) + ~(f3638 & 593082) + 1 ^ 256170459);
   }

   public boolean m3520(C0178 var1) {
      return (boolean)(!(this.f3636 < this.f3634) && !(this.f3636 > w.a<"Û">(var1, 234657144698359511L))
            || !(this.f3637 < this.f3635) && !(this.f3637 > w.a<"Û">(var1, 197654897311531322L))
            || !(w.a<"Û">(var1, 311720846848181188L) < w.a<"Û">(var1, 234657144698359511L)) && !(w.a<"Û">(var1, 311720846848181188L) > this.f3634)
            || !(w.a<"Û">(var1, 270530290490397677L) < w.a<"Û">(var1, 197654897311531322L)) && !(w.a<"Û">(var1, 270530290490397677L) > this.f3635)
         ? (f3638 | 49350) + ~(f3638 & 49350) + 1 ^ 256710055
         : (f3638 | 897172) + ~(f3638 & 897172) + 1 ^ 255878644);
   }

   public C0178 m3521(float var1) {
      return w.a<"Û">(this, var1, var1, 162545242592179570L);
   }

   public C0178 m3522(float var1, float var2) {
      return new C0178(
         w.a<"Û">(this, 234657144698359511L) - var1,
         w.a<"Û">(this, 197654897311531322L) - var2,
         w.a<"Û">(this, 311720846848181188L) + var1,
         w.a<"Û">(this, 270530290490397677L) + var2
      );
   }

   public C0178 m3523(C0178... var1) {
      float var2 = w.a<"Û">(this, 234657144698359511L);
      float var3 = w.a<"Û">(this, 311720846848181188L);
      float var4 = w.a<"Û">(this, 197654897311531322L);
      float var5 = w.a<"Û">(this, 270530290490397677L);
      C0178[] var6 = var1;
      int var7 = var1.length;

      for (int var8 = (f3638 | 979941) + ~(f3638 & 979941) + 1 ^ 256059012; var8 < var7; var8++) {
         C0178 var9 = var6[var8];
         var2 = w.a<"B">(var2, w.a<"Û">(var9, 234657144698359511L), 304661293439332345L);
         var4 = w.a<"B">(var4, w.a<"Û">(var9, 197654897311531322L), 304661293439332345L);
         var3 = w.a<"B">(var3, w.a<"Û">(var9, 311720846848181188L), 121763288940510105L);
         var5 = w.a<"B">(var5, w.a<"Û">(var9, 270530290490397677L), 121763288940510105L);
      }

      return new C0178(var2, var4, var3, var5);
   }

   public float m3524() {
      return this.f3634;
   }

   public float m3525() {
      return this.f3635;
   }

   public float m3526() {
      return this.f3636;
   }

   public float m3527() {
      return this.f3637;
   }
}
