package me.mioclient;

import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;

public final class C0171 implements C0045 {
   public double f1583;
   public double f1584;
   public double f1585;
   public boolean f1586;
   public boolean f1587;
   public boolean f1588;
   public boolean f1589;
   public int f1590;
   public int f1591;
   public float[] f1592;
   public static int f1593 = w.a<"B">(3127225462529537826L, 257832362129977838L);

   public C0171() {
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   @C1027
   public void m2698(C0612 var1) {
      this.f1588 = this.f1587;
      this.f1587 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L
      );
      if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)
         && !this.f1586) {
         this.f1590 = (f1593 | 440450) + ~(f1593 & 440450) + 1 ^ 75623587;
         this.f1591 = this.f1591 + ((f1593 | 677550) + ~(f1593 & 677550) + 1 ^ 76350094);
      } else {
         this.f1591 = (f1593 | 67721) + ~(f1593 & 67721) + 1 ^ 75914408;
         this.f1590 = this.f1590 + ((f1593 | 662126) + ~(f1593 & 662126) + 1 ^ 76369486);
      }
   }

   @C1027
   public void m2699(C0131 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2828 var2) {
         this.f1583 = w.a<"Û">(
            var2,
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L),
            221035443772680640L
         );
         this.f1584 = w.a<"Û">(
            var2,
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L),
            295470329057738010L
         );
         this.f1585 = w.a<"Û">(
            var2,
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L),
            254439125621034101L
         );
         this.f1586 = w.a<"Û">(var2, 353321937257230310L);
         float[] var10001 = new float[(f1593 | 873754) + ~(f1593 & 873754) + 1 ^ 76153145];
         var10001[(f1593 | 425263) + ~(f1593 & 425263) + 1 ^ 75573518] = w.a<"Û">(
            var2,
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L),
            278034105378354660L
         );
         var10001[(f1593 | 903272) + ~(f1593 & 903272) + 1 ^ 76192840] = w.a<"Û">(
            var2,
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 218194352988080011L),
            134036950582865025L
         );
         this.f1592 = var10001;
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2848 var4) {
         if (w.a<"Û">(var4, 147437756794204774L) == class_2849.field_12979) {
            this.f1589 = (boolean)((f1593 | 421925) + ~(f1593 & 421925) + 1 ^ 75572229);
         } else if (w.a<"Û">(var4, 147437756794204774L) == class_2849.field_12984) {
            this.f1589 = (boolean)((f1593 | 388013) + ~(f1593 & 388013) + 1 ^ 75677580);
         }
      }
   }

   public void m2700(Runnable var1) {
      boolean var2 = w.a<"Û">(C0933.f1429, 124482006455045322L);
      if (var2) {
         w.a<"B">(
            new class_2848(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, class_2849.field_12984
            ),
            384821682750494902L
         );
         w.a<"Û">(var1, 324159666149362285L);
         w.a<"B">(
            new class_2848(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, class_2849.field_12979
            ),
            384821682750494902L
         );
      } else {
         w.a<"Û">(var1, 324159666149362285L);
      }
   }

   public void m2701(Runnable var1) {
      int var2 = !w.a<"Û">(C0933.f1429, 124482006455045322L)
         ? (f1593 | 997329) + ~(f1593 & 997329) + 1 ^ 76047345
         : (f1593 | 551946) + ~(f1593 & 551946) + 1 ^ 76494891;
      if (var2 != 0) {
         w.a<"B">(
            new class_2848(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, class_2849.field_12979
            ),
            384821682750494902L
         );
         w.a<"Û">(var1, 324159666149362285L);
         w.a<"B">(
            new class_2848(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, class_2849.field_12984
            ),
            384821682750494902L
         );
      } else {
         w.a<"Û">(var1, 324159666149362285L);
      }
   }

   public double m2702() {
      return this.f1583;
   }

   public double m2703() {
      return this.f1584;
   }

   public double m2704() {
      return this.f1585;
   }

   public class_243 m2705() {
      return new class_243(this.f1583, this.f1584, this.f1585);
   }

   public boolean m2706() {
      return this.f1586;
   }

   public boolean m2707() {
      return this.f1588;
   }

   public boolean m2708() {
      return this.f1589;
   }

   public int m2709() {
      return this.f1590;
   }

   public int m2710() {
      return this.f1591;
   }

   public float[] m2711() {
      return this.f1592;
   }
}
