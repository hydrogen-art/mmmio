package me.mioclient;

import java.util.function.Predicate;

public class C0446 implements Predicate {
   public C0671 f5076;

   public C0446(C0671 var1) {
      this.f5076 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f5076.f4651, 174312564406604366L) == C0672.f4558;
   }
}
