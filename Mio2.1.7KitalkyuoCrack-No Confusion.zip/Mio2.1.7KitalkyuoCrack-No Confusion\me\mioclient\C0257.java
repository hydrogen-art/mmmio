package me.mioclient;

import net.minecraft.class_437;

public class C0257 extends C1180 {
   public final class_437 f1620;
   public final class_437 f1621;

   public C0257(class_437 var1, class_437 var2) {
      this.f1620 = var1;
      this.f1621 = var2;
   }

   public class_437 m2712() {
      return this.f1621;
   }

   public class_437 m2713() {
      return this.f1620;
   }
}
