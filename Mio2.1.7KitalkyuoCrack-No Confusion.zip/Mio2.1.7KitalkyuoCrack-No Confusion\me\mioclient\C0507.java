package me.mioclient;

import com.google.gson.annotations.SerializedName;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.UnaryOperator;
import net.minecraft.class_124;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_2568.class_5247;

public class C0507 implements C0196 {
   @SerializedName("x")
   public final double f3790;
   @SerializedName("y")
   public final double f3791;
   @SerializedName("z")
   public final double f3792;
   @SerializedName("name")
   public final String f3793;
   @SerializedName("dimension")
   public final String f3794;
   @SerializedName("server")
   public final String f3795;
   @SerializedName("toggled")
   public boolean f3796;
   public transient class_243 f3797;
   public static int f3798 = w.a<"B">(6861280201786633801L, 257832362129977838L);

   public C0507(String var1, double var2, double var4, double var6, String var8, String var9) {
      this.f3790 = w.a<"Û">(this, var2, 244940109960803256L);
      this.f3791 = w.a<"Û">(this, var4, 244940109960803256L);
      this.f3792 = w.a<"Û">(this, var6, 244940109960803256L);
      this.f3794 = var8;
      this.f3795 = var9;
      this.f3793 = var1;
      this.f3797 = new class_243(var2, var4, var6);
      this.f3796 = (boolean)((f3798 | 492947) + ~(f3798 & 492947) + 1 ^ 857783704);
   }

   public C0507(String var1, class_243 var2, String var3, String var4) {
      this(var1, var2.field_1352, var2.field_1351, var2.field_1350, var3, var4);
   }

   public double m3557() {
      return this.f3790;
   }

   public double m3558() {
      return this.f3791;
   }

   public double m3559() {
      return this.f3792;
   }

   public String m3560() {
      return this.f3794;
   }

   public String m3561() {
      return this.f3795;
   }

   public double m3562(class_243 var1) {
      return w.a<"Û">(var1, this.f3797, 180844654503832142L);
   }

   public double m3563(double var1) {
      return w.a<"B">(var1, (f3798 | 131830) + ~(f3798 & 131830) + 1 ^ 858077949, 364699117636043148L);
   }

   public boolean isToggled() {
      return this.f3796;
   }

   public void m3564(boolean var1) {
      this.f3796 = var1;
   }

   public class_243 m3565() {
      if (this.f3797 == null) {
         this.f3797 = new class_243(this.f3790, this.f3791, this.f3792);
      }

      return this.f3797;
   }

   public boolean m3566(String var1, String var2) {
      return (boolean)(w.a<"Û">(this, 298372959493530421L).equals(var1) && w.a<"Û">(w.a<"Û">(this, 152751372260714295L), var2, 307662238383225114L)
         ? (f3798 | 177901) + ~(f3798 & 177901) + 1 ^ 858099430
         : (f3798 | 286924) + ~(f3798 & 286924) + 1 ^ 857954502);
   }

   @Override
   public String getName() {
      return this.f3793;
   }

   @Override
   public class_2561 m0742() {
      return w.a<"Û">(
         w.a<"B">(this.f3793, 228465064790135899L),
         (UnaryOperator)var1 -> {
            class_5247 var10003 = class_5247.field_24342;
            Object[] var10005 = new Object[(f3798 | 37721) + ~(f3798 & 37721) + 1 ^ 858237781];
            var10005[(f3798 | 207656) + ~(f3798 & 207656) + 1 ^ 858002210] = this.f3793;
            var10005[(f3798 | 847852) + ~(f3798 & 847852) + 1 ^ 858511335] = w.a<"B">(this.f3790, 165155940100814265L);
            var10005[(f3798 | 76792) + ~(f3798 & 76792) + 1 ^ 858133488] = w.a<"B">(this.f3791, 165155940100814265L);
            var10005[(f3798 | 698468) + ~(f3798 & 698468) + 1 ^ 858624109] = w.a<"B">(this.f3792, 165155940100814265L);
            var10005[(f3798 | 689876) + ~(f3798 & 689876) + 1 ^ 858635994] = this.f3794;
            var10005[(f3798 | 519056) + ~(f3798 & 519056) + 1 ^ 857789343] = this.f3795;
            return w.a<"Û">(
               var1,
               new class_2568(
                  var10003,
                  w.a<"Û">(
                     w.a<"B">(w.a<"B">("%s's info:\nx: %.1f\ny: %.1f\nz: %.1f\ndimension: %s\nserver: %s", var10005, 223779026484277040L), 228465064790135899L),
                     (UnaryOperator)var0 -> w.a<"Û">(var0, class_124.field_1080, 152778664851569676L),
                     165931758622126162L
                  )
               ),
               120979910123777007L
            );
         },
         165931758622126162L
      );
   }

   public static String yGXW4ZTdzoSPSJcYDSRzJBhA7aiMCf7QCtHKCqORSGpM8sl32BYt7D56vpnh55EU3lBTF4fqEIeYzHoZ9UNTxzMSVir3mtArhyay(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
