package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.io.FileNotFoundException;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;

public final class C0123 extends C0219 {
   public final C0720 f4507;
   public static int f4508 = w.a<"B">(4516435690140059424L, 257832362129977838L);

   public C0123(C0720 var1) {
      super(var1.name().toLowerCase());
      this.f4507 = var1;
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"B">("add", 233839479830701924L),
            w.a<"Û">(
               w.a<"B">("name", new C0403(), 191188367299315725L),
               (Command)var1x -> {
                  String var2 = (String)w.a<"Û">(var1x, "name", String.class, 275658406246533271L);
                  if (w.a<"Û">(C0933.f1417, var2, 338925027459788934L) == this.f4507) {
                     w.a<"B">(
                        w.a<"Û">(
                           w.a<"Û">(this, var2, 187170534302109250L), w.a<"Û">(this, " is already in your %s list", 285878327032435129L), 194629304146735395L
                        ),
                        w.a<"B">((f4508 | 657810) + ~(f4508 & 657810) + 1 ^ -345727930, 289296048454852994L),
                        241936116971186271L
                     );
                  } else {
                     if (this.f4507 == C0720.f3465) {
                        w.a<"Û">(C0933.f1417, var2, 234380613327980501L);
                     } else {
                        w.a<"Û">(C0933.f1417, var2, 268852395399414033L);
                     }

                     w.a<"B">(
                        w.a<"Û">(
                           w.a<"Û">(this, var2, 187170534302109250L),
                           w.a<"Û">(this, " has been added to your %s list", 285878327032435129L),
                           194629304146735395L
                        ),
                        w.a<"B">((f4508 | 673180) + ~(f4508 & 673180) + 1 ^ -345714616, 289296048454852994L),
                        241936116971186271L
                     );
                  }

                  return (f4508 | 981880) + ~(f4508 & 981880) + 1 ^ 346001746;
               },
               368995281709124746L
            ),
            289819728773344295L
         ),
         289819728773344295L
      );
      String[] var10001 = new String[(f4508 | 484263) + ~(f4508 & 484263) + 1 ^ 345377167];
      var10001[(f4508 | 194674) + ~(f4508 & 194674) + 1 ^ 345215577] = "remove";
      var10001[(f4508 | 533187) + ~(f4508 & 533187) + 1 ^ 345589993] = "delete";
      var10001[(f4508 | 233808) + ~(f4508 & 233808) + 1 ^ 345176953] = "del";
      w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"B">(var10001, 188216523544133420L),
            w.a<"Û">(
               w.a<"Û">(w.a<"B">("name", w.a<"B">(192168525870671914L), 191188367299315725L), this::m1821, 357832626693996259L),
               (Command)var1x -> {
                  String var2 = (String)w.a<"Û">(var1x, "name", String.class, 275658406246533271L);
                  if (w.a<"Û">(C0933.f1417, var2, 338925027459788934L) == this.f4507) {
                     w.a<"Û">(C0933.f1417, var2, 193741371501337623L);
                     w.a<"B">(
                        w.a<"Û">(
                           w.a<"Û">(this, var2, 187170534302109250L),
                           w.a<"Û">(this, " has been removed from your %s list", 285878327032435129L),
                           194629304146735395L
                        ),
                        w.a<"B">((f4508 | 555719) + ~(f4508 & 555719) + 1 ^ -345575661, 289296048454852994L),
                        241936116971186271L
                     );
                  } else {
                     w.a<"B">(
                        w.a<"Û">(w.a<"Û">(this, var2, 187170534302109250L), w.a<"Û">(this, " is not your %s", 285878327032435129L), 194629304146735395L),
                        w.a<"B">((f4508 | 535418) + ~(f4508 & 535418) + 1 ^ -345588050, 289296048454852994L),
                        241936116971186271L
                     );
                  }

                  return (f4508 | 655939) + ~(f4508 & 655939) + 1 ^ 345729129;
               },
               368995281709124746L
            ),
            364326416200407929L
         ),
         289819728773344295L
      );
      w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"B">("list", 233839479830701924L),
            (Command)var1x -> {
               List var2 = w.a<"Û">(
                  w.a<"Û">(
                     w.a<"Û">(
                        w.a<"Û">((List)w.a<"Û">(C0933.f1417, 268370374673263607L), 110814793610710346L),
                        (Predicate<C0894>)var1xx -> (boolean)(w.a<"Û">(var1xx, 163085392749476037L) == this.f4507
                              ? (f4508 | 119418) + ~(f4508 & 119418) + 1 ^ 345028688
                              : (f4508 | 923560) + ~(f4508 & 923560) + 1 ^ 345996675),
                        287370376266094532L
                     ),
                     (Function<C0894, class_2561>)var0 -> w.a<"B">(w.a<"Û">(var0, 235072627054557593L), 273107254583785490L),
                     141209812120559377L
                  ),
                  325049488880240942L
               );
               w.a<"B">(
                  w.a<"Û">(
                     w.a<"B">(w.a<"Û">(this, "%S list: ", 285878327032435129L), 228465064790135899L),
                     w.a<"B">(var2, w.a<"B">(", ", 273107254583785490L), 262430922960211376L),
                     267862536496645581L
                  ),
                  w.a<"B">((f4508 | 802264) + ~(f4508 & 802264) + 1 ^ -345855988, 289296048454852994L),
                  241936116971186271L
               );
               return (f4508 | 656528) + ~(f4508 & 656528) + 1 ^ 345730746;
            },
            286944572020109927L
         ),
         289819728773344295L
      );
      w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"B">("sync", 233839479830701924L),
            w.a<"Û">(
               w.a<"B">("importer", new C0417<>(C0743.class, "importer"), 191188367299315725L),
               (Command)var0 -> {
                  C0743 var1x = (C0743)w.a<"Û">(var0, "importer", C0743.class, 275658406246533271L);

                  List var2;
                  try {
                     var2 = w.a<"Û">(var1x, 351318873771881462L);
                  } catch (Exception var6) {
                     if (var6 instanceof FileNotFoundException) {
                        Object[] var7 = new Object[(f4508 | 57173) + ~(f4508 & 57173) + 1 ^ 345093503];
                        var7[(f4508 | 636233) + ~(f4508 & 636233) + 1 ^ 345562978] = w.a<"Û">(var1x, 242645949544232806L);
                        w.a<"B">(
                           w.a<"Û">(
                              w.a<"B">(w.a<"B">("Couldn't find %s friends file", var7, 223779026484277040L), 228465064790135899L),
                              (UnaryOperator)var0x -> w.a<"Û">(var0x, class_124.field_1061, 279049886156942355L),
                              165931758622126162L
                           ),
                           w.a<"B">((f4508 | 998463) + ~(f4508 & 998463) + 1 ^ -345921045, 289296048454852994L),
                           C0639.f3882,
                           211469761772001922L
                        );
                     } else {
                        w.a<"Û">(var6, 277292852406578821L);
                        Object[] var10001x = new Object[(f4508 | 742546) + ~(f4508 & 742546) + 1 ^ 345652920];
                        var10001x[(f4508 | 496706) + ~(f4508 & 496706) + 1 ^ 345439849] = w.a<"Û">(var1x, 242645949544232806L);
                        w.a<"B">(
                           w.a<"Û">(
                              w.a<"B">(
                                 w.a<"B">("Couldn't import friends from %s due to an unknown error, check your log file", var10001x, 223779026484277040L),
                                 228465064790135899L
                              ),
                              (UnaryOperator)var0x -> w.a<"Û">(var0x, class_124.field_1061, 279049886156942355L),
                              165931758622126162L
                           ),
                           w.a<"B">((f4508 | 534403) + ~(f4508 & 534403) + 1 ^ -345591209, 289296048454852994L),
                           C0639.f3882,
                           211469761772001922L
                        );
                     }

                     return (f4508 | 521838) + ~(f4508 & 521838) + 1 ^ 345414724;
                  }

                  int var3 = (f4508 | 912540) + ~(f4508 & 912540) + 1 ^ 345802423;
                  Iterator var4 = w.a<"Û">(var2, 341496865259068134L);

                  while (w.a<"Û">(var4, 333900474771661065L)) {
                     String var5 = (String)w.a<"Û">(var4, 192468336863492695L);
                     if (!w.a<"Û">(C0933.f1417, var5, 225253295937045434L)) {
                        w.a<"Û">(C0933.f1417, var5, 268852395399414033L);
                        var3++;
                     }
                  }

                  Object[] var8 = new Object[(f4508 | 196887) + ~(f4508 & 196887) + 1 ^ 345140030];
                  var8[(f4508 | 240604) + ~(f4508 & 240604) + 1 ^ 345162231] = w.a<"B">(var3, 367942141483020029L);
                  var8[(f4508 | 849745) + ~(f4508 & 849745) + 1 ^ 345873787] = w.a<"Û">(var1x, 242645949544232806L);
                  w.a<"B">(
                     w.a<"B">(w.a<"B">("Added %d new friends from %s", var8, 223779026484277040L), 228465064790135899L),
                     w.a<"B">((f4508 | 23150) + ~(f4508 & 23150) + 1 ^ -345059398, 289296048454852994L),
                     241936116971186271L
                  );
                  return (f4508 | 516366) + ~(f4508 & 516366) + 1 ^ 345410340;
               },
               368995281709124746L
            ),
            289819728773344295L
         ),
         289819728773344295L
      );
   }

   public CompletableFuture<Suggestions> m1821(CommandContext<class_2172> var1, SuggestionsBuilder var2) {
      return w.a<"B">(
         w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">((List)w.a<"Û">(C0933.f1417, 268370374673263607L), 110814793610710346L),
               (Predicate<C0894>)var1x -> (boolean)(w.a<"Û">(var1x, 163085392749476037L) == this.f4507
                     ? (f4508 | 125776) + ~(f4508 & 125776) + 1 ^ 345014650
                     : (f4508 | 219448) + ~(f4508 & 219448) + 1 ^ 345125651),
               287370376266094532L
            ),
            C0196::getName,
            141209812120559377L
         ),
         var2,
         379722968704725371L
      );
   }

   public String m1822(String var1) {
      return w.a<"Û">(
         w.a<"Û">(var1, "%s", w.a<"Û">(this.f4507, 201365076246746602L), 328425598364162988L),
         "%S",
         C0498.m3882(w.a<"Û">(this.f4507, 201365076246746602L)),
         328425598364162988L
      );
   }

   public static String Fdmsu42iD73dWPB5IjfdqOq91zsiskTV84LjHfSWLOoE3pxJ3vYxFwDpKNmmMXbQ0uZ5M5suofI0cCAZhDPv3xYm0OxT0zfcHzbI(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
