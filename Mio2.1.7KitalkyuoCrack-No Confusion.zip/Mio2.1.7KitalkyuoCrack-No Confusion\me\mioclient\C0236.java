package me.mioclient;

import java.util.function.Predicate;

public class C0236 implements Predicate {
   public C0464 f3499;

   public C0236(C0464 var1) {
      this.f3499 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3499.f4342, 174312564406604366L) == C0466.f3598 || w.a<"Û">(this.f3499.f4342, 174312564406604366L) == C0466.f3599;
   }
}
