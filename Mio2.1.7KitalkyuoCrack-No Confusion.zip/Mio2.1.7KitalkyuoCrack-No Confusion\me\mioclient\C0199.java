package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public class C0199 extends C0601 {
   public C0015<C0200> f3186 = w.a<"Û">(this, new C0495<>("Mode", C0200.f4051), 192839886211813275L);
   public final C0015<String> f3187 = w.a<"Û">(
      this,
      new C0975(
         "Text",
         "Welcome to Mio.",
         var1 -> (boolean)(w.a<"Û">(this.f3186, 174312564406604366L) == C0200.f4053
               ? (f3188 | 726354) + ~(f3188 & 726354) + 1 ^ 1959192827
               : (f3188 | 941296) + ~(f3188 & 941296) + 1 ^ 1958977880)
      ),
      192839886211813275L
   );
   public static int f3188 = w.a<"B">(5665983009000499162L, 257832362129977838L);

   public C0199() {
      super("Welcomer");
      this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(
         new C0442(
            this,
            new C1050(
               () -> w.a<"Û">((C0200)w.a<"Û">(this.f3186, 174312564406604366L), this, 286476881261056869L),
               () -> w.a<"B">((boolean)((f3188 | 468774) + ~(f3188 & 468774) + 1 ^ 1959451279), 320330632857389983L)
            )
         )
      );
   }

   public static String WdTjtLDW89zl2AWa0WmkZYBjYd7Po7IEv12bWC7FZZHPlIH6XYV1FjmLXRrOwh28AcjkL378nWPsw24U4vijOqCj5mTNL5QTyqIr(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
