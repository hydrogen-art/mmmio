package me.mioclient;

import java.util.function.Predicate;

public class C0107 implements Predicate {
   public C1272 f0844;

   public C0107(C1272 var1) {
      this.f0844 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0844.f1612, 254992554122318132L);
   }
}
