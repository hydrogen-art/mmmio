package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.Map.Entry;
import net.minecraft.class_124;

record C0280() {
   public final String f3447;
   public final int f3448;
   public static int f3449 = w.a<"B">(5728673217437598666L, 257832362129977838L);

   public C0280(String var1, int var2) {
      this.f3447 = var1;
      this.f3448 = var2;
   }

   public static C0280 m1395(Entry<String, Integer> var0) {
      return new C0280((String)w.a<"Û">(var0, 141740301999341859L), w.a<"Û">((Integer)w.a<"Û">(var0, 196870340575900401L), 260981171345819427L));
   }

   public String m1396(class_124 var1) {
      String var10000 = this.f3447;
      int var10001 = this.f3448;
      return new C1002().m2578(var10001).m2591(var10000).m2593("\u0001 x\u0001");
   }

   public String m1397() {
      return this.f3447;
   }

   public int m1398() {
      return this.f3448;
   }

   public static String Y3rAksm6MJ4mfRFFTNwkdQ0gHbIoUxW4sx1AWSk3TAvliQURBFTUld5VTNvjts7WWopK7ImzwtEyENCrpRmpx0WD0Tq00ZuzHpJc(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
