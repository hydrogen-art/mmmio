package me.mioclient;

import java.util.List;
import net.minecraft.class_303.class_7590;

public interface C0207 {
   List<class_7590> getVisible();
}
