package me.mioclient;

public interface C0170 {
   void m3340(C0685 var1);

   boolean m0689();
}
