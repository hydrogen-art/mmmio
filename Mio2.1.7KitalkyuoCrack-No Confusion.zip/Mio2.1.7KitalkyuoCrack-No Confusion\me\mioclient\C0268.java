package me.mioclient;

import java.util.function.Predicate;

public class C0268 implements Predicate {
   public C0309 f1836;

   public C0268(C0309 var1) {
      this.f1836 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1836.f3400, 174312564406604366L) == C0310.f1937;
   }
}
