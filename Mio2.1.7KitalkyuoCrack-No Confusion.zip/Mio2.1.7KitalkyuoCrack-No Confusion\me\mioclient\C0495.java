package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.function.Predicate;

public final class C0495<T extends Enum<T>> extends C0015<T> {
   public final C0391 f1646 = new C0391(w.a<"Û">((Enum)w.a<"Û">(this, 174312564406604366L), 135670909312549892L));
   public static int f1647 = w.a<"B">(6742449369698993344L, 257832362129977838L);

   public C0495(String var1, T var2, Predicate<T> var3) {
      super(var1, (T)var2, var3);
      if (!w.a<"B">(var2, 359240398534589109L)) {
         throw new IllegalArgumentException();
      }
   }

   public C0495(String var1, T var2) {
      super(var1, (T)var2);
      if (!w.a<"B">(var2, 359240398534589109L)) {
         throw new IllegalArgumentException();
      }
   }

   @Override
   public void m0645(String var1) {
      w.a<"Û">(this, w.a<"Û">(this.f1646, new JsonPrimitive(var1), 296689921156774772L), 277551887451345681L);
   }

   @Override
   public JsonElement toJson() {
      return w.a<"Û">(this.f1646, (Enum)w.a<"Û">(this, 174312564406604366L), 164237795345242582L);
   }

   @Override
   public void fromJson(JsonElement var1) {
      w.a<"Û">(this, w.a<"Û">(this.f1646, var1, 296689921156774772L), 277551887451345681L);
   }
}
