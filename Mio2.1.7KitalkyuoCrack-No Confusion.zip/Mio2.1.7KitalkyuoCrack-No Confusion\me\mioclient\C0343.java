package me.mioclient;

import java.util.ArrayList;
import java.util.List;

public class C0343 {
   public static final int f2457 = (C0343.f2461 | 683547) + ~(C0343.f2461 & 683547) + 1 ^ -1502853057;
   public final List<String> f2458 = new ArrayList<>();
   public final C0083 f2459 = new C0083();
   public int f2460;
   public static int f2461 = w.a<"B">(213925890395840068L, 257832362129977838L);

   public C0343() {
      this.f2460 = (f2461 | 441968) + ~(f2461 & 441968) + 1 ^ -1503618991;
   }

   public void m3089() {
      if (w.a<"Û">(this.f2459, ((long)f2461 | 188844L) + ~((long)f2461 & 188844L) + 1L ^ -1503346095L, 309642602085515378L)) {
         this.f2460 = this.f2460 + ((f2461 | 208278) + ~(f2461 & 208278) + 1 ^ -1503327306);
         w.a<"Û">(this.f2459, 387780412884547639L);
      }

      if (this.f2460 >= w.a<"Û">(this.f2458, 260708190417501501L)) {
         this.f2460 = (f2461 | 587889) + ~(f2461 & 587889) + 1 ^ -1502683568;
      }
   }

   public void reset() {
      w.a<"Û">(this.f2458, 140901994866995976L);
      this.f2460 = (f2461 | 589862) + ~(f2461 & 589862) + 1 ^ -1502665209;
   }

   public List<String> m3090() {
      if (w.a<"Û">(this.f2458, 260708190417501501L) <= ((f2461 | 361162) + ~(f2461 & 361162) + 1 ^ -1503419154)) {
         return this.f2458;
      } else {
         ArrayList var1 = new ArrayList();

         for (int var2 = (f2461 | 226901) + ~(f2461 & 226901) + 1 ^ -1503309708; var2 < ((f2461 | 120359) + ~(f2461 & 120359) + 1 ^ -1503137789); var2++) {
            w.a<"Û">(
               var1, (String)w.a<"Û">(this.f2458, (var2 + this.f2460) % w.a<"Û">(this.f2458, 260708190417501501L), 325739049664951543L), 276802003864609490L
            );
         }

         return var1;
      }
   }

   public int m3091() {
      return this.f2460;
   }

   public List<String> m3092() {
      return this.f2458;
   }
}
