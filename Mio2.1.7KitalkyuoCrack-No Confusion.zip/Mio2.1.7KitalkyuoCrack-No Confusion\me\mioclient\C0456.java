package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0456 implements C0196 {
   f0069("Screen"),
   f0070("Gamma"),
   f0071("Sky"),
   f0072("Potion"),
   f0073("None");

   public final String f0074;

   public C0456(String var3) {
      this.f0074 = var3;
   }

   @Override
   public String getName() {
      return this.f0074;
   }

   public static String _05FqRW2F4bth62nqwcW7TC63To9Uz1lUzU8nznzbnWCcHrwRTZJjGQMOXD6ECGLAS94ny0dNs2ZIzF6BJv3f00PBIA9TU5wauRj/* $VF was: 205FqRW2F4bth62nqwcW7TC63To9Uz1lUzU8nznzbnWCcHrwRTZJjGQMOXD6ECGLAS94ny0dNs2ZIzF6BJv3f00PBIA9TU5wauRj*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
