package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import me.mioclient.mixin.ducks.DuckMinecraftClient;
import net.minecraft.class_304;

public enum C0409 implements C0196 {
   f4259("Left"),
   f4260("Right");

   public final String f4261;

   public C0409(String var3) {
      this.f4261 = var3;
   }

   public void m1721() {
      if (this == f4259) {
         ((DuckMinecraftClient)C0045.f2103).attack();
      } else {
         ((DuckMinecraftClient)C0045.f2103).interact();
      }
   }

   public class_304 m1722() {
      return this == f4259 ? C0045.f2103.field_1690.field_1886 : C0045.f2103.field_1690.field_1904;
   }

   @Override
   public String getName() {
      return this.f4261;
   }

   public static String FBiUr6rCXae64VFgC5M4ncsejSMsVVAG80Fd9BIR1QoCbWrv5dQMC1nv2YVh46darmVicb1zxcboV1wjmeCndBKg7zGtQx945rF9(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
