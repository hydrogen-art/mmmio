package me.mioclient;

import java.util.function.Predicate;

public class C0480 implements Predicate {
   public C0411 f4967;

   public C0480(C0411 var1) {
      this.f4967 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4967.f0694, 254992554122318132L);
   }
}
