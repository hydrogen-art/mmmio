package me.mioclient;

import java.util.function.BiConsumer;
import net.minecraft.class_2338;
import net.minecraft.class_2626;
import net.minecraft.class_2637;
import net.minecraft.class_2680;

public final class C0292 {
   public static final long f4975 = ((long)C0292.f4980 | 336651L) + ~((long)C0292.f4980 & 336651L) + 1L ^ 116428371L;
   public final C0846 f4976;
   public final C0083 f4977 = new C0083();
   public boolean f4978;
   public class_2338 f4979;
   public static int f4980 = w.a<"B">(1631471707176545484L, 257832362129977838L);

   public C0292(C0846 var1) {
      this.f4976 = var1;
   }

   public void m2012(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2626 var2
         && w.a<"Û">(w.a<"Û">(var2, 352440678900927401L), 363526675043086623L)
         && w.a<"Û">(var2, 374912813267946826L).equals(this.f4979)) {
         w.a<"Û">(this, 237294986535933940L);
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2637 var4) {
         w.a<"Û">(var4, (BiConsumer<class_2338, class_2680>)(var1x, var2x) -> {
            if (var1x.equals(this.f4979) && w.a<"Û">(var2x, 363526675043086623L)) {
               w.a<"Û">(this, 237294986535933940L);
            }
         }, 297095639837123530L);
      }
   }

   public void m2013(class_2338 var1) {
      if (!this.f4978) {
         this.f4978 = (boolean)((f4980 | 982945) + ~(f4980 & 982945) + 1 ^ 117133334);
         this.f4979 = var1;
         w.a<"Û">(this.f4977, 387780412884547639L);
      }
   }

   public void m2014() {
      if (this.f4978) {
         if (!w.a<"B">(this.f4979, 168455243775731585L) || w.a<"B">(this.f4979, 264833804936079815L)) {
            w.a<"Û">(this, 237294986535933940L);
         }

         if (this.f4979 != null && !this.f4979.equals(w.a<"Û">(this.f4976, 305504058178342304L))) {
            w.a<"Û">(this, 237294986535933940L);
         }
      }
   }

   public boolean m2015() {
      if (this.f4978 && this.f4979 != null) {
         long var1 = (long)(
            w.a<"B">(
                  (double)(
                     (float)w.a<"Û">(C0933.f1416, 337906300250345140L)
                        * w.a<"B">((f4980 | 757628) + ~(f4980 & 757628) + 1 ^ 1200496842, 349057757755238323L)
                        / w.a<"B">((f4980 | 60954) + ~(f4980 & 60954) + 1 ^ 1153253804, 349057757755238323L)
                  ),
                  348087577662528735L
               )
               * w.a<"B">(((long)f4980 | 527650L) + ~((long)f4980 & 527650L) + 1L ^ 4632233691844551316L, 317139102743630955L)
         );
         var1 = w.a<"B">(var1, ((long)f4980 | 580899L) + ~((long)f4980 & 580899L) + 1L ^ 117272699L, 329552778111668452L);
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f4976.f5199, 174312564406604366L), 354697271520518137L)) {
            var1 = (long)((float)var1 / w.a<"Û">(C0933.f1416, 329491062951172765L));
         }

         var1 = (long)((float)var1 + w.a<"Û">((Float)w.a<"Û">(this.f4976.f5204, 174312564406604366L), 149784643039979208L));
         return w.a<"Û">(this.f4977, var1, 309642602085515378L);
      } else {
         return (boolean)((f4980 | 762626) + ~(f4980 & 762626) + 1 ^ 117312692);
      }
   }

   public void reset() {
      this.f4978 = (boolean)((f4980 | 365953) + ~(f4980 & 365953) + 1 ^ 116406839);
      this.f4979 = null;
   }
}
