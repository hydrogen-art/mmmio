package me.mioclient;

import java.util.function.Predicate;

public class C0112 implements Predicate {
   public C0671 f2633;

   public C0112(C0671 var1) {
      this.f2633 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2633.f4651, 174312564406604366L) == C0672.f4560 || w.a<"Û">(this.f2633.f4651, 174312564406604366L) == C0672.f4558;
   }
}
