package me.mioclient;

import java.util.function.Predicate;

public class C0518 implements Predicate {
   public C0814 f3189;

   public C0518(C0814 var1) {
      this.f3189 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3189.f4938, 254992554122318132L);
   }
}
