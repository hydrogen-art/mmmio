package me.mioclient;

import java.util.function.Predicate;

public class C0227 implements Predicate {
   public C1259 f1287;

   public C0227(C1259 var1) {
      this.f1287 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1287.f4285, 174312564406604366L) == C1260.f2322;
   }
}
