package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1755;
import net.minecraft.class_243;
import net.minecraft.class_2661;
import net.minecraft.class_434;
import net.minecraft.class_5498;

public class C0461 extends C1266 {
   public final C0777 f1595 = new C0777();
   public final C0015<Float> f1596;
   public final C0015<Float> f1597;
   public final C0015<Boolean> f1598;
   public final C0015<Boolean> f1599;
   public final C0015<Boolean> f1600;
   public class_243 f1601;
   public class_243 f1602;
   public float[] f1603;
   public class_5498 f1604;
   public float f1605;
   public float f1606;
   public float f1607;
   public float f1608;
   public static int f1609 = w.a<"B">(9038059965857844660L, 257832362129977838L);

   public C0461() {
      super("Freecam", "Allows your camera to fly through walls.", C1045.f3176);
      w.a<"B">(this, 242859112966675773L);
      this.f1603 = null;
      w.a<"Û">(this.f1596, 267469972706306663L);
      w.a<"Û">(this.f1597, 267469972706306663L);
   }

   @Override
   public void onEnable() {
      if (w.a<"Û">(this, 205492958615326489L)) {
         w.a<"Û">(this, 155417974908982175L);
      } else {
         this.f1604 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 143691430875225825L
         );
         w.a<"Û">(
            new C0772(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913, 0.0F),
            219578312889574614L
         );
         this.f1602 = this.f1601 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L),
            133466035608991790L
         );
         float[] var10001 = new float[(f1609 | 356930) + ~(f1609 & 356930) + 1 ^ 1308490610];
         var10001[(f1609 | 439277) + ~(f1609 & 439277) + 1 ^ 1308506847] = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L
         );
         var10001[(f1609 | 348952) + ~(f1609 & 348952) + 1 ^ 1308482091] = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 218194352988080011L
         );
         this.f1603 = var10001;
         this.f1606 = this.f1605 = this.f1603[(f1609 | 866586) + ~(f1609 & 866586) + 1 ^ 1307947048];
         this.f1608 = this.f1607 = this.f1603[(f1609 | 119523) + ~(f1609 & 119523) + 1 ^ 1308187600];
      }
   }

   @Override
   public void onDisable() {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            this.f1603[(f1609 | 719849) + ~(f1609 & 719849) + 1 ^ 1307734747],
            368221038918368764L
         );
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            this.f1603[(f1609 | 887194) + ~(f1609 & 887194) + 1 ^ 1307902121],
            209955992115144040L
         );
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, this.f1604, 304735625826416513L
         );
      }
   }

   @C1027
   public void m0669(C0612 var1) {
      if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 instanceof class_434) {
         w.a<"Û">(this, 155417974908982175L);
      }

      w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690,
         class_5498.field_26664,
         304735625826416513L
      );
      this.f1602 = this.f1601;
      double[] var2 = w.a<"B">(
         this.f1605, this.f1595, (double)w.a<"Û">((Float)w.a<"Û">(this.f1596, 174312564406604366L), 149784643039979208L), 108620803423508722L
      );
      this.f1601 = w.a<"Û">(
         this.f1601,
         var2[(f1609 | 160129) + ~(f1609 & 160129) + 1 ^ 1308293299],
         0.0,
         var2[(f1609 | 397381) + ~(f1609 & 397381) + 1 ^ 1308531062],
         215037093685651073L
      );
      if (w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690.field_1903, 262940020655803083L
      )) {
         this.f1601 = w.a<"Û">(
            this.f1601, 0.0, (double)w.a<"Û">((Float)w.a<"Û">(this.f1597, 174312564406604366L), 149784643039979208L), 0.0, 215037093685651073L
         );
      }

      if (w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690.field_1832, 262940020655803083L
      )) {
         this.f1601 = w.a<"Û">(
            this.f1601, 0.0, (double)w.a<"Û">((Float)w.a<"Û">(this.f1597, 174312564406604366L), 149784643039979208L), 0.0, 124635973600234141L
         );
      }

      w.a<"Û">(
         this.f1595,
         (boolean)((f1609 | 157227) + ~(f1609 & 157227) + 1 ^ 1308290841),
         w.a<"B">((f1609 | 259266) + ~(f1609 & 259266) + 1 ^ 1920695792, 349057757755238323L),
         149205243634614659L
      );
   }

   @C1027
   public void m0670(C0773 var1) {
      w.a<"Û">(var1, 385440235371820560L);
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = 1000
   )
   public void m0671(C1095 var1) {
      boolean var2 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761, 180640643363611893L
      );
      if (w.a<"Û">(var1, 336212328865671254L) != C0277.f4215
         && w.a<"Û">((Boolean)w.a<"Û">(this.f1599, 174312564406604366L), 354697271520518137L)
         && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1765 != null
         && (!w.a<"B">(171090672375251307L) || var2 || w.a<"Û">((Boolean)w.a<"Û">(this.f1600, 174312564406604366L), 354697271520518137L))) {
         w.a<"Û">(
            var1,
            w.a<"B">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1765, 152935392184286408L),
               213766782372904553L
            ),
            260052617773785522L
         );
      }
   }

   @C1027
   public void m0672(C0816 var1) {
      boolean var2 = w.a<"Û">(
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            w.a<"Û">(var1, 313087336970921067L),
            116318201500984113L
         ),
         222207108884875224L
      ) instanceof class_1755;
      if (var2 || w.a<"Û">((Boolean)w.a<"Û">(this.f1599, 174312564406604366L), 354697271520518137L) && w.a<"B">(171090672375251307L)) {
         float[] var3 = w.a<"B">(w.a<"Û">(w.a<"Û">(var1, 300389461640657860L), 378186176745654896L), 213766782372904553L);
         w.a<"Û">(C0933.f1412, var3, (f1609 | 416056) + ~(f1609 & 416056) + 1 ^ 1308546018, 236731835237641613L);
      }
   }

   @C1027
   public void m0673(C0843 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1599, 174312564406604366L), 354697271520518137L)
         && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1765 != null
         && !w.a<"Û">((Boolean)w.a<"Û">(this.f1600, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(
            var1,
            w.a<"B">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1765, 152935392184286408L),
               213766782372904553L
            ),
            222258786971662221L
         );
      }
   }

   @C1027
   public void m0674(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2661) {
         w.a<"Û">(this, 155417974908982175L);
      }
   }

   @C1027
   public void m0675(C1056 var1) {
      w.a<"Û">(
         this,
         w.a<"Û">(var1, 374721086599555778L) * w.a<"B">(((long)f1609 | 382701L) + ~((long)f1609 & 382701L) + 1L ^ 4594572339219095519L, 317139102743630955L),
         w.a<"Û">(var1, 260504042896958167L) * w.a<"B">(((long)f1609 | 128250L) + ~((long)f1609 & 128250L) + 1L ^ 4594572339218841032L, 317139102743630955L),
         286018533077508147L
      );
      w.a<"Û">(var1, 385440235371820560L);
   }

   @C1027
   public void m0676(C0109 var1) {
      float var2 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 380669592707466289L),
         (boolean)((f1609 | 55098) + ~(f1609 & 55098) + 1 ^ 1308122633),
         364990628252262409L
      );
      w.a<"Û">(
         var1,
         new class_243(w.a<"Û">(this, var2, 358083840337069381L), w.a<"Û">(this, var2, 227727589208020907L), w.a<"Û">(this, var2, 241901064649041981L)),
         227870749902163462L
      );
      w.a<"Û">(var1, 385440235371820560L);
   }

   public void m0677(double var1, double var3) {
      this.f1606 = this.f1605;
      this.f1608 = this.f1607;
      this.f1605 = (float)((double)this.f1605 + var1);
      this.f1607 = (float)((double)this.f1607 + var3);
      this.f1607 = w.a<"B">(this.f1607, (float)(-C1074.f4547), (float)C1074.f4547, 131506059371757968L);
   }

   public double m0678(float var1) {
      return w.a<"B">((double)var1, this.f1602.field_1352, this.f1601.field_1352, 308057504384614299L);
   }

   public double m0679(float var1) {
      return w.a<"B">((double)var1, this.f1602.field_1351, this.f1601.field_1351, 308057504384614299L);
   }

   public double m0680(float var1) {
      return w.a<"B">((double)var1, this.f1602.field_1350, this.f1601.field_1350, 308057504384614299L);
   }

   public double m0681(float var1) {
      return m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 != null
         ? (double)this.f1605
         : (double)w.a<"B">(var1, this.f1606, this.f1605, 286181508181077551L);
   }

   public double m0682(float var1) {
      return m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 != null
         ? (double)this.f1607
         : (double)w.a<"B">(var1, this.f1608, this.f1607, 286181508181077551L);
   }

   public boolean m0683() {
      return (boolean)(w.a<"Û">(this, 314537768572362865L) && w.a<"Û">((Boolean)w.a<"Û">(this.f1598, 174312564406604366L), 354697271520518137L)
         ? (f1609 | 549313) + ~(f1609 & 549313) + 1 ^ 1307633906
         : (f1609 | 862729) + ~(f1609 & 862729) + 1 ^ 1307943739);
   }

   public static String sOvQK5PNT16hjz9QkHtcdNorv9htEPLHBeUmi039ptBfh2vdiGjtewtIKfZjXawTOxW1vTpYhqjz4EvxYzTynDwhzd5mCieolH6Y(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
