package me.mioclient;

import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2172;
import net.minecraft.class_5250;

public abstract class C0219 extends C0502 {
   public String[] f3835;
   public static int f3836 = w.a<"B">(6384628606676166876L, 257832362129977838L);

   public C0219(String var1) {
      super(var1);
      this.f3835 = new String[(f3836 | 259256) + ~(f3836 & 259256) + 1 ^ -1174580326];
   }

   public static <T> RequiredArgumentBuilder<class_2172, T> argument(String var0, ArgumentType<T> var1) {
      return w.a<"B">(var0, var1, 198410103369191770L);
   }

   public static LiteralArgumentBuilder<class_2172> literal(String var0) {
      return w.a<"B">(var0, 319973089233605172L);
   }

   public static RequiredArgumentBuilder<class_2172, String> m1569(String... var0) {
      return w.a<"B">(var0[(f3836 | 34972) + ~(f3836 & 34972) + 1 ^ -1174523970], new C1239(var0), 191188367299315725L);
   }

   public static CompletableFuture<Suggestions> m1570(SuggestionsBuilder var0, String... var1) {
      String[] var2 = var1;
      int var3 = var1.length;

      for (int var4 = (f3836 | 57989) + ~(f3836 & 57989) + 1 ^ -1174518361; var4 < var3; var4++) {
         String var5 = var2[var4];
         w.a<"Û">(var0, var5, 199735903588157119L);
      }

      return w.a<"Û">(var0, 135487642270960168L);
   }

   public void m1571(Runnable var1) {
      w.a<"Û">(C0933.f1433, var1, (f3836 | 943839) + ~(f3836 & 943839) + 1 ^ -1175404035, 122889728173745617L);
   }

   public class_5250 m1572(String var1) {
      return w.a<"Û">(w.a<"B">(151712998973257886L), w.a<"B">(var1, 247312894434258291L), 267862536496645581L);
   }

   public void m1573(String... var1) {
      this.f3835 = var1;
   }

   public String[] getAliases() {
      return this.f3835;
   }

   public abstract void exec(LiteralArgumentBuilder<class_2172> var1);

   public void m1574(C0219 var1, LiteralArgumentBuilder<class_2172> var2) {
      LiteralArgumentBuilder var3 = w.a<"B">(w.a<"Û">(var1, 248211090350577353L), 233839479830701924L);
      w.a<"Û">(var1, var3, 196091701403883079L);
      w.a<"Û">(var2, var3, 289819728773344295L);
   }
}
