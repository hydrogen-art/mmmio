package me.mioclient;

import java.util.function.Predicate;

public class C0337 implements Predicate {
   public C0012 f4011;

   public C0337(C0012 var1) {
      this.f4011 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4011.f2876, 254992554122318132L);
   }
}
