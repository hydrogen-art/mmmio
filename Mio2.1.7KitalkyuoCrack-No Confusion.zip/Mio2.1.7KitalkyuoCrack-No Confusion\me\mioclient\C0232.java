package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles.Lookup;

public abstract class C0232 extends C1266 {
   public static int f0948 = w.a<"B">(898168062632737728L, 257832362129977838L);

   public C0232(String var1, String var2, C1045 var3, String... var4) {
      super(var1, var2, var3, var4);
   }

   public C0232(String var1, C1045 var2, String... var3) {
      this(var1, "", var2, var3);
   }

   @Override
   public boolean isDrawn() {
      return (boolean)((f0948 | 824885) + ~(f0948 & 824885) + 1 ^ 1424770164);
   }

   @Override
   public boolean isToggled() {
      return (boolean)((f0948 | 931945) + ~(f0948 & 931945) + 1 ^ 1424943657);
   }

   @Override
   public void disable() {
   }

   @Override
   public C1088 getKeybind() {
      return C1088.f3076;
   }

   @Override
   public JsonElement toJson() {
      JsonObject var1 = w.a<"Û">(super.toJson(), 322749330123725882L);
      w.a<"Û">(var1, "enabled", 123031262139480692L);
      w.a<"Û">(var1, "key", 123031262139480692L);
      w.a<"Û">(var1, "state", 123031262139480692L);
      return var1;
   }

   public static String _JjnHwPuJZ5T6WXnAJeSwrwG2TwHCdkXqykTigAyp2SbPGPB95Gr06KjcqvBjJvciUXojELjsvRypJR3fdy9GxU0doPZ4f14g4oh/* $VF was: 5JjnHwPuJZ5T6WXnAJeSwrwG2TwHCdkXqykTigAyp2SbPGPB95Gr06KjcqvBjJvciUXojELjsvRypJR3fdy9GxU0doPZ4f14g4oh*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
