package me.mioclient;

import java.util.function.Predicate;

public class C0193 implements Predicate {
   public C0936 f2509;

   public C0193(C0936 var1) {
      this.f2509 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2509.f1817, 254992554122318132L);
   }
}
