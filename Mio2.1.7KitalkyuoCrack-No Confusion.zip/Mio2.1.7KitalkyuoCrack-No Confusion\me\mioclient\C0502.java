package me.mioclient;

import java.util.Objects;

public class C0502 implements C0045, C0196 {
   public final String f1130;
   public String f1131 = "";
   public static int f1132 = w.a<"B">(180683872512969646L, 257832362129977838L);

   public C0502(String var1) {
      this.f1130 = var1;
   }

   @Override
   public String getName() {
      return this.f1130;
   }

   public String getDescription() {
      return this.f1131;
   }

   public void setDescription(String var1) {
      this.f1131 = var1;
   }

   public boolean isDescriptionPresent() {
      return (boolean)(!Objects.equals(this.f1131, "")
         ? (f1132 | 323090) + ~(f1132 & 323090) + 1 ^ -1677614110
         : (f1132 | 158055) + ~(f1132 & 158055) + 1 ^ -1677253482);
   }

   @Override
   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)((f1132 | 699385) + ~(f1132 & 699385) + 1 ^ -1676679671);
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         C0502 var2 = (C0502)var1;
         return Objects.equals(this.f1130, var2.f1130);
      } else {
         return (boolean)((f1132 | 660869) + ~(f1132 & 660869) + 1 ^ -1676715916);
      }
   }

   @Override
   public int hashCode() {
      Object[] var10000 = new Object[(f1132 | 394882) + ~(f1132 & 394882) + 1 ^ -1677505678];
      var10000[(f1132 | 595059) + ~(f1132 & 595059) + 1 ^ -1676912254] = this.f1130;
      return w.a<"B">(var10000, 292132947184505832L);
   }
}
