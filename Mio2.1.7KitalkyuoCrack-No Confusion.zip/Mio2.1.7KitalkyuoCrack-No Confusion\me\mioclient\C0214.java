package me.mioclient;

import java.util.function.Predicate;

public class C0214 implements Predicate {
   public C0931 f1078;

   public C0214(C0931 var1) {
      this.f1078 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1078.f2424, 254992554122318132L);
   }
}
