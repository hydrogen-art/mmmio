package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0269 implements C0196 {
   f4217("Plain"),
   f4218("Grim"),
   f4219("NoVelocity");

   public final String f4220;

   public C0269(String var3) {
      this.f4220 = var3;
   }

   @Override
   public String getName() {
      return this.f4220;
   }

   public static String _L6Bzx52VAl6CbVG3hDacIqNSehdZvn5LdyeHZynBSy9JPAqPDrFxlMr4vGPuD9PwQQn5tOZhTcxTpnfUrGjhT3njp2VD49uiWbY/* $VF was: 9L6Bzx52VAl6CbVG3hDacIqNSehdZvn5LdyeHZynBSy9JPAqPDrFxlMr4vGPuD9PwQQn5tOZhTcxTpnfUrGjhT3njp2VD49uiWbY*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
