package me.mioclient;

import com.google.common.collect.ImmutableList;
import com.mojang.blaze3d.platform.GlStateManager;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_286;
import net.minecraft.class_2960;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL32C;

public class C0525 implements C0045 {
   public static final FloatBuffer f3085 = BufferUtils.createFloatBuffer((C0525.f3097 | 717438) + ~(C0525.f3097 & 717438) + 1 ^ 954079333);
   public static final C0918 f3086 = m1299("DEPTH");
   public static final C0918 f3087 = m1299("BLEND");
   public static final C0918 f3088 = m1299("CULL");
   public static final C0918 f3089 = m1299("SCISSOR");
   public static boolean f3090;
   public static boolean f3091;
   public static boolean f3092;
   public static boolean f3093;
   public static boolean f3094 = (boolean)((C0525.f3097 | 880443) + ~(C0525.f3097 & 880443) + 1 ^ 953779505);
   public static int f3095;
   public static int f3096;
   public static int f3097 = 953477643;

   public static int m1244() {
      return GlStateManager._glGenVertexArrays();
   }

   public static int m1245() {
      return GlStateManager._glGenBuffers();
   }

   public static int m1246() {
      return GlStateManager._genTexture();
   }

   public static int m1247() {
      return GlStateManager.glGenFramebuffers();
   }

   public static void m1248(int var0) {
      GlStateManager._glDeleteBuffers(var0);
   }

   public static void m1249(int var0) {
      GlStateManager._glDeleteVertexArrays(var0);
   }

   public static void m1250(int var0) {
      GlStateManager.glDeleteShader(var0);
   }

   public static void m1251(int var0) {
      GlStateManager._deleteTexture(var0);
   }

   public static void m1252(int var0) {
      GlStateManager._glDeleteFramebuffers(var0);
   }

   public static void m1253(int var0) {
      GlStateManager.glDeleteProgram(var0);
   }

   public static void m1254(int var0) {
      GlStateManager._glBindVertexArray(var0);
      if (f3094) {
         class_286.field_38982 = null;
      }
   }

   public static void m1255(int var0) {
      GlStateManager._glBindBuffer((f3097 | 311322) + ~(f3097 & 311322) + 1 ^ 953197187, var0);
   }

   public static void m1256(int var0) {
      if (var0 != 0) {
         f3096 = f3095;
      }

      GlStateManager._glBindBuffer((f3097 | 355735) + ~(f3097 & 355735) + 1 ^ 953224975, var0 != 0 ? var0 : f3096);
   }

   public static void m1257(int var0) {
      GlStateManager._glBindFramebuffer((f3097 | 238343) + ~(f3097 & 238343) + 1 ^ 953664588, var0);
   }

   public static void m1258(int var0, ByteBuffer var1, int var2) {
      GlStateManager._glBufferData(var0, var1, var2);
   }

   public static void m1259(int var0, int var1, int var2) {
      GlStateManager._drawElements(var0, var1, var2, 0L);
   }

   public static void m1260(int var0) {
      GlStateManager._enableVertexAttribArray(var0);
   }

   public static void m1261(int var0, int var1, int var2, boolean var3, int var4, long var5) {
      GlStateManager._vertexAttribPointer(var0, var1, var2, var3, var4, var5);
   }

   public static int m1262(int var0) {
      return GlStateManager.glCreateShader(var0);
   }

   public static void m1263(int var0, String var1) {
      GlStateManager.glShaderSource(var0, ImmutableList.of(var1));
   }

   public static String m1264(int var0) {
      GlStateManager.glCompileShader(var0);
      return GlStateManager.glGetShaderi(var0, (f3097 | 88714) + ~(f3097 & 88714) + 1 ^ 953498368) == 0
         ? GlStateManager.glGetShaderInfoLog(var0, (f3097 | 168675) + ~(f3097 & 168675) + 1 ^ 953580264)
         : null;
   }

   public static int m1265() {
      return GlStateManager.glCreateProgram();
   }

   public static String m1266(int var0, int var1, int var2) {
      GlStateManager.glAttachShader(var0, var1);
      GlStateManager.glAttachShader(var0, var2);
      GlStateManager.glLinkProgram(var0);
      return GlStateManager.glGetProgrami(var0, (f3097 | 548798) + ~(f3097 & 548798) + 1 ^ 953957943) == 0
         ? GlStateManager.glGetProgramInfoLog(var0, (f3097 | 522500) + ~(f3097 & 522500) + 1 ^ 953356559)
         : null;
   }

   public static void m1267(int var0) {
      GlStateManager._glUseProgram(var0);
   }

   public static int m1268(int var0, String var1) {
      return GlStateManager._glGetUniformLocation(var0, var1);
   }

   public static void m1269(int var0, int var1) {
      GlStateManager._glUniform1i(var0, var1);
   }

   public static void m1270(int var0, float var1) {
      GL32C.glUniform1f(var0, var1);
   }

   public static void m1271(int var0, float var1, float var2) {
      GL32C.glUniform2f(var0, var1, var2);
   }

   public static void m1272(int var0, float var1, float var2, float var3) {
      GL32C.glUniform3f(var0, var1, var2, var3);
   }

   public static void m1273(int var0, float var1, float var2, float var3, float var4) {
      GL32C.glUniform4f(var0, var1, var2, var3, var4);
   }

   public static void m1274(int var0, float[] var1) {
      GL32C.glUniform3fv(var0, var1);
   }

   public static void m1275(int var0, Matrix4f var1) {
      var1.get(f3085);
      GlStateManager._glUniformMatrix4(var0, (boolean)((f3097 | 317228) + ~(f3097 & 317228) + 1 ^ 953171239), f3085);
   }

   public static void m1276(int var0, int var1) {
      GlStateManager._pixelStore(var0, var1);
   }

   public static void m1277(int var0, int var1, int var2) {
      GlStateManager._texParameter(var0, var1, var2);
   }

   public static void m1278(int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, ByteBuffer var8) {
      GL32C.glTexImage2D(var0, var1, var2, var3, var4, var5, var6, var7, var8);
   }

   public static void m1279() {
      m1276((f3097 | 927446) + ~(f3097 & 927446) + 1 ^ 953860141, (f3097 | 728259) + ~(f3097 & 728259) + 1 ^ 954201800);
      m1276((f3097 | 548221) + ~(f3097 & 548221) + 1 ^ 953990023, (f3097 | 917142) + ~(f3097 & 917142) + 1 ^ 953750685);
      m1276((f3097 | 730360) + ~(f3097 & 730360) + 1 ^ 954188289, (f3097 | 521737) + ~(f3097 & 521737) + 1 ^ 953359362);
      m1276((f3097 | 370485) + ~(f3097 & 370485) + 1 ^ 953273680, (f3097 | 878981) + ~(f3097 & 878981) + 1 ^ 953779086);
      m1276((f3097 | 704010) + ~(f3097 & 704010) + 1 ^ 954095858, (f3097 | 835304) + ~(f3097 & 835304) + 1 ^ 953701603);
      m1276((f3097 | 503358) + ~(f3097 & 503358) + 1 ^ 953370817, (f3097 | 665781) + ~(f3097 & 665781) + 1 ^ 954122942);
      m1276((f3097 | 374256) + ~(f3097 & 374256) + 1 ^ 953278358, (f3097 | 371411) + ~(f3097 & 371411) + 1 ^ 953237720);
      m1276((f3097 | 25537) + ~(f3097 & 25537) + 1 ^ 953451839, (f3097 | 909459) + ~(f3097 & 909459) + 1 ^ 953748124);
   }

   public static void m1280(int var0) {
      GL32C.glGenerateMipmap(var0);
   }

   public static void m1281(int var0, int var1, int var2, int var3, int var4) {
      GlStateManager._glFramebufferTexture2D(var0, var1, var2, var3, var4);
   }

   public static void m1282(int var0) {
      GlStateManager._clearColor(0.0F, 0.0F, 0.0F, Float.intBitsToFloat((f3097 | 777549) + ~(f3097 & 777549) + 1 ^ 123680582));
      GlStateManager._clear(var0, (boolean)((f3097 | 970166) + ~(f3097 & 970166) + 1 ^ 953821117));
   }

   public static void m1283() {
      f3090 = f3086.getState();
      f3091 = f3087.getState();
      f3092 = f3088.getState();
      f3093 = f3089.getState();
   }

   public static void m1284() {
      f3086.set(f3090);
      f3087.set(f3091);
      f3088.set(f3092);
      f3089.set(f3093);
      m1294();
   }

   public static void m1285() {
      GlStateManager._enableDepthTest();
   }

   public static void m1286() {
      GlStateManager._disableDepthTest();
   }

   public static void m1287() {
      GlStateManager._enableBlend();
      GlStateManager._blendFunc((f3097 | 715295) + ~(f3097 & 715295) + 1 ^ 954073878, (f3097 | 818730) + ~(f3097 & 818730) + 1 ^ 953718562);
   }

   public static void m1288() {
      GlStateManager._disableBlend();
   }

   public static void m1289() {
      GlStateManager._enableCull();
   }

   public static void m1290() {
      GlStateManager._disableCull();
   }

   public static void m1291() {
      GlStateManager._enableScissorTest();
   }

   public static void m1292() {
      GlStateManager._disableScissorTest();
   }

   public static void m1293() {
      GL32C.glEnable((f3097 | 90106) + ~(f3097 & 90106) + 1 ^ 953532113);
      GL32C.glLineWidth(Float.intBitsToFloat((f3097 | 961006) + ~(f3097 & 961006) + 1 ^ 123356133));
   }

   public static void m1294() {
      GL32C.glDisable((f3097 | 912590) + ~(f3097 & 912590) + 1 ^ 953748965);
   }

   public static void m1295(class_2960 var0) {
      GlStateManager._activeTexture((f3097 | 385814) + ~(f3097 & 385814) + 1 ^ 953257437);
      m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1531().method_22813(var0);
   }

   public static void m1296(int var0, int var1) {
      GlStateManager._activeTexture(((f3097 | 369904) + ~(f3097 & 369904) + 1 ^ 953272891) + var1);
      GlStateManager._bindTexture(var0);
   }

   public static void m1297(int var0) {
      m1296(var0, (f3097 | 250201) + ~(f3097 & 250201) + 1 ^ 953629522);
   }

   public static void m1298() {
      GlStateManager._activeTexture((f3097 | 365370) + ~(f3097 & 365370) + 1 ^ 953286129);
   }

   public static C0918 m1299(String var0) {
      try {
         Class<GlStateManager> var1 = GlStateManager.class;
         Field var2 = var1.getDeclaredField(var0);
         var2.setAccessible((boolean)((f3097 | 211248) + ~(f3097 & 211248) + 1 ^ 953668410));
         Object var3 = var2.get(null);
         String var4 = FabricLoader.getInstance().getMappingResolver().mapClassName("intermediary", "com.mojang.blaze3d.platform.GlStateManager$class_1018");
         Field var5 = null;
         Field[] var6 = var3.getClass().getDeclaredFields();
         int var7 = var6.length;

         for (int var8 = (f3097 | 428223) + ~(f3097 & 428223) + 1 ^ 953311924; var8 < var7; var8++) {
            Field var9 = var6[var8];
            if (var9.getType().getName().equals(var4)) {
               var5 = var9;
               break;
            }
         }

         var5.setAccessible((boolean)((f3097 | 819094) + ~(f3097 & 819094) + 1 ^ 953718172));
         return (C0918)var5.get(var3);
      } catch (IllegalAccessException | NoSuchFieldException var10) {
         var10.printStackTrace();
         return null;
      }
   }

   static {
      long var10000 = 5239878143473213438L;
   }

   public static String _JIMauuQZBmEsv9ItSSiegRYKChUGe7clJw5vpaQPCa4twNiHlRIcGgenTHl24CbZHrhBmOnE2IFPTPwrDBMpnxjeedjSsqf0Rct/* $VF was: 5JIMauuQZBmEsv9ItSSiegRYKChUGe7clJw5vpaQPCa4twNiHlRIcGgenTHl24CbZHrhBmOnE2IFPTPwrDBMpnxjeedjSsqf0Rct*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
