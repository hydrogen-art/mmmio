package me.mioclient;

import java.util.function.Predicate;

public class C0197 implements Predicate {
   public C0309 f5323;

   public C0197(C0309 var1) {
      this.f5323 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f5323.f3405, 254992554122318132L);
   }
}
