package me.mioclient;

import java.util.function.Predicate;

public class C0218 implements Predicate {
   public C0544 f1934;

   public C0218(C0544 var1) {
      this.f1934 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1934.f2978, 254992554122318132L);
   }
}
