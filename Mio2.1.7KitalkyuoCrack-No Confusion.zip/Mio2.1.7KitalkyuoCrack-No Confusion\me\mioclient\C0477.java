package me.mioclient;

import java.util.function.Predicate;

public class C0477 implements Predicate {
   public C1261 f2345;

   public C0477(C1261 var1) {
      this.f2345 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2345.f0676, 174312564406604366L) != C1262.f4531;
   }
}
