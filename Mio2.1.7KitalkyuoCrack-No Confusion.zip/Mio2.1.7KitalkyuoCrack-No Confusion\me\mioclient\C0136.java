package me.mioclient;

public record C0136() {
   public final int f0278;
   public final int f0279;
   public static final C0136 f0280 = new C0136(
      (C0136.f0281 | 740282) + ~(C0136.f0281 & 740282) + 1 ^ 1145174198, (C0136.f0281 | 454859) + ~(C0136.f0281 & 454859) + 1 ^ 1145848775
   );
   public static int f0281 = w.a<"B">(8348211359353438206L, 257832362129977838L);

   public C0136(int var1, int var2) {
      this.f0278 = var1;
      this.f0279 = var2;
   }

   public boolean m0179() {
      return (boolean)(this.f0278 != ((f0281 | 698571) + ~(f0281 & 698571) + 1 ^ 1145052103)
            && this.f0279 != ((f0281 | 303828) + ~(f0281 & 303828) + 1 ^ 1145967064)
         ? (f0281 | 819838) + ~(f0281 & 819838) + 1 ^ -1145450867
         : (f0281 | 779136) + ~(f0281 & 779136) + 1 ^ -1145131150);
   }

   public int m0180() {
      return this.f0278;
   }

   public int m0181() {
      return this.f0279;
   }
}
