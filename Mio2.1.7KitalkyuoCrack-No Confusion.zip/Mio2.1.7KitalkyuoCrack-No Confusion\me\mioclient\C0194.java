package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2246;

public enum C0194 implements C0045, C0196 {
   f3839("Place"),
   f3840("Hit");

   public final String f3841;
   public static C1055 f3842 = C0933.f1409.m2696(C1055.class);

   public C0194(String var3) {
      this.f3841 = var3;
   }

   public double m3588(class_1657 var1) {
      if (f3842.f4837) {
         return 0.1;
      } else if (!w.a<"Û">((Boolean)w.a<"Û">(f3842.f4778, 174312564406604366L), 354697271520518137L)
         || !(w.a<"B">(var1, 181476777857313967L) <= w.a<"Û">((Float)w.a<"Û">(f3842.f4779, 174312564406604366L), 149784643039979208L))
            && !(w.a<"B">(var1, 356149954255543373L) <= (float)w.a<"Û">((Integer)w.a<"Û">(f3842.f4780, 174312564406604366L), 260981171345819427L))) {
         if (w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
               310987074049434965L
            ),
            class_2246.field_10316,
            272812080270536171L
         )) {
            return 0.6;
         } else {
            double var2 = (double)w.a<"Û">((Float)w.a<"Û">(f3842.f4748, 174312564406604366L), 149784643039979208L);
            double var4 = (double)w.a<"Û">((Float)w.a<"Û">(f3842.f4765, 174312564406604366L), 149784643039979208L);
            if (w.a<"Û">(f3842.f4748, 234167214910835683L)) {
               var2 = (double)w.a<"B">(var1, 181476777857313967L);
            }

            if (w.a<"Û">(f3842, 252498128781009397L)) {
               var2 = w.a<"B">(var2, 5.0, 199488685501753436L);
               var4 = 3.0;
            }

            return w.a<"B">(this == f3840 ? var4 : var2, (double)w.a<"B">(var1, 181476777857313967L), 199488685501753436L);
         }
      } else {
         return 0.6;
      }
   }

   public double m3589() {
      return w.a<"Û">(f3842, 118409517985567549L)
         ? 999.0
         : (double)w.a<"Û">(
            this == f3840 ? (Float)w.a<"Û">(f3842.f4766, 174312564406604366L) : (Float)w.a<"Û">(f3842.f4749, 174312564406604366L), 149784643039979208L
         );
   }

   public boolean m3590(class_1657 var1, double var2, double var4, C1292 var6) {
      boolean var7 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 159396947398056288L),
            class_1802.field_8288,
            282470456889867724L
         )
         || w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L),
            class_1802.field_8288,
            282470456889867724L
         );
      boolean var8 = var6.equals(C1292.f1761);
      if (w.a<"Û">((Boolean)w.a<"Û">(f3842.f4800, 174312564406604366L), 354697271520518137L)) {
         return false;
      } else {
         if (w.a<"Û">(f3842, 118409517985567549L)) {
            var2 = 0.0;
         }

         if (!(var2 >= (double)w.a<"B">(346651574723755238L))
            || !w.a<"Û">((Boolean)w.a<"Û">(f3842.f4767, 174312564406604366L), 354697271520518137L)
            || var8 && var7) {
            if (var8) {
               return false;
            } else {
               return this == f3839 && var2 > 0.0 && var4 / var2 < (double)w.a<"Û">((Float)w.a<"Û">(f3842.f4750, 174312564406604366L), 149784643039979208L)
                  ? true
                  : !(var4 >= (double)w.a<"B">(var1, 181476777857313967L))
                     && (!(var4 >= w.a<"Û">(this, var1, 327737967645256998L)) || !(var2 <= w.a<"Û">(this, 352151981484277847L)));
            }
         } else {
            return true;
         }
      }
   }

   @Override
   public String getName() {
      return this.f3841;
   }

   public static String TqrKNpGhkH5klU7FKm2PxqXAWVMbnsPQ5cR4WWvNbeVerFs1xnL9ZIanE56IfjU45hBCoxe0g04806TGqqyAgzwsl4lFZO2XrpJf(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
