package me.mioclient;

public class C0255 extends C1180 {
   public final C0221 f0282;

   public C0255(C0221 var1) {
      this.f0282 = var1;
   }

   public C0221 m0182() {
      return this.f0282;
   }
}
