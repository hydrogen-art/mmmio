package me.mioclient;

import net.minecraft.class_2596;

public final class C0132 extends C0130 {
   public C0132(class_2596<?> var1) {
      super(var1);
   }
}
