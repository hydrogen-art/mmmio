package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_4587;

public class C0244 extends C1266 {
   public final C0015<Boolean> f2887;
   public final C0015<Boolean> f2888;
   public final C0015<Boolean> f2889;
   public final C0015<Integer> f2890;
   public final C0015<Boolean> f2891;
   public final C0015<Boolean> f2892;
   public final C0015<Float> f2893;
   public final C0015<Integer> f2894;
   public final C0015<Integer> f2895;
   public final C0015<Integer> f2896;
   public final C0015<Color> f2897;
   public final C0614 f2898;
   public static int f2899 = w.a<"B">(6219950675449089239L, 257832362129977838L);

   public C0244() {
      super("Crosshair", "Allows you to customize your crosshair.", C1045.f3174);
      w.a<"B">(this, 242859112966675773L);
      this.f2898 = new C0614(
         w.a<"B">((f2899 | 802189) + ~(f2899 & 802189) + 1 ^ 1278889052, 349057757755238323L), (boolean)((f2899 | 12346) + ~(f2899 & 12346) + 1 ^ 204882410)
      );
      w.a<"Û">(this, (boolean)((f2899 | 493231) + ~(f2899 & 493231) + 1 ^ 204601214), 135570431627433065L);
   }

   @C1027
   public void m1127(C0287 var1) {
      if (!w.a<"Û">(this, 205492958615326489L)
         && (
            !w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L),
                  316146075363717916L
               )
               || w.a<"Û">((Boolean)w.a<"Û">(this.f2887, 174312564406604366L), 354697271520518137L)
         )) {
         float var2 = (float)w.a<"Û">((Integer)w.a<"Û">(this.f2894, 174312564406604366L), 260981171345819427L);
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f2891, 174312564406604366L), 354697271520518137L)) {
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f2892, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(
                  this.f2898,
                  (boolean)(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913.field_3905
                           == 0.0F
                        && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913.field_3907
                           == 0.0F
                        && !m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913.field_3904
                     ? (f2899 | 325709) + ~(f2899 & 325709) + 1 ^ 204638620
                     : (f2899 | 439498) + ~(f2899 & 439498) + 1 ^ 204522778),
                  386177623722366053L
               );
            } else {
               w.a<"Û">(
                  this.f2898,
                  (boolean)(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913.field_3905
                           == 0.0F
                        && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913.field_3907
                           == 0.0F
                        && !m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913.field_3904
                     ? (f2899 | 269115) + ~(f2899 & 269115) + 1 ^ 204630762
                     : (f2899 | 845663) + ~(f2899 & 845663) + 1 ^ 205166223),
                  169045546171463933L
               );
            }

            var2 += w.a<"Û">((Float)w.a<"Û">(this.f2893, 174312564406604366L), 149784643039979208L) * w.a<"Û">(this.f2898, 261144342534166569L);
         }

         float var3 = (float)w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
            348892776066937051L
         );
         w.a<"Û">(w.a<"Û">(var1, 300827487269311485L), 156066167197700274L);
         w.a<"Û">(
            w.a<"Û">(var1, 300827487269311485L),
            w.a<"B">((f2899 | 609802) + ~(f2899 & 609802) + 1 ^ 868171739, 349057757755238323L) / var3,
            w.a<"B">((f2899 | 766176) + ~(f2899 & 766176) + 1 ^ 868073777, 349057757755238323L) / var3,
            w.a<"B">((f2899 | 696514) + ~(f2899 & 696514) + 1 ^ 868012307, 349057757755238323L) / var3,
            338733048864940183L
         );
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f2889, 174312564406604366L), 354697271520518137L)) {
            class_4587 var4 = w.a<"Û">(var1, 300827487269311485L);
            w.a<"Û">(var4, 156066167197700274L);
            w.a<"Û">(
               var4,
               (float)w.a<"Û">((Integer)w.a<"Û">(this.f2890, 174312564406604366L), 260981171345819427L),
               (float)w.a<"Û">((Integer)w.a<"Û">(this.f2890, 174312564406604366L), 260981171345819427L),
               0.0F,
               202980495898708244L
            );
            w.a<"Û">(
               this,
               w.a<"Û">(var1, 300827487269311485L),
               (float)w.a<"Û">((Integer)w.a<"Û">(this.f2895, 174312564406604366L), 260981171345819427L),
               (float)w.a<"Û">((Integer)w.a<"Û">(this.f2896, 174312564406604366L), 260981171345819427L)
                  / w.a<"B">((f2899 | 345505) + ~(f2899 & 345505) + 1 ^ 1278424176, 349057757755238323L),
               var2,
               Color.BLACK,
               226368604006499502L
            );
            w.a<"Û">(var4, 250771500943331132L);
         }

         w.a<"Û">(
            this,
            w.a<"Û">(var1, 300827487269311485L),
            (float)w.a<"Û">((Integer)w.a<"Û">(this.f2895, 174312564406604366L), 260981171345819427L),
            (float)w.a<"Û">((Integer)w.a<"Û">(this.f2896, 174312564406604366L), 260981171345819427L)
               / w.a<"B">((f2899 | 89898) + ~(f2899 & 89898) + 1 ^ 1278684923, 349057757755238323L),
            var2,
            (Color)w.a<"Û">(this.f2897, 174312564406604366L),
            226368604006499502L
         );
         w.a<"Û">(w.a<"Û">(var1, 300827487269311485L), 250771500943331132L);
      }
   }

   public void m1128(class_4587 var1, float var2, float var3, float var4, Color var5) {
      int var6 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
            136847433828789928L
         )
         / ((f2899 | 304677) + ~(f2899 & 304677) + 1 ^ 204658678);
      int var7 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
            195480914817407808L
         )
         / ((f2899 | 9796) + ~(f2899 & 9796) + 1 ^ 204887959);
      if (w.a<"B">((double)var3, 348087577662528735L) - (double)var3 != 0.0) {
         var4 += w.a<"B">((f2899 | 822015) + ~(f2899 & 822015) + 1 ^ 859503406, 349057757755238323L);
      } else {
         var6--;
         var7++;
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2888, 174312564406604366L), 354697271520518137L)) {
         C0438.m3962(var1, (float)var6 - var3, (float)var7 - var3, (float)var6 + var3, (float)var7 + var3, var5);
      }

      if (var2 != 0.0F) {
         C0438.m3962(var1, (float)var6 - var3, (float)var7 - var4 - var2, (float)var6 + var3, (float)var7 - var4, var5);
         C0438.m3962(var1, (float)var6 + var4, (float)var7 - var3, (float)var6 + var4 + var2, (float)var7 + var3, var5);
         C0438.m3962(var1, (float)var6 - var3, (float)var7 + var4, (float)var6 + var3, (float)var7 + var4 + var2, var5);
         C0438.m3962(var1, (float)var6 - var4 - var2, (float)var7 - var3, (float)var6 - var4, (float)var7 + var3, var5);
      }
   }

   public static String Hk66BgiGHgx7GOJ1UDNzGo0sn9Dc9fpg31MB8c6xLtFEVG8xoi6vKhOktYNFKiKY5rAywP0sZ8fZITIyTZZvsVxADYOW6Ze7t8VW(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
