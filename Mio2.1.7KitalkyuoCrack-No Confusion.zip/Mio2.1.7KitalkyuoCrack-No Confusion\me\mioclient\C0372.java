package me.mioclient;

import java.util.function.Predicate;

public class C0372 implements Predicate {
   public C0039 f0767;

   public C0372(C0039 var1) {
      this.f0767 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0767.f5272, 254992554122318132L);
   }
}
