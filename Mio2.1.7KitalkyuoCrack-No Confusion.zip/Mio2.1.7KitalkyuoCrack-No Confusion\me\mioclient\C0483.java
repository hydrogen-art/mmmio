package me.mioclient;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class C0483 implements ArgumentType<String>, C0045 {
   public final C1266 f0410;
   public static int f0411 = w.a<"B">(2295737992578976957L, 257832362129977838L);

   public C0483(C1266 var1) {
      this.f0410 = var1;
   }

   public String parse(StringReader var1) {
      return w.a<"Û">(var1, 269296760635713865L);
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> var1, SuggestionsBuilder var2) {
      Stream var3 = w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(w.a<"Û">(this.f0410, 359176775407045966L), 110814793610710346L),
            (Predicate<C0015>)var0 -> (boolean)(!w.a<"Û">(var0, 196897786122219351L)
                  ? (f0411 | 2412) + ~(f0411 & 2412) + 1 ^ -1711104960
                  : (f0411 | 591904) + ~(f0411 & 591904) + 1 ^ -1710514931),
            287370376266094532L
         ),
         C0997::getConfigName,
         141209812120559377L
      );
      return w.a<"B">(var3, var2, 379722968704725371L);
   }

   public static C0015<?> getOption(CommandContext<?> var0, C1266 var1, String var2) {
      String var3 = (String)w.a<"Û">(var0, var2, String.class, 275658406246533271L);
      Optional var4 = w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(w.a<"Û">(var1, 359176775407045966L), 110814793610710346L),
            (Predicate<C0015>)var1x -> w.a<"Û">(w.a<"Û">(var1x, 375063696801642121L), var3, 307662238383225114L),
            287370376266094532L
         ),
         169842024635180775L
      );
      if (w.a<"Û">(var4, 334854191428563747L)) {
         throw w.a<"Û">(
            new DynamicCommandExceptionType(
               var0x -> w.a<"B">(new C1002().m2591(w.a<"B">(var0x, 174997918119584642L)).m2593("Setting not found \u0001"), 228465064790135899L)
            ),
            var3,
            303734573678124276L
         );
      } else {
         return (C0015<?>)w.a<"Û">(var4, 145495104118328881L);
      }
   }

   public static String _PXDanSRDO8qR9Nm9x6FCuFrPHanZ1Fj6LXO84pxbW8gkGfImH1LasHWbNKSU8WAdfpMt6IeH53U4obg9tjIQmMCM4jgzARvgkbZ/* $VF was: 3PXDanSRDO8qR9Nm9x6FCuFrPHanZ1Fj6LXO84pxbW8gkGfImH1LasHWbNKSU8WAdfpMt6IeH53U4obg9tjIQmMCM4jgzARvgkbZ*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
