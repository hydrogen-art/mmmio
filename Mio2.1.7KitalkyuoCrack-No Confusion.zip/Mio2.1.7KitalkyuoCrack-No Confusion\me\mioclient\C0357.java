package me.mioclient;

import java.util.function.Predicate;

public class C0357 implements Predicate {
   public C0671 f0642;

   public C0357(C0671 var1) {
      this.f0642 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0642.f4651, 174312564406604366L) == C0672.f4559;
   }
}
