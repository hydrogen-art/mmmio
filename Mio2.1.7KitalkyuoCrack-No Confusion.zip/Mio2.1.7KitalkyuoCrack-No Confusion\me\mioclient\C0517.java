package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2172;

public final class C0517 extends C0219 {
   public static int f3370 = w.a<"B">(562943555802021295L, 257832362129977838L);

   public C0517() {
      super("pitch");
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"B">("pitch", w.a<"B">((float)(-C1074.f4547), (float)C1074.f4547, 362246925715839581L), 191188367299315725L),
            (Command)var0 -> {
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  w.a<"Û">((Float)w.a<"Û">(var0, "pitch", Float.class, 275658406246533271L), 149784643039979208L),
                  209955992115144040L
               );
               w.a<"B">(
                  w.a<"B">(
                     new C1002()
                        .m2591(w.a<"B">(w.a<"Û">(var0, "pitch", Float.class, 275658406246533271L), 174997918119584642L))
                        .m2593("Player's pitch has been set to \u0001."),
                     228465064790135899L
                  ),
                  w.a<"B">((f3370 | 772031) + ~(f3370 & 772031) + 1 ^ 91648617, 289296048454852994L),
                  241936116971186271L
               );
               return (f3370 | 332177) + ~(f3370 & 332177) + 1 ^ -91792455;
            },
            368995281709124746L
         ),
         289819728773344295L
      );
   }

   public static String _bdRLObOOoOECq4PH8mdulpOcHKxNa620FncYxThUUX6AyHCFPNILahvOkiNfFfCRSIt4b8oulU5sFtQ0SYoqmhTUhppwp0OPvUG/* $VF was: 1bdRLObOOoOECq4PH8mdulpOcHKxNa620FncYxThUUX6AyHCFPNILahvOkiNfFfCRSIt4b8oulU5sFtQ0SYoqmhTUhppwp0OPvUG*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
