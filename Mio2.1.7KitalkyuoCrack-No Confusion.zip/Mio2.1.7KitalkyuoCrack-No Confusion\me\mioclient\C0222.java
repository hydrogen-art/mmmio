package me.mioclient;

import java.util.function.Predicate;

public class C0222 implements Predicate {
   public C0396 f2862;

   public C0222(C0396 var1) {
      this.f2862 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return (w.a<"Û">(this.f2862.f0146, 174312564406604366L) == C0069.f3532 || w.a<"Û">(this.f2862.f0146, 174312564406604366L) == C0069.f3533)
         && w.a<"Û">(this.f2862.f0130, 254992554122318132L)
         && w.a<"Û">(this.f2862.f0145, 254992554122318132L);
   }
}
