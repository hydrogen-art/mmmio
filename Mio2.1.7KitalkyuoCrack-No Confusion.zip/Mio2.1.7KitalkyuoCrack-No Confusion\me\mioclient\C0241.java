package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import net.minecraft.class_642;

public class C0241 extends C1266 {
   public final C0015<Float> f0823;
   public final C0015<Boolean> f0824;
   public final C0015<Boolean> f0825;
   public final C0015<Boolean> f0826;
   public final C0015<Boolean> f0827;
   public final C0015<Boolean> f0828;
   public final C0015<Boolean> f0829;
   public final DateTimeFormatter f0830;
   public final List<String> f0831;
   public final List<String> f0832;
   public final C0083 f0833;
   public String f0834;
   public class_642 f0835;
   public static int f0836 = w.a<"B">(746897583608038709L, 257832362129977838L);

   public C0241() {
      super("DiscordNotifs", "Sends chat messages to your Discord webhook.", C1045.f3173);
      w.a<"B">(this, 242859112966675773L);
      this.f0830 = w.a<"B">("HH:mm", 170850873617789405L);
      this.f0831 = w.a<"B">(new ArrayList(), 291435362423732219L);
      this.f0832 = new ArrayList<>();
      this.f0833 = new C0083();
   }

   @Override
   public void onEnable() {
      w.a<"Û">(this.f0833, 387780412884547639L);
      if (w.a<"Û">(C0933.f1435, 291250801921422195L) == null || w.a<"Û">(w.a<"Û">(C0933.f1435, 291250801921422195L), 226515538076917205L)) {
         String var1 = w.a<"B">(178229868054081660L);
         String var2 = new C1002().m2591(var1).m2593("\u0001webhook set <url>");
         w.a<"B">(
            w.a<"Û">(
               w.a<"Û">(w.a<"B">("You don't have a webhook URL set. Set one by typing \"", 228465064790135899L), var2, 194629304146735395L),
               "\".",
               194629304146735395L
            ),
            w.a<"B">((f0836 | 35821) + ~(f0836 & 35821) + 1 ^ 221625173, 289296048454852994L),
            C0639.f3881,
            211469761772001922L
         );
      }
   }

   @C1027
   public void m2448(C0330 var1) {
      if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687 != null) {
         this.f0835 = w.a<"Û">(C0933.f1416, 249252991026173401L);
      }

      if (w.a<"Û">(C0933.f1435, 291250801921422195L) != null && !w.a<"Û">(w.a<"Û">(C0933.f1435, 291250801921422195L), 226515538076917205L)) {
         if (w.a<"Û">(
               this.f0833, (double)w.a<"Û">((Float)w.a<"Û">(this.f0823, 174312564406604366L), 149784643039979208L), TimeUnit.SECONDS, 215737872562411156L
            )
            && !w.a<"Û">(this.f0831, 284469716622774448L)) {
            w.a<"Û">(this.f0833, 387780412884547639L);
            synchronized (this.f0831) {
               StringBuilder var3 = new StringBuilder();
               LocalDateTime var4 = w.a<"B">(348833448534811669L);
               Object[] var10001 = new Object[(f0836 | 556867) + ~(f0836 & 556867) + 1 ^ -222127969];
               var10001[(f0836 | 226964) + ~(f0836 & 226964) + 1 ^ -221671095] = w.a<"Û">(this.f0830, var4, 254588015435115948L);
               String var5 = w.a<"Û">("[%s] ", var10001, 259257223839993282L);
               Iterator var6 = w.a<"Û">(this.f0831, 341496865259068134L);

               while (w.a<"Û">(var6, 333900474771661065L)) {
                  String var7 = (String)w.a<"Û">(var6, 192468336863492695L);
                  if (w.a<"Û">(var3, 154295658723187557L) > ((f0836 | 615433) + ~(f0836 & 615433) + 1 ^ -222067528)) {
                     break;
                  }

                  if (w.a<"Û">((Boolean)w.a<"Û">(this.f0824, 174312564406604366L), 354697271520518137L)) {
                     w.a<"Û">(var3, var5, 150545021362368941L);
                  }

                  w.a<"Û">(var3, var7, 150545021362368941L);
                  w.a<"Û">(var3, "\n", 150545021362368941L);
                  w.a<"Û">(this.f0832, var7, 276802003864609490L);
               }

               String var11 = w.a<"Û">(var3, 167209770867625114L);
               String var12 = w.a<"Û">(
                  var11,
                  (f0836 | 639182) + ~(f0836 & 639182) + 1 ^ -222091501,
                  w.a<"Û">(var11, 120891947504160641L) - ((f0836 | 938703) + ~(f0836 & 938703) + 1 ^ -221989613),
                  145614115509746641L
               );
               C0091 var10000 = C0933.f1435;
               Object[] var10002 = new Object[(f0836 | 502153) + ~(f0836 & 502153) + 1 ^ -221426091];
               var10002[(f0836 | 207718) + ~(f0836 & 207718) + 1 ^ -221655877] = var12;
               w.a<"Û">(var10000, w.a<"Û">("```%s```", var10002, 259257223839993282L), 238747913687799063L);
               Iterator var13 = w.a<"Û">(this.f0832, 341496865259068134L);

               while (w.a<"Û">(var13, 333900474771661065L)) {
                  String var8 = (String)w.a<"Û">(var13, 192468336863492695L);
                  w.a<"Û">(this.f0831, var8, 168530247599193607L);
               }

               w.a<"Û">(this.f0832, 140901994866995976L);
            }
         }
      }
   }

   @C1027
   public void m2449(C0750 var1) {
      if (!w.a<"Û">(var1, 228050418011231981L)) {
         if (w.a<"Û">(C0933.f1435, 291250801921422195L) != null && !w.a<"Û">(w.a<"Û">(C0933.f1435, 291250801921422195L), 226515538076917205L)) {
            if (w.a<"Û">(var1, 318720623556278375L) == C0277.f4214 && w.a<"Û">(var1, 264195975804836073L) != null) {
               if (w.a<"Û">((Boolean)w.a<"Û">(this.f0829, 174312564406604366L), 354697271520518137L) && w.a<"Û">(var1, 386356504964951090L) == C0638.f2944) {
                  return;
               }

               String var2 = w.a<"Û">(var1, 264195975804836073L);
               String[] var3 = w.a<"Û">(var2, "\n", 369825978071233340L);
               boolean var4 = w.a<"B">(var2, 157835969717632611L);
               boolean var5 = w.a<"B">(var2, 166984774749945890L);
               if (!var4 && !var5) {
                  if (w.a<"Û">(var2, "Position in queue:", 160084314699716367L) && var3.length > ((f0836 | 784326) + ~(f0836 & 784326) + 1 ^ -222228460)) {
                     if (this.f0834 == null) {
                        this.f0834 = var2;
                     } else {
                        if (this.f0834.equals(var2)) {
                           return;
                        }

                        if (w.a<"Û">((Boolean)w.a<"Û">(this.f0825, 174312564406604366L), 354697271520518137L)) {
                           w.a<"Û">(this, var3, 386105273846119319L);
                           this.f0834 = var2;
                        }
                     }
                  } else if (w.a<"Û">((Boolean)w.a<"Û">(this.f0828, 174312564406604366L), 354697271520518137L)) {
                     w.a<"Û">(this, var3, 386105273846119319L);
                  }
               } else if (w.a<"Û">((Boolean)w.a<"Û">(this.f0827, 174312564406604366L), 354697271520518137L)) {
                  w.a<"Û">(this, var3, 386105273846119319L);
               }
            }
         }
      }
   }

   @C1027
   public void m2450(C0190 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0826, 174312564406604366L), 354697271520518137L) && this.f0835 != null) {
         Object[] var10001 = new Object[(f0836 | 133248) + ~(f0836 & 133248) + 1 ^ -221712548];
         var10001[(f0836 | 114287) + ~(f0836 & 114287) + 1 ^ -221554254] = this.f0835.field_3761;
         String var2 = w.a<"Û">("You have been disconnected from %s!", var10001, 259257223839993282L);
         String[] var3 = w.a<"Û">(var2, "\n", 369825978071233340L);
         w.a<"Û">(this, var3, 386105273846119319L);
         this.f0835 = null;
      }
   }

   public void m2451(String[] var1) {
      StringBuilder var2 = new StringBuilder();
      String[] var3 = var1;
      int var4 = var1.length;

      for (int var5 = (f0836 | 21158) + ~(f0836 & 21158) + 1 ^ -221596293; var5 < var4; var5++) {
         String var6 = var3[var5];
         if (!w.a<"Û">(var6, 226515538076917205L)) {
            w.a<"Û">(var2, w.a<"B">(var6, 222815525246781378L), 150545021362368941L);
            w.a<"Û">(var2, "\n", 150545021362368941L);
         }
      }

      String var7 = w.a<"Û">(var2, 167209770867625114L);
      if (w.a<"Û">(var7, 120891947504160641L) >= ((f0836 | 324277) + ~(f0836 & 324277) + 1 ^ -221375126)) {
         String var8 = w.a<"Û">(
            var7,
            (f0836 | 301614) + ~(f0836 & 301614) + 1 ^ -221348365,
            w.a<"Û">(var7, 120891947504160641L) - ((f0836 | 230824) + ~(f0836 & 230824) + 1 ^ -221683084),
            145614115509746641L
         );
         w.a<"Û">(this.f0831, var8, 276802003864609490L);
      }
   }

   public static String mpqyGSeLLs1Ja8m6Ua1rxcrpUEiuiV3XnYiPPryRTmqZlaWCPRGbFFRQVmlsvuadHT9VK0b6fLytiyf8iWm2pU6gLxbogBgHUBKn(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
