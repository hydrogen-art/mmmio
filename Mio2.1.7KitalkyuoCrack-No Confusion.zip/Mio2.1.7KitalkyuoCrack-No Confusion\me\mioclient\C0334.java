package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1294;

public class C0334 extends C1266 {
   public static int f0775 = w.a<"B">(1019707671657518882L, 257832362129977838L);

   public C0334() {
      super("AntiLevitation", "Cancels certain effects that can make you levitate.", C1045.f3177);
   }

   @C1027
   public void m2427(C0325 var1) {
      if (w.a<"Û">(var1, 137223212027576899L) == class_1294.field_5906 || w.a<"Û">(var1, 137223212027576899L) == class_1294.field_5902) {
         w.a<"Û">(var1, 385440235371820560L);
      }
   }

   public static String CUkqg8cEBQoixy4RCfvog0YBxz5RHgxIwMj6uWxOvmCcFNpJ6LOTryC7l3JAUWnqsR3y5YKUnyoRyXPWLJcSTlg5QENfbWr63HLa(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
