package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2561;

enum C0200 implements C0196 {
   f4051("Name") {
      @Override
      public class_2561 m0402(C0199 var1) {
         return w.a<"B">("Hello " + w.a<"Û">(w.a<"Û">(C0045.f2103.field_1724, 325699207128272228L), 286788181028845103L) + " :')", 228465064790135899L);
      }
   },
   f4052("UID") {
      @Override
      public class_2561 m0402(C0199 var1) {
         return w.a<"B">("Hello uid" + w.a<"Û">(C0933.f1423, 215809475655423530L) + " :')", 228465064790135899L);
      }
   },
   f4053("Custom") {
      @Override
      public class_2561 m0402(C0199 var1) {
         return w.a<"B">((String)w.a<"Û">(var1.f3187, 174312564406604366L), 228465064790135899L);
      }
   };

   public final String f4054;

   public C0200(String var3) {
      this.f4054 = var3;
   }

   @Override
   public String getName() {
      return this.f4054;
   }

   public class_2561 m0402(C0199 var1) {
      return null;
   }

   public static String POujdxZbieotGlpdLpUAYlMpxnXvZsuE2CAJXGckNclMZKOq6OqNimXlHT2nGvBSCLIfisiuBQzrbSVQ5FkG0ssw5eWZ8JUPBSoM(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
