package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;
import net.minecraft.class_2558.class_2559;
import net.minecraft.class_2568.class_5247;
import org.jetbrains.annotations.NotNull;

public final class C0356 extends C0219 {
   public final C1266 f0060;
   public static int f0061 = w.a<"B">(4181731734979130253L, 257832362129977838L);

   public C0356(C1266 var1) {
      super(var1.getName());
      this.f0060 = var1;
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      LiteralArgumentBuilder var10000 = (LiteralArgumentBuilder)w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"Û">(
               w.a<"B">("state", w.a<"B">(220219768860453495L), 191188367299315725L),
               (SuggestionProvider)(var0, var1x) -> w.a<"Û">(var1x, 135487642270960168L),
               357832626693996259L
            ),
            (Command)var1x -> {
               w.a<"Û">(this.f0060, w.a<"Û">((Boolean)w.a<"Û">(var1x, "state", Boolean.class, 275658406246533271L), 354697271520518137L), 116379243843723603L);
               return (f0061 | 490501) + ~(f0061 & 490501) + 1 ^ 995053173;
            },
            368995281709124746L
         ),
         289819728773344295L
      );
      RequiredArgumentBuilder var10001 = w.a<"B">("setting", new C0483(this.f0060), 191188367299315725L);
      String[] var10002 = new String[(f0061 | 981129) + ~(f0061 & 981129) + 1 ^ 994495225];
      var10002[(f0061 | 815750) + ~(f0061 & 815750) + 1 ^ 994328823] = "clear";
      w.a<"Û">(
         (LiteralArgumentBuilder)w.a<"Û">(
            (LiteralArgumentBuilder)w.a<"Û">(
               var10000,
               w.a<"Û">(
                  (RequiredArgumentBuilder)w.a<"Û">(
                     (RequiredArgumentBuilder)w.a<"Û">(
                        (RequiredArgumentBuilder)w.a<"Û">(
                           var10001,
                           w.a<"Û">(
                              w.a<"Û">(w.a<"B">(var10002, 188216523544133420L), this::m0086, 357832626693996259L),
                              (Command)var1x -> {
                                 C0015 var2 = w.a<"B">(var1x, this.f0060, "setting", 314625662720342166L);
                                 if (var2 instanceof C0298 var3) {
                                    w.a<"Û">((Set)w.a<"Û">(var3, 174312564406604366L), 259971657844247781L);
                                    w.a<"B">(
                                       w.a<"Û">(
                                          w.a<"Û">(
                                             w.a<"B">(w.a<"Û">(this.f0060, 248211090350577353L), 228465064790135899L),
                                             w.a<"Û">(
                                                w.a<"Û">(w.a<"B">(" ", 228465064790135899L), w.a<"Û">(var2, 248211090350577353L), 194629304146735395L),
                                                (UnaryOperator)var0 -> w.a<"Û">(var0, class_124.field_1080, 152778664851569676L),
                                                165931758622126162L
                                             ),
                                             267862536496645581L
                                          ),
                                          ": Cleared",
                                          194629304146735395L
                                       ),
                                       w.a<"B">(this.f0060, 314838320576798960L),
                                       C0639.f3882,
                                       211469761772001922L
                                    );
                                 }

                                 return (f0061 | 257504) + ~(f0061 & 257504) + 1 ^ 994828176;
                              },
                              368995281709124746L
                           ),
                           364326416200407929L
                        ),
                        w.a<"Û">(
                           w.a<"B">("value", new C0247(this.f0060, "setting"), 191188367299315725L),
                           (Command)var1x -> {
                              C0015 var2 = w.a<"B">(var1x, this.f0060, "setting", 314625662720342166L);
                              String var3 = (String)w.a<"Û">(var1x, "value", String.class, 275658406246533271L);

                              try {
                                 class_124 var4 = null;
                                 if (var2 instanceof C0275 var5) {
                                    C0832 var6 = w.a<"B">(w.a<"Û">(var5, 136685182057298513L), 277528539100350036L);
                                    Collection var7 = w.a<"Û">(var6, var3, 331360546766490530L);
                                    if (!w.a<"Û">(var7, 288981848775625970L)) {
                                       Stream var10000x = w.a<"Û">(var7, 366567241942811964L);
                                       w.a<"B">(var5, 131918113315390561L);
                                       if (w.a<"Û">(var10000x, var5::m3956, 342868315342270588L)) {
                                          w.a<"B">(var5, 131918113315390561L);
                                          w.a<"Û">(var7, var5::m3954, 137048598233213028L);
                                          var4 = class_124.field_1061;
                                       } else {
                                          w.a<"B">(var5, 131918113315390561L);
                                          w.a<"Û">(var7, var5::m3952, 137048598233213028L);
                                          var4 = class_124.field_1060;
                                       }
                                    }
                                 }

                                 if (var4 == null) {
                                    w.a<"Û">(var2, var3, 327160169598874492L);
                                 }

                                 Object var9 = w.a<"Û">(this, var2, 161746709809054403L);
                                 if (var2 instanceof C0298 var10) {
                                    if (var4 == null) {
                                       var4 = w.a<"Û">(var10, var3, 331436881107486694L) ? class_124.field_1060 : class_124.field_1061;
                                    }

                                    class_124 var11 = var4;
                                    var9 = w.a<"Û">(
                                       w.a<"B">(var3, 228465064790135899L),
                                       (UnaryOperator)var1xx -> w.a<"Û">(var1xx, var11, 152778664851569676L),
                                       165931758622126162L
                                    );
                                 }

                                 w.a<"B">(
                                    w.a<"Û">(
                                       w.a<"Û">(
                                          w.a<"Û">(
                                             w.a<"B">(w.a<"Û">(this.f0060, 248211090350577353L), 228465064790135899L),
                                             w.a<"Û">(
                                                w.a<"Û">(w.a<"B">(" ", 228465064790135899L), w.a<"Û">(var2, 248211090350577353L), 194629304146735395L),
                                                (UnaryOperator)var0 -> w.a<"Û">(var0, class_124.field_1080, 152778664851569676L),
                                                165931758622126162L
                                             ),
                                             267862536496645581L
                                          ),
                                          ": ",
                                          194629304146735395L
                                       ),
                                       var9,
                                       267862536496645581L
                                    ),
                                    w.a<"B">(this.f0060, 314838320576798960L),
                                    C0639.f3882,
                                    211469761772001922L
                                 );
                              } catch (Throwable var8) {
                                 w.a<"B">(
                                    w.a<"Û">(w.a<"B">("Invalid value: ", 228465064790135899L), var3, 194629304146735395L),
                                    w.a<"B">(this.f0060, 314838320576798960L),
                                    C0639.f3880,
                                    211469761772001922L
                                 );
                              }

                              return (f0061 | 878649) + ~(f0061 & 878649) + 1 ^ 994400841;
                           },
                           368995281709124746L
                        ),
                        364326416200407929L
                     ),
                     w.a<"Û">(w.a<"B">("reset", 233839479830701924L), (Command)var1x -> {
                        C0015 var2 = w.a<"B">(var1x, this.f0060, "setting", 314625662720342166L);
                        w.a<"Û">(var2, 242624335741210544L);
                        return (f0061 | 96510) + ~(f0061 & 96510) + 1 ^ 994658958;
                     }, 286944572020109927L),
                     364326416200407929L
                  ),
                  (Command)var1x -> {
                     C0015 var2 = w.a<"B">(var1x, this.f0060, "setting", 314625662720342166L);
                     w.a<"B">(
                        w.a<"Û">(
                           w.a<"Û">(
                              w.a<"Û">(
                                 w.a<"B">(w.a<"Û">(this.f0060, 248211090350577353L), 228465064790135899L),
                                 w.a<"Û">(
                                    w.a<"Û">(w.a<"B">(" ", 228465064790135899L), w.a<"Û">(var2, 248211090350577353L), 194629304146735395L),
                                    (UnaryOperator)var0 -> w.a<"Û">(var0, class_124.field_1080, 152778664851569676L),
                                    165931758622126162L
                                 ),
                                 267862536496645581L
                              ),
                              ": ",
                              194629304146735395L
                           ),
                           w.a<"Û">(this, var2, 161746709809054403L),
                           267862536496645581L
                        ),
                        w.a<"B">(this.f0060, 314838320576798960L),
                        241936116971186271L
                     );
                     return (f0061 | 450596) + ~(f0061 & 450596) + 1 ^ 995021396;
                  },
                  368995281709124746L
               ),
               289819728773344295L
            ),
            w.a<"Û">(
               (LiteralArgumentBuilder)w.a<"Û">(
                  w.a<"B">("Enabled", 233839479830701924L), w.a<"Û">(w.a<"B">("state", w.a<"B">(220219768860453495L), 191188367299315725L), (Command)var1x -> {
                     w.a<"Û">(
                        this.f0060, w.a<"Û">((Boolean)w.a<"Û">(var1x, "state", Boolean.class, 275658406246533271L), 354697271520518137L), 116379243843723603L
                     );
                     return (f0061 | 548156) + ~(f0061 & 548156) + 1 ^ 994078540;
                  }, 368995281709124746L), 289819728773344295L
               ),
               (Command)var1x -> {
                  w.a<"B">(
                     w.a<"Û">(
                        w.a<"Û">(
                           w.a<"Û">(
                              w.a<"B">("Module ", 228465064790135899L),
                              w.a<"Û">(
                                 w.a<"B">(w.a<"Û">(this.f0060, 248211090350577353L), 228465064790135899L),
                                 (UnaryOperator)var0 -> w.a<"Û">(var0, class_124.field_1080, 152778664851569676L),
                                 165931758622126162L
                              ),
                              267862536496645581L
                           ),
                           " is ",
                           194629304146735395L
                        ),
                        w.a<"Û">(
                           w.a<"B">(w.a<"Û">(this.f0060, 314537768572362865L) ? "enabled" : "disabled", 228465064790135899L),
                           (UnaryOperator)var1xx -> w.a<"Û">(this.f0060, 314537768572362865L)
                                 ? w.a<"Û">(var1xx, class_124.field_1060, 152778664851569676L)
                                 : w.a<"Û">(var1xx, class_124.field_1061, 152778664851569676L),
                           165931758622126162L
                        ),
                        267862536496645581L
                     ),
                     w.a<"B">(this.f0060, 314838320576798960L),
                     241936116971186271L
                  );
                  return (f0061 | 401525) + ~(f0061 & 401525) + 1 ^ 994972165;
               },
               286944572020109927L
            ),
            289819728773344295L
         ),
         (Command)var1x -> {
            class_5250 var2 = w.a<"B">(151712998973257886L);
            class_5250 var3 = w.a<"Û">(this, 290200604654090454L);
            class_5250 var10000x = w.a<"Û">(var2, var3, 267862536496645581L);
            Object[] var10002x = new Object[(f0061 | 849779) + ~(f0061 & 849779) + 1 ^ 994362624];
            var10002x[(f0061 | 733281) + ~(f0061 & 733281) + 1 ^ 994247184] = w.a<"Û">(w.a<"Û">(this.f0060, 299774196298174789L), 338391653860412648L);
            var10002x[(f0061 | 38693) + ~(f0061 & 38693) + 1 ^ 994616661] = w.a<"Û">(
               w.a<"Û">(w.a<"Û">(this.f0060, 299774196298174789L), 298459350812887843L), 148386175155036532L
            );
            w.a<"Û">(var10000x, w.a<"Û">(" [%s - %s]", var10002x, 259257223839993282L), 194629304146735395L);
            Iterator var4 = w.a<"Û">(w.a<"Û">(this.f0060, 359176775407045966L), 341496865259068134L);

            while (w.a<"Û">(var4, 333900474771661065L)) {
               Object var5 = (C0015)w.a<"Û">(var4, 192468336863492695L);
               class_5250 var6 = w.a<"B">(new C1002().m2591(w.a<"Û">(var5, 248211090350577353L)).m2593("\n\u0001: "), 228465064790135899L);
               w.a<"B">(var5, 131918113315390561L);
               switch (var5) {
                  case C0495 var9:
                     w.a<"Û">(
                        var6,
                        w.a<"Û">(
                           w.a<"B">(C0498.m3882(w.a<"Û">((Enum)w.a<"Û">(var9, 174312564406604366L), 235224272799028434L)), 228465064790135899L),
                           class_124.field_1080,
                           173336747796326302L
                        ),
                        267862536496645581L
                     );
                     break;
                  case C0298 var10:
                     w.a<"Û">(
                        var6,
                        w.a<"Û">(
                           w.a<"B">(w.a<"B">(", ", w.a<"Û">(var10, 132767236493521372L), 287659237527975893L), 228465064790135899L),
                           class_124.field_1080,
                           173336747796326302L
                        ),
                        267862536496645581L
                     );
                     break;
                  case C1118 var11:
                     String var12 = w.a<"Û">(this, var11, 152291890118418881L);
                     w.a<"Û">(
                        var6,
                        w.a<"Û">(
                           w.a<"B">(var12, 228465064790135899L),
                           (UnaryOperator)var1xx -> w.a<"Û">(var1xx, w.a<"Û">(w.a<"Û">(var11, 316482330801136200L), 301840407077149108L), 349393047474482868L),
                           165931758622126162L
                        ),
                        267862536496645581L
                     );
                     break;
                  default:
                     w.a<"Û">(
                        var6,
                        w.a<"Û">(
                           w.a<"B">(w.a<"Û">(w.a<"Û">(var5, 174312564406604366L), 232385667124573302L), 228465064790135899L),
                           class_124.field_1080,
                           173336747796326302L
                        ),
                        267862536496645581L
                     );
               }

               String var7 = new C1002()
                  .m2591(w.a<"Û">(var5, 248211090350577353L))
                  .m2591(w.a<"Û">(w.a<"Û">(this.f0060, 248211090350577353L), 308826267231227763L))
                  .m2591(w.a<"B">(178229868054081660L))
                  .m2593("\u0001\u0001 \u0001 ");
               w.a<"Û">(var6, (UnaryOperator)var1xx -> w.a<"Û">(var1xx, new class_2558(class_2559.field_11745, var7), 291578796023597487L), 165931758622126162L);
               w.a<"Û">(var2, var6, 267862536496645581L);
            }

            w.a<"B">(var2, w.a<"B">((f0061 | 989212) + ~(f0061 & 989212) + 1 ^ -994519662, 289296048454852994L), 241936116971186271L);
            return (f0061 | 955801) + ~(f0061 & 955801) + 1 ^ 994486249;
         },
         286944572020109927L
      );
      w.a<"Û">(var1, w.a<"Û">(w.a<"B">("reset", 233839479830701924L), (Command)var1x -> {
         Iterator var2 = w.a<"Û">(w.a<"Û">(this.f0060, 359176775407045966L), 341496865259068134L);

         while (w.a<"Û">(var2, 333900474771661065L)) {
            C0015 var3 = (C0015)w.a<"Û">(var2, 192468336863492695L);
            w.a<"Û">(var3, 242624335741210544L);
         }

         return (f0061 | 715274) + ~(f0061 & 715274) + 1 ^ 994236538;
      }, 286944572020109927L), 289819728773344295L);
   }

   @NotNull
   public class_5250 m0084() {
      class_5250 var1 = w.a<"B">(w.a<"Û">(this.f0060, 248211090350577353L), 228465064790135899L);
      w.a<"Û">(
         var1,
         (UnaryOperator)var1x -> w.a<"B">(
               var1x,
               (Supplier<Integer>)() -> w.a<"Û">(this.f0060, 314537768572362865L)
                     ? w.a<"Û">(class_124.field_1060, 374429673714334308L)
                     : w.a<"Û">(class_124.field_1061, 374429673714334308L),
               154649488180116735L
            ),
         165931758622126162L
      );
      w.a<"Û">(
         var1,
         (UnaryOperator)var1x -> w.a<"Û">(
               var1x,
               new class_2568(
                  class_5247.field_24342,
                  w.a<"B">(
                     w.a<"Û">(w.a<"Û">(this.f0060, 315277626289820950L), "\n", 369825978071233340L)[(f0061 | 912890) + ~(f0061 & 912890) + 1 ^ 994434955],
                     228465064790135899L
                  )
               ),
               120979910123777007L
            ),
         165931758622126162L
      );
      w.a<"Û">(
         var1,
         (UnaryOperator)var1x -> w.a<"Û">(
               var1x,
               new class_2558(
                  class_2559.field_11750,
                  new C1002().m2591(w.a<"Û">(this.f0060, 248211090350577353L)).m2591(w.a<"B">(178229868054081660L)).m2593("\u0001toggle \u0001")
               ),
               291578796023597487L
            ),
         165931758622126162L
      );
      return var1;
   }

   public String m0085(C1118 var1) {
      Color var2 = w.a<"Û">(var1, 316482330801136200L);
      if (var1.m$$1dsgj6mh2JF3oQ8y6fs9VC16hJnzMbRawWoHtr7gyovTbQJi9O4MUgfwNZd8A5RSlbt8cJtDSDaRJEAuudGrdochAwQdSi4RT) {
         Object[] var3 = new Object[(f0061 | 38129) + ~(f0061 & 38129) + 1 ^ 994616963];
         var3[(f0061 | 192528) + ~(f0061 & 192528) + 1 ^ 994755169] = w.a<"B">(w.a<"Û">(var2, 239609820066095028L), 367942141483020029L);
         var3[(f0061 | 933143) + ~(f0061 & 933143) + 1 ^ 994447207] = w.a<"B">(w.a<"Û">(var2, 340797987757289690L), 367942141483020029L);
         var3[(f0061 | 122393) + ~(f0061 & 122393) + 1 ^ 994700394] = w.a<"B">(w.a<"Û">(var2, 212499208735578764L), 367942141483020029L);
         return w.a<"Û">("rgb(%d, %d, %d)", var3, 259257223839993282L);
      } else {
         Object[] var10001 = new Object[(f0061 | 304978) + ~(f0061 & 304978) + 1 ^ 994874663];
         var10001[(f0061 | 323576) + ~(f0061 & 323576) + 1 ^ 994893193] = w.a<"B">(w.a<"Û">(var2, 239609820066095028L), 367942141483020029L);
         var10001[(f0061 | 619668) + ~(f0061 & 619668) + 1 ^ 994133732] = w.a<"B">(w.a<"Û">(var2, 340797987757289690L), 367942141483020029L);
         var10001[(f0061 | 315151) + ~(f0061 & 315151) + 1 ^ 994901372] = w.a<"B">(w.a<"Û">(var2, 212499208735578764L), 367942141483020029L);
         var10001[(f0061 | 742174) + ~(f0061 & 742174) + 1 ^ 994271596] = w.a<"B">(w.a<"Û">(var2, 245270953955453918L), 367942141483020029L);
         return w.a<"Û">("rgba(%d, %d, %d, %d)", var10001, 259257223839993282L);
      }
   }

   public CompletableFuture<Suggestions> m0086(CommandContext<?> var1, SuggestionsBuilder var2) {
      try {
         C0015 var3 = w.a<"B">(var1, this.f0060, "setting", 314625662720342166L);
         if (var3 instanceof C0298) {
            String[] var10000 = new String[(f0061 | 977908) + ~(f0061 & 977908) + 1 ^ 994498948];
            var10000[(f0061 | 108592) + ~(f0061 & 108592) + 1 ^ 994679361] = "clear";
            return w.a<"B">(var10000, var2, 248134377526489165L);
         }
      } catch (CommandSyntaxException var4) {
      }

      return w.a<"B">(189209840766080016L);
   }

   public class_2561 m0087(C0015<?> var1) {
      class_5250 var2 = w.a<"B">(w.a<"Û">(w.a<"Û">(var1, 174312564406604366L), 232385667124573302L), 228465064790135899L);
      if (var1 instanceof C1118 var3) {
         var2 = w.a<"Û">(
            w.a<"B">(C0152.m3483(w.a<"Û">(var3, 316482330801136200L), (boolean)((f0061 | 492811) + ~(f0061 & 492811) + 1 ^ 995080059)), 228465064790135899L),
            (UnaryOperator)var1x -> w.a<"Û">(var1x, w.a<"Û">(var1, 174312564406604366L).hashCode(), 349393047474482868L),
            165931758622126162L
         );
      } else if (var1 instanceof C0298 var4) {
         var2 = w.a<"B">(
            w.a<"Û">(var4, 132767236493521372L),
            w.a<"Û">(w.a<"B">(", ", 228465064790135899L), (UnaryOperator)var0 -> w.a<"Û">(var0, class_124.field_1080, 152778664851569676L), 165931758622126162L),
            class_2561::method_43470,
            353443470837538032L
         );
      } else if (var1 instanceof C0011 var5) {
         var2 = w.a<"B">(w.a<"Û">((C1348)w.a<"Û">(var5, 174312564406604366L), 380852241946877156L), 228465064790135899L);
      }

      return var2;
   }

   public static String y42a7SPq56yHY0mfYHAbmOMekf0YfyYtwz0IiQ3OQGPRzhAitWDzeR6SBzNeiSYwS4eDDbADmjxPE1q2MSnoeFMQt1iYgO8ZoHDT(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
