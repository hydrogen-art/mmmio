package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_2215;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2323;
import net.minecraft.class_2478;
import net.minecraft.class_2480;
import net.minecraft.class_2482;
import net.minecraft.class_2504;
import net.minecraft.class_2506;
import net.minecraft.class_2577;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_6880.class_6883;

public class C0322 implements C0832 {
   public static final Map<String, List<String>> f2652 = new HashMap<>();
   public static int f2653 = w.a<"B">(2497050075753807136L, 257832362129977838L);

   @Override
   public Collection<String> m0356(String var1) {
      return (Collection<String>)w.a<"Û">(f2652, w.a<"Û">(var1, 308826267231227763L), w.a<"B">(213923925692950600L), 183430545168542698L);
   }

   @Override
   public Collection<String> m0357() {
      return w.a<"Û">(f2652, 344909330910693100L);
   }

   @Override
   public class_2960 m0358() {
      return w.a<"Û">(class_7924.field_41254, 144891116350603214L);
   }

   public static void m1022(String var0, Stream<class_2248> var1) {
      w.a<"Û">(f2652, var0, w.a<"Û">(w.a<"Û">(var1, C0322::m1023, 141209812120559377L), 325049488880240942L), 121875332790264405L);
   }

   public static String m1023(class_2248 var0) {
      return w.a<"Û">(w.a<"Û">(class_7923.field_41175, var0, 300784992733413080L), 278176929127734773L);
   }

   static {
      w.a<"B">(
         "beds",
         w.a<"Û">(w.a<"Û">(class_7923.field_41175, 321331281766202645L), (Predicate<class_2248>)var0 -> var0 instanceof class_2244, 287370376266094532L),
         284849556324003158L
      );
      w.a<"B">(
         "banners",
         w.a<"Û">(w.a<"Û">(class_7923.field_41175, 321331281766202645L), (Predicate<class_2248>)var0 -> var0 instanceof class_2215, 287370376266094532L),
         284849556324003158L
      );
      w.a<"B">(
         "doors",
         w.a<"Û">(w.a<"Û">(class_7923.field_41175, 321331281766202645L), (Predicate<class_2248>)var0 -> var0 instanceof class_2323, 287370376266094532L),
         284849556324003158L
      );
      w.a<"B">(
         "slabs",
         w.a<"Û">(w.a<"Û">(class_7923.field_41175, 321331281766202645L), (Predicate<class_2248>)var0 -> var0 instanceof class_2482, 287370376266094532L),
         284849556324003158L
      );
      w.a<"B">(
         "shulkers",
         w.a<"Û">(w.a<"Û">(class_7923.field_41175, 321331281766202645L), (Predicate<class_2248>)var0 -> var0 instanceof class_2480, 287370376266094532L),
         284849556324003158L
      );
      w.a<"B">(
         "carpets",
         w.a<"Û">(w.a<"Û">(class_7923.field_41175, 321331281766202645L), (Predicate<class_2248>)var0 -> var0 instanceof class_2577, 287370376266094532L),
         284849556324003158L
      );
      w.a<"B">(
         "glasses",
         w.a<"Û">(
            w.a<"Û">(class_7923.field_41175, 321331281766202645L),
            (Predicate<class_2248>)var0 -> (boolean)(!(var0 instanceof class_2506) && var0 != class_2246.field_10033
                  ? (f2653 | 794504) + ~(f2653 & 794504) + 1 ^ 660058263
                  : (f2653 | 464866) + ~(f2653 & 464866) + 1 ^ 660388092),
            287370376266094532L
         ),
         284849556324003158L
      );
      w.a<"B">(
         "glass_panes",
         w.a<"Û">(
            w.a<"Û">(class_7923.field_41175, 321331281766202645L),
            (Predicate<class_2248>)var0 -> (boolean)(!(var0 instanceof class_2504) && var0 != class_2246.field_10285
                  ? (f2653 | 529580) + ~(f2653 & 529580) + 1 ^ 659798963
                  : (f2653 | 688624) + ~(f2653 & 688624) + 1 ^ 659631854),
            287370376266094532L
         ),
         284849556324003158L
      );
      w.a<"B">(
         "signs",
         w.a<"Û">(w.a<"Û">(class_7923.field_41175, 321331281766202645L), (Predicate<class_2248>)var0 -> var0 instanceof class_2478, 287370376266094532L),
         284849556324003158L
      );
      w.a<"B">(
         "ores",
         w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(class_7923.field_41175, 303680887452795752L),
               (Predicate<class_6883>)var0 -> w.a<"Û">(
                     var0,
                     (Predicate<class_5321>)var0x -> w.a<"Û">(w.a<"Û">(w.a<"Û">(var0x, 144891116350603214L), 228759726252330260L), "ore", 160084314699716367L),
                     212152111123195709L
                  ),
               287370376266094532L
            ),
            class_6883::comp_349,
            141209812120559377L
         ),
         284849556324003158L
      );
   }

   public static String x4jOutbR44P81samNhzy93dCa7VS3ucHPlpcZRrCESA7NOahEKyokqgOzfp5WnapZHiaNQ7wsGgzjXYP6dEvwnk4fmoVF1EqMmbA(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
