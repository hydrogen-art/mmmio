package me.mioclient;

public class C0437 extends C1180 {
   public final C0277 f2319;

   public C0437(C0277 var1) {
      this.f2319 = var1;
   }

   public C0277 m0949() {
      return this.f2319;
   }
}
