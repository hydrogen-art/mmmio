package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Predicate;
import me.mioclient.mixin.ducks.DuckHandledScreen;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.class_1703;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1733;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_476;
import net.minecraft.class_495;
import net.minecraft.class_9323;

public class C0124 extends C1266 {
   public static C1332 f3113 = C0933.f1409.m2696(C1332.class);
   public final C0015<Set<class_1792>> f3114;
   public final C0015<Set<String>> f3115;
   public final C0015<C0367> f3116;
   public final C0015<C0040> f3117;
   public final C0015<C0830> f3118;
   public final C0015<Boolean> f3119;
   public final C0015<Boolean> f3120;
   public final C0015<Boolean> f3121;
   public final C0015<Boolean> f3122;
   public final C0015<Integer> f3123;
   public final C0015<Integer> f3124;
   public final C0015<Integer> f3125;
   public final List<C0913> f3126;
   public final C0083 f3127;
   public final C0083 f3128;
   public C0367 f3129;
   public boolean f3130;
   public class_1735 f3131;
   public static int f3133 = w.a<"B">(1301173436787423441L, 257832362129977838L);

   public C0124() {
      C1045 var10003 = C1045.f3176;
      String[] var10004 = new String[(f3133 | 373302) + ~(f3133 & 373302) + 1 ^ 814774502];
      var10004[(f3133 | 561232) + ~(f3133 & 561232) + 1 ^ 815618689] = "stealer";
      super("ChestStealer", "Steals items from the storages you open.", var10003, var10004);
      w.a<"B">(this, 242859112966675773L);
      this.f3126 = w.a<"B">(new ArrayList(), 291435362423732219L);
      this.f3127 = new C0083();
      this.f3128 = new C0083();
      C0015 var10000 = this.f3122;
      List var10001 = this.f3126;
      w.a<"B">(this.f3126, 131918113315390561L);
      w.a<"Û">(var10000, var10001::clear, 276217487236498440L);
      w.a<"Û">(
         this.f3116,
         (Predicate<C0367>)var1 -> (boolean)(!w.a<"Û">((Boolean)w.a<"Û">(this.f3121, 174312564406604366L), 354697271520518137L)
               ? (f3133 | 916130) + ~(f3133 & 916130) + 1 ^ 815280242
               : (f3133 | 572477) + ~(f3133 & 572477) + 1 ^ 815625964),
         235935633196277017L
      );
      w.a<"Û">(ScreenEvents.AFTER_INIT, new C0335(this), 210693612100348525L);
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   @C1027
   public void m3310(C0612 var1) {
      if ((
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 instanceof class_476
               || m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 instanceof class_495
         )
         && w.a<"Û">(this.f3127, (long)w.a<"Û">((Integer)w.a<"Û">(this.f3123, 174312564406604366L), 260981171345819427L), 309642602085515378L)
         && (!w.a<"Û">((Boolean)w.a<"Û">(this.f3121, 174312564406604366L), 354697271520518137L) || this.f3129 != null)
         && w.a<"Û">(this.f3128, (long)w.a<"Û">((Integer)w.a<"Û">(this.f3124, 174312564406604366L), 260981171345819427L), 309642602085515378L)
         && !(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 instanceof C0737)) {
         C0367 var2 = w.a<"Û">((Boolean)w.a<"Û">(this.f3121, 174312564406604366L), 354697271520518137L)
            ? this.f3129
            : (C0367)w.a<"Û">(this.f3116, 174312564406604366L);
         class_1703 var3 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512;
         int var4 = (f3133 | 305180) + ~(f3133 & 305180) + 1 ^ 814834381;
         int var5 = (f3133 | 967649) + ~(f3133 & 967649) + 1 ^ 815466795;
         int var6 = var3.field_7763;
         if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 instanceof class_476 var7) {
            var5 = ((f3133 | 8679) + ~(f3133 & 8679) + 1 ^ 815131455) * w.a<"Û">((class_1707)w.a<"Û">(var7, 171142047871967334L), 320798725880828106L);
         }

         DuckHandledScreen var23 = (DuckHandledScreen)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755;
         Map var24 = w.a<"Û">(this, var5, 163557160712244895L);
         if (var2 == C0367.f3281) {
            var4 = var5;
            var5 = (f3133 | 978929) + ~(f3133 & 978929) + 1 ^ 815473924;
         }

         int var9 = (f3133 | 750673) + ~(f3133 & 750673) + 1 ^ 815709824;

         for (int var10 = var4; var10 < var4 + var5; var10++) {
            class_1799 var11 = w.a<"Û">(w.a<"Û">(var3, var10, 246529961808014541L), 204138723689318293L);
            if (!w.a<"Û">(var11, 330190014994709712L)
               && (
                  !w.a<"Û">((Boolean)w.a<"Û">(this.f3119, 174312564406604366L), 354697271520518137L)
                     || !w.a<"Û">(f3113, 314537768572362865L)
                     || w.a<"Û">(f3113, var11, w.a<"Û">((Boolean)w.a<"Û">(this.f3120, 174312564406604366L), 354697271520518137L), 175933806290829927L)
               )) {
               boolean var12 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 instanceof class_495;
               if (w.a<"Û">(this.f3118, 174312564406604366L) == C0830.f2646
                  ? w.a<"Û">((C0040)w.a<"Û">(this.f3117, 174312564406604366L), w.a<"Û">(var11, 222207108884875224L), this.f3114, 158749129574266968L)
                  : w.a<"Û">(
                     (C0040)w.a<"Û">(this.f3117, 174312564406604366L),
                     w.a<"Û">(w.a<"Û">(w.a<"Û">(var11, 248308138707081744L), 286788181028845103L), Locale.ROOT, 149330587742400121L),
                     this.f3115,
                     158749129574266968L
                  )) {
                  List var13 = (List)w.a<"Û">(var24, new C0844(w.a<"Û">(var11, 222207108884875224L), w.a<"Û">(var11, 217955156103058661L)), 299255156581412505L);
                  switch (<unrepresentable>.f0582[w.a<"Û">(var2, 160123498372577929L)]) {
                     case 1:
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                           var6,
                           var10,
                           (f3133 | 87833) + ~(f3133 & 87833) + 1 ^ 815046089,
                           class_1713.field_7795,
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                           270665692837061225L
                        );
                        break;
                     case 2:
                     case 3:
                        if (var12 && w.a<"B">(w.a<"Û">(var11, 222207108884875224L), 336282008572946725L)) {
                           continue;
                        }

                        this.f3131 = null;
                        this.f3130 = (boolean)((f3133 | 379548) + ~(f3133 & 379548) + 1 ^ 814743628);
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                           var6,
                           var10,
                           (f3133 | 56581) + ~(f3133 & 56581) + 1 ^ 815077332,
                           class_1713.field_7794,
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                           270665692837061225L
                        );
                        this.f3130 = (boolean)((f3133 | 191111) + ~(f3133 & 191111) + 1 ^ 815210582);
                        if (this.f3131 != null) {
                           w.a<"Û">(
                              this, w.a<"Û">(var3, var10, 246529961808014541L), this.f3131, w.a<"Û">(this.f3131, 204138723689318293L), 385231952779303250L
                           );
                        }
                        break;
                     case 4:
                        if (var13 == null) {
                           continue;
                        }

                        w.a<"Û">(this, var10, var13, 313364569775541784L);
                        var9 = (f3133 | 395981) + ~(f3133 & 395981) + 1 ^ 814990331;
                        break;
                     case 5:
                        if (var13 != null) {
                           w.a<"Û">(this, var10, var13, 313364569775541784L);
                           var9 = (f3133 | 57752) + ~(f3133 & 57752) + 1 ^ 815081646;
                        } else {
                           C0624 var14 = w.a<"Û">(C0933.f1439, 339528134023670155L);
                           if (var14 == null) {
                              continue;
                           }

                           class_1735 var15 = w.a<"Û">(var3, var10, 246529961808014541L);
                           int var16 = (f3133 | 141956) + ~(f3133 & 141956) + 1 ^ 815259733;
                           Iterator var17 = w.a<"Û">(w.a<"Û">(w.a<"Û">(var14, 119713120622016867L), 354320704134596920L), 194435811056609302L);

                           while (w.a<"Û">(var17, 333900474771661065L)) {
                              Entry var18 = (Entry)w.a<"Û">(var17, 192468336863492695L);
                              if (w.a<"Û">((C0625)w.a<"Û">(var18, 196870340575900401L), var11, 244520962132807216L)) {
                                 int var19 = w.a<"Û">((Integer)w.a<"Û">(var18, 141740301999341859L), 260981171345819427L)
                                       < ((f3133 | 924759) + ~(f3133 & 924759) + 1 ^ 815519375)
                                    ? (f3133 | 53198) + ~(f3133 & 53198) + 1 ^ 815072542
                                    : (f3133 | 130721) + ~(f3133 & 130721) + 1 ^ 815019120;
                                 int var20 = var5
                                    + (
                                       var19 != 0
                                          ? w.a<"Û">((Integer)w.a<"Û">(var18, 141740301999341859L), 260981171345819427L)
                                             + ((f3133 | 887561) + ~(f3133 & 887561) + 1 ^ 815284675)
                                          : w.a<"Û">((Integer)w.a<"Û">(var18, 141740301999341859L), 260981171345819427L)
                                             - ((f3133 | 344487) + ~(f3133 & 344487) + 1 ^ 814779263)
                                    );
                                 class_1799 var21 = w.a<"Û">(w.a<"Û">(var3, var20, 246529961808014541L), 204138723689318293L);
                                 if (!w.a<"Û">((C0625)w.a<"Û">(var18, 196870340575900401L), var21, 244520962132807216L)
                                    && (!w.a<"B">(w.a<"Û">(var21, 222207108884875224L), 336282008572946725L) || !(var3 instanceof class_1733))) {
                                    class_1735 var22 = w.a<"Û">(var3, var20, 246529961808014541L);
                                    w.a<"Û">(this, var15, var22, w.a<"Û">(var15, 204138723689318293L), 385231952779303250L);
                                    if (var19 != 0) {
                                       w.a<"Û">(
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                                          var6,
                                          var10,
                                          w.a<"Û">((Integer)w.a<"Û">(var18, 141740301999341859L), 260981171345819427L),
                                          class_1713.field_7791,
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                          270665692837061225L
                                       );
                                    } else {
                                       w.a<"Û">(
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                                          var6,
                                          var10,
                                          (f3133 | 511153) + ~(f3133 & 511153) + 1 ^ 814876256,
                                          class_1713.field_7790,
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                          270665692837061225L
                                       );
                                       w.a<"Û">(
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                                          var6,
                                          var20,
                                          (f3133 | 214033) + ~(f3133 & 214033) + 1 ^ 815173312,
                                          class_1713.field_7790,
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                          270665692837061225L
                                       );
                                       w.a<"Û">(
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                                          var6,
                                          var10,
                                          (f3133 | 168320) + ~(f3133 & 168320) + 1 ^ 815225681,
                                          class_1713.field_7790,
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                          270665692837061225L
                                       );
                                    }

                                    var9 = (f3133 | 295228) + ~(f3133 & 295228) + 1 ^ 814827530;
                                    var16 = (f3133 | 475604) + ~(f3133 & 475604) + 1 ^ 814910212;
                                    break;
                                 }
                              }
                           }

                           if (var16 == 0) {
                              continue;
                           }
                        }
                  }

                  w.a<"Û">(this.f3127, 387780412884547639L);
                  if (++var9 >= w.a<"Û">((Integer)w.a<"Û">(this.f3125, 174312564406604366L), 260981171345819427L)) {
                     break;
                  }
               }
            }
         }
      }
   }

   @C1027
   public void m3311(C0258 var1) {
      w.a<"Û">(this.f3128, 387780412884547639L);
      w.a<"Û">(this.f3126, 140901994866995976L);
   }

   @C1027
   public void onRender(C0333 var1) {
      synchronized (this.f3126) {
         w.a<"Û">(this.f3126, C0913::m0540, 372804948295703628L);
         Iterator var3 = w.a<"Û">(this.f3126, 341496865259068134L);

         while (w.a<"Û">(var3, 333900474771661065L)) {
            C0913 var4 = (C0913)w.a<"Û">(var3, 192468336863492695L);
            w.a<"Û">(var4, w.a<"Û">(var1, 136958205775673921L), 188066032316758194L);
         }
      }
   }

   @C1027
   public void m3312(C1016 var1) {
      if (this.f3130 && !w.a<"Û">(w.a<"Û">(w.a<"Û">(var1, 134449068668723599L), 204138723689318293L), 330190014994709712L)) {
         this.f3131 = w.a<"Û">(var1, 134449068668723599L);
      }
   }

   public void m3313(int var1, List<C0075> var2) {
      class_1735 var3 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512, var1, 246529961808014541L
      );
      if (w.a<"Û">(w.a<"Û">(var3, 204138723689318293L), 333186106469144731L)) {
         int var4 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512.field_7763;
         int var5 = w.a<"Û">(w.a<"Û">(var3, 204138723689318293L), 144154955567765793L);
         int var6 = (f3133 | 273655) + ~(f3133 & 273655) + 1 ^ 814868006;
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            var4,
            var1,
            (f3133 | 675645) + ~(f3133 & 675645) + 1 ^ 815760876,
            class_1713.field_7790,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            270665692837061225L
         );
         Iterator var7 = w.a<"Û">(var2, 341496865259068134L);

         while (w.a<"Û">(var7, 333900474771661065L)) {
            C0075 var8 = (C0075)w.a<"Û">(var7, 192468336863492695L);
            var3 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512,
               w.a<"Û">(var8, 377740731441791968L),
               246529961808014541L
            );
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
               var4,
               w.a<"Û">(var8, 377740731441791968L),
               (f3133 | 763971) + ~(f3133 & 763971) + 1 ^ 815686290,
               class_1713.field_7790,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               270665692837061225L
            );
            int var9 = w.a<"Û">(var8, 270239898868972550L) - w.a<"Û">(var8, 317486842161160875L);
            w.a<"Û">(var8, w.a<"Û">(var8, 317486842161160875L) + var5, 154194363615703135L);
            var5 -= var9;
            w.a<"Û">(
               this,
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512,
                  var1,
                  246529961808014541L
               ),
               var3,
               w.a<"Û">(w.a<"Û">(var3, 204138723689318293L), var9, 153266819952143934L),
               385231952779303250L
            );
            if (w.a<"Û">(
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512,
                     121341052621301599L
                  ),
                  330190014994709712L
               )
               || ++var6 >= w.a<"Û">((Integer)w.a<"Û">(this.f3125, 174312564406604366L), 260981171345819427L)) {
               break;
            }
         }

         if (!w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512, 121341052621301599L
            ),
            330190014994709712L
         )) {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
               var4,
               var1,
               (f3133 | 128918) + ~(f3133 & 128918) + 1 ^ 815021383,
               class_1713.field_7790,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               270665692837061225L
            );
         }
      }
   }

   public boolean m3314(class_1799 var1) {
      if (!(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512 instanceof class_1733)) {
         return (boolean)((f3133 | 18771) + ~(f3133 & 18771) + 1 ^ 815104899);
      } else {
         return (boolean)(!w.a<"B">(w.a<"Û">(var1, 222207108884875224L), 336282008572946725L)
            ? (f3133 | 747073) + ~(f3133 & 747073) + 1 ^ 815705233
            : (f3133 | 425662) + ~(f3133 & 425662) + 1 ^ 814986351);
      }
   }

   public void m3315(class_1735 var1, class_1735 var2, class_1799 var3) {
      DuckHandledScreen var4 = (DuckHandledScreen)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755;
      if (!f3132 && var4 == null) {
         throw new AssertionError();
      } else {
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f3122, 174312564406604366L), 354697271520518137L)) {
            w.a<"Û">(
               this.f3126,
               new C0913(
                  var3,
                  new C0490(var4.getX() + var1.field_7873, var4.getY() + var1.field_7872),
                  new C0490(var4.getX() + var2.field_7873, var4.getY() + var2.field_7872)
               ),
               276802003864609490L
            );
         }
      }
   }

   public Map<C0844, List<C0075>> m3316(int var1) {
      HashMap var2 = new HashMap();

      for (int var3 = (f3133 | 550704) + ~(f3133 & 550704) + 1 ^ 815640033; var3 < ((f3133 | 668435) + ~(f3133 & 668435) + 1 ^ 815790566); var3++) {
         if (var3 + var1
            < w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512.field_7761,
               281692963295227694L
            )) {
            class_1799 var4 = w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512,
                  var1 + var3,
                  246529961808014541L
               ),
               204138723689318293L
            );
            if (w.a<"Û">(var4, 144154955567765793L) < w.a<"Û">(var4, 158640503227305050L)
               && !w.a<"Û">(var4, 330190014994709712L)
               && w.a<"Û">(var4, 333186106469144731L)) {
               class_9323 var5 = w.a<"Û">(var4, 217955156103058661L);
               C0844 var6 = new C0844(w.a<"Û">(var4, 222207108884875224L), var5);
               w.a<"Û">(var2, var6, new ArrayList(), 265103749380408799L);
               int var7 = w.a<"Û">(var4, 158640503227305050L);
               w.a<"Û">((List)w.a<"Û">(var2, var6, 299255156581412505L), new C0075(var1 + var3, var7, w.a<"Û">(var4, 144154955567765793L)), 276802003864609490L);
            }
         }
      }

      return var2;
   }

   public void m3317(C0367 var1) {
      this.f3129 = var1;
   }

   public C0367 m3318() {
      return this.f3129;
   }

   public static String xImtAye4JbPyExHu5hM4NA6hUnp8AVhiz1h4LLsG34VtwylJvrtNBlf6NtntNj3JeaYPqjjBZVQktnHZZeyNJ4P0frcYJg4kVblB(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
