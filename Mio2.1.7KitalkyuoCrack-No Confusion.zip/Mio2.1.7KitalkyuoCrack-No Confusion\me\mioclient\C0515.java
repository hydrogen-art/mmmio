package me.mioclient;

public class C0515 {
   public static int f5243;
   public static String f5244;
   public static String f5245;
   public static long f5246;
   public static long f5247;

   public static String m2111() {
      return f5244 + " - " + f5245;
   }

   static {
      C0095.NQgBxPvHu2CtjBoU3wrUzMnWZ6Y7u8Q0YGyrVJVXwSeNXqEilhrtes8ckkWQRQCoJkjuxKJBqHTRBTjAhNARHYA1bb1wTomJsDFQ();
   }
}
