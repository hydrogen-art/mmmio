package me.mioclient;

import java.util.function.Predicate;

public class C0273 implements Predicate {
   public C0345 f5106;

   public C0273(C0345 var1) {
      this.f5106 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f5106.f0369, 174312564406604366L) != C0347.f1910 && w.a<"Û">(this.f5106.f0369, 174312564406604366L) != C0347.f1913;
   }
}
