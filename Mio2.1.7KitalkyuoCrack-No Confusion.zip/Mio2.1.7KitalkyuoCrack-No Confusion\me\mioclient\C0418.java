package me.mioclient;

import java.util.function.Predicate;

public class C0418 implements Predicate {
   public C0464 f3194;

   public C0418(C0464 var1) {
      this.f3194 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3194.f4348, 254992554122318132L);
   }
}
