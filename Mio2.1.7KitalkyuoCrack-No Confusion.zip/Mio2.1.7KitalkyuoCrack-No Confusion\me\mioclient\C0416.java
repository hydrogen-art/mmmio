package me.mioclient;

import com.google.gson.JsonObject;
import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.UUID;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1321;
import net.minecraft.class_1422;
import net.minecraft.class_1477;
import net.minecraft.class_1542;
import net.minecraft.class_1569;
import net.minecraft.class_1657;
import net.minecraft.class_1683;
import net.minecraft.class_1684;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2587;
import net.minecraft.class_2595;
import net.minecraft.class_2601;
import net.minecraft.class_2609;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2625;
import net.minecraft.class_2627;
import net.minecraft.class_3719;
import net.minecraft.class_8172;
import net.minecraft.class_3620.class_6594;

public class C0416 implements C0045 {
   public final C0396 f5337;
   public final HashMap<UUID, String> f5338 = new HashMap<>();
   public static int f5339 = w.a<"B">(8061207065735613989L, 257832362129977838L);

   public C0416(C0396 var1) {
      this.f5337 = var1;
   }

   public boolean m4108(class_1297 var1) {
      if (var1 != null && w.a<"Û">(var1, 225708705569795011L) != null) {
         if (!w.a<"B">(w.a<"Û">(var1, 225708705569795011L), 132682894836608805L)) {
            return (boolean)((f5339 | 219084) + ~(f5339 & 219084) + 1 ^ 506521685);
         } else {
            class_243 var2 = w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L),
               133466035608991790L
            );
            if (var1 instanceof class_1542
               && w.a<"Û">(w.a<"Û">(var1, 360959056130751432L), var2, 180844654503832142L)
                  > (double)w.a<"Û">((Integer)w.a<"Û">(this.f5337.f0147, 174312564406604366L), 260981171345819427L)) {
               return (boolean)((f5339 | 525667) + ~(f5339 & 525667) + 1 ^ 507230970);
            } else {
               return (boolean)((
                        !(var1 instanceof class_1657)
                           || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0136, 174312564406604366L), 354697271520518137L)
                           || var1 == m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
                     )
                     && (
                        !(var1 instanceof class_1542)
                           || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0145, 174312564406604366L), 354697271520518137L)
                           || w.a<"Û">(this.f5337.f0146, 174312564406604366L) == C0069.f3532
                     )
                     && (!(var1 instanceof class_1683) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0154, 174312564406604366L), 354697271520518137L))
                     && (
                        !(var1 instanceof class_1296) && !(var1 instanceof class_1422) && !(var1 instanceof class_1477)
                           || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0139, 174312564406604366L), 354697271520518137L)
                     )
                     && (!(var1 instanceof class_1569) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0133, 174312564406604366L), 354697271520518137L))
                     && (!(var1 instanceof class_1684) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0142, 174312564406604366L), 354697271520518137L))
                  ? (f5339 | 940237) + ~(f5339 & 940237) + 1 ^ 507373396
                  : (f5339 | 638790) + ~(f5339 & 638790) + 1 ^ 507117790);
            }
         }
      } else {
         return (boolean)((f5339 | 889412) + ~(f5339 & 889412) + 1 ^ 507391453);
      }
   }

   public boolean m4109(class_2586 var1) {
      if (var1 == null) {
         return (boolean)((f5339 | 388183) + ~(f5339 & 388183) + 1 ^ 506876878);
      } else if (!w.a<"B">(new class_238(w.a<"Û">(var1, 269630716540245963L)), 132682894836608805L)) {
         return (boolean)((f5339 | 432513) + ~(f5339 & 432513) + 1 ^ 506799640);
      } else {
         return (boolean)((
                  !(var1 instanceof class_2595) && !(var1 instanceof class_3719)
                     || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0160, 174312564406604366L), 354697271520518137L)
               )
               && (!(var1 instanceof class_2587) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0163, 174312564406604366L), 354697271520518137L))
               && (!(var1 instanceof class_2611) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0161, 174312564406604366L), 354697271520518137L))
               && (!(var1 instanceof class_2627) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0162, 174312564406604366L), 354697271520518137L))
               && (!(var1 instanceof class_2609) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0167, 174312564406604366L), 354697271520518137L))
               && (!(var1 instanceof class_2601) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0165, 174312564406604366L), 354697271520518137L))
               && (!(var1 instanceof class_2614) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0166, 174312564406604366L), 354697271520518137L))
               && (!(var1 instanceof class_2625) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0164, 174312564406604366L), 354697271520518137L))
               && (!(var1 instanceof class_8172) || !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0168, 174312564406604366L), 354697271520518137L))
            ? (f5339 | 796220) + ~(f5339 & 796220) + 1 ^ 507484581
            : (f5339 | 444452) + ~(f5339 & 444452) + 1 ^ 506820540);
      }
   }

   public boolean m4110() {
      return (boolean)(!w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0160, 174312564406604366L), 354697271520518137L)
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0161, 174312564406604366L), 354697271520518137L)
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0162, 174312564406604366L), 354697271520518137L)
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0163, 174312564406604366L), 354697271520518137L)
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0164, 174312564406604366L), 354697271520518137L)
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0165, 174312564406604366L), 354697271520518137L)
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0166, 174312564406604366L), 354697271520518137L)
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0167, 174312564406604366L), 354697271520518137L)
         ? (f5339 | 975363) + ~(f5339 & 975363) + 1 ^ 507338138
         : (f5339 | 902512) + ~(f5339 & 902512) + 1 ^ 507411176);
   }

   public void m4111(C1358 var1, String var2, class_243 var3, float var4, Color var5, Color var6) {
      double var7 = w.a<"B">(
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L),
            133466035608991790L
         ),
         var3,
         (double)var4,
         241370723479498950L
      );
      if (var6 != null) {
         C0094.f4640.m1904(w.a<"Û">(var1, 173269294235887931L), var3, 0.0F, 0.0F, C0498.f4738.m3896(var2), (float)C0498.f4738.m3897(), var7, var6);
      }

      C0094.f4640
         .m1907(w.a<"Û">(var1, 271310623277980550L), var2, var3, 0.0F, 0.0F, var7, var5, (boolean)((f5339 | 722822) + ~(f5339 & 722822) + 1 ^ 507033630));
   }

   public void m4112(UUID var1) {
      try {
         HttpClient var2 = w.a<"B">(204835803970455568L);

         try {
            HttpRequest var3 = w.a<"Û">(
               w.a<"Û">(
                  w.a<"Û">(
                     w.a<"Û">(
                        w.a<"B">(268948722625549773L),
                        new URI(
                           new C1002()
                              .m2591(w.a<"Û">(w.a<"Û">(var1, 380441990755472682L), "-", "", 328425598364162988L))
                              .m2593("https://sessionserver.mojang.com/session/minecraft/profile/\u0001")
                        ),
                        181212615093036204L
                     ),
                     w.a<"B">(((long)f5339 | 190606L) + ~((long)f5339 & 190606L) + 1L ^ 506550036L, ChronoUnit.SECONDS, 193001244410813325L),
                     157642401779953798L
                  ),
                  371158238520554826L
               ),
               300736675051851570L
            );
            HttpResponse var4 = w.a<"Û">(var2, var3, w.a<"B">(321132295963193403L), 323830589517684085L);
            JsonObject var5 = w.a<"Û">(w.a<"B">((String)w.a<"Û">(var4, 244454023818740046L), 360179252972467592L), 322749330123725882L);
            if (w.a<"Û">(var5, "name", 314399812765309162L)) {
               String var6 = w.a<"Û">(w.a<"Û">(var5, "name", 268791691692763549L), 327479800495025542L);
               w.a<"Û">(this.f5338, var1, var6, 298749053205630862L);
            }
         } catch (Throwable var8) {
            if (var2 != null) {
               try {
                  w.a<"Û">(var2, 347212322959730913L);
               } catch (Throwable var7) {
                  w.a<"Û">(var8, var7, 146475198553194593L);
               }
            }

            throw var8;
         }

         if (var2 != null) {
            w.a<"Û">(var2, 347212322959730913L);
         }
      } catch (Exception var9) {
      }
   }

   public String m4113(class_1297 var1) {
      UUID var2 = null;
      if (!w.a<"Û">((Boolean)w.a<"Û">(this.f5337.f0131, 174312564406604366L), 354697271520518137L)) {
         return null;
      } else {
         if (var1 instanceof class_1684 var3 && w.a<"Û">(var3, 368852572726115665L) != null) {
            return w.a<"Û">(w.a<"Û">(w.a<"Û">(var3, 368852572726115665L), 291295238331520790L), 286788181028845103L);
         }

         if (var1 instanceof class_1321 var4) {
            var2 = w.a<"Û">(var4, 343313759724118006L);
         }

         if (var2 != null) {
            class_1657 var5 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var2, 191871202600449693L
            );
            if (var5 != null) {
               String var7 = w.a<"Û">(w.a<"Û">(var5, 138826997201410603L), 211085733983653208L);
               w.a<"Û">(this.f5338, var2, var7, 155741541934407963L);
               return var7;
            }

            if (w.a<"Û">(this.f5338, var2, 350552054306772964L)) {
               return (String)w.a<"Û">(this.f5338, var2, 208914271082929313L);
            }

            w.a<"Û">(this.f5338, var2, null, 298749053205630862L);
            UUID var6 = var2;
            w.a<"Û">(
               m$$ST0lYU78VmyXastPw1lLFDyjhGsVzgyCIA2iF6clygrko2h3N2g9nQ0NE00dM9oeZ5yr22Y8aXvILtAlo6yP2lrTJIwGiJraq,
               (Runnable)() -> w.a<"Û">(this, var6, 291885855637507402L),
               343388196825787852L
            );
         }

         return null;
      }
   }

   public Color m4114(class_1297 var1, boolean var2) {
      Color var3 = Color.white;
      if (var1 instanceof class_1657) {
         var3 = var2 ? (Color)w.a<"Û">(this.f5337.f0137, 174312564406604366L) : (Color)w.a<"Û">(this.f5337.f0138, 174312564406604366L);
      } else if (var1 instanceof class_1542) {
         var3 = var2 ? (Color)w.a<"Û">(this.f5337.f0152, 174312564406604366L) : (Color)w.a<"Û">(this.f5337.f0153, 174312564406604366L);
      } else if (var1 instanceof class_1683) {
         var3 = var2 ? (Color)w.a<"Û">(this.f5337.f0155, 174312564406604366L) : (Color)w.a<"Û">(this.f5337.f0156, 174312564406604366L);
      } else if (!(var1 instanceof class_1296) && !(var1 instanceof class_1422) && !(var1 instanceof class_1477)) {
         if (var1 instanceof class_1569) {
            var3 = var2 ? (Color)w.a<"Û">(this.f5337.f0134, 174312564406604366L) : (Color)w.a<"Û">(this.f5337.f0135, 174312564406604366L);
         } else if (var1 instanceof class_1684) {
            var3 = var2 ? (Color)w.a<"Û">(this.f5337.f0143, 174312564406604366L) : (Color)w.a<"Û">(this.f5337.f0144, 174312564406604366L);
         }
      } else {
         var3 = var2 ? (Color)w.a<"Û">(this.f5337.f0140, 174312564406604366L) : (Color)w.a<"Û">(this.f5337.f0141, 174312564406604366L);
      }

      int var4 = (int)w.a<"B">(
         w.a<"B">((float)(var1.field_6012 - ((f5339 | 104219) + ~(f5339 & 104219) + 1 ^ 506603651)), (float)var1.field_6012, 191728904643652775L)
            * w.a<"B">((f5339 | 557196) + ~(f5339 & 557196) + 1 ^ 1604009749, 349057757755238323L),
         0.0F,
         (float)w.a<"Û">(var3, 245270953955453918L),
         131506059371757968L
      );
      if (var1 instanceof class_1684 || var1 instanceof class_1683) {
         var4 = w.a<"Û">(var3, 245270953955453918L);
      }

      return C0152.m3473(var3, var4);
   }

   public Color m4115(class_2586 var1) {
      int var2 = w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
               w.a<"Û">(var1, 269630716540245963L),
               310987074049434965L
            ),
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
            w.a<"Û">(var1, 269630716540245963L),
            246708465850471499L
         ),
         class_6594.field_34761,
         369246500338609047L
      );
      if (var1 instanceof class_2627) {
         return new Color(
            (f5339 | 446322) + ~(f5339 & 446322) + 1 ^ 506818580,
            (f5339 | 517762) + ~(f5339 & 517762) + 1 ^ 506747163,
            (f5339 | 45611) + ~(f5339 & 45611) + 1 ^ 506662173
         );
      } else if (var1 instanceof class_2611) {
         return new Color(
            (f5339 | 404936) + ~(f5339 & 404936) + 1 ^ 506827308,
            (f5339 | 955296) + ~(f5339 & 955296) + 1 ^ 507325457,
            (f5339 | 94853) + ~(f5339 & 94853) + 1 ^ 506645928
         );
      } else {
         if (var1 instanceof class_2587 var3) {
            var2 = w.a<"Û">(w.a<"Û">(w.a<"Û">(var3, 130371706813976764L), 161822033047812532L), class_6594.field_34761, 369246500338609047L);
         }

         int var6 = var2 >> ((f5339 | 83200) + ~(f5339 & 83200) + 1 ^ 506657417) & ((f5339 | 685743) + ~(f5339 & 685743) + 1 ^ 507103689);
         int var4 = var2 >> ((f5339 | 883314) + ~(f5339 & 883314) + 1 ^ 507430371) & ((f5339 | 136800) + ~(f5339 & 136800) + 1 ^ 506571014);
         int var5 = var2 & ((f5339 | 597280) + ~(f5339 & 597280) + 1 ^ 507159110);
         return w.a<"Û">(new Color(var5, var4, var6), 276690253004086927L);
      }
   }

   public static String VIl6NpfajNzGAYcG1PgJMYMaBKB2ZyE0MCMBXesJdjlgucRicmm2nuJuiNosJOpkxE8D8E4CFQtOTjn0nwYSTjHCcdQPTeNtbC2x(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
