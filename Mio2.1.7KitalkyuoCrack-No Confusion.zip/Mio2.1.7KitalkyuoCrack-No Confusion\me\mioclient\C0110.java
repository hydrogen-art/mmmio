package me.mioclient;

import java.util.function.Predicate;

public class C0110 implements Predicate {
   public C1272 f4903;

   public C0110(C1272 var1) {
      this.f4903 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4903.f1612, 254992554122318132L);
   }
}
