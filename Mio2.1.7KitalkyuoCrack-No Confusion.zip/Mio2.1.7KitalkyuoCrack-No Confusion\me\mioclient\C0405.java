package me.mioclient;

import java.util.function.Predicate;

public class C0405 implements Predicate {
   public C0464 f2033;

   public C0405(C0464 var1) {
      this.f2033 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2033.f4342, 174312564406604366L) == C0466.f3598 || w.a<"Û">(this.f2033.f4342, 174312564406604366L) == C0466.f3599;
   }
}
