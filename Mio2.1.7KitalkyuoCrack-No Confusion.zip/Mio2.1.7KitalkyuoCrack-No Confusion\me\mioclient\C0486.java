package me.mioclient;

import java.awt.Color;
import net.minecraft.class_238;
import net.minecraft.class_4587;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

record C0486() {
   public final Matrix4f f4502;
   public final Matrix3f f4503;
   public final class_238 f4504;
   public final Color f4505;
   public final float f4506;

   public C0486(Matrix4f var1, Matrix3f var2, class_238 var3, Color var4, float var5) {
      this.f4502 = var1;
      this.f4503 = var2;
      this.f4504 = var3;
      this.f4505 = var4;
      this.f4506 = var5;
   }

   public static C0486 m1815(class_4587 var0, class_238 var1, Color var2, float var3) {
      return new C0486(new Matrix4f(var0.method_23760().method_23761()), new Matrix3f(var0.method_23760().method_23762()), var1, var2, var3);
   }

   public Matrix4f m1816() {
      return this.f4502;
   }

   public Matrix3f m1817() {
      return this.f4503;
   }

   public class_238 m1818() {
      return this.f4504;
   }

   public Color m1819() {
      return this.f4505;
   }

   public float m1820() {
      return this.f4506;
   }
}
