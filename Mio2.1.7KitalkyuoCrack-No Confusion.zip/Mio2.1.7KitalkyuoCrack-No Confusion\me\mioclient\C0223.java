package me.mioclient;

public class C0223 extends C1108 {
   public boolean f1991;
   public static int f1992 = w.a<"B">(8164558120600697036L, 257832362129977838L);

   public C0223(String var1, C1088 var2) {
      super(var1, C0272.f3584, var2);
   }

   @Override
   public void run() {
   }

   public void m0857(boolean var1) {
      if (this.f1991 != var1) {
         this.f1991 = var1;
         if (!w.a<"Û">(this.m$$Pj8KnzzsTD4xKKhQb68ECP9g0nEEpfufc7jFY70HUwPGeOvVekkswMX1i2w14VV02yg6VKSM5QFhrBBDf5OkEZjmAMRXT47Mn, 284469716622774448L)) {
            if (this.f1991) {
               w.a<"Û">(
                  this,
                  (String)w.a<"Û">(
                     this.m$$Pj8KnzzsTD4xKKhQb68ECP9g0nEEpfufc7jFY70HUwPGeOvVekkswMX1i2w14VV02yg6VKSM5QFhrBBDf5OkEZjmAMRXT47Mn, 190855132863596333L
                  ),
                  152247831893841791L
               );
            } else {
               w.a<"Û">(
                  this,
                  (String)w.a<"Û">(
                     this.m$$Pj8KnzzsTD4xKKhQb68ECP9g0nEEpfufc7jFY70HUwPGeOvVekkswMX1i2w14VV02yg6VKSM5QFhrBBDf5OkEZjmAMRXT47Mn, 303940721173427496L
                  ),
                  152247831893841791L
               );
            }
         }
      }
   }
}
