package me.mioclient;

import com.mojang.authlib.GameProfile;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Predicate;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_2703;
import net.minecraft.class_4184;
import net.minecraft.class_640;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2703.class_2705;

public class C0464 extends C1266 {
   public static final C0719 f4339 = C0933.f1409.m2696(C0719.class);
   public static boolean f4340 = (boolean)((C0464.f4371 | 861808) + ~(C0464.f4371 & 861808) + 1 ^ 1922537358);
   public final C0015<Float> f4341;
   public final C0015<C0466> f4342;
   public final C0015<Boolean> f4343;
   public final C0015<Float> f4344;
   public final C0015<Float> f4345;
   public final C0015<Boolean> f4346;
   public final C0015<Float> f4347;
   public final C0015<Boolean> f4348;
   public final C0015<Float> f4349;
   public final C0015<C0468> f4350;
   public final C0015<Boolean> f4351;
   public final C0015<Boolean> f4352;
   public final C0015<Boolean> f4353;
   public final C0015<Boolean> f4354;
   public final C0015<Boolean> f4355;
   public final C0015<C1348> f4356;
   public final C0015<Boolean> f4357;
   public final C0015<C1348> f4358;
   public final C0015<Boolean> f4359;
   public final C0015<Color> f4360;
   public final C0015<Color> f4361;
   public final C0015<Color> f4362;
   public final C0015<Color> f4363;
   public final C0015<Color> f4364;
   public final C0015<Color> f4365;
   public final C0015<Boolean> f4366;
   public final C0015<Boolean> f4367;
   public final C0015<Boolean> f4368;
   public final Object2ObjectOpenHashMap<String, C0465> f4369;
   public final List<C0467> f4370;
   public static int f4371 = w.a<"B">(5995113736140637990L, 257832362129977838L);

   public C0464() {
      super("LogoutSpots", "Highlights log out spots.", C1045.f3174);
      w.a<"B">(this, 242859112966675773L);
      this.f4369 = new Object2ObjectOpenHashMap();
      this.f4370 = new ArrayList<>();
      w.a<"Û">(this.f4341, "Unlimited", C0508.f2372, 381268910042652120L);
      w.a<"Û">(this.f4356, "LoginSoundPath", 275243698516531804L);
      w.a<"Û">(this.f4358, "LogoutSoundPath", 275243698516531804L);
      w.a<"Û">(this, (boolean)((f4371 | 840068) + ~(f4371 & 840068) + 1 ^ 1922457722), 135570431627433065L);
   }

   @Override
   public void onToggle() {
      w.a<"Û">(this.f4369, 251494219067421375L);
   }

   @C1027
   public void m1756(C1358 var1) {
      class_4184 var2 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L
      );
      class_243 var3 = w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(
               new class_243(0.0, 0.0, w.a<"B">(((long)f4371 | 205597L) + ~((long)f4371 & 205597L) + 1L ^ 4607182420722684643L, 317139102743630955L)),
               -((float)w.a<"B">((double)w.a<"Û">(var2, 172998423274345737L), 175389272199548133L)),
               255739159657143373L
            ),
            -((float)w.a<"B">((double)w.a<"Û">(var2, 370804508038485452L), 175389272199548133L)),
            125302572034401955L
         ),
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 186577611421056948L).field_4686,
            133466035608991790L
         ),
         300445064978294627L
      );
      synchronized (this.f4369) {
         ObjectIterator var5 = w.a<"Û">(w.a<"Û">(this.f4369, 378273265866110265L), 333638455299985005L);

         while (w.a<"Û">(var5, 333900474771661065L)) {
            Entry var6 = (Entry)w.a<"Û">(var5, 192468336863492695L);
            if (w.a<"Û">((C0465)w.a<"Û">(var6, 196870340575900401L), 358257034893215910L).equals(w.a<"Û">(this, 369457096744171671L))
               && w.a<"Û">((C0465)w.a<"Û">(var6, 196870340575900401L), 342430583857149780L) == w.a<"B">(375727057840316412L)
               && (
                  !(
                        w.a<"Û">(
                              w.a<"Û">(((C0465)w.a<"Û">(var6, 196870340575900401L)).f3224, 376895844755266015L),
                              w.a<"Û">(
                                 w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773,
                                    202182323384413167L
                                 ),
                                 133466035608991790L
                              ),
                              180844654503832142L
                           )
                           > (double)w.a<"Û">((Float)w.a<"Û">(this.f4341, 174312564406604366L), 149784643039979208L)
                     )
                     || w.a<"Û">((Float)w.a<"Û">(this.f4341, 174312564406604366L), 149784643039979208L)
                        == w.a<"B">((f4371 | 347111) + ~(f4371 & 347111) + 1 ^ 822704665, 349057757755238323L)
               )) {
               if (w.a<"Û">(this.f4342, 174312564406604366L) == C0466.f3597 || w.a<"Û">(this.f4342, 174312564406604366L) == C0466.f3599) {
                  w.a<"B">(
                     w.a<"Û">(var1, 173269294235887931L),
                     w.a<"Û">((C0465)w.a<"Û">(var6, 196870340575900401L), 120560598481539100L),
                     (Color)w.a<"Û">(this.f4362, 174312564406604366L),
                     246072095578695914L
                  );
                  C0485.m3219(
                     w.a<"Û">(var1, 173269294235887931L),
                     w.a<"Û">((C0465)w.a<"Û">(var6, 196870340575900401L), 120560598481539100L),
                     (Color)w.a<"Û">(this.f4363, 174312564406604366L),
                     w.a<"Û">((Float)w.a<"Û">(this.f4345, 174312564406604366L), 149784643039979208L)
                  );
               }

               if (w.a<"Û">(this.f4342, 174312564406604366L) == C0466.f3598 || w.a<"Û">(this.f4342, 174312564406604366L) == C0466.f3599) {
                  C0164 var7 = w.a<"Û">((C0465)w.a<"Û">(var6, 196870340575900401L), 307585612998678981L);
                  if (w.a<"Û">((Boolean)w.a<"Û">(this.f4343, 174312564406604366L), 354697271520518137L)) {
                     f4340 = (boolean)((f4371 | 213536) + ~(f4371 & 213536) + 1 ^ 1922692063);
                     w.a<"B">(
                        w.a<"B">((f4371 | 940112) + ~(f4371 & 940112) + 1 ^ 1293216174, 349057757755238323L),
                        w.a<"B">((f4371 | 334554) + ~(f4371 & 334554) + 1 ^ 1293921060, 349057757755238323L),
                        w.a<"B">((f4371 | 297019) + ~(f4371 & 297019) + 1 ^ 1293826501, 349057757755238323L),
                        w.a<"Û">((Float)w.a<"Û">(this.f4344, 174312564406604366L), 149784643039979208L),
                        338561931007909111L
                     );
                     C0094.f4640
                        .m1911(
                           var7,
                           w.a<"B">((f4371 | 398078) + ~(f4371 & 398078) + 1 ^ 1293722368, 349057757755238323L),
                           w.a<"Û">(var1, 173269294235887931L),
                           w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 307206842868879895L
                              ),
                              224491904139370894L
                           )
                        );
                     w.a<"Û">(
                        w.a<"Û">(
                           w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 307206842868879895L),
                           224491904139370894L
                        ),
                        170217939166473161L
                     );
                     w.a<"B">(
                        w.a<"B">((f4371 | 678870) + ~(f4371 & 678870) + 1 ^ 1292954152, 349057757755238323L),
                        w.a<"B">((f4371 | 946150) + ~(f4371 & 946150) + 1 ^ 1293213208, 349057757755238323L),
                        w.a<"B">((f4371 | 692405) + ~(f4371 & 692405) + 1 ^ 1292902731, 349057757755238323L),
                        w.a<"B">((f4371 | 783425) + ~(f4371 & 783425) + 1 ^ 1292977599, 349057757755238323L),
                        338561931007909111L
                     );
                     f4340 = (boolean)((f4371 | 933593) + ~(f4371 & 933593) + 1 ^ 1922338599);
                  }

                  C0297.m2461((double)w.a<"Û">((Float)w.a<"Û">(this.f4345, 174312564406604366L), 149784643039979208L));
                  C0297.m2453((Color)w.a<"Û">(this.f4361, 174312564406604366L), (Color)w.a<"Û">(this.f4360, 174312564406604366L));
                  C0297.m2456(w.a<"Û">(var1, 173269294235887931L), var7);
               }

               if (w.a<"Û">((Boolean)w.a<"Û">(this.f4346, 174312564406604366L), 354697271520518137L)) {
                  C0094.f4640
                     .m1897(
                        w.a<"Û">(var1, 173269294235887931L),
                        var3,
                        w.a<"Û">(w.a<"Û">((C0465)w.a<"Û">(var6, 196870340575900401L), 120560598481539100L), 376895844755266015L),
                        (Color)w.a<"Û">(this.f4361, 174312564406604366L),
                        w.a<"Û">((Float)w.a<"Û">(this.f4347, 174312564406604366L), 149784643039979208L)
                     );
               }

               if (w.a<"Û">((Boolean)w.a<"Û">(this.f4348, 174312564406604366L), 354697271520518137L)) {
                  class_243 var10000 = w.a<"Û">(w.a<"Û">((C0465)w.a<"Û">(var6, 196870340575900401L), 120560598481539100L), 376895844755266015L);
                  long var10003 = (long)f4371 | 743545L;
                  class_243 var15 = w.a<"Û">(
                     var10000,
                     class_2351.field_11052,
                     w.a<"Û">((C0465)w.a<"Û">(var6, 196870340575900401L), 120560598481539100L).field_1325
                        + w.a<"B">(var10003 + ~((long)f4371 & 743545L) + 1L ^ 4602678821094812039L, 317139102743630955L),
                     156744506625070247L
                  );
                  String var8 = new C1002().m2591((String)w.a<"Û">(var6, 141740301999341859L)).m2593("\u0001 logout spot");
                  String var9 = w.a<"Û">(this, (C0465)w.a<"Û">(var6, 196870340575900401L), 345367469588621153L);
                  float var10 = w.a<"Û">(f4339, 314537768572362865L)
                     ? w.a<"B">((f4371 | 438169) + ~(f4371 & 438169) + 1 ^ 1293688423, 349057757755238323L)
                     : 0.0F;
                  if (!w.a<"Û">(var9, 226515538076917205L)) {
                     var8 = new C1002().m2591(var9).m2591(var8).m2593("\u0001\u0001");
                  }

                  double var11 = w.a<"B">(
                     w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L
                        ),
                        133466035608991790L
                     ),
                     var15,
                     (double)w.a<"Û">((Float)w.a<"Û">(this.f4349, 174312564406604366L), 149784643039979208L),
                     241370723479498950L
                  );
                  C0094.f4640
                     .m1904(
                        w.a<"Û">(var1, 173269294235887931L),
                        var15,
                        w.a<"B">((f4371 | 304922) + ~(f4371 & 304922) + 1 ^ -831794069, 349057757755238323L),
                        0.0F,
                        -(C0498.f4738.m3896(var8) / w.a<"B">((f4371 | 655674) + ~(f4371 & 655674) + 1 ^ 848343236, 349057757755238323L))
                           - w.a<"B">((f4371 | 331485) + ~(f4371 & 331485) + 1 ^ 849329955, 349057757755238323L),
                        w.a<"B">((f4371 | 993739) + ~(f4371 & 993739) + 1 ^ 842373173, 349057757755238323L) + var10,
                        var11 * w.a<"B">(((long)f4371 | 491783L) + ~((long)f4371 & 491783L) + 1L ^ 4611686020350292217L, 317139102743630955L),
                        (Color)w.a<"Û">(this.f4365, 174312564406604366L)
                     );
                  C0094.f4640
                     .m1908(
                        w.a<"Û">(var1, 271310623277980550L),
                        var8,
                        var15,
                        0.0F,
                        0.0F,
                        -(C0498.f4738.m3896(var8) / w.a<"B">((f4371 | 34425) + ~(f4371 & 34425) + 1 ^ 848967559, 349057757755238323L)),
                        w.a<"B">((f4371 | 303432) + ~(f4371 & 303432) + 1 ^ 849219766, 349057757755238323L),
                        var11,
                        (Color)w.a<"Û">(this.f4364, 174312564406604366L),
                        (boolean)((f4371 | 809079) + ~(f4371 & 809079) + 1 ^ 1922492808)
                     );
               }
            }
         }
      }
   }

   @C1027
   public void m1757(C0612 var1) {
      Iterator var2 = w.a<"Û">(this.f4370, 341496865259068134L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         C0467 var3 = (C0467)w.a<"Û">(var2, 192468336863492695L);
         class_1657 var4 = w.a<"Û">(var3, 214544475220810786L);
         if (w.a<"Û">(this, var4, 290658584790617180L)) {
            w.a<"Û">(var3.f4065, (boolean)((f4371 | 213697) + ~(f4371 & 213697) + 1 ^ 1922691902), 378016260982040195L);
            w.a<"Û">(
               this.f4369,
               w.a<"Û">(w.a<"Û">(var4, 138826997201410603L), 211085733983653208L),
               w.a<"B">(var4, w.a<"Û">(this, 369457096744171671L), 365885653551315908L),
               200823060238053497L
            );
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f4354, 174312564406604366L), 354697271520518137L)
               && w.a<"Û">((Boolean)w.a<"Û">(this.f4357, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(
                  C0933.f1420,
                  (C1348)w.a<"Û">(this.f4358, 174312564406604366L),
                  w.a<"B">((f4371 | 60766) + ~(f4371 & 60766) + 1 ^ 1293573280, 349057757755238323L),
                  359079024815758851L
               );
            }
         }
      }

      w.a<"Û">(this.f4370, C0467::m1688, 372804948295703628L);
   }

   @C1027
   public void m1758(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2703 var2) {
         Iterator var5 = w.a<"Û">(w.a<"Û">(var2, 240453058334290051L), 341496865259068134L);

         while (w.a<"Û">(var5, 333900474771661065L)) {
            class_2705 var4 = (class_2705)w.a<"Û">(var5, 192468336863492695L);
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff,
               (Runnable)() -> {
                  GameProfile var2x = w.a<"Û">(var4, 264765544793987569L);
                  String var3 = var2x == null ? "" : w.a<"Û">(var2x, 211085733983653208L);
                  if (w.a<"Û">((Boolean)w.a<"Û">(this.f4354, 174312564406604366L), 354697271520518137L)
                     && w.a<"Û">((Boolean)w.a<"Û">(this.f4355, 174312564406604366L), 354697271520518137L)
                     && w.a<"Û">(this.f4369, var3, 201201335417520122L)) {
                     w.a<"Û">(
                        C0933.f1420,
                        (C1348)w.a<"Û">(this.f4356, 174312564406604366L),
                        w.a<"B">((f4371 | 103946) + ~(f4371 & 103946) + 1 ^ 1293625332, 349057757755238323L),
                        359079024815758851L
                     );
                  }

                  w.a<"Û">(this.f4369, var3, 212403965966609811L);
               },
               121403494422088628L
            );
         }
      }
   }

   @C1027
   public void m1759(C1243 var1) {
      if (w.a<"Û">(C0933.f1416, 249252991026173401L) == null
         || w.a<"Û">(var1, 183371481221279650L).equals(w.a<"Û">(C0933.f1416, 249252991026173401L).field_3761)) {
         w.a<"Û">(this.f4369, 251494219067421375L);
      }
   }

   @C1027
   public void m1760(C1041 var1) {
      if (w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
         w.a<"Û">(var1, 114026181039104081L),
         336328433021103938L
      ) instanceof class_1657 var2) {
         if (var2 instanceof C0804) {
            return;
         }

         if (var2.field_6213 > 0 || w.a<"B">(var2, 181476777857313967L) <= 0.0F) {
            return;
         }

         if (w.a<"Û">((Boolean)w.a<"Û">(this.f4367, 174312564406604366L), 354697271520518137L) && w.a<"Û">(C0933.f1417, var2, 241036547861815495L)) {
            return;
         }

         if (w.a<"Û">((Boolean)w.a<"Û">(this.f4368, 174312564406604366L), 354697271520518137L) && !w.a<"B">(var2, 130756052256592378L)) {
            return;
         }

         w.a<"Û">(this.f4370, new C0467(var2, w.a<"B">(223409559795593705L), new AtomicBoolean()), 276802003864609490L);
      }
   }

   public String m1761(C0465 var1) {
      StringBuilder var2 = new StringBuilder();
      if (w.a<"Û">(this.f4350, 174312564406604366L) == C0468.f0255) {
         class_243 var3 = w.a<"Û">(var1, 255266638779684569L);
         w.a<"Û">(var2, " ", 150545021362368941L);
         Locale var10001 = Locale.US;
         Object[] var10003 = new Object[(f4371 | 57159) + ~(f4371 & 57159) + 1 ^ 1922723514];
         var10003[(f4371 | 75036) + ~(f4371 & 75036) + 1 ^ 1922798818] = w.a<"B">(w.a<"Û">(var3, 366754089402394978L), 165155940100814265L);
         var10003[(f4371 | 473315) + ~(f4371 & 473315) + 1 ^ 1922926876] = w.a<"B">(w.a<"Û">(var3, 292829928904272542L), 165155940100814265L);
         var10003[(f4371 | 975287) + ~(f4371 & 975287) + 1 ^ 1922322507] = w.a<"B">(w.a<"Û">(var3, 317360164092454553L), 165155940100814265L);
         w.a<"Û">(var2, w.a<"B">(var10001, "X: %.1f, Y: %.1f, Z: %.1f", var10003, 192245597425079245L), 150545021362368941L);
      }

      if (w.a<"Û">(this.f4350, 174312564406604366L) == C0468.f0256) {
         double var5 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L),
            w.a<"Û">(var1, 255266638779684569L),
            180844654503832142L
         );
         w.a<"Û">(var2, " ", 150545021362368941L);
         Object[] var10002 = new Object[(f4371 | 960712) + ~(f4371 & 960712) + 1 ^ 1922308407];
         var10002[(f4371 | 588849) + ~(f4371 & 588849) + 1 ^ 1922190799] = w.a<"B">(var5, 165155940100814265L);
         w.a<"Û">(var2, w.a<"Û">("%.1fm", var10002, 259257223839993282L), 150545021362368941L);
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f4351, 174312564406604366L), 354697271520518137L)) {
         Object[] var7 = new Object[(f4371 | 180016) + ~(f4371 & 180016) + 1 ^ 1922567887];
         var7[(f4371 | 311653) + ~(f4371 & 311653) + 1 ^ 1922986139] = w.a<"Û">(
            new SimpleDateFormat("HH:mm"), new Date(w.a<"Û">(var1, 126870690663297628L)), 387358855454593605L
         );
         String var6 = w.a<"Û">(" %s", var7, 259257223839993282L);
         w.a<"Û">(var2, var6, 150545021362368941L);
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f4352, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(var2, " (", 150545021362368941L);
         w.a<"Û">(var2, var1.f3226, 247028270812929167L);
         w.a<"Û">(var2, "hp)", 150545021362368941L);
      }

      if (var1.f3227 > 0 && w.a<"Û">((Boolean)w.a<"Û">(this.f4353, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(var2, " -", 150545021362368941L);
         w.a<"Û">(var2, var1.f3227, 247028270812929167L);
      }

      return w.a<"Û">(var2, 167209770867625114L);
   }

   public boolean m1762(class_1657 var1) {
      return w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944, 375973895142890397L
            ),
            366567241942811964L
         ),
         (Predicate<class_640>)var1x -> w.a<"Û">(w.a<"Û">(var1x, 340696059510910540L), 211085733983653208L)
               .equals(w.a<"Û">(w.a<"Û">(var1, 138826997201410603L), 211085733983653208L)),
         123195066106903135L
      );
   }

   public static boolean m1763() {
      return f4340;
   }

   public String m1764() {
      return m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687 != null
            && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 300193738958224619L)
            && w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
                  131347417028836246L
               )
               != null
         ? w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944, 131347417028836246L
            )
            .field_3761
         : "singleplayer";
   }

   public static String w2lZXUeJDAKTZFvZy5dpKP17edYSVf9GmjFIUHhfAf4Z2lRK5o6ymmqYq0zmuoCiyBcDiTuoYMaxaFIg7ThtWw7MbX5Q1d9UYl7O(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
