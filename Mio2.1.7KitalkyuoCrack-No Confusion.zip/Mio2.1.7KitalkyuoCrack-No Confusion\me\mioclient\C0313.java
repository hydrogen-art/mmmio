package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.Comparator;
import java.util.function.Function;
import net.minecraft.class_1297;

public enum C0313 implements C0196 {
   f1526(
      "Distance",
      w.a<"B">(
         (Function<class_1297, Float>)var0 -> w.a<"B">(w.a<"Û">(var0, C0045.f2103.field_1724, 239298884281641152L), 243402859552372891L), 224107444354928270L
      )
   ),
   f1527(
      "Crosshair",
      w.a<"B">(
         (Function<class_1297, Float>)var0 -> w.a<"B">(
               w.a<"B">(w.a<"Û">(C0045.f2103.field_1724, 152871992642526281L), w.a<"B">(var0, 227058158510945889L)[0], 123679565561004181L),
               243402859552372891L
            ),
         224107444354928270L
      )
   ),
   f1528("Health", w.a<"B">(C0982::m2751, 224107444354928270L));

   public final String f1529;
   public final Comparator<class_1297> f1530;

   public C0313(String var3, Comparator<class_1297> var4) {
      this.f1529 = var3;
      this.f1530 = var4;
   }

   @Override
   public String getName() {
      return this.f1529;
   }

   public Comparator<class_1297> m2685() {
      return this.f1530;
   }

   public static String Xbr2TVIcm2VVidIvGZVQw525xD49ctUZGXBCVD28yAZ1sT1ijB6XS4fb15R8RBAWZwUs60fye2Z47bCKFSMjdR0vDqEPVqwivF4Q(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
