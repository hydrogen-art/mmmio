package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import net.minecraft.class_1664;
import net.minecraft.class_315;

public class C0165 extends C1266 {
   public static final class_1664[] f3139;
   public static final class_1664[] f3140;
   public final C0015<C0166> f3141;
   public final C0015<Boolean> f3142;
   public final C0015<Float> f3143;
   public final Map<class_1664, Boolean> f3144;
   public final int f3145;
   public final C0083 f3146;
   public int f3147;
   public static int f3148 = w.a<"B">(3112087394690841686L, 257832362129977838L);

   public C0165() {
      C1045 var10003 = C1045.f3173;
      String[] var10004 = new String[(f3148 | 607405) + ~(f3148 & 607405) + 1 ^ -1192280946];
      var10004[(f3148 | 159316) + ~(f3148 & 159316) + 1 ^ -1193011594] = "skinblinker";
      super("SkinFlicker", "Flicks your skin parts.", var10003, var10004);
      w.a<"B">(this, 242859112966675773L);
      this.f3144 = new HashMap<>();
      this.f3145 = w.a<"B">(245766347670166649L).length;
      this.f3146 = new C0083();
   }

   @Override
   public void onEnable() {
      class_1664[] var1 = w.a<"B">(245766347670166649L);
      int var2 = var1.length;

      for (int var3 = (f3148 | 873499) + ~(f3148 & 873499) + 1 ^ -1192547271; var3 < var2; var3++) {
         class_1664 var4 = var1[var3];
         w.a<"Û">(
            this.f3144,
            var4,
            w.a<"B">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, var4, 170888553284277354L
               ),
               320330632857389983L
            ),
            121875332790264405L
         );
      }
   }

   @Override
   public void onDisable() {
      Map var10000 = this.f3144;
      class_315 var10001 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690;
      w.a<"B">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, 131918113315390561L);
      w.a<"Û">(var10000, var10001::method_1631, 316328768057134350L);
   }

   @C1027
   public void m1303(C0612 var1) {
      if (w.a<"Û">(this.f3146, (double)w.a<"Û">((Float)w.a<"Û">(this.f3143, 174312564406604366L), 149784643039979208L), TimeUnit.SECONDS, 215737872562411156L)) {
         switch (w.a<"Û">((C0166)w.a<"Û">(this.f3141, 174312564406604366L), 268628638556122796L)) {
            case 0:
               class_1664[] var7 = w.a<"B">(245766347670166649L);
               int var3 = var7.length;

               for (int var4 = (f3148 | 602207) + ~(f3148 & 602207) + 1 ^ -1192277891; var4 < var3; var4++) {
                  class_1664 var5 = var7[var4];
                  if (w.a<"Û">(this, var5, 163460580825339305L)) {
                     w.a<"Û">(this, var5, 127380001679412400L);
                  }
               }
               break;
            case 1:
            case 2:
               class_1664 var6 = (w.a<"Û">(this.f3141, 174312564406604366L) == C0166.f3591 ? f3139 : f3140)[this.f3147
                  % ((f3148 | 716742) + ~(f3148 & 716742) + 1 ^ -1192454174)];
               if (w.a<"Û">(this, var6, 163460580825339305L)) {
                  w.a<"Û">(this, var6, 127380001679412400L);
                  this.f3147 = (this.f3147 + ((f3148 | 520217) + ~(f3148 & 520217) + 1 ^ -1193179078))
                     % ((f3148 | 841540) + ~(f3148 & 841540) + 1 ^ -1192579232);
               }
               break;
            case 3:
               class_1664 var2 = w.a<"B">(245766347670166649L)[w.a<"Û">(w.a<"B">(339623076596514038L), this.f3145, 290903900221401347L)];
               if (w.a<"Û">(this, var2, 163460580825339305L)) {
                  w.a<"Û">(this, var2, 127380001679412400L);
               }
         }

         w.a<"Û">(this.f3146, 387780412884547639L);
      }
   }

   public void m1304(class_1664 var1) {
      w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690,
         var1,
         (boolean)(!w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1690, var1, 170888553284277354L
            )
            ? (f3148 | 145651) + ~(f3148 & 145651) + 1 ^ -1193000752
            : (f3148 | 298264) + ~(f3148 & 298264) + 1 ^ -1193085638),
         330446184219287195L
      );
   }

   public boolean m1305(class_1664 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f3142, 174312564406604366L), 354697271520518137L)) {
         return (boolean)((f3148 | 664732) + ~(f3148 & 664732) + 1 ^ -1192469313);
      } else {
         return (boolean)(var1 != class_1664.field_7559
            ? (f3148 | 664420) + ~(f3148 & 664420) + 1 ^ -1192469689
            : (f3148 | 6217) + ~(f3148 & 6217) + 1 ^ -1192861589);
      }
   }

   static {
      class_1664[] var10000 = new class_1664[(f3148 | 180059) + ~(f3148 & 180059) + 1 ^ -1192966273];
      var10000[(f3148 | 178425) + ~(f3148 & 178425) + 1 ^ -1192967973] = class_1664.field_7568;
      var10000[(f3148 | 432005) + ~(f3148 & 432005) + 1 ^ -1193218138] = class_1664.field_7564;
      var10000[(f3148 | 120428) + ~(f3148 & 120428) + 1 ^ -1192776116] = class_1664.field_7563;
      var10000[(f3148 | 270608) + ~(f3148 & 270608) + 1 ^ -1193125583] = class_1664.field_7566;
      var10000[(f3148 | 527236) + ~(f3148 & 527236) + 1 ^ -1192332382] = class_1664.field_7565;
      var10000[(f3148 | 368677) + ~(f3148 & 368677) + 1 ^ -1193027582] = class_1664.field_7570;
      f3139 = var10000;
      var10000 = new class_1664[(f3148 | 161407) + ~(f3148 & 161407) + 1 ^ -1193013669];
      var10000[(f3148 | 663814) + ~(f3148 & 663814) + 1 ^ -1192470236] = class_1664.field_7563;
      var10000[(f3148 | 525034) + ~(f3148 & 525034) + 1 ^ -1192330551] = class_1664.field_7564;
      var10000[(f3148 | 355098) + ~(f3148 & 355098) + 1 ^ -1193077958] = class_1664.field_7568;
      var10000[(f3148 | 868933) + ~(f3148 & 868933) + 1 ^ -1192543644] = class_1664.field_7570;
      var10000[(f3148 | 755539) + ~(f3148 & 755539) + 1 ^ -1192362123] = class_1664.field_7566;
      var10000[(f3148 | 890307) + ~(f3148 & 890307) + 1 ^ -1192497692] = class_1664.field_7565;
      f3140 = var10000;
   }

   public static String _TOw937sQZTYHmytzUIDOsWu2pKAEfMJQKXNoLnloPRllT6FW0awfFCbtsFnqpSJfqXEMHbHiEgDuup22baMCy3oI0q5xWhFUQaQ/* $VF was: 7TOw937sQZTYHmytzUIDOsWu2pKAEfMJQKXNoLnloPRllT6FW0awfFCbtsFnqpSJfqXEMHbHiEgDuup22baMCy3oI0q5xWhFUQaQ*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
