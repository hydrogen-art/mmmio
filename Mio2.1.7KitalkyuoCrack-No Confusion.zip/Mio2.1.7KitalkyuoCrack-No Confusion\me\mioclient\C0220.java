package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class C0220 extends C0293<Enum<?>> {
   public final ArrayList<C0821> f4700 = new ArrayList<>();
   public final C0792 f4701;
   public final C0614 f4702;
   public boolean f4703;
   public int f4704;
   public int f4705;
   public int f4706;
   public int f4707;
   public final int f4708;
   public static int f4709 = 1415638110;

   public C0220(C1244 var1, C1008 var2, C0015<?> var3) {
      super(var1, var2, var3);
      this.f4701 = new C0792(
         () -> Float.intBitsToFloat((f4709 | 609682) + ~(f4709 & 609682) + 1 ^ 342467020)
               * this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3754.getValue(),
         (boolean)((f4709 | 945988) + ~(f4709 & 945988) + 1 ^ 1416528667)
      );
      this.f4702 = new C0614(
         () -> Float.intBitsToFloat((f4709 | 36546) + ~(f4709 & 36546) + 1 ^ 341861020) * C0879.f3743.f3754.getValue(),
         (boolean)((f4709 | 740769) + ~(f4709 & 740769) + 1 ^ 1416339966)
      );
      this.f4703 = (boolean)((f4709 | 11807) + ~(f4709 & 11807) + 1 ^ 1415627329);
      int var4 = this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL();
      int var5 = (f4709 | 336089) + ~(f4709 & 336089) + 1 ^ 1415957639;
      Enum[] var6 = (Enum[])((Enum)this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.m3387())
         .getDeclaringClass()
         .getEnumConstants();
      int var7 = var6.length;

      for (int var8 = (f4709 | 810549) + ~(f4709 & 810549) + 1 ^ 1416409707; var8 < var7; var8++) {
         Enum var9 = var6[var8];
         if (!C0680.m3727(var9)) {
            this.f4700.add(new C0821(this, C0391.m3982(var9), var4, var5));
            var4 += this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL();
            var5++;
         }
      }

      this.f4708 = var5;
   }

   public void m1918(int var1) {
      this.f4704 = var1;
   }

   @Override
   public void m0003(double var1, double var3, int var5) {
      if (!this.m$$STDt5JeVOLvpsDsEaqvKooezG4fl5lgQQRrGRKi1BSQx5RCTZiGpiNl9MhmPuA122tO5m0lfbSnyOh6ELiKUca8nxNN9fcD8V()) {
         super.m0003(var1, var3, var5);
         this.f4700.forEach(var5x -> var5x.m0003(var1, var3, var5));
         if (this.m1921(var1, var3)) {
            if (var5 == 0) {
               this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH
                  .m2603(
                     C0391.m3981((Enum)this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getValue())
                  );
               this.f4707 = (this.f4707 + ((f4709 | 796669) + ~(f4709 & 796669) + 1 ^ 1416416162)) % this.f4708;
            }

            if (var5 == ((f4709 | 936662) + ~(f4709 & 936662) + 1 ^ 1416537737)) {
               int var6 = (f4709 | 832355) + ~(f4709 & 832355) + 1 ^ 1416388413;

               for (int var7 = (f4709 | 206983) + ~(f4709 & 206983) + 1 ^ 1415824601;
                  var7
                     < (
                        (Enum[])((Enum)this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getValue())
                           .getDeclaringClass()
                           .getEnumConstants()
                     ).length;
                  var7++
               ) {
                  Enum var8 = ((Enum[])((Enum)this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH
                        .getValue())
                     .getDeclaringClass()
                     .getEnumConstants())[var7];
                  if (var8 == this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getValue()) {
                     this.f4707 = var6;
                     break;
                  }

                  if (!C0680.m3727(var8)) {
                     var6++;
                  }
               }

               this.f4703 = (boolean)(!this.f4703 ? (f4709 | 185757) + ~(f4709 & 185757) + 1 ^ 1415723458 : (f4709 | 17012) + ~(f4709 & 17012) + 1 ^ 1415622186);
               this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().m0239();
            }
         }
      }
   }

   public void m1919(double var1, double var3) {
      if (!this.m$$STDt5JeVOLvpsDsEaqvKooezG4fl5lgQQRrGRKi1BSQx5RCTZiGpiNl9MhmPuA122tO5m0lfbSnyOh6ELiKUca8nxNN9fcD8V()) {
         this.f4706 = this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().getY() + this.f4704;
         this.f4705 = this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().getX();
      }
   }

   public void m1920(class_332 var1, class_4587 var2, double var3, double var5) {
      if (this.m$$STDt5JeVOLvpsDsEaqvKooezG4fl5lgQQRrGRKi1BSQx5RCTZiGpiNl9MhmPuA122tO5m0lfbSnyOh6ELiKUca8nxNN9fcD8V()) {
         this.f4702.reset();
      } else {
         super.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(var1, var2, var3, var5);
         this.f4702.m2328((boolean)((f4709 | 228292) + ~(f4709 & 228292) + 1 ^ 1415813019));
         if (this.f4703) {
            this.f4701.m2326((float)(this.f4707 * this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL()));
            float var7 = this.f4701.m2325();
            C0438.m3962(
               var2,
               (float)(
                  this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                     + this.m$$NS6TKVieR7Xlj1stwELtzhosiSSdbbqnOWlolJ0xXC4zrfT8Xy1aT9eDfPClVRYR4rkRGXRycEszCfpQdjHBpGXBWCmEzMF7H()
                     + ((f4709 | 948674) + ~(f4709 & 948674) + 1 ^ 1416533405)
               ),
               (float)(this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY() + this.f4704)
                  + var7
                  + (float)this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL()
                  - Float.intBitsToFloat((f4709 | 557587) + ~(f4709 & 557587) + 1 ^ 1802006093),
               (float)(
                  this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                     + this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.m0240()
                     - ((f4709 | 663056) + ~(f4709 & 663056) + 1 ^ 1416294988)
               ),
               (float)(
                     this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                        + this.f4704
                        + this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL()
                           * ((f4709 | 570937) + ~(f4709 & 570937) + 1 ^ 1416125029)
                  )
                  + var7
                  - Float.intBitsToFloat((f4709 | 440438) + ~(f4709 & 440438) + 1 ^ 1801868328),
               this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3779.getValue()
            );
         } else {
            this.f4701.m2326((float)(-this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL()));
         }

         int var13 = this.f4703 ? (f4709 | 998175) + ~(f4709 & 998175) + 1 ^ 1416615744 : (f4709 | 877579) + ~(f4709 & 877579) + 1 ^ 1416464469;
         float var8 = Math.max(
            (float)this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.m0240() * this.f4702.m2325()
               - Float.intBitsToFloat((f4709 | 132443) + ~(f4709 & 132443) + 1 ^ 1810032901),
            Float.intBitsToFloat((f4709 | 390644) + ~(f4709 & 390644) + 1 ^ 342170026)
         );
         C0438.m3962(
            var2,
            (float)(
               this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                  + this.m$$NS6TKVieR7Xlj1stwELtzhosiSSdbbqnOWlolJ0xXC4zrfT8Xy1aT9eDfPClVRYR4rkRGXRycEszCfpQdjHBpGXBWCmEzMF7H()
                  + var13
            ),
            (float)(this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY() + this.f4704)
               + Float.intBitsToFloat((f4709 | 328435) + ~(f4709 & 328435) + 1 ^ 1801842349)
               + (float)var13,
            (float)this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX() + var8 - (float)var13,
            (float)(
                  this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                     + this.f4704
                     + this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL()
               )
               - Float.intBitsToFloat((f4709 | 952644) + ~(f4709 & 952644) + 1 ^ 1802396954),
            this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3779.getValue()
         );
         if (this.f4703) {
            this.f4700.forEach(var6 -> var6.m0001(var1, var2, var3, var5));
            if (C0879.f3743.f3758.getValue()) {
               C0438.m3960(
                  var2,
                  (float)(
                     this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                        + this.m$$NS6TKVieR7Xlj1stwELtzhosiSSdbbqnOWlolJ0xXC4zrfT8Xy1aT9eDfPClVRYR4rkRGXRycEszCfpQdjHBpGXBWCmEzMF7H()
                  ),
                  (float)(this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY() + this.f4704)
                     + Float.intBitsToFloat((f4709 | 493610) + ~(f4709 & 493610) + 1 ^ 1801938036),
                  (float)(
                     this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                        + this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.m0240()
                        - ((f4709 | 585525) + ~(f4709 & 585525) + 1 ^ 1416102761)
                  ),
                  (float)(
                        this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                           + this.f4704
                           + this.m0172()
                     )
                     - Float.intBitsToFloat((f4709 | 76320) + ~(f4709 & 76320) + 1 ^ 1805764222),
                  this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3779.getValue()
               );
            }
         }

         String var9 = new C1002()
            .m2591(C0391.m3982((Enum<?>)this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getValue()))
            .m2591(this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getName())
            .m2593("\u0001: \u0001");
         this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(
            var2,
            var9,
            () -> C0498.f4738
                  .m3889(
                     var1,
                     var9,
                     (float)(
                        this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                           + ((f4709 | 939237) + ~(f4709 & 939237) + 1 ^ 1416542399)
                     ),
                     (float)this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                        + this.m$$Q6v7Z8vHWixFGmnIwtPT9IRjbEDcp4pbIBg72K4rvMLMAvr4NRM7tkUiW5GGFIwz5ErOctZd5wyLot9rbgaFeWhVicVZ9yVxZ()
                        - this.m$$F4zako7ZnM6Q4oBXFdOvlGhEdnVEGYRWpCXVM3b498QSheE2JxUfvz3PeTnhcFs37rb30sKqxM30g1NRLsO51EuMfjqHIZr01()
                        + (float)this.f4704,
                     this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3776.getValue()
                  )
         );
         int var10 = this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL();

         for (C0821 var12 : this.f4700) {
            var12.m$$DqD0pf6q8HsA4IPLrbe51KvKqjiMPYBLwyKzpNpnOd8QFMC41ZvQvnmFwixCdhYjreSFQ3eejADSbrXoj4pmvbqKYpzXbvSGS(var10);
            var10 += this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL();
         }
      }
   }

   public boolean m1921(double var1, double var3) {
      return (boolean)(var1 > (double)this.f4705
            && var1
               < (double)(this.f4705 + this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().m0240())
            && var3 > (double)this.f4706
            && var3 < (double)(this.f4706 + ((f4709 | 542067) + ~(f4709 & 542067) + 1 ^ 1416145190))
         ? (f4709 | 732140) + ~(f4709 & 732140) + 1 ^ 1416349619
         : (f4709 | 694555) + ~(f4709 & 694555) + 1 ^ 1416262981);
   }

   @Override
   public int m0172() {
      if (this.m$$STDt5JeVOLvpsDsEaqvKooezG4fl5lgQQRrGRKi1BSQx5RCTZiGpiNl9MhmPuA122tO5m0lfbSnyOh6ELiKUca8nxNN9fcD8V()) {
         this.f4701.m4117((float)(-this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL()));
         return (f4709 | 634327) + ~(f4709 & 634327) + 1 ^ 1416184201;
      } else {
         return this.f4703
            ? this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL()
               + this.f4708 * this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL()
               + ((f4709 | 65043) + ~(f4709 & 65043) + 1 ^ 1415582284)
            : super.m0172();
      }
   }

   @Override
   public void init() {
      this.m1924(((Enum)this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getValue()).ordinal());
   }

   public int getY() {
      return this.f4706;
   }

   public int getX() {
      return this.f4705;
   }

   public boolean m1922() {
      return this.f4703;
   }

   public int m1923() {
      return this.f4707;
   }

   public void m1924(int var1) {
      this.f4707 = var1;
   }

   static {
      long var10000 = 4719246931884931431L;
   }

   public static String nwDDSQ4FwrYeRxu5uEgADxDZxoTaxofEumLrX5JZARVP38OhuIFHlGqh6xSDim0L9mqIKdEWfbH97FUdXbijeIKtixo3TA7aN9Iv(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
