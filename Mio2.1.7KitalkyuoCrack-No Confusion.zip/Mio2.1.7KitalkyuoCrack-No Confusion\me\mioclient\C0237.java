package me.mioclient;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_2680;
import net.minecraft.class_744;

public class C0237 implements C0045 {
   public static int f3837 = w.a<"B">(82726958284211400L, 257832362129977838L);

   public static boolean m1575(class_1657 var0) {
      return w.a<"Û">(
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
            w.a<"Û">(var0, 224997102751365724L),
            126037888129474044L
         ),
         (Predicate<class_2680>)var0x -> w.a<"Û">(var0x, class_2246.field_10343, 272812080270536171L),
         342868315342270588L
      );
   }

   public static boolean m1576(class_1657 var0) {
      return (boolean)(w.a<"B">(
                  w.a<"B">(
                     w.a<"Û">(var0, 232702264516987563L),
                     w.a<"Û">(var0, 224997102751365724L).field_1322,
                     w.a<"Û">(var0, 203672616216990522L),
                     377906593793678812L
                  ),
                  177993935146070759L
               )
               != class_2246.field_10382
            && !w.a<"Û">(var0, 254195947848459790L)
         ? (f3837 | 763162) + ~(f3837 & 763162) + 1 ^ -905377999
         : (f3837 | 610750) + ~(f3837 & 610750) + 1 ^ -905186412);
   }

   public static boolean m1577(class_1657 var0) {
      return (boolean)(!w.a<"B">(var0, 273496629978720125L) && !w.a<"Û">(var0, 158586513016203286L)
         ? (f3837 | 647898) + ~(f3837 & 647898) + 1 ^ -905232143
         : (f3837 | 962549) + ~(f3837 & 962549) + 1 ^ -905179681);
   }

   public static class_2338 m1578() {
      return w.a<"B">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 185161616837346565L);
   }

   public static class_2338 m1579(class_1309 var0) {
      return w.a<"B">(
         w.a<"Û">(var0, 358007713849864548L),
         (double)w.a<"B">(w.a<"Û">(var0, 268567970542010659L), 252407822608387354L),
         w.a<"Û">(var0, 334293516901328516L),
         377906593793678812L
      );
   }

   public static class_2350 m1580() {
      class_744 var0 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913;
      double[] var1 = w.a<"B">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L),
         var0,
         w.a<"B">(((long)f3837 | 581833L) + ~((long)f3837 & 581833L) + 1L ^ -4607182419705314590L, 317139102743630955L),
         108620803423508722L
      );
      return w.a<"B">(
         w.a<"B">(
               w.a<"B">(
                  var1[(f3837 | 54696) + ~(f3837 & 54696) + 1 ^ -905807998], var1[(f3837 | 309048) + ~(f3837 & 309048) + 1 ^ -905571053], 370151239157781531L
               ),
               207871222047649314L
            )
            - (double)C1074.f4547,
         143516572368317919L
      );
   }

   public static List<class_2338> m1581(class_1309 var0) {
      ArrayList var1 = new ArrayList();
      Set var2 = w.a<"B">(var0, 306837952283953468L);
      Iterator var3 = w.a<"Û">(var2, 194435811056609302L);

      while (w.a<"Û">(var3, 333900474771661065L)) {
         class_2338 var4 = (class_2338)w.a<"Û">(var3, 192468336863492695L);
         class_2382[] var5 = w.a<"Û">(C0354.f1073, 184257962110235255L);
         int var6 = var5.length;

         for (int var7 = (f3837 | 81789) + ~(f3837 & 81789) + 1 ^ -905732778; var7 < var6; var7++) {
            class_2382 var8 = var5[var7];
            class_2338 var9 = w.a<"Û">(var4, var8, 332515151004208459L);
            if (!w.a<"Û">(var2, var9, 338145669613544495L)) {
               w.a<"Û">(var1, var9, 276802003864609490L);
            }
         }
      }

      return var1;
   }

   public static Set<class_2338> m1582(class_1309 var0) {
      class_2338 var1 = w.a<"B">(var0, 185161616837346565L);
      HashSet var2 = new HashSet();
      class_238 var3 = w.a<"Û">(var0, 381939097272295099L);
      var3 = w.a<"Û">(var3, -C0397.f2037, 130605157384247280L);
      w.a<"Û">(var2, w.a<"B">(var3.field_1323, (double)w.a<"Û">(var1, 171752333823210875L), var3.field_1321, 377906593793678812L), 309270453639690490L);
      w.a<"Û">(var2, w.a<"B">(var3.field_1323, (double)w.a<"Û">(var1, 171752333823210875L), var3.field_1324, 377906593793678812L), 309270453639690490L);
      w.a<"Û">(var2, w.a<"B">(var3.field_1320, (double)w.a<"Û">(var1, 171752333823210875L), var3.field_1321, 377906593793678812L), 309270453639690490L);
      w.a<"Û">(var2, w.a<"B">(var3.field_1320, (double)w.a<"Û">(var1, 171752333823210875L), var3.field_1324, 377906593793678812L), 309270453639690490L);
      return var2;
   }

   public static boolean m1583() {
      return (boolean)(w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 291003760205423210L),
               314808447908074059L
            )
            < ((f3837 | 130152) + ~(f3837 & 130152) + 1 ^ -905748923)
         ? (f3837 | 448795) + ~(f3837 & 448795) + 1 ^ -905675983
         : (f3837 | 17050) + ~(f3837 & 17050) + 1 ^ -905781071);
   }

   public static boolean m1584(class_1309 var0) {
      Iterator var1 = w.a<"Û">(w.a<"Û">(var0, 265534388557724891L), 191661729848227466L);

      while (w.a<"Û">(var1, 333900474771661065L)) {
         class_1799 var2 = (class_1799)w.a<"Û">(var1, 192468336863492695L);
         if (!w.a<"Û">(var2, 330190014994709712L)) {
            return (boolean)((f3837 | 946965) + ~(f3837 & 946965) + 1 ^ -905129665);
         }
      }

      return (boolean)((f3837 | 94211) + ~(f3837 & 94211) + 1 ^ -905719256);
   }

   public static boolean m1585(class_1657 var0) {
      return w.a<"Û">(
         w.a<"Û">(w.a<"Û">(var0, 128194116942239918L), w.a<"Û">(class_1304.field_6174, 296145192384863639L), 266240718425717133L),
         class_1802.field_8833,
         282470456889867724L
      );
   }

   public static boolean m1586() {
      if (C0671.f4650) {
         return w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L);
      } else {
         C0671.f4650 = (boolean)((f3837 | 972881) + ~(f3837 & 972881) + 1 ^ -905151877);
         boolean var0 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L
         );
         C0671.f4650 = (boolean)((f3837 | 938659) + ~(f3837 & 938659) + 1 ^ -905121656);
         return var0;
      }
   }

   public static class_1268 m1587(class_1268 var0) {
      return var0 == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808;
   }
}
