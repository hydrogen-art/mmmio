package me.mioclient;

public class C0129 extends RuntimeException {
   public C0129(Class<?> var1) {
      super("No registered lambda listener for '" + var1.getName() + "'.");
   }
}
