package me.mioclient;

import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;

record C0429() {
   public final class_2350 f3810;
   public final class_2338 f3811;
   public final class_243 f3812;
   public static int f3813 = w.a<"B">(8265906058781227215L, 257832362129977838L);

   public C0429(class_2350 var1, class_2338 var2, class_243 var3) {
      this.f3810 = var1;
      this.f3811 = var2;
      this.f3812 = var3;
   }

   public class_2350 m3577() {
      return this.f3810;
   }

   public class_2338 m3578() {
      return this.f3811;
   }

   public class_243 m3579() {
      return this.f3812;
   }
}
