package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_332;
import net.minecraft.class_4587;

public class C0516 extends C0871 {
   public boolean f3930;
   public boolean f3931;
   public boolean f3932;
   public int f3933;
   public int f3934;
   public int f3935;
   public C0782 f3936;
   public C1033[] f3937;
   public static int f3938 = 1736167782;

   public C0516(C1244 var1, int var2) {
      super(var1, var2, (f3938 | 921289) + ~(f3938 & 921289) + 1 ^ 1735778233, (f3938 | 229510) + ~(f3938 & 229510) + 1 ^ 1735938550);
      this.f3930 = (boolean)((f3938 | 282059) + ~(f3938 & 282059) + 1 ^ 1736416429);
      this.f3931 = (boolean)((f3938 | 778007) + ~(f3938 & 778007) + 1 ^ 1735396977);
      this.f3932 = (boolean)((f3938 | 526342) + ~(f3938 & 526342) + 1 ^ 1735645536);
      this.f3933 = (f3938 | 237356) + ~(f3938 & 237356) + 1 ^ 1735937610;
      this.f3934 = (f3938 | 906055) + ~(f3938 & 906055) + 1 ^ 1735787041;
      this.f3935 = (f3938 | 242902) + ~(f3938 & 242902) + 1 ^ 1735943600;
   }

   @Override
   public void m0360() {
      if (this.f3936 == null) {
         this.m3611();
      }

      if (!this.f3931) {
         if (this.f3930) {
            this.f3930 = (boolean)((f3938 | 735916) + ~(f3938 & 735916) + 1 ^ 1735453642);
            this.m3617();
         } else {
            this.m3614();
         }
      }
   }

   @Override
   public int m0361() {
      return (f3938 | 415305) + ~(f3938 & 415305) + 1 ^ 1736279771;
   }

   @Override
   public void m0001(class_332 var1, class_4587 var2, double var3, double var5) {
      super.m0001(var1, var2, var3, var5);

      for (int var7 = (f3938 | 845407) + ~(f3938 & 845407) + 1 ^ 1735866169;
         var7 < this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf;
         var7++
      ) {
         for (int var8 = (f3938 | 352275) + ~(f3938 & 352275) + 1 ^ 1736356213;
            var8 < this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs;
            var8++
         ) {
            C1033 var9 = this.m3612(
               var8,
               this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf
                  - var7
                  - ((f3938 | 621359) + ~(f3938 & 621359) + 1 ^ 1735567944)
            );
            if (var9 != C1033.f3162) {
               this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(var2, var8, var7, var9.m1311());
            }
         }
      }

      if (this.f3936.m1375() != C1033.f3162) {
         C0782 var13 = new C0782();
         var13.m1370(this.f3936.m1375());

         for (int var15 = (f3938 | 594330) + ~(f3938 & 594330) + 1 ^ 1735573756; var15 < ((f3938 | 358137) + ~(f3938 & 358137) + 1 ^ 1736353691); var15++) {
            var13.m1371(var15, this.f3936.m1373(var15));
            var13.m1372(var15, this.f3936.m1374(var15));
            int var17 = this.f3934 + this.f3936.m1373(var15);
            int var10 = this.f3935 - this.f3936.m1374(var15);
            Color var11 = this.f3936.m1375().m1311();
            this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(
               var2,
               var17,
               this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf
                  - var10
                  - ((f3938 | 670327) + ~(f3938 & 670327) + 1 ^ 1735518992),
               var11
            );
         }

         int var16 = this.f3935;

         while (var16 > 0 && this.m3618(var13, this.f3934, var16 - ((f3938 | 718851) + ~(f3938 & 718851) + 1 ^ 1735469412))) {
            var16--;
         }

         for (int var18 = (f3938 | 558325) + ~(f3938 & 558325) + 1 ^ 1735611795; var18 < ((f3938 | 843833) + ~(f3938 & 843833) + 1 ^ 1735864667); var18++) {
            int var19 = this.f3934 + var13.m1373(var18);
            int var20 = var16 - var13.m1374(var18);
            Color var12 = this.f3936.m1375().m1311();
            this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(
               var2,
               var19,
               this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf
                  - var20
                  - ((f3938 | 948935) + ~(f3938 & 948935) + 1 ^ 1735764896),
               C0152.m3473(var12, (f3938 | 447762) + ~(f3938 & 447762) + 1 ^ 1736246342)
            );
         }
      }

      if (this.f3932) {
         int var10000 = this.f3933;
         String var14 = new C1002().m2578(var10000).m2593("Score \u0001. Press R.");
         C0498.f4738
            .m3889(
               var1,
               var14,
               (float)(
                  (double)this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().getX()
                     + (double)this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().m0240()
                        * C1074.f4550
                     - (double)C0498.f4738.m3896(var14) * C1074.f4550
               ),
               (float)(
                  (double)(
                        this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().getY()
                           + this.m$$hlCUpAMCB8w0fikXDazwCNyOBsPOGWgAm2lmO5tu7dGyqkbhliec158gzgZe9bnF3DuoOxLmXH5dfCU0wQDHsWXD8knX2Gis1
                     )
                     + (double)this.m3621() * C1074.f4550
               ),
               Color.white
            );
      } else {
         C0498.f4738
            .m3893(
               var1,
               String.valueOf(this.f3933),
               (float)this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().getX()
                  + Float.intBitsToFloat((f3938 | 243417) + ~(f3938 & 243417) + 1 ^ 1488480191),
               (float)(
                  this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().getY()
                     + this.m$$hlCUpAMCB8w0fikXDazwCNyOBsPOGWgAm2lmO5tu7dGyqkbhliec158gzgZe9bnF3DuoOxLmXH5dfCU0wQDHsWXD8knX2Gis1
                     + ((f3938 | 157130) + ~(f3938 & 157130) + 1 ^ 1736029357)
               ),
               Float.intBitsToFloat((f3938 | 329206) + ~(f3938 & 329206) + 1 ^ 1480512656),
               Color.white
            );
      }
   }

   public void m3610(int var1) {
      switch (var1) {
         case 32:
            this.m3613();
            break;
         case 68:
            this.m3614();
            break;
         case 82:
            this.m3611();
            break;
         case 262:
            this.m3619(this.f3936, this.f3934 + ((f3938 | 38545) + ~(f3938 & 38545) + 1 ^ 1736132598), this.f3935);
            break;
         case 263:
            this.m3619(this.f3936, this.f3934 - ((f3938 | 501292) + ~(f3938 & 501292) + 1 ^ 1736210251), this.f3935);
            break;
         case 264:
            this.m3619(this.f3936.m1380(), this.f3934, this.f3935);
            break;
         case 265:
            this.m3619(this.f3936.m1379(), this.f3934, this.f3935);
      }
   }

   public void m3611() {
      this.f3932 = (boolean)((f3938 | 717985) + ~(f3938 & 717985) + 1 ^ 1735468487);
      this.f3936 = new C0782();
      this.f3937 = new C1033[this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs
         * this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf];
      this.m3615();
      this.m3617();
   }

   public C1033 m3612(int var1, int var2) {
      return this.f3937[var2 * this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs + var1];
   }

   public void m3613() {
      int var1 = this.f3935;

      while (var1 > 0 && this.m3619(this.f3936, this.f3934, var1 - ((f3938 | 718100) + ~(f3938 & 718100) + 1 ^ 1735468147))) {
         var1--;
      }

      this.m3616();
   }

   public void m3614() {
      if (!this.m3619(this.f3936, this.f3934, this.f3935 - ((f3938 | 941828) + ~(f3938 & 941828) + 1 ^ 1735757411))) {
         this.m3616();
      }
   }

   public void m3615() {
      this.f3933 = (f3938 | 389339) + ~(f3938 & 389339) + 1 ^ 1736319421;

      for (int var1 = (f3938 | 21047) + ~(f3938 & 21047) + 1 ^ 1736147793;
         var1
            < this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf
               * this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs;
         var1++
      ) {
         this.f3937[var1] = C1033.f3162;
      }
   }

   public void m3616() {
      for (int var1 = (f3938 | 445909) + ~(f3938 & 445909) + 1 ^ 1736252595; var1 < ((f3938 | 842024) + ~(f3938 & 842024) + 1 ^ 1735854154); var1++) {
         int var2 = this.f3934 + this.f3936.m1373(var1);
         int var3 = this.f3935 - this.f3936.m1374(var1);
         this.f3937[var3 * this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs + var2] = this.f3936
            .m1375();
      }

      this.m3620();
      if (!this.f3930) {
         this.m3617();
      }
   }

   public void m3617() {
      this.f3936.m1376();
      this.f3934 = this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs
            / ((f3938 | 924118) + ~(f3938 & 924118) + 1 ^ 1735772338)
         + ((f3938 | 152866) + ~(f3938 & 152866) + 1 ^ 1736016965);
      this.f3935 = this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf
         - ((f3938 | 521291) + ~(f3938 & 521291) + 1 ^ 1736189228)
         + this.f3936.m1378();
      if (!this.m3619(this.f3936, this.f3934, this.f3935)) {
         this.f3936.m1370(C1033.f3162);
         this.f3932 = (boolean)((f3938 | 544384) + ~(f3938 & 544384) + 1 ^ 1735630823);
      }
   }

   public boolean m3618(C0782 var1, int var2, int var3) {
      for (int var4 = (f3938 | 718843) + ~(f3938 & 718843) + 1 ^ 1735468701; var4 < ((f3938 | 355786) + ~(f3938 & 355786) + 1 ^ 1736359080); var4++) {
         int var5 = var2 + var1.m1373(var4);
         int var6 = var3 - var1.m1374(var4);
         if (var5 < 0
            || var5 >= this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs
            || var6 < 0
            || var6 >= this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf) {
            return (boolean)((f3938 | 704385) + ~(f3938 & 704385) + 1 ^ 1735487207);
         }

         if (this.m3612(var5, var6) != C1033.f3162) {
            return (boolean)((f3938 | 800611) + ~(f3938 & 800611) + 1 ^ 1735910917);
         }
      }

      return (boolean)((f3938 | 641326) + ~(f3938 & 641326) + 1 ^ 1735530569);
   }

   public boolean m3619(C0782 var1, int var2, int var3) {
      if (!this.m3618(var1, var2, var3)) {
         return (boolean)((f3938 | 762105) + ~(f3938 & 762105) + 1 ^ 1735422367);
      } else {
         this.f3936 = var1;
         this.f3934 = var2;
         this.f3935 = var3;
         return (boolean)((f3938 | 107286) + ~(f3938 & 107286) + 1 ^ 1736077937);
      }
   }

   public void m3620() {
      int var1 = (f3938 | 400758) + ~(f3938 & 400758) + 1 ^ 1736297488;

      for (int var2 = this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf
            - ((f3938 | 741980) + ~(f3938 & 741980) + 1 ^ 1735426875);
         var2 >= 0;
         var2--
      ) {
         int var3 = (f3938 | 78982) + ~(f3938 & 78982) + 1 ^ 1736107489;

         for (int var4 = (f3938 | 432481) + ~(f3938 & 432481) + 1 ^ 1736263687;
            var4 < this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs;
            var4++
         ) {
            if (this.m3612(var4, var2) == C1033.f3162) {
               var3 = (f3938 | 402115) + ~(f3938 & 402115) + 1 ^ 1736307621;
               break;
            }
         }

         if (var3 != 0) {
            var1++;

            for (int var6 = var2;
               var6
                  < this.m$$xIlMa0S15okxnSdTCSiGBkySzlukFtKuaGZMG7FOWgbNrb6oxqXJr1DKWzwDsWbs8sSeFZHDS5cyuttprRxfnQJyms2rOgSgf
                     - ((f3938 | 585497) + ~(f3938 & 585497) + 1 ^ 1735605886);
               var6++
            ) {
               for (int var5 = (f3938 | 838503) + ~(f3938 & 838503) + 1 ^ 1735858689;
                  var5 < this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs;
                  var5++
               ) {
                  this.f3937[var6 * this.m$$zWfTxxA3mBdhbLb06Qx0drZBS5iGsr9FRipZsLa4WrqetkRJ2thRPx2rzQszoEGJCZ6H6zBUxk3XB2OnAxbJjc4fEMMM1okJs + var5] = this.m3612(
                     var5, var6 + ((f3938 | 362753) + ~(f3938 & 362753) + 1 ^ 1736333414)
                  );
               }
            }
         }
      }

      if (var1 > 0) {
         this.f3933 += var1;
         this.f3930 = (boolean)((f3938 | 763454) + ~(f3938 & 763454) + 1 ^ 1735423833);
         this.f3936.m1370(C1033.f3162);
      }
   }

   public int m3621() {
      return this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().m0240();
   }

   static {
      long var10000 = 5245680112262577515L;
   }

   public static String SKlL6jp8fiwJDAoxPFgA653zRZBKdGloAomPiG9JUdo5gZ4e10EuJJMbOz0AMqz4f16X5XiwKTt26UI8qPeLyxkr9U2oRVhTKeVC(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
