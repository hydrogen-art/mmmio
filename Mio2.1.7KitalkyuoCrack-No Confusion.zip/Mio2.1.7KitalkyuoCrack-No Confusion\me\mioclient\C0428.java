package me.mioclient;

import net.minecraft.class_2338;
import net.minecraft.class_2350;

record C0428() {
   public final class_2350 f4293;
   public final class_2338 f4294;
   public static int f4295 = w.a<"B">(7362548896023834435L, 257832362129977838L);

   public C0428(class_2350 var1, class_2338 var2) {
      this.f4293 = var1;
      this.f4294 = var2;
   }

   public class_2350 m3790() {
      return this.f4293;
   }

   public class_2338 m3791() {
      return this.f4294;
   }
}
