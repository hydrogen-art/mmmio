package me.mioclient;

import java.util.LinkedList;
import java.util.Queue;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_6374;

public class C0239 implements C0045 {
   public final Queue<class_2596<?>> f4499 = new LinkedList<>();
   public final C1194 f4500;
   public static int f4501 = w.a<"B">(3384342315901079761L, 257832362129977838L);

   public C0239(C1194 var1) {
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
      this.f4500 = var1;
   }

   @C1027
   public void m1813(C0612 var1) {
      if (!w.a<"Û">(this.f4500, 141648292726139937L) && w.a<"Û">(this.f4500.f1166, 174312564406604366L) == C1195.f2244) {
         this.f4500.f1177 = w.a<"B">(
            w.a<"Û">((Integer)w.a<"Û">(this.f4500.f1168, 174312564406604366L), 260981171345819427L),
            this.f4500.f1177 + w.a<"Û">((Integer)w.a<"Û">(this.f4500.f1169, 174312564406604366L), 260981171345819427L),
            244670932612973720L
         );
      }
   }

   @C1027
   public void m1814(C0132 var1) {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         if (w.a<"Û">(this.f4500, 314537768572362865L)
            && w.a<"Û">(this.f4500.f1166, 174312564406604366L) == C1195.f2245
            && w.a<"Û">(var1, 127302489982333990L) instanceof class_6374 var2) {
            if (!w.a<"Û">(this.f4500, 381859303287846479L)
               && w.a<"Û">(this.f4499, 176073280393572450L) < w.a<"Û">((Integer)w.a<"Û">(this.f4500.f1168, 174312564406604366L), 260981171345819427L)) {
               w.a<"Û">(var1, 385440235371820560L);
               w.a<"Û">(this.f4499, var2, 276905752407976510L);
            }

            if (!w.a<"Û">(this.f4499, 296374206093673190L)) {
               w.a<"Û">(var1, 385440235371820560L);
            }
         }

         if (w.a<"Û">(this.f4500.f1166, 174312564406604366L) == C1195.f2244 && w.a<"Û">(var1, 127302489982333990L) instanceof class_2828) {
            if (!w.a<"Û">(this.f4500, 141648292726139937L)
               || this.f4500.f1177 == 0
               || !w.a<"Û">(this.f4500, 314537768572362865L) && w.a<"Û">(this.f4500.f1170, 174312564406604366L) == C0055.f1838) {
               return;
            }

            this.f4500.f1177 = w.a<"B">(
               (f4501 | 926240) + ~(f4501 & 926240) + 1 ^ -1759983343,
               this.f4500.f1177 - ((f4501 | 408671) + ~(f4501 & 408671) + 1 ^ -1760503953),
               250328644894878425L
            );
         }
      }
   }
}
