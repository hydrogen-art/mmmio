package me.mioclient;

public class C0190 extends C1180 {
}
