package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0212 implements C0196 {
   f0018("Plain"),
   f0019("Strict"),
   f0020("Instant");

   public final String f0021;

   public C0212(String var3) {
      this.f0021 = var3;
   }

   @Override
   public String getName() {
      return this.f0021;
   }

   public static String qnqobkunNw5whxUllKJrtVKYovfFkuACdZP7cuehTJftLvI9A2N5B4b3vImBK322BtppMD1zY0Sx2QLaZMwESesXVt3u5exCTndN(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
