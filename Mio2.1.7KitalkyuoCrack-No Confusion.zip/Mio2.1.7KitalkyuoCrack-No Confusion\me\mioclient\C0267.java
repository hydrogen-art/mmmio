package me.mioclient;

import java.util.function.Predicate;

public class C0267 implements Predicate {
   public C1055 f1021;

   public C0267(C1055 var1) {
      this.f1021 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1021.f4807, 174312564406604366L) == C1123.f0859;
   }
}
