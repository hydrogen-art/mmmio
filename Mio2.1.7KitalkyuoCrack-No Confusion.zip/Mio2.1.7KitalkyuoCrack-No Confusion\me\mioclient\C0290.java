package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.function.Predicate;

public final class C0290<T extends Number> extends C0015<T> {
   public String f2920 = "";
   public static int f2921 = w.a<"B">(2596347275788810114L, 257832362129977838L);

   public C0290(String var1, T var2, T var3, T var4, Predicate<T> var5) {
      super(var1, (T)var2, (T)var3, (T)var4, var5);
   }

   public C0290(String var1, T var2, T var3, T var4) {
      super(var1, (T)var2, (T)var3, (T)var4);
   }

   public void m3234(T var1) {
      super.m2603((T)w.a<"Û">(this, var1, 360106131429417949L));
   }

   public C0290<T> m3235(String var1) {
      this.f2920 = var1;
      return this;
   }

   public String m3236() {
      return this.f2920;
   }

   public Number m3237(T var1) {
      if (w.a<"Û">(this, 174312564406604366L) instanceof Double) {
         return w.a<"B">(w.a<"Û">(var1, 206993253953599792L), 165155940100814265L);
      } else if (w.a<"Û">(this, 174312564406604366L) instanceof Integer) {
         return w.a<"B">(w.a<"Û">(var1, 253079423968864392L), 367942141483020029L);
      } else {
         return (Number)(w.a<"Û">(this, 174312564406604366L) instanceof Float
            ? w.a<"B">(w.a<"Û">(var1, 164830166794491443L), 243402859552372891L)
            : w.a<"B">(w.a<"Û">(var1, 183999791045411728L), 279131300036783447L));
      }
   }

   @Override
   public void m0645(String var1) {
      if (w.a<"Û">(this, 174312564406604366L) instanceof Double) {
         w.a<"Û">(this, w.a<"B">(w.a<"B">(var1, 323543520957720825L), 165155940100814265L), 345659706916219305L);
      } else if (w.a<"Û">(this, 174312564406604366L) instanceof Integer) {
         w.a<"Û">(this, w.a<"B">(w.a<"B">(var1, 217089499813018459L), 367942141483020029L), 345659706916219305L);
      } else if (w.a<"Û">(this, 174312564406604366L) instanceof Float) {
         w.a<"Û">(this, w.a<"B">(w.a<"B">(var1, 345649987783673028L), 243402859552372891L), 345659706916219305L);
      }
   }

   @Override
   public JsonElement toJson() {
      return new JsonPrimitive((Number)w.a<"Û">(this, 174312564406604366L));
   }

   @Override
   public void fromJson(JsonElement var1) {
      if (w.a<"Û">(this, 174312564406604366L) instanceof Double) {
         w.a<"Û">(this, w.a<"B">(w.a<"Û">(var1, 237233785586873407L), 165155940100814265L), 345659706916219305L);
      } else if (w.a<"Û">(this, 174312564406604366L) instanceof Integer) {
         w.a<"Û">(this, w.a<"B">(w.a<"Û">(var1, 113424266836384094L), 367942141483020029L), 345659706916219305L);
      } else if (w.a<"Û">(this, 174312564406604366L) instanceof Float) {
         w.a<"Û">(this, w.a<"B">(w.a<"Û">(var1, 376986914090330882L), 243402859552372891L), 345659706916219305L);
      }
   }
}
