package me.mioclient;

import java.util.function.Predicate;

public class C0420 implements Predicate {
   public C0814 f4375;

   public C0420(C0814 var1) {
      this.f4375 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4375.f4945, 254992554122318132L);
   }
}
