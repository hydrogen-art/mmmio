package me.mioclient;

import java.util.function.Predicate;

public class C0104 implements Predicate {
   public C0244 f3451;

   public C0104(C0244 var1) {
      this.f3451 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3451.f2891, 254992554122318132L);
   }
}
