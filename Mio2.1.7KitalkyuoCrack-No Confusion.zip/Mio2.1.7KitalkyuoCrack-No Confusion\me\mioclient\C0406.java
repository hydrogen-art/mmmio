package me.mioclient;

import java.util.function.Predicate;

public class C0406 implements Predicate {
   public C1161 f3720;

   public C0406(C1161 var1) {
      this.f3720 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3720.f1185, 254992554122318132L);
   }
}
