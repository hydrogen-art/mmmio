package me.mioclient;

import java.util.function.Predicate;

public class C0261 implements Predicate {
   public C0911 f4904;

   public C0261(C0911 var1) {
      this.f4904 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4904.f0794, 254992554122318132L);
   }
}
