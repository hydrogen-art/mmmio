package me.mioclient;

public class C0158 extends C1180 {
}
