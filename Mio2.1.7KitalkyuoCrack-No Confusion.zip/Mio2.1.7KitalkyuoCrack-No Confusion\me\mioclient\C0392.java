package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_2172;
import net.minecraft.class_410;
import net.minecraft.class_303.class_7590;

public final class C0392 extends C0219 {
   public static boolean f2332 = (boolean)((C0392.f2334 | 634106) + ~(C0392.f2334 & 634106) + 1 ^ -712391345);
   public static final String f2333 = "ㅤ";
   public static int f2334 = w.a<"B">(297042616344390667L, 257832362129977838L);

   public C0392() {
      super("panic");
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         var1,
         (Command)var1x -> {
            w.a<"Û">(
               this,
               (Runnable)() -> w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, new class_410(var1xx -> {
                        if (var1xx) {
                           w.a<"Û">(this, 238567495561958142L);
                        }

                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, null, 304438186446504550L
                        );
                     }, w.a<"B">("Unload the client.", 228465064790135899L), w.a<"B">("Continue?", 228465064790135899L)), 304438186446504550L
                  ),
               122279747764383364L
            );
            return (f2334 | 705479) + ~(f2334 & 705479) + 1 ^ -712332685;
         },
         286944572020109927L
      );
   }

   public void m3018() {
      w.a<"Û">(C0933.f1411, 139714358080866868L);
      f2332 = (boolean)((f2334 | 528551) + ~(f2334 & 528551) + 1 ^ -712476397);
      String var1 = w.a<"B">(178229868054081660L);
      w.a<"B">("ㅤ", 114568770405329757L);
      Iterator var2 = w.a<"Û">((List)w.a<"Û">(C0933.f1413, 268370374673263607L), 341496865259068134L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         C1266 var3 = (C1266)w.a<"Û">(var2, 192468336863492695L);
         w.a<"Û">(
            var3,
            (Function<C1088, C1088>)var0 -> w.a<"Û">(var0, (f2334 | 348337) + ~(f2334 & 348337) + 1 ^ 712689403, 297190102171421307L),
            123564429822166450L
         );
         if (w.a<"Û">(var3, 314537768572362865L)) {
            w.a<"Û">(var3, 289688631157446311L);
         }
      }

      w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1705, 294062101267071896L),
            373630957266314650L
         ),
         (Predicate<String>)var1x -> w.a<"Û">(var1x, var1, 339063961306778534L),
         218261126359876747L
      );
      w.a<"Û">(
         w.a<"Û">(
            (C0207)w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1705, 294062101267071896L
            ),
            221571662279219624L
         ),
         (Predicate<class_7590>)var0 -> {
            C1066 var1x = (C1066)var0;
            return (boolean)(w.a<"Û">(var1x, 270057427045115755L) != null
                  && w.a<"Û">(w.a<"Û">(w.a<"Û">(var1x, 270057427045115755L), 327505817645347795L), 274031710563829614L) < 0
               ? (f2334 | 18362) + ~(f2334 & 18362) + 1 ^ -713019890
               : (f2334 | 452836) + ~(f2334 & 452836) + 1 ^ -712605359);
         },
         372804948295703628L
      );
      w.a<"Û">(
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1705, 294062101267071896L),
            373630957266314650L
         ),
         (Predicate<String>)var1x -> w.a<"Û">(var1x, var1, 339063961306778534L),
         218261126359876747L
      );
   }

   public static String i6iALjz0xCcy9BYJOCtevddbDRnOcGJEU9Nhazg7cWkSLtYthEahvSuAGKyXmOZ9fMQCUCbUvdexjPAIO0FDMvpN7PDzyT5HDuVZ(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
