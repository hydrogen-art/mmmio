package me.mioclient;

import java.util.function.Predicate;

public class C0317 implements Predicate {
   public C0547 f0273;

   public C0317(C0547 var1) {
      this.f0273 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0273.f4512, 254992554122318132L);
   }
}
