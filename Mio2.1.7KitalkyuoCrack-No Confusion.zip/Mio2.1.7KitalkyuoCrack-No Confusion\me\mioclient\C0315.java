package me.mioclient;

import net.minecraft.class_1799;

public final class C0315 extends C0314 {
   public class_1799 f2052;

   public C0315(class_1799 var1) {
      this.f2052 = var1;
   }

   public class_1799 m0889() {
      return this.f2052;
   }
}
