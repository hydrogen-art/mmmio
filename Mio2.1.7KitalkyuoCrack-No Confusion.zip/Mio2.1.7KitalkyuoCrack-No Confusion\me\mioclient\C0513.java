package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.function.Predicate;
import me.mioclient.mixin.ducks.DuckMobSpawnerLogic;
import net.minecraft.class_1923;
import net.minecraft.class_1972;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2636;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_3610;
import net.minecraft.class_4184;
import net.minecraft.class_642;
import net.minecraft.class_6880;
import net.minecraft.class_2338.class_2339;

public class C0513 extends C1266 {
   public final C0015<Boolean> f1324;
   public final C0015<Integer> f1325;
   public final C0015<Integer> f1326;
   public final C0015<Integer> f1327;
   public final C0015<Float> f1328;
   public final C0015<Boolean> f1329;
   public final C0015<Color> f1330;
   public final C0015<Color> f1331;
   public final C0015<Boolean> f1332;
   public final C0015<Color> f1333;
   public final C0015<Color> f1334;
   public final C0015<Boolean> f1335;
   public final C0015<Color> f1336;
   public final C0015<Color> f1337;
   public final C0015<Boolean> f1338;
   public final C0015<Boolean> f1339;
   public final C0015<Color> f1340;
   public final C0015<Color> f1341;
   public final C0015<Integer> f1342;
   public final C0015<Boolean> f1343;
   public final C0015<Boolean> f1344;
   public final C0015<Color> f1345;
   public final C0015<Color> f1346;
   public final C0015<Boolean> f1347;
   public final C0015<C1348> f1348;
   public final C0015<Float> f1349;
   public static final class_2339 f1350 = new class_2339();
   public final Map<C1263, List<C0188>> f1351;
   public final List<class_2338> f1352;
   public final List<C0188> f1353;
   public final C0083 f1354;
   public final C0962 f1355;
   public final C0633 f1356;
   public final C0755 f1357;
   public static int f1358 = w.a<"B">(5836387324078371050L, 257832362129977838L);

   public C0513() {
      super("NewChunks", "Allows you to see which chunks were generated before.", C1045.f3177);
      w.a<"B">(this, 242859112966675773L);
      this.f1351 = w.a<"B">(new HashMap(), 297409492390560467L);
      this.f1352 = w.a<"B">(new C0706((f1358 | 183893) + ~(f1358 & 183893) + 1 ^ -844912700), 291435362423732219L);
      this.f1353 = new ArrayList<>();
      this.f1354 = new C0083();
      this.f1355 = new C0962(this);
      this.f1356 = new C0633();
      this.f1357 = new C0755(
         (f1358 | 821759) + ~(f1358 & 821759) + 1 ^ -844242040,
         (var1, var2) -> {
            w.a<"Û">(this, var1, var2, 225501796315327391L);
            if ((
                     w.a<"Û">((Boolean)w.a<"Û">(this.f1332, 174312564406604366L), 354697271520518137L)
                        || w.a<"Û">((Boolean)w.a<"Û">(this.f1329, 174312564406604366L), 354697271520518137L)
                  )
                  && !w.a<"Û">((Boolean)w.a<"Û">(this.f1324, 174312564406604366L), 354697271520518137L)
               || w.a<"Û">((Boolean)w.a<"Û">(this.f1338, 174312564406604366L), 354697271520518137L)) {
               for (int var3 = (f1358 | 372506) + ~(f1358 & 372506) + 1 ^ -844839572; var3 < ((f1358 | 171628) + ~(f1358 & 171628) + 1 ^ -844893174); var3++) {
                  for (int var4 = (f1358 | 944169) + ~(f1358 & 944169) + 1 ^ -844168609;
                     var4
                        < w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 290783177543878799L
                        );
                     var4++
                  ) {
                     for (int var5 = (f1358 | 766128) + ~(f1358 & 766128) + 1 ^ -844440890;
                        var5 < ((f1358 | 912760) + ~(f1358 & 912760) + 1 ^ -844331234);
                        var5++
                     ) {
                        w.a<"Û">(f1350, w.a<"Û">(var1, 246289701840133598L) + var3, var4, w.a<"Û">(var1, 255085604585515475L) + var5, 254891861700948234L);
                        class_2680 var6 = w.a<"Û">(var2, f1350, 330559084091970443L);
                        if (w.a<"Û">(this, w.a<"Û">(var6, 152622786059621427L), 177840527058196017L)) {
                           return;
                        }

                        class_3610 var7 = w.a<"Û">(var2, var3, var4, var5, 265922468729811144L);
                        if (!w.a<"Û">(var7, 249198674057315725L) && !w.a<"Û">(var7, 114855608555999604L)) {
                           if (w.a<"Û">((Boolean)w.a<"Û">(this.f1338, 174312564406604366L), 354697271520518137L)) {
                              class_3610 var8 = w.a<"Û">(var2, var3, var4 - ((f1358 | 441783) + ~(f1358 & 441783) + 1 ^ -844638272), var5, 265922468729811144L);
                              if (w.a<"Û">(var8, 249198674057315725L)
                                    && !w.a<"Û">(
                                       w.a<"Û">(
                                          var2,
                                          w.a<"B">(
                                             (double)var3,
                                             (double)(var4 - ((f1358 | 969402) + ~(f1358 & 969402) + 1 ^ -844128051)),
                                             (double)var5,
                                             377906593793678812L
                                          ),
                                          330559084091970443L
                                       ),
                                       363526675043086623L
                                    )
                                 || w.a<"Û">(var8, 114855608555999604L)
                                 || w.a<"Û">(this, f1350, var2, 362689112922547057L)) {
                                 int var20 = (f1358 | 959688) + ~(f1358 & 959688) + 1 ^ -844116289;

                                 for (int var22 = (f1358 | 380018) + ~(f1358 & 380018) + 1 ^ -844847611;
                                    var22 <= w.a<"Û">((Integer)w.a<"Û">(this.f1342, 174312564406604366L), 260981171345819427L);
                                    var22++
                                 ) {
                                    class_3610 var11 = w.a<"Û">(var2, var3, var4 + var22, var5, 265922468729811144L);
                                    if (w.a<"Û">(var11, 249198674057315725L) || w.a<"Û">(var11, 114855608555999604L)) {
                                       var20 = (f1358 | 911508) + ~(f1358 & 911508) + 1 ^ -844332318;
                                       break;
                                    }
                                 }

                                 if (var20 != 0) {
                                    int var23 = (f1358 | 785908) + ~(f1358 & 785908) + 1 ^ -844458109;
                                    C0188 var24 = w.a<"B">(var1, C0026.f1847, 297013667898269598L);
                                    if (w.a<"Û">((Boolean)w.a<"Û">(this.f1339, 174312564406604366L), 354697271520518137L)) {
                                       C0026[] var12 = w.a<"B">(171407253564828753L);
                                       int var13 = var12.length;

                                       for (int var14 = (f1358 | 833916) + ~(f1358 & 833916) + 1 ^ -844246262; var14 < var13; var14++) {
                                          C0026 var15 = var12[var14];
                                          if (w.a<"Û">(this, w.a<"B">(var1, var15, 297013667898269598L), 196779805360118490L)) {
                                             var23 = (f1358 | 182426) + ~(f1358 & 182426) + 1 ^ -844913940;
                                             break;
                                          }
                                       }
                                    }

                                    if (var23 != 0) {
                                       w.a<"Û">(this, var24, 286091088946719899L);
                                    }
                                 }

                                 return;
                              }
                           }

                           int var18 = (f1358 | 288733) + ~(f1358 & 288733) + 1 ^ -844821078;

                           for (int var9 = (f1358 | 593010) + ~(f1358 & 593010) + 1 ^ -844601851;
                              var9 <= w.a<"Û">((Integer)w.a<"Û">(this.f1327, 174312564406604366L), 260981171345819427L);
                              var9++
                           ) {
                              class_3610 var10 = w.a<"Û">(var2, var3, var4 + var9, var5, 265922468729811144L);
                              if (w.a<"Û">(var10, 249198674057315725L) || w.a<"Û">(var10, 114855608555999604L)) {
                                 var18 = (f1358 | 647017) + ~(f1358 & 647017) + 1 ^ -844581601;
                                 break;
                              }
                           }

                           C0188 var19 = w.a<"B">(var1, C0026.f1845, 297013667898269598L);
                           List var21 = w.a<"Û">(this, var1, 118309451867026136L);
                           w.a<"Û">(
                              var21,
                              (Predicate<C0188>)var2x -> (boolean)(w.a<"Û">(var2x, 338760375740343559L).equals(var1)
                                       && w.a<"Û">(var2x, 209834752898289767L) == w.a<"Û">(var19, 209834752898289767L)
                                    ? (f1358 | 729005) + ~(f1358 & 729005) + 1 ^ -844466726
                                    : (f1358 | 332052) + ~(f1358 & 332052) + 1 ^ -844858526),
                              372804948295703628L
                           );
                           if (var18 != 0
                              && w.a<"Û">((Boolean)w.a<"Û">(this.f1332, 174312564406604366L), 354697271520518137L)
                              && !w.a<"Û">(this, var19, 196779805360118490L)
                              && !w.a<"Û">((Boolean)w.a<"Û">(this.f1324, 174312564406604366L), 354697271520518137L)) {
                              w.a<"Û">(this, var19, 286091088946719899L);
                              return;
                           }
                        }
                     }
                  }
               }
            }

            if (w.a<"Û">((Boolean)w.a<"Û">(this.f1335, 174312564406604366L), 354697271520518137L) && w.a<"Û">(this, var1, var2, 127057837337257649L)) {
               C0188 var16 = w.a<"B">(var1, C0026.f1846, 297013667898269598L);
               w.a<"Û">(this, var16, 286091088946719899L);
            }

            C0188 var17 = w.a<"B">(var1, C0026.f1848, 297013667898269598L);
            if (!w.a<"Û">(this, var17, 196779805360118490L)) {
               w.a<"Û">(this, var17, 286091088946719899L);
            }
         },
         (var0, var1) -> {
         },
         (var1, var2) -> {
            if (!w.a<"Û">(w.a<"Û">(var2, 367769494756460329L), 249198674057315725L)
               && !w.a<"Û">(w.a<"Û">(var2, 367769494756460329L), 114855608555999604L)
               && w.a<"Û">((Boolean)w.a<"Û">(this.f1329, 174312564406604366L), 354697271520518137L)) {
               if (w.a<"Û">((Boolean)w.a<"Û">(this.f1324, 174312564406604366L), 354697271520518137L)) {
                  return;
               }

               class_1923 var3 = new class_1923(var1);
               C0188 var4 = w.a<"B">(var3, C0026.f1845, 297013667898269598L);
               C0188 var5 = w.a<"B">(var3, C0026.f1844, 297013667898269598L);
               class_2350[] var6 = w.a<"B">(179161450352945543L);
               int var7 = var6.length;

               for (int var8 = (f1358 | 895411) + ~(f1358 & 895411) + 1 ^ -844315707; var8 < var7; var8++) {
                  class_2350 var9 = var6[var8];
                  if (class_2350.field_11033 != var9
                     && !w.a<"Û">(
                        w.a<"Û">(
                           w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                              w.a<"Û">(var1, var9, 361576458954219689L),
                              310987074049434965L
                           ),
                           367769494756460329L
                        ),
                        114855608555999604L
                     )
                     && !w.a<"Û">(this, var4, 196779805360118490L)) {
                     if (!w.a<"Û">(w.a<"Û">(this, w.a<"B">(var1, 144265636656068447L), 345378172269929898L), var5, 144617673607550225L)) {
                        w.a<"Û">(this, var5, 286091088946719899L);
                     }

                     return;
                  }
               }
            }
         }
      );
      C0015 var10000 = this.f1343;
      List var10001 = this.f1352;
      w.a<"B">(this.f1352, 131918113315390561L);
      w.a<"Û">(var10000, var10001::clear, 276217487236498440L);
      w.a<"Û">(this.f1330, "NewFill", 275243698516531804L);
      w.a<"Û">(this.f1331, "NewLine", 275243698516531804L);
      w.a<"Û">(this.f1333, "OldFill", 275243698516531804L);
      w.a<"Û">(this.f1334, "OldLine", 275243698516531804L);
      w.a<"Û">(this.f1336, "1.12Fill", 275243698516531804L);
      w.a<"Û">(this.f1337, "1.12Line", 275243698516531804L);
      w.a<"Û">(this.f1345, "DungeonFill", 275243698516531804L);
      w.a<"Û">(this.f1346, "DungeonLine", 275243698516531804L);
      w.a<"Û">(this.f1340, "OverflowFill", 275243698516531804L);
      w.a<"Û">(this.f1341, "OverflowLine", 275243698516531804L);
      w.a<"Û">(this.f1342, "OverflowBlocks", 275243698516531804L);
      w.a<"Û">(this.f1325, "Off", C0508.f2371, 381268910042652120L);
   }

   @Override
   public void onEnable() {
      w.a<"Û">(this.f1357, 117139040742577827L);
      w.a<"Û">(this, 163159628095860643L);
      if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 231206531387546689L) != null) {
         class_642 var1 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 231206531387546689L),
            131347417028836246L
         );
         if (var1 == null) {
            return;
         }

         String var2 = var1.field_3761;
         w.a<"Û">(this.f1355, var2, 159515206582147705L);
         w.a<"Û">(this.f1355, var2, 176775181029871316L);
      }
   }

   @Override
   public void onDisable() {
      if (w.a<"Û">(this.f1355, 372501684286817655L) != null) {
         w.a<"Û">(this.f1355, w.a<"Û">(this.f1355, 372501684286817655L), 286404358537309120L);
         w.a<"Û">(this.f1355, null, 176775181029871316L);
      }

      w.a<"Û">(this.f1357, 346846091234297624L);
      w.a<"Û">(this.f1352, 140901994866995976L);
   }

   @C1027
   public void m2608(C0612 var1) {
      w.a<"Û">(this.f1353, 140901994866995976L);

      for (int var2 = (f1358 | 551804) + ~(f1358 & 551804) + 1 ^ 844562165; var2 <= ((f1358 | 360113) + ~(f1358 & 360113) + 1 ^ -844884794); var2++) {
         for (int var3 = (f1358 | 10616) + ~(f1358 & 10616) + 1 ^ 845069553; var3 <= ((f1358 | 73397) + ~(f1358 & 73397) + 1 ^ -845122366); var3++) {
            C1263 var4 = w.a<"Û">(
               w.a<"B">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
                  144265636656068447L
               ),
               var2,
               var3,
               199970981941914043L
            );
            List var5 = w.a<"Û">(this, var4, 345378172269929898L);
            synchronized (var5) {
               Iterator var7 = w.a<"Û">(var5, 341496865259068134L);

               while (w.a<"Û">(var7, 333900474771661065L)) {
                  C0188 var8 = (C0188)w.a<"Û">(var7, 192468336863492695L);
                  if (w.a<"Û">(var8, 209834752898289767L) == w.a<"B">(375727057840316412L)) {
                     w.a<"Û">(this.f1353, var8, 276802003864609490L);
                  }
               }
            }
         }
      }

      if (w.a<"Û">(
            this.f1354,
            w.a<"B">(((long)f1358 | 585640L) + ~((long)f1358 & 585640L) + 1L ^ -4607182419644545570L, 317139102743630955L),
            TimeUnit.MINUTES,
            215737872562411156L
         )
         && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6012
            > ((f1358 | 746798) + ~(f1358 & 746798) + 1 ^ -844492996)) {
         w.a<"Û">(this.f1355, w.a<"Û">(this.f1355, 372501684286817655L), 286404358537309120L);
         w.a<"Û">(this.f1354, 387780412884547639L);
      }

      w.a<"Û">(this, 163159628095860643L);
   }

   public void m2609(class_1923 var1, class_2818 var2) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1324, 174312564406604366L), 354697271520518137L)) {
         C0364 var3 = w.a<"B">(375727057840316412L);
         if (!w.a<"Û">(this, new C0188(var1, var3, C0026.f1845), 196779805360118490L)) {
            boolean var4 = w.a<"Û">(this.f1356, var2, 208015374089199578L);
            if (var4 && w.a<"Û">((Boolean)w.a<"Û">(this.f1329, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(this, new C0188(var1, var3, C0026.f1844), 286091088946719899L);
            } else if (!var4 && w.a<"Û">((Boolean)w.a<"Û">(this.f1332, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(this, new C0188(var1, var3, C0026.f1845), 286091088946719899L);
            }
         }
      }
   }

   @C1027
   public void m2610(C1358 var1) {
      Iterator var2 = w.a<"Û">(this.f1353, 341496865259068134L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         C0188 var3 = (C0188)w.a<"Û">(var2, 192468336863492695L);
         if (w.a<"Û">(this.f1325, 335309852205562156L)) {
            break;
         }

         w.a<"Û">(var3, var1, this, 194525484743860740L);
      }

      var2 = w.a<"Û">(w.a<"Û">(this, 221962116844294304L), 341496865259068134L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         class_2338 var7 = (class_2338)w.a<"Û">(var2, 192468336863492695L);
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f1344, 174312564406604366L), 354697271520518137L)) {
            class_4184 var4 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L
            );
            class_243 var5 = w.a<"Û">(
               w.a<"Û">(
                  w.a<"Û">(
                     new class_243(0.0, 0.0, w.a<"B">(((long)f1358 | 400999L) + ~((long)f1358 & 400999L) + 1L ^ -4607182419644681199L, 317139102743630955L)),
                     -((float)w.a<"B">((double)w.a<"Û">(var4, 172998423274345737L), 175389272199548133L)),
                     255739159657143373L
                  ),
                  -((float)w.a<"B">((double)w.a<"Û">(var4, 370804508038485452L), 175389272199548133L)),
                  125302572034401955L
               ),
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 186577611421056948L).field_4686,
                  133466035608991790L
               ),
               300445064978294627L
            );
            C0094.f4640.m1898(w.a<"Û">(var1, 173269294235887931L), var5, w.a<"B">(var7, 292575487436775098L), (Color)w.a<"Û">(this.f1346, 174312564406604366L));
         }

         if (w.a<"B">(new class_238(var7), 132682894836608805L)) {
            C0485.m3215(w.a<"Û">(var1, 173269294235887931L), var7, (Color)w.a<"Û">(this.f1345, 174312564406604366L));
            C0485.m3218(
               w.a<"Û">(var1, 173269294235887931L),
               var7,
               (Color)w.a<"Û">(this.f1346, 174312564406604366L),
               w.a<"Û">((Float)w.a<"Û">(this.f1328, 174312564406604366L), 149784643039979208L)
            );
         }
      }
   }

   @C1027
   public void m2611(C1243 var1) {
      w.a<"Û">(this.f1355, w.a<"Û">(var1, 183371481221279650L), 176775181029871316L);
      w.a<"Û">(this.f1355, w.a<"Û">(var1, 183371481221279650L), 159515206582147705L);
   }

   @C1027
   public void m2612(C0190 var1) {
      if (w.a<"Û">(this.f1355, 372501684286817655L) != null) {
         w.a<"Û">(this.f1355, w.a<"Û">(this.f1355, 372501684286817655L), 286404358537309120L);
         w.a<"Û">(this.f1355, null, 176775181029871316L);
      }
   }

   public boolean m2613(class_2248 var1) {
      return (boolean)(var1 != class_2246.field_10266 && var1 != class_2246.field_23874
         ? (f1358 | 269838) + ~(f1358 & 269838) + 1 ^ -844794760
         : (f1358 | 584125) + ~(f1358 & 584125) + 1 ^ -844528694);
   }

   public boolean m2614(class_2248 var1) {
      return w.a<"B">(375727057840316412L) == C0364.f1227 ? w.a<"Û">(C0460.f1060, var1, 338145669613544495L) : w.a<"Û">(C0460.f1059, var1, 338145669613544495L);
   }

   public void m2615() {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1343, 174312564406604366L), 354697271520518137L) && !w.a<"Û">(this, 205492958615326489L)) {
         Iterator var1 = w.a<"Û">(w.a<"Û">(C0933.f1436, 256388424110503341L), 341496865259068134L);

         while (w.a<"Û">(var1, 333900474771661065L)) {
            class_2586 var2 = (class_2586)w.a<"Û">(var1, 192468336863492695L);
            if (var2 instanceof class_2636) {
               class_2636 var3 = (class_2636)var2;
               if (((DuckMobSpawnerLogic)w.a<"Û">(var3, 301580729573931813L)).getSpawnDelay() != ((f1358 | 218127) + ~(f1358 & 218127) + 1 ^ -845005203)
                  && w.a<"B">(375727057840316412L) != C0364.f1227) {
                  if (!w.a<"Û">(w.a<"Û">(this, 221962116844294304L), w.a<"Û">(var3, 281056874110918966L), 144617673607550225L)
                     && w.a<"Û">((Boolean)w.a<"Û">(this.f1347, 174312564406604366L), 354697271520518137L)) {
                     C1348 var4 = (C1348)w.a<"Û">(this.f1348, 174312564406604366L);
                     w.a<"Û">(C0933.f1420, var4, w.a<"Û">((Float)w.a<"Û">(this.f1349, 174312564406604366L), 149784643039979208L), 359079024815758851L);
                  }

                  w.a<"Û">(w.a<"Û">(this, 221962116844294304L), w.a<"Û">(var3, 281056874110918966L), 276802003864609490L);
               }
            }
         }

         w.a<"Û">(
            w.a<"Û">(this, 221962116844294304L),
            (Predicate<class_2338>)var1x -> (boolean)(!w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                           var1x,
                           310987074049434965L
                        ),
                        363526675043086623L
                     )
                     && w.a<"Û">(
                        w.a<"Û">(
                           w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773,
                              202182323384413167L
                           ),
                           311335674990834024L
                        ),
                        var1x,
                        (double)(
                           w.a<"Û">(C0933.f1436, 351903969671141748L)
                              * ((f1358 | 300341) + ~(f1358 & 300341) + 1 ^ -844759213)
                              * w.a<"Û">((Integer)w.a<"Û">(this.f1325, 174312564406604366L), 260981171345819427L)
                        ),
                        217636444529705754L
                     )
                  ? (f1358 | 483106) + ~(f1358 & 483106) + 1 ^ -844745388
                  : (f1358 | 369453) + ~(f1358 & 369453) + 1 ^ -844838566),
            372804948295703628L
         );
      }
   }

   public void m2616(C0188 var1) {
      List var2 = w.a<"Û">(this, w.a<"Û">(var1, 338760375740343559L), 118309451867026136L);
      synchronized (var2) {
         w.a<"Û">(
            var2,
            (Predicate<C0188>)var1x -> (boolean)(w.a<"Û">(var1x, 338760375740343559L).equals(w.a<"Û">(var1, 338760375740343559L))
                     && w.a<"Û">(var1x, 209834752898289767L) == w.a<"Û">(var1, 209834752898289767L)
                  ? (f1358 | 733213) + ~(f1358 & 733213) + 1 ^ -844473750
                  : (f1358 | 160646) + ~(f1358 & 160646) + 1 ^ -844949008),
            372804948295703628L
         );
         w.a<"Û">(var2, var1, 276802003864609490L);
      }
   }

   public boolean m2617(C0188 var1) {
      List var2 = w.a<"Û">(this, w.a<"Û">(var1, 338760375740343559L), 118309451867026136L);
      synchronized (var2) {
         Iterator var4 = w.a<"Û">(var2, 341496865259068134L);

         while (w.a<"Û">(var4, 333900474771661065L)) {
            C0188 var5 = (C0188)w.a<"Û">(var4, 192468336863492695L);
            if (!w.a<"Û">(var5, C0026.f1848, 140505213677773835L)
               && w.a<"Û">(var5, 338760375740343559L).equals(w.a<"Û">(var1, 338760375740343559L))
               && w.a<"Û">(var5, 209834752898289767L) == w.a<"Û">(var1, 209834752898289767L)) {
               return (boolean)((f1358 | 472683) + ~(f1358 & 472683) + 1 ^ -844735460);
            }
         }
      }

      return (boolean)((f1358 | 278569) + ~(f1358 & 278569) + 1 ^ -844813729);
   }

   public List<C0188> m2618(class_1923 var1) {
      return w.a<"Û">(this, w.a<"B">(var1, 280346753947051443L), 345378172269929898L);
   }

   public List<C0188> m2619(C1263 var1) {
      return (List<C0188>)w.a<"Û">(this.f1351, var1, (Function<C1263, List>)var0 -> w.a<"B">(new ArrayList(), 291435362423732219L), 370265103704210937L);
   }

   public Map<C1263, List<C0188>> m2620() {
      return this.f1351;
   }

   public List<C0188> m2621() {
      return this.f1353;
   }

   public synchronized List<class_2338> m2622() {
      return this.f1352;
   }

   public boolean m2623(class_2338 var1, class_2818 var2) {
      return (boolean)(w.a<"Û">(
               this,
               w.a<"Û">(
                  var1,
                  (f1358 | 491927) + ~(f1358 & 491927) + 1 ^ -844698656,
                  (f1358 | 893891) + ~(f1358 & 893891) + 1 ^ -844314187,
                  (f1358 | 630373) + ~(f1358 & 630373) + 1 ^ -844565485,
                  122005601087033807L
               ),
               var2,
               189432586836099407L
            )
            && w.a<"Û">(
               this,
               w.a<"Û">(
                  var1,
                  (f1358 | 785119) + ~(f1358 & 785119) + 1 ^ 844459862,
                  (f1358 | 676062) + ~(f1358 & 676062) + 1 ^ -844416344,
                  (f1358 | 224729) + ~(f1358 & 224729) + 1 ^ -845019217,
                  122005601087033807L
               ),
               var2,
               189432586836099407L
            )
            && w.a<"Û">(
               this,
               w.a<"Û">(
                  var1,
                  (f1358 | 831844) + ~(f1358 & 831844) + 1 ^ -844244206,
                  (f1358 | 37827) + ~(f1358 & 37827) + 1 ^ -845022795,
                  (f1358 | 560845) + ~(f1358 & 560845) + 1 ^ -844503878,
                  122005601087033807L
               ),
               var2,
               189432586836099407L
            )
            && w.a<"Û">(
               this,
               w.a<"Û">(
                  var1,
                  (f1358 | 428325) + ~(f1358 & 428325) + 1 ^ -844635309,
                  (f1358 | 841603) + ~(f1358 & 841603) + 1 ^ -844251659,
                  (f1358 | 866572) + ~(f1358 & 866572) + 1 ^ 844344453,
                  122005601087033807L
               ),
               var2,
               189432586836099407L
            )
         ? (f1358 | 677736) + ~(f1358 & 677736) + 1 ^ -844415713
         : (f1358 | 188993) + ~(f1358 & 188993) + 1 ^ -844920777);
   }

   public boolean m2624(class_2338 var1, class_2818 var2) {
      return w.a<"Û">(
         w.a<"Û">(
            var2,
            w.a<"Û">(
               var1,
               (f1358 | 241729) + ~(f1358 & 241729) + 1 ^ -844965322,
               (f1358 | 951441) + ~(f1358 & 951441) + 1 ^ -844108057,
               (f1358 | 206036) + ~(f1358 & 206036) + 1 ^ -845001054,
               122005601087033807L
            ),
            332344150505895904L
         ),
         249198674057315725L
      );
   }

   public boolean m2625(class_1923 var1, class_2818 var2) {
      if (w.a<"B">(375727057840316412L) == C0364.f1228) {
         class_6880 var7 = w.a<"Û">(
            w.a<"Û">(var2, w.a<"Û">(var2, (f1358 | 113408) + ~(f1358 & 113408) + 1 ^ -845098698, 361213865724017013L), 136744862229199357L),
            (f1358 | 102150) + ~(f1358 & 102150) + 1 ^ -845093512,
            (f1358 | 736637) + ~(f1358 & 736637) + 1 ^ -844474613,
            (f1358 | 287557) + ~(f1358 & 287557) + 1 ^ -844822213,
            208956435619613620L
         );
         return (boolean)(w.a<"Û">(w.a<"Û">(var7, 196749109655723574L), null, 237682386832069967L) == class_1972.field_9411
            ? (f1358 | 201347) + ~(f1358 & 201347) + 1 ^ -844990220
            : (f1358 | 837377) + ~(f1358 & 837377) + 1 ^ -844255881);
      } else {
         for (int var3 = (f1358 | 75159) + ~(f1358 & 75159) + 1 ^ -845131807; var3 < ((f1358 | 707892) + ~(f1358 & 707892) + 1 ^ -844388526); var3++) {
            for (int var4 = (f1358 | 146673) + ~(f1358 & 146673) + 1 ^ -844933497;
               var4
                  < w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 290783177543878799L
                  );
               var4++
            ) {
               for (int var5 = (f1358 | 782146) + ~(f1358 & 782146) + 1 ^ -844462796; var5 < ((f1358 | 510185) + ~(f1358 & 510185) + 1 ^ -844717425); var5++) {
                  w.a<"Û">(f1350, w.a<"Û">(var1, 246289701840133598L) + var3, var4, w.a<"Û">(var1, 255085604585515475L) + var5, 254891861700948234L);
                  class_2680 var6 = w.a<"Û">(var2, f1350, 330559084091970443L);
                  if (w.a<"Û">(this, w.a<"Û">(var6, 152622786059621427L), 140340816661512872L)) {
                     return (boolean)((f1358 | 297307) + ~(f1358 & 297307) + 1 ^ -844766419);
                  }
               }
            }
         }

         return (boolean)((f1358 | 325533) + ~(f1358 & 325533) + 1 ^ -844784150);
      }
   }

   public static String Ua5JOjwhROvkFw94MIkgBIMZItDC7v1Tz9AlllqNcajl1BGYhuqZAqwYm2rafQf8Hb0CCUJPV8mKnFAq9EmYsOOAqO2wlKHbJNtE(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
