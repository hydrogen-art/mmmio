package me.mioclient;

import com.google.common.base.Converter;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class C0391 extends Converter<Enum, JsonElement> {
   public final Class<? extends Enum> f4917;
   public static int f4918 = w.a<"B">(4164343825818177845L, 257832362129977838L);

   public C0391(Class<? extends Enum<?>> var1) {
      this.f4917 = var1;
   }

   public static int m3980(Enum<?> var0) {
      for (int var1 = (f4918 | 662218) + ~(f4918 & 662218) + 1 ^ 936251726;
         var1 < ((Enum[])w.a<"Û">(w.a<"Û">(var0, 135670909312549892L), 144334009663342992L)).length;
         var1++
      ) {
         Enum var2 = ((Enum[])w.a<"Û">(w.a<"Û">(var0, 135670909312549892L), 144334009663342992L))[var1];
         if (!w.a<"B">(var2, 369567614708363881L) && w.a<"Û">(w.a<"Û">(var2, 235224272799028434L), w.a<"Û">(var0, 235224272799028434L), 307662238383225114L)) {
            return var1;
         }
      }

      return (f4918 | 975702) + ~(f4918 & 975702) + 1 ^ -936044755;
   }

   public static Enum<?> m3981(Enum var0) {
      int var1 = w.a<"B">(var0, 138044113909036078L);

      for (int var2 = (f4918 | 334866) + ~(f4918 & 334866) + 1 ^ 935401366;
         var2 < w.a<"Û">(w.a<"Û">(var0, 135670909312549892L), 144334009663342992L).length;
         var2++
      ) {
         Enum var3 = (Enum)w.a<"Û">(w.a<"Û">(var0, 135670909312549892L), 144334009663342992L)[var2];
         if (!w.a<"B">(var3, 369567614708363881L) && var2 > var1) {
            return var3;
         }
      }

      return (Enum<?>)w.a<"Û">(w.a<"Û">(var0, 135670909312549892L), 144334009663342992L)[(f4918 | 4583) + ~(f4918 & 4583) + 1 ^ 935598691];
   }

   public static String m3982(Enum<?> var0) {
      if (var0 instanceof C0196 var1) {
         return w.a<"Û">(var1, 352801181599163784L);
      } else {
         throw new IllegalArgumentException();
      }
   }

   public JsonElement m3983(Enum var1) {
      if (var1 instanceof C0196 var2) {
         return new JsonPrimitive(w.a<"Û">(var2, 352801181599163784L));
      } else {
         throw new IllegalArgumentException();
      }
   }

   public Enum m3984(JsonElement var1) {
      Enum[] var2 = (Enum[])w.a<"Û">(this.f4917, 144334009663342992L);
      int var3 = var2.length;

      for (int var4 = (f4918 | 851754) + ~(f4918 & 851754) + 1 ^ 935916718; var4 < var3; var4++) {
         Enum var5 = var2[var4];
         if (!w.a<"B">(var5, 359240398534589109L)) {
            throw new IllegalArgumentException();
         }

         if (!w.a<"B">(var5, 369567614708363881L)
            && var5 instanceof C0196 var6
            && w.a<"Û">(w.a<"Û">(var1, 327479800495025542L), w.a<"Û">(var6, 352801181599163784L), 307662238383225114L)) {
            return var5;
         }
      }

      return ((Enum[])w.a<"Û">(this.f4917, 144334009663342992L))[(f4918 | 738174) + ~(f4918 & 738174) + 1 ^ 936331514];
   }
}
