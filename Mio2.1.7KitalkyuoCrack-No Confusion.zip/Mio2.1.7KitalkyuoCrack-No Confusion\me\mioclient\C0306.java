package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_124;

public class C0306 extends C1266 {
   public static int f0978 = w.a<"B">(7921819878719283431L, 257832362129977838L);

   public C0306() {
      super(
         "NoHitDelay",
         new C1002().m2591(String.valueOf(class_124.field_1061)).m2593("Removes the weapon attack delay. \n\u0001Only works on pre 1.9 servers."),
         C1045.f3172
      );
   }

   public static String dXUMsFQw3visx1HreUGiiX24vUbSGpxRNBVJ8ARXNIqAx4xaodNZgbgIgSpp9nAdMX1wmfOiaNy97LNyx1Wajirv2l0iLpItnwxw(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
