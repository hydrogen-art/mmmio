package me.mioclient;

import net.minecraft.class_1657;
import net.minecraft.class_2338;

public class C0504 extends C0445 {
   public static int f1723 = w.a<"B">(2665729476011726116L, 257832362129977838L);

   @Override
   public boolean m2746(class_2338 var1, class_1657 var2, C0870 var3) {
      return w.a<"Û">(w.a<"B">(var2, 129205818283773035L), w.a<"Û">(w.a<"Û">(var3, 215307501250491533L), var1, 252103202185457587L), 133676266014519719L);
   }
}
