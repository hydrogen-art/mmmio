package me.mioclient;

import net.minecraft.class_1792;

public class C0195 implements Runnable, C0045 {
   public final C0846 f0570;
   public final long f0571;
   public final class_1792 f0572;
   public final int f0573;
   public final int f0574;
   public static int f0575 = w.a<"B">(2944444777761548958L, 257832362129977838L);

   public C0195(C0846 var1, class_1792 var2, int var3, int var4) {
      this.f0572 = var2;
      this.f0573 = var3;
      this.f0574 = var4;
      this.f0571 = w.a<"B">(223409559795593705L);
      this.f0570 = var1;
   }

   @Override
   public void run() {
      if (w.a<"Û">(this.f0570, 109862026138821216L) == null || w.a<"Û">(this.f0570, 109862026138821216L).equals(this)) {
         if (!w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
               this.f0574,
               386860178278302175L
            ),
            this.f0572,
            282470456889867724L
         )) {
            w.a<"B">(this.f0573, 209502932342608419L);
         }
      }
   }

   @Override
   public boolean equals(Object var1) {
      if (var1 instanceof C0195 var2) {
         return (boolean)(var2.f0571 == this.f0571
            ? (f0575 | 667482) + ~(f0575 & 667482) + 1 ^ 1400448234
            : (f0575 | 209985) + ~(f0575 & 209985) + 1 ^ 1399865328);
      } else {
         return (boolean)((f0575 | 8429) + ~(f0575 & 8429) + 1 ^ 1400056668);
      }
   }
}
