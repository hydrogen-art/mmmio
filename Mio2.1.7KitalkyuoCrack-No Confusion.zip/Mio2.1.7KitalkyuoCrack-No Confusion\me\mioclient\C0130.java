package me.mioclient;

import net.minecraft.class_2596;

public abstract sealed class C0130 extends C1180 permits C0132, C0133, C0131 {
   public final class_2596<?> f4849;

   public C0130(class_2596<?> var1) {
      this.f4849 = var1;
   }

   public class_2596<?> m3948() {
      return this.f4849;
   }
}
