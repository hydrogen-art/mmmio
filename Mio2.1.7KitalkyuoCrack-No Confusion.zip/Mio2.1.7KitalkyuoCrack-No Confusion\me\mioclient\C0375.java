package me.mioclient;

import java.awt.Color;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_4587;

public class C0375 {
   public class_238 f2727;
   public long f2728;
   public float f2729;
   public static int f2730 = w.a<"B">(8922188226258134821L, 257832362129977838L);

   public C0375() {
      this.f2729 = w.a<"B">((f2730 | 911894) + ~(f2730 & 911894) + 1 ^ 2027762948, 349057757755238323L);
   }

   public void m3164() {
      this.f2728 = w.a<"B">(223409559795593705L) + (((long)f2730 | 608654L) + ~((long)f2730 & 608654L) + 1L ^ 1197053450L);
   }

   public void m3165(class_2338 var1) {
      this.f2727 = new class_238(var1);
   }

   public void m3166(class_238 var1) {
      this.f2727 = var1;
   }

   public void m3167(float var1) {
      this.f2729 = var1;
   }

   public void m3168(class_4587 var1, Color var2, Color var3, float var4, boolean var5) {
      if (this.f2727 != null && w.a<"B">(this.f2727, 132682894836608805L)) {
         float var6 = w.a<"Û">(this, var4, 279181546310867412L);
         w.a<"B">(var1, this.f2727, var5 ? C0152.m3473(var2, (int)((float)w.a<"Û">(var2, 245270953955453918L) * var6)) : var2, 246072095578695914L);
         C0485.m3219(var1, this.f2727, var5 ? C0152.m3473(var3, (int)((float)w.a<"Û">(var3, 245270953955453918L) * var6)) : var3, this.f2729);
         if (var6 == 0.0F) {
            this.f2727 = null;
         }
      }
   }

   public float m3169(float var1) {
      return w.a<"B">(
         w.a<"B">((f2730 | 49861) + ~(f2730 & 49861) + 1 ^ 2026905047, 349057757755238323L)
            - (float)w.a<"B">(w.a<"B">(223409559795593705L) - this.f2728, 0L, 329552778111668452L) / var1,
         0.0F,
         w.a<"B">((f2730 | 977151) + ~(f2730 & 977151) + 1 ^ 2027829229, 349057757755238323L),
         131506059371757968L
      );
   }

   public class_238 m3170() {
      return this.f2727;
   }
}
