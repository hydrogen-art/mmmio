package me.mioclient;

import it.unimi.dsi.fastutil.objects.ObjectLinkedOpenHashSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Predicate;
import net.minecraft.class_2338;
import net.minecraft.class_238;

public final class C0121 extends C0767<C0122, List<C0122>> implements C0045 {
   public final Map<C0122, Set<C0375>> f0351 = new HashMap<>();
   public static int f0352 = w.a<"B">(6906819700236102512L, 257832362129977838L);

   public C0121() {
      super(new ArrayList<>());
      w.a<"Û">(C0045.f2104, this, 157496676404787811L);
   }

   public void m2262(C0502 var1, class_2338 var2) {
      if (var2 != null) {
         w.a<"Û">(this, var1, new class_238(var2), 317866513404830971L);
      }
   }

   public void m2263(C0502 var1, class_238 var2) {
      if (var2 != null) {
         C0122 var3 = (C0122)w.a<"Û">(this, (Predicate<C0122>)var1x -> w.a<"Û">(var1x, 315115758372020313L).equals(var1), 256902482587857123L);
         if (var3 == null) {
            throw new NoSuchElementException();
         } else {
            synchronized (this.f0351) {
               Set var5 = (Set)w.a<"Û">(this.f0351, var3, 299255156581412505L);
               if (w.a<"Û">(var3, 151234285976350741L)) {
                  Iterator var6 = w.a<"Û">(var5, 194435811056609302L);

                  while (w.a<"Û">(var6, 333900474771661065L)) {
                     C0375 var7 = (C0375)w.a<"Û">(var6, 192468336863492695L);
                     if (var2.equals(w.a<"Û">(var7, 267495423269357342L))) {
                        w.a<"Û">(var7, 129384286966120835L);
                        return;
                     }
                  }
               } else {
                  w.a<"Û">(var5, 259971657844247781L);
               }

               C0375 var10 = new C0375();
               w.a<"Û">(var10, var2, 338064210773670432L);
               w.a<"Û">(var10, 129384286966120835L);
               w.a<"Û">(var5, var10, 309270453639690490L);
            }
         }
      }
   }

   @C1027
   public void m2264(C0612 var1) {
      synchronized (this.f0351) {
         Iterator var3 = w.a<"Û">(w.a<"Û">(this.f0351, 354320704134596920L), 194435811056609302L);

         while (w.a<"Û">(var3, 333900474771661065L)) {
            Entry var4 = (Entry)w.a<"Û">(var3, 192468336863492695L);
            w.a<"Û">(
               (Set)w.a<"Û">(var4, 196870340575900401L),
               (Predicate<C0375>)var1x -> (boolean)(w.a<"Û">(
                           var1x, w.a<"Û">((C0122)w.a<"Û">(var4, 141740301999341859L), 199271797766786384L), 279181546310867412L
                        )
                        == 0.0F
                     ? (f0352 | 345215) + ~(f0352 & 345215) + 1 ^ -1637311228
                     : (f0352 | 372434) + ~(f0352 & 372434) + 1 ^ -1637320792),
               271448142827029127L
            );
         }
      }
   }

   @C1027
   public void m2265(C1358 var1) {
      synchronized (this.f0351) {
         Iterator var3 = w.a<"Û">(w.a<"Û">(this.f0351, 354320704134596920L), 194435811056609302L);

         while (w.a<"Û">(var3, 333900474771661065L)) {
            Entry var4 = (Entry)w.a<"Û">(var3, 192468336863492695L);
            C0122 var5 = (C0122)w.a<"Û">(var4, 141740301999341859L);
            Iterator var6 = w.a<"Û">((Set)w.a<"Û">(var4, 196870340575900401L), 194435811056609302L);

            while (w.a<"Û">(var6, 333900474771661065L)) {
               C0375 var7 = (C0375)w.a<"Û">(var6, 192468336863492695L);
               w.a<"Û">(var7, w.a<"Û">(var5, 293816910337928404L), 372224214376719814L);
               w.a<"Û">(
                  var7,
                  w.a<"Û">(var1, 173269294235887931L),
                  w.a<"Û">(var5, 329613898824841474L),
                  w.a<"Û">(var5, 364856568104970472L),
                  w.a<"Û">(var5, 199271797766786384L),
                  w.a<"Û">(var5, 380815239322802388L),
                  352223484999560991L
               );
            }
         }
      }
   }

   public boolean m2266(C0122 var1) {
      w.a<"Û">(this.f0351, var1, new ObjectLinkedOpenHashSet(), 121875332790264405L);
      return w.a<"Û">((List)w.a<"Û">(this, 268370374673263607L), var1, 276802003864609490L);
   }

   public boolean m2267(C0122 var1) {
      throw new UnsupportedOperationException();
   }
}
