package me.mioclient;

import net.minecraft.class_2338;
import net.minecraft.class_2680;

public record C0246() implements C0045 {
   public final class_2680 f5128;
   public final class_2338 f5129;
   public final long f5130;
   public static int f5131 = w.a<"B">(2138520185990352506L, 257832362129977838L);

   public C0246(class_2680 var1, class_2338 var2, long var3) {
      this.f5128 = var1;
      this.f5129 = var2;
      this.f5130 = var3;
   }

   public static C0246 m2105(class_2338 var0) {
      return new C0246(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var0, 310987074049434965L),
         var0,
         w.a<"B">(223409559795593705L)
      );
   }

   public boolean m2106() {
      return (boolean)(w.a<"B">(223409559795593705L) - this.f5130 >= (((long)f5131 | 315178L) + ~((long)f5131 & 315178L) + 1L ^ 1498353087L)
         ? (f5131 | 974030) + ~(f5131 & 974030) + 1 ^ 1497702318
         : (f5131 | 145544) + ~(f5131 & 145544) + 1 ^ 1498020841);
   }

   public class_2680 m2107() {
      return this.f5128;
   }

   public class_2338 m2108() {
      return this.f5129;
   }

   public long m2109() {
      return this.f5130;
   }
}
