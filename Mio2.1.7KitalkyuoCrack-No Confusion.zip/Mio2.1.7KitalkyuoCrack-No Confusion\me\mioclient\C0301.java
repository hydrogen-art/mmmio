package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0301 implements C0196 {
   f4495("Plain"),
   f4496("GrimHop");

   public final String f4497;

   public C0301(String var3) {
      this.f4497 = var3;
   }

   @Override
   public String getName() {
      return this.f4497;
   }

   public static String CMvU9F8WcwfKteUendkiugH7UDmvjRMIeUK3IxEK21QY3FnrillLPOnMbB3JM1eKKJvzLQY8JeYm41rDy47nyBJhUDZL5IliGsOI(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
