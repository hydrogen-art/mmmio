package me.mioclient;

public final class C0291 extends C1180 {
   public final int f1785;
   public final boolean f1786;

   public C0291(int var1, boolean var2) {
      this.f1785 = var1;
      this.f1786 = var2;
   }

   public int m0771() {
      return this.f1785;
   }

   public boolean m0772() {
      return this.f1786;
   }
}
