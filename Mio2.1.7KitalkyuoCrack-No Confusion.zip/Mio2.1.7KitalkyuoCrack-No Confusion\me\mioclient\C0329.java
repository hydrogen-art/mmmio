package me.mioclient;

import java.util.function.Predicate;

public class C0329 implements Predicate {
   public C1362 f2175;

   public C0329(C1362 var1) {
      this.f2175 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2175.f3545, 254992554122318132L);
   }
}
