package me.mioclient;

import java.io.InputStream;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1102;
import net.minecraft.class_1113;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3419;
import net.minecraft.class_4228;
import net.minecraft.class_4234;
import net.minecraft.class_4237;

public class C0191 extends class_1102 {
   public InputStream f1622;
   public static int f1623 = w.a<"B">(7518352665417047889L, 257832362129977838L);

   public C0191(class_243 var1, InputStream var2) {
      super(class_2960.method_60655(C0045.m2861() ? "mioloader" : "mio", "sound"), class_3419.field_15250, class_1113.method_43221());
      this.field_5439 = var1.field_1352;
      this.field_5450 = var1.field_1351;
      this.field_5449 = var1.field_1350;
      this.f1622 = var2;
   }

   public C0191(InputStream var1) {
      super(class_2960.method_60655(C0045.m2861() ? "mioloader" : "mio", "sound"), class_3419.field_15250, class_1113.method_43221());
      this.f1622 = var1;
      this.field_18936 = (boolean)((f1623 | 935850) + ~(f1623 & 935850) + 1 ^ -656115248);
      this.field_5439 = 0.0;
      this.field_5450 = 0.0;
      this.field_5449 = w.a<"B">(-4616189618054758400L, 317139102743630955L);
   }

   public CompletableFuture<class_4234> getAudioStream(class_4237 var1, class_2960 var2, boolean var3) {
      try {
         return w.a<"B">(new class_4228(this.f1622), 172813072404835053L);
      } catch (Exception var5) {
         return w.a<"B">(var5, 381603067456578421L);
      }
   }

   public static String WeHeHL2VCng5ICFKFDsMp9cbBJJfKwqNWk5TxWEmDjPo2xHljXK4P45RZ3JgUuHMbkef4pXqT7pkui9YzPVS0zaNflOiRejGy5i2(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
