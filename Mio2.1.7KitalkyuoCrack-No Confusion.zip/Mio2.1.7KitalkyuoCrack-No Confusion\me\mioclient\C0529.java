package me.mioclient;

import java.util.function.Predicate;

public class C0529 implements Predicate {
   public C0671 f0306;

   public C0529(C0671 var1) {
      this.f0306 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0306.f4651, 174312564406604366L) == C0672.f4559;
   }
}
