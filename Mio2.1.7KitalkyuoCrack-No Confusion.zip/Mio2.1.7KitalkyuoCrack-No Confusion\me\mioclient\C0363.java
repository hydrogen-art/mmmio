package me.mioclient;

import java.util.function.Predicate;

public class C0363 implements Predicate {
   public C0607 f4289;

   public C0363(C0607 var1) {
      this.f4289 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4289.f0625, 254992554122318132L);
   }
}
