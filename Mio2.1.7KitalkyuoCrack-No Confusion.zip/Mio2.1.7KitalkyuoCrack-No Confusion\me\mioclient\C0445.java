package me.mioclient;

import java.util.Iterator;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2399;

public class C0445 implements C0045, C0998 {
   public static final List<C0870> f2985 = w.a<"B">(
      w.a<"B">(class_2350.field_11034, class_2399.field_11255, 125620483547542532L),
      w.a<"B">(class_2350.field_11039, class_2399.field_11252, 125620483547542532L),
      w.a<"B">(class_2350.field_11043, class_2399.field_11256, 125620483547542532L),
      w.a<"B">(class_2350.field_11035, class_2399.field_11254, 125620483547542532L),
      319034520487861803L
   );
   public static int f2986 = w.a<"B">(5531060314619832151L, 257832362129977838L);

   @Override
   public C0725 m2150(C0340 var1, class_1657 var2) {
      class_2338 var3 = w.a<"B">(var2, 185161616837346565L);
      class_2350 var4 = null;
      class_238 var5 = null;
      float var6 = w.a<"B">((f2986 | 922451) + ~(f2986 & 922451) + 1 ^ -1999341233, 349057757755238323L);
      if (!w.a<"B">(var3, 264833804936079815L)) {
         return null;
      } else {
         Iterator var7 = w.a<"Û">(f2985, 341496865259068134L);

         while (w.a<"Û">(var7, 333900474771661065L)) {
            C0870 var8 = (C0870)w.a<"Û">(var7, 192468336863492695L);
            class_2350 var9 = w.a<"Û">(var8, 261331807502858658L);
            class_2338 var10 = w.a<"Û">(var3, var9, 361576458954219689L);
            if (!w.a<"Û">(this, var3, var2, var8, 276983879935843844L)
               && (!w.a<"Û">((Boolean)w.a<"Û">(var1.f2164, 174312564406604366L), 354697271520518137L) || !w.a<"Û">(this, var10, var9, 210483113041548649L))) {
               float var11 = (float)w.a<"Û">(w.a<"Û">(var2, 359920018220808632L), w.a<"Û">(var10, 229561253177300454L), 271768320413122837L);
               if (var11 < var6) {
                  var5 = w.a<"Û">(var8, 215307501250491533L);
                  var4 = var9;
                  var6 = var11;
               }
            }
         }

         return var4 == null
            ? null
            : new C0725(w.a<"Û">(var3, var4, 361576458954219689L), w.a<"Û">(var4, 368417885573126044L), w.a<"Û">(var5, var3, 252103202185457587L));
      }
   }

   public boolean m2746(class_2338 var1, class_1657 var2, C0870 var3) {
      class_2350 var4 = w.a<"Û">(var3, 261331807502858658L);
      class_2338 var5 = w.a<"Û">(var1, var4, 361576458954219689L);
      return (boolean)(!w.a<"Û">(
               w.a<"B">(var2, 129205818283773035L), w.a<"Û">(w.a<"Û">(var3, 215307501250491533L), var1, 252103202185457587L), 133676266014519719L
            )
            && !w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var5, 310987074049434965L
               ),
               289106033197017315L
            )
         ? (f2986 | 883383) + ~(f2986 & 883383) + 1 ^ -860958549
         : (f2986 | 738118) + ~(f2986 & 738118) + 1 ^ -861345445);
   }

   public boolean m3241(class_2338 var1, class_2350 var2) {
      List var3 = w.a<"B">(var1, 239126559569481376L);
      return (boolean)(!w.a<"Û">(var3, w.a<"Û">(var2, 368417885573126044L), 144617673607550225L)
         ? (f2986 | 4738) + ~(f2986 & 4738) + 1 ^ -861685601
         : (f2986 | 560115) + ~(f2986 & 560115) + 1 ^ -861199889);
   }
}
