package me.mioclient;

import java.util.function.Predicate;

public class C0491 implements Predicate {
   public C0159 f0552;

   public C0491(C0159 var1) {
      this.f0552 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0552.f5296, 174312564406604366L) == C0160.f4388;
   }
}
