package me.mioclient;

import java.util.function.Predicate;

public class C0185 implements Predicate {
   public C0366 f3155;

   public C0185(C0366 var1) {
      this.f3155 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3155.f3251, 254992554122318132L);
   }
}
