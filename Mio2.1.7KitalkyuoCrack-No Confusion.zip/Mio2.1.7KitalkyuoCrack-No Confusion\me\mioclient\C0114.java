package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1268;
import net.minecraft.class_1321;
import net.minecraft.class_243;

enum C0114 implements C0196 {
   f3648("Tame") {
      @Override
      public class_243 m2761(class_1321 var1) {
         if (w.a<"Û">(var1, 123830646594754789L) != null) {
            return null;
         } else {
            int var2 = w.a<"B">(w.a<"B">(var1, 251806739331498123L), 344867982687893969L);
            if (var2 == -1) {
               return null;
            } else {
               w.a<"B">(var2, 279757124141714355L);
               w.a<"B">(var1, class_1268.field_5808, 259824374474014814L);
               return w.a<"Û">(w.a<"Û">(var1, 259129236132542086L), 376895844755266015L);
            }
         }
      }
   },
   f3649("Sit") {
      @Override
      public class_243 m2761(class_1321 var1) {
         if (!w.a<"Û">(var1, 303162748781796173L)
            && !w.a<"Û">(var1, 305767413615533111L)
            && C0045.f2103.field_1724 == w.a<"Û">(var1, 123830646594754789L)
            && !w.a<"Û">(var1, w.a<"Û">(C0045.f2103.field_1724, 229019767109027877L), 159031973622168066L)) {
            w.a<"B">(var1, class_1268.field_5808, 259824374474014814L);
            return w.a<"Û">(w.a<"Û">(var1, 259129236132542086L), 376895844755266015L);
         } else {
            return null;
         }
      }
   },
   f3650("Stand") {
      @Override
      public class_243 m2761(class_1321 var1) {
         if ((w.a<"Û">(var1, 303162748781796173L) || w.a<"Û">(var1, 305767413615533111L))
            && C0045.f2103.field_1724 == w.a<"Û">(var1, 123830646594754789L)
            && !w.a<"Û">(var1, w.a<"Û">(C0045.f2103.field_1724, 229019767109027877L), 159031973622168066L)) {
            w.a<"B">(var1, class_1268.field_5808, 259824374474014814L);
            return w.a<"Û">(w.a<"Û">(var1, 259129236132542086L), 376895844755266015L);
         } else {
            return null;
         }
      }
   };

   public final String f3651;

   public C0114(String var3) {
      this.f3651 = var3;
   }

   @Override
   public String getName() {
      return this.f3651;
   }

   public abstract class_243 m2761(class_1321 var1);

   public static String q9R2uLXqy4HjghGlOdB4e7sB1htLTPZ5KzlpoWmx6q3SvK441HbjcGCOvBZebLFWcpv2ecmy1iZeLNiq74PN7LC7mSmbSFEAkRcH(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
