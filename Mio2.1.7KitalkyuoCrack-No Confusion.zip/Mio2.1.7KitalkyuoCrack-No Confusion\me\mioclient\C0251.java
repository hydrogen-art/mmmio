package me.mioclient;

import java.util.function.Predicate;

public class C0251 implements Predicate {
   public C0846 f3713;

   public C0251(C0846 var1) {
      this.f3713 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3713.f5215, 254992554122318132L) && w.a<"Û">(this.f3713.f5220, 174312564406604366L) == C1057.f0082;
   }
}
