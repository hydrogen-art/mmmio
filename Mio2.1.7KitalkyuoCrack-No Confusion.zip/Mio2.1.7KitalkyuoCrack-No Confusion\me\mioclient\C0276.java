package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.TimeUnit;
import me.mioclient.mixin.ducks.DuckFireworkEntity;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1671;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2604;
import net.minecraft.class_2708;
import net.minecraft.class_2824;
import net.minecraft.class_2886;
import net.minecraft.class_6373;
import net.minecraft.class_6374;
import net.minecraft.class_1297.class_5529;
import net.minecraft.class_677.class_680;

public class C0276 extends C1266 {
   public static C0175 fireworks = C0933.f1409.m2696(C0175.class);
   public final C0015<Float> f2258;
   public final C0015<Boolean> f2259;
   public final Queue<class_6373> f2260;
   public final C0083 f2261;
   public final C0083 f2262;
   public int f2263;
   public class_2338 f2264;
   public class_243 f2265;
   public boolean f2266;
   public boolean f2267;
   public static int f2268 = w.a<"B">(2575345068358620060L, 257832362129977838L);

   public C0276() {
      String var10002 = new C1002().m2591(String.valueOf(class_124.field_1061)).m2593("Makes firework rockets last longer. \n\u0001Old Grim v2 only.");
      C1045 var10003 = C1045.f3177;
      String[] var10004 = new String[(f2268 | 454520) + ~(f2268 & 454520) + 1 ^ -1301533447];
      var10004[(f2268 | 555559) + ~(f2268 & 555559) + 1 ^ -1302152795] = "rocket";
      var10004[(f2268 | 289036) + ~(f2268 & 289036) + 1 ^ -1301370225] = "extendedrocket";
      var10004[(f2268 | 137248) + ~(f2268 & 137248) + 1 ^ -1301750880] = "grimrocket";
      super("RocketExtender", var10002, var10003, var10004);
      w.a<"B">(this, 242859112966675773L);
      this.f2260 = new ArrayDeque<>();
      this.f2261 = new C0083();
      this.f2262 = new C0083();
      this.f2263 = (f2268 | 812851) + ~(f2268 & 812851) + 1 ^ 1301896014;
   }

   @Override
   public String getInfo() {
      if (this.f2263 != ((f2268 | 543906) + ~(f2268 & 543906) + 1 ^ 1302163679) && this.f2264 != null) {
         Object[] var10001 = new Object[(f2268 | 978035) + ~(f2268 & 978035) + 1 ^ -1302056973];
         var10001[(f2268 | 761778) + ~(f2268 & 761778) + 1 ^ -1302242256] = w.a<"B">(
            w.a<"B">(
               w.a<"Û">((Float)w.a<"Û">(this.f2258, 174312564406604366L), 149784643039979208L)
                  - (float)w.a<"Û">(this.f2261, 336650996613030016L) / w.a<"B">((f2268 | 469215) + ~(f2268 & 469215) + 1 ^ -166204579, 349057757755238323L),
               0.0F,
               121763288940510105L
            ),
            243402859552372891L
         );
         var10001[(f2268 | 570161) + ~(f2268 & 570161) + 1 ^ -1302171470] = w.a<"B">(
            w.a<"B">(
               (float)w.a<"Û">(this, 159087442474805106L)
                  - w.a<"B">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L
                     ),
                     w.a<"Û">(this.f2264, 229561253177300454L),
                     342075947093997425L
                  ),
               0.0F,
               121763288940510105L
            ),
            243402859552372891L
         );
         return w.a<"Û">("%.1fs, %.0fm", var10001, 259257223839993282L);
      } else {
         return super.getInfo();
      }
   }

   @Override
   public void onDisable() {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         w.a<"Û">(this, 201888422229170957L);
         this.f2263 = (f2268 | 800161) + ~(f2268 & 800161) + 1 ^ 1301875164;
      }
   }

   @C1027
   public void m2930(C0612 var1) {
      if (this.f2263 != ((f2268 | 981951) + ~(f2268 & 981951) + 1 ^ 1302054850)) {
         class_1297 var2 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, this.f2263, 336328433021103938L
         );
         if (var2 instanceof class_1671) {
            if (this.f2266) {
               this.f2267 = (boolean)((f2268 | 686144) + ~(f2268 & 686144) + 1 ^ -1302283326);
               this.f2266 = (boolean)((f2268 | 18719) + ~(f2268 & 18719) + 1 ^ -1301640547);
               this.f2264 = w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 255985208769192509L),
                  (f2268 | 314010) + ~(f2268 & 314010) + 1 ^ -1301411568,
                  (f2268 | 314833) + ~(f2268 & 314833) + 1 ^ -1301410221,
                  (f2268 | 440709) + ~(f2268 & 440709) + 1 ^ -1301513713,
                  185231893858478475L
               );
            }

            ((DuckFireworkEntity)var2).setLife((f2268 | 743119) + ~(f2268 & 743119) + 1 ^ -1302227635);
         }
      }

      if (!this.f2267) {
         this.f2264 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 255985208769192509L),
            (f2268 | 397790) + ~(f2268 & 397790) + 1 ^ -1301491116,
            (f2268 | 484174) + ~(f2268 & 484174) + 1 ^ -1301438260,
            (f2268 | 411504) + ~(f2268 & 411504) + 1 ^ -1301510918,
            185231893858478475L
         );
      }

      if (this.f2264 != null
         && !w.a<"Û">(
            this.f2264,
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
               (f2268 | 317033) + ~(f2268 & 317033) + 1 ^ -1301408277,
               322697695374850390L
            ),
            (double)w.a<"Û">(this, 159087442474805106L),
            217636444529705754L
         )) {
         w.a<"Û">(this, 201888422229170957L);
      }

      if (w.a<"Û">(
         this.f2261,
         (double)w.a<"B">(
            w.a<"Û">((Float)w.a<"Û">(this.f2258, 174312564406604366L), 149784643039979208L),
            w.a<"B">((f2268 | 549875) + ~(f2268 & 549875) + 1 ^ -267476879, 349057757755238323L),
            304661293439332345L
         ),
         TimeUnit.SECONDS,
         215737872562411156L
      )) {
         w.a<"Û">(this, 201888422229170957L);
      }

      if (!w.a<"Û">((Boolean)w.a<"Û">(this.f2259, 174312564406604366L), 354697271520518137L)
         && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)) {
         w.a<"Û">(this, 201888422229170957L);
      }
   }

   @C1027
   public void m2931(C0816 var1) {
      if (w.a<"B">(w.a<"Û">(w.a<"Û">(var1, 300389461640657860L), 318588572047519347L), 219692839015221423L)) {
         w.a<"Û">(this, 201888422229170957L);
      }
   }

   @C1027
   public void m2932(C1041 var1) {
      if (w.a<"Û">(var1, 114026181039104081L) == this.f2263) {
         this.f2267 = (boolean)((f2268 | 465553) + ~(f2268 & 465553) + 1 ^ -1301423854);
         w.a<"Û">(var1, 385440235371820560L);
      }
   }

   @C1027
   public void m2933(C0521 var1) {
      if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)
         && w.a<"Û">(var1, 274841324610399830L) instanceof class_680
         && this.f2263 != ((f2268 | 567163) + ~(f2268 & 567163) + 1 ^ 1302174470)) {
         w.a<"Û">(var1, 385440235371820560L);
      }
   }

   @C1027
   public void m2934(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2604 var2
         && w.a<"Û">(var2, 353809255235785168L) == class_1299.field_6133
         && this.f2265 != null
         && w.a<"Û">(
               this.f2265, w.a<"Û">(var2, 180182980834797487L), w.a<"Û">(var2, 350612975000976430L), w.a<"Û">(var2, 193879592482149874L), 145073102115949444L
            )
            <= w.a<"B">(((long)f2268 | 664252L) + ~((long)f2268 & 664252L) + 1L ^ -4630263368192564930L, 317139102743630955L)
         && !w.a<"Û">(var1, 228050418011231981L)) {
         this.f2263 = w.a<"Û">(var2, 381677040267722388L);
         this.f2266 = (boolean)((f2268 | 981576) + ~(f2268 & 981576) + 1 ^ -1302054453);
         w.a<"Û">(this.f2261, 387780412884547639L);
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_6373 var4 && this.f2263 != ((f2268 | 213574) + ~(f2268 & 213574) + 1 ^ 1301708347) && this.f2267
         )
       {
         w.a<"Û">(this.f2260, var4, 276905752407976510L);
         w.a<"Û">(var1, 385440235371820560L);
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2708) {
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, this::m2936, 302363253312076733L);
      }
   }

   @C1027
   public void m2935(C0132 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2886 var2
         && w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  w.a<"Û">(var2, 188810737630318213L),
                  116318201500984113L
               ),
               222207108884875224L
            )
            == class_1802.field_8639) {
         this.f2265 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L
         );
         this.f2267 = (boolean)((f2268 | 572310) + ~(f2268 & 572310) + 1 ^ -1302169580);
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2824 && this.f2263 != ((f2268 | 155474) + ~(f2268 & 155474) + 1 ^ 1301766959) && this.f2267) {
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, this::m2936, 302363253312076733L);
      }
   }

   public void m2936() {
      this.f2263 = (f2268 | 742759) + ~(f2268 & 742759) + 1 ^ 1302227226;
      ArrayList var1 = new ArrayList();
      Iterator var2 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
         191661729848227466L
      );

      while (w.a<"Û">(var2, 333900474771661065L)) {
         class_1297 var3 = (class_1297)w.a<"Û">(var2, 192468336863492695L);
         if (var3 instanceof class_1671) {
            w.a<"Û">(var1, w.a<"B">(w.a<"Û">(var3, 137614607914618029L), 367942141483020029L), 276802003864609490L);
         }
      }

      var2 = w.a<"Û">(var1, 341496865259068134L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         Integer var5 = (Integer)w.a<"Û">(var2, 192468336863492695L);
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
            w.a<"Û">(var5, 260981171345819427L),
            class_5529.field_26998,
            247071483100332389L
         );
      }

      w.a<"Û">(var1, 140901994866995976L);
      w.a<"Û">(this, 270713313545586776L);
      if (w.a<"Û">(fireworks, 314537768572362865L)
         && w.a<"Û">((Boolean)w.a<"Û">(fireworks.f1469, 174312564406604366L), 354697271520518137L)
         && w.a<"Û">(this.f2262, ((long)f2268 | 775346L) + ~((long)f2268 & 775346L) + 1L ^ -1302261012L, 309642602085515378L)) {
         w.a<"Û">(fireworks, 350224882188364959L);
         w.a<"Û">(this.f2262, 387780412884547639L);
      }
   }

   public int m2937() {
      return w.a<"Û">(C0933.f1436, 351903969671141748L) * ((f2268 | 907152) + ~(f2268 & 907152) + 1 ^ -1301867518);
   }

   public void m2938() {
      while (!w.a<"Û">(this.f2260, 296374206093673190L)) {
         class_6373 var1 = (class_6373)w.a<"Û">(this.f2260, 154912847677331014L);
         if (var1 != null) {
            w.a<"B">(new class_6374(w.a<"Û">(var1, 215226256139899291L)), 384821682750494902L);
         }
      }
   }

   public static String _IEjdupjDdYQh4l1IYYybopQ8dtfPUJBEkKsv617zNQHpkJbKjS1YMqhjK81pLBC4mGV0UQfAtak58tHLgO4fyWaPY9s6LZNpQ8G/* $VF was: 4IEjdupjDdYQh4l1IYYybopQ8dtfPUJBEkKsv617zNQHpkJbKjS1YMqhjK81pLBC4mGV0UQfAtak58tHLgO4fyWaPY9s6LZNpQ8G*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
