package me.mioclient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.lang.invoke.MethodHandles.Lookup;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.util.function.BiFunction;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_22;
import net.minecraft.class_2683;
import net.minecraft.class_9209;
import net.minecraft.class_9334;

public final class C0476 implements C0045 {
   public final C0083 f2733 = new C0083();
   public final Map<String, class_22> f2734 = w.a<"B">(new HashMap(), 297409492390560467L);
   public String f2735 = null;
   public static int f2736 = w.a<"B">(3584371551944040664L, 257832362129977838L);

   public C0476() {
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   public class_22 m1081(class_1799 var1, int var2) {
      return w.a<"Û">(this, var1, new class_9209(var2), 138921357189625074L);
   }

   public class_22 m1082(class_1799 var1, class_9209 var2) {
      class_22 var3 = w.a<"B">(
         var2, m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 201092440250810377L
      );
      if (w.a<"Û">(var2, 137360608547095361L) != ((f2736 | 205225) + ~(f2736 & 205225) + 1 ^ 574606083) && var3 != null) {
         return var3;
      } else {
         String var4 = w.a<"Û">(w.a<"Û">(var1, 248308138707081744L), 286788181028845103L);
         return w.a<"Û">(var1, class_9334.field_49631, 130182657201466113L) ? (class_22)w.a<"Û">(this.f2734, var4, null, 183430545168542698L) : null;
      }
   }

   @C1027
   public void m1083(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2683) {
         w.a<"Û">(
            C0933.f1433,
            (Runnable)() -> {
               Iterator var1x = w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L)
                     .field_7547,
                  299599814954325426L
               );

               while (w.a<"Û">(var1x, 333900474771661065L)) {
                  class_1799 var2 = (class_1799)w.a<"Û">(var1x, 192468336863492695L);
                  w.a<"Û">(this, var2, 109173080984930101L);
               }
            },
            (f2736 | 743490) + ~(f2736 & 743490) + 1 ^ -574075626,
            122889728173745617L
         );
      }
   }

   @C1027
   public void m1084(C1243 var1) {
      this.f2735 = w.a<"Û">(var1, 183371481221279650L);
      w.a<"Û">(this, this.f2735, 339531990315191312L);
   }

   @C1027
   public void m1085(C0612 var1) {
      if (w.a<"Û">(this.f2733, ((long)f2736 | 955388L) + ~((long)f2736 & 955388L) + 1L ^ -573733204L, TimeUnit.MINUTES, 227589533608945164L)
         && this.f2735 != null) {
         w.a<"B">(
            (Runnable)() -> w.a<"Û">(this, this.f2735, 199831472620596241L),
            m$$ST0lYU78VmyXastPw1lLFDyjhGsVzgyCIA2iF6clygrko2h3N2g9nQ0NE00dM9oeZ5yr22Y8aXvILtAlo6yP2lrTJIwGiJraq,
            291638628714148360L
         );
      }
   }

   @C1027
   public void m1086(C0190 var1) {
      if (this.f2735 != null) {
         w.a<"Û">(this, this.f2735, 199831472620596241L);
      }
   }

   public void m1087(class_1799 var1) {
      if (w.a<"Û">(var1, 222207108884875224L) == class_1802.field_8204 && w.a<"Û">(var1, class_9334.field_49631, 130182657201466113L)) {
         String var2 = w.a<"Û">(w.a<"Û">(var1, 248308138707081744L), 286788181028845103L);
         class_9209 var3 = (class_9209)w.a<"Û">(
            var1, class_9334.field_49646, new class_9209((f2736 | 575815) + ~(f2736 & 575815) + 1 ^ 573842413), 276046324541139581L
         );
         w.a<"Û">(
            this.f2734,
            var2,
            (BiFunction<String, class_22, class_22>)(var1x, var2x) -> w.a<"B">(
                  var3, m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 201092440250810377L
               ),
            280205116198276366L
         );
      }
   }

   public void m1088(String var1) {
      if (!w.a<"Û">(this.f2734, 199311245529055798L)) {
         ByteArrayOutputStream var2 = new ByteArrayOutputStream();
         DataOutputStream var3 = new DataOutputStream(var2);

         try {
            w.a<"Û">(var3, w.a<"Û">(this.f2734, 165622882639398740L), 304147976532847671L);
            Iterator var4 = w.a<"Û">(new HashSet(w.a<"Û">(this.f2734, 354320704134596920L)), 293403309622732054L);

            while (w.a<"Û">(var4, 333900474771661065L)) {
               Entry var5 = (Entry)w.a<"Û">(var4, 192468336863492695L);
               w.a<"Û">(var3, (String)w.a<"Û">(var5, 141740301999341859L), 295744656452293195L);
               w.a<"Û">(var3, ((class_22)w.a<"Û">(var5, 196870340575900401L)).field_119, 207216472812072892L);
               byte[] var6 = ((class_22)w.a<"Û">(var5, 196870340575900401L)).field_122;
               int var7 = var6.length;

               for (int var8 = (f2736 | 638483) + ~(f2736 & 638483) + 1 ^ -573920442; var8 < var7; var8++) {
                  byte var9 = var6[var8];
                  w.a<"Û">(var3, var9, 207216472812072892L);
               }
            }

            w.a<"B">(
               w.a<"Û">(C1165.f0529, new C1002().m2591(C0498.m3903(var1)).m2593("\u0001.data"), 208803259736780592L),
               w.a<"Û">(this, w.a<"Û">(var2, 364620682254096550L), 380409560111349298L),
               146599005179503313L
            );
         } catch (Exception var10) {
            w.a<"Û">(var10, 277292852406578821L);
         }
      }
   }

   public void m1089(String var1) {
      w.a<"Û">(this.f2734, 288879253482200997L);

      try {
         Path var2 = w.a<"Û">(C1165.f0529, new C1002().m2591(C0498.m3903(var1)).m2593("\u0001.data"), 208803259736780592L);
         if (!w.a<"Û">(w.a<"Û">(var2, 318068064568792515L), 317839649527142638L)) {
            return;
         }

         byte[] var3 = w.a<"Û">(this, w.a<"B">(var2, 151569379125095176L), 120894540358358268L);
         ByteArrayInputStream var4 = new ByteArrayInputStream(var3);
         DataInputStream var5 = new DataInputStream(var4);
         int var6 = w.a<"Û">(var5, 385128449716077832L);

         for (int var7 = (f2736 | 959794) + ~(f2736 & 959794) + 1 ^ -573722521; var7 < var6; var7++) {
            String var8 = w.a<"Û">(var5, 324739747070342739L);
            byte var9 = w.a<"Û">(var5, 166251342565308208L);
            class_22 var10 = w.a<"B">(var9, (boolean)((f2736 | 858490) + ~(f2736 & 858490) + 1 ^ -573699026), null, 208413562820086854L);

            for (int var11 = (f2736 | 726562) + ~(f2736 & 726562) + 1 ^ -574094473; var11 < ((f2736 | 508277) + ~(f2736 & 508277) + 1 ^ -574319584); var11++) {
               var10.field_122[var11] = w.a<"Û">(var5, 166251342565308208L);
            }

            w.a<"Û">(this.f2734, var8, var10, 121875332790264405L);
         }
      } catch (Exception var12) {
         w.a<"Û">(var12, 277292852406578821L);
      }
   }

   public byte[] m1090(byte[] var1) {
      try {
         ByteArrayOutputStream var2 = new ByteArrayOutputStream();
         Inflater var3 = new Inflater();
         w.a<"Û">(var3, var1, 113316035219122259L);
         byte[] var4 = new byte[(f2736 | 929999) + ~(f2736 & 929999) + 1 ^ -573766246];

         while (!w.a<"Û">(var3, 127444829110360300L)) {
            int var5 = w.a<"Û">(var3, var4, 283550305584055208L);
            if (var5 == 0) {
               break;
            }

            w.a<"Û">(var2, var4, (f2736 | 988215) + ~(f2736 & 988215) + 1 ^ -573832862, var5, 355193647423640635L);
         }

         w.a<"Û">(var3, 337560000345957884L);
         return w.a<"Û">(var2, 364620682254096550L);
      } catch (Exception var6) {
         throw new RuntimeException();
      }
   }

   public byte[] m1091(byte[] var1) {
      ByteArrayOutputStream var2 = new ByteArrayOutputStream();
      Deflater var3 = new Deflater((f2736 | 181992) + ~(f2736 & 181992) + 1 ^ -574499916);
      w.a<"Û">(var3, var1, 225927552205956562L);
      w.a<"Û">(var3, 223107161454098348L);
      byte[] var4 = new byte[(f2736 | 864971) + ~(f2736 & 864971) + 1 ^ -573700194];

      while (!w.a<"Û">(var3, 320930749236086551L)) {
         int var5 = w.a<"Û">(var3, var4, 177651612319576355L);
         w.a<"Û">(var2, var4, (f2736 | 302770) + ~(f2736 & 302770) + 1 ^ -574125081, var5, 355193647423640635L);
      }

      w.a<"Û">(var3, 299331078032241673L);
      return w.a<"Û">(var2, 364620682254096550L);
   }

   public static String jMz3lYczwmEgaN0JMUNVn7yJ3CYp5Xj5rMm1KelkK4epZJhLQVrtk6GxD2aaSurTvdKVm6OwViqVwp0BAgh9FSH22WCbIvRpKlEY(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
