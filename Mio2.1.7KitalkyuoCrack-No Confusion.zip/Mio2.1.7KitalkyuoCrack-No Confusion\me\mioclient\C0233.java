package me.mioclient;

import java.util.function.Predicate;

public class C0233 implements Predicate {
   public C1220 f4905;

   public C0233(C1220 var1) {
      this.f4905 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4905.f1541, 174312564406604366L) == C1221.f4252;
   }
}
