package me.mioclient;

import java.io.DataOutput;
import org.jetbrains.annotations.NotNull;

public class C0111 implements DataOutput {
   public int f3038;
   public static int f3039 = w.a<"B">(8230684058887995759L, 257832362129977838L);

   public int m3275() {
      return this.f3038;
   }

   @Override
   public void write(int var1) {
      this.f3038 = this.f3038 + ((f3039 | 578378) + ~(f3039 & 578378) + 1 ^ -1832995478);
   }

   @Override
   public void write(byte[] var1) {
      this.f3038 += var1.length;
   }

   @Override
   public void write(@NotNull byte[] var1, int var2, int var3) {
      this.f3038 += var3;
   }

   @Override
   public void writeBoolean(boolean var1) {
      this.f3038 = this.f3038 + ((f3039 | 35491) + ~(f3039 & 35491) + 1 ^ -1833505661);
   }

   @Override
   public void writeByte(int var1) {
      this.f3038 = this.f3038 + ((f3039 | 522955) + ~(f3039 & 522955) + 1 ^ -1833853717);
   }

   @Override
   public void writeShort(int var1) {
      this.f3038 = this.f3038 + ((f3039 | 157447) + ~(f3039 & 157447) + 1 ^ -1833696988);
   }

   @Override
   public void writeChar(int var1) {
      this.f3038 = this.f3038 + ((f3039 | 217683) + ~(f3039 & 217683) + 1 ^ -1833618320);
   }

   @Override
   public void writeInt(int var1) {
      this.f3038 = this.f3038 + ((f3039 | 686858) + ~(f3039 & 686858) + 1 ^ -1833165521);
   }

   @Override
   public void writeLong(long var1) {
      this.f3038 = this.f3038 + ((f3039 | 637016) + ~(f3039 & 637016) + 1 ^ -1832919439);
   }

   @Override
   public void writeFloat(float var1) {
      this.f3038 = this.f3038 + ((f3039 | 83647) + ~(f3039 & 83647) + 1 ^ -1833492326);
   }

   @Override
   public void writeDouble(double var1) {
      this.f3038 = this.f3038 + ((f3039 | 791881) + ~(f3039 & 791881) + 1 ^ -1833274528);
   }

   @Override
   public void writeBytes(String var1) {
      this.f3038 = this.f3038 + w.a<"Û">(var1, 120891947504160641L);
   }

   @Override
   public void writeChars(String var1) {
      this.f3038 = this.f3038 + w.a<"Û">(var1, 246450913230257000L).length;
   }

   @Override
   public void writeUTF(@NotNull String var1) {
      this.f3038 = this.f3038 + w.a<"Û">(var1, 246450913230257000L).length;
   }
}
