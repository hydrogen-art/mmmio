package me.mioclient;

import net.minecraft.class_4587;

public class C0127 {
   public static C1301 f4204;
   public static final class_4587 f4205 = new class_4587();
   public static int f4206 = 1097419423;

   public static void init() {
      C1303 var10002 = C1303.f4569;
      C1302[] var10003 = new C1302[(f4206 | 27437) + ~(f4206 & 27437) + 1 ^ 1097408947];
      var10003[(f4206 | 9982) + ~(f4206 & 9982) + 1 ^ 1097428065] = C1302.f0720;
      f4204 = new C1301(var10002, var10003);
      f4204.m3773();
      f4204.m3779(
         f4204.m3775(Double.longBitsToDouble(-4616189618054758400L), Double.longBitsToDouble(-4616189618054758400L)).m3777(),
         f4204.m3775(
               Double.longBitsToDouble(-4616189618054758400L),
               Double.longBitsToDouble(((long)f4206 | 443228L) + ~((long)f4206 & 443228L) + 1L ^ 4607182419897846211L)
            )
            .m3777(),
         f4204.m3775(
               Double.longBitsToDouble(((long)f4206 | 400609L) + ~((long)f4206 & 400609L) + 1L ^ 4607182419897833086L),
               Double.longBitsToDouble(((long)f4206 | 876655L) + ~((long)f4206 & 876655L) + 1L ^ 4607182419897101040L)
            )
            .m3777(),
         f4204.m3775(
               Double.longBitsToDouble(((long)f4206 | 737295L) + ~((long)f4206 & 737295L) + 1L ^ 4607182419896961680L),
               Double.longBitsToDouble(-4616189618054758400L)
            )
            .m3777()
      );
      f4204.m3781();
   }

   public static void m3752() {
      f4204.m3782(f4205);
   }

   public static void m3753() {
      f4204.m3783(f4205);
   }

   public static void m3754() {
      f4204.m3784();
   }

   static {
      long var10000 = 8725725736086361574L;
   }
}
