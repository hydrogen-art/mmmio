package me.mioclient;

import com.mojang.datafixers.util.Pair;
import me.mioclient.mixin.ducks.DuckBoatEntityRenderer;
import net.minecraft.class_1690;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4595;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import org.joml.Quaternionf;

public class C0522 implements C0045, C0967<class_1690> {
   public static final Quaternionf f4003 = new Quaternionf();

   public void m3654(class_1690 var1, float var2, class_4587 var3) {
      DuckBoatEntityRenderer var4 = (DuckBoatEntityRenderer)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1561()
         .method_3953(var1);
      var3.method_22903();
      var3.method_46416(0.0F, 0.375F, 0.0F);
      var3.method_22907(class_7833.field_40716.rotationDegrees(180.0F - class_3532.method_16439(var2, var1.field_5982, var1.method_36454())));
      float var5 = (float)var1.method_54295() - var2;
      float var6 = var1.method_54294() - var2;
      if (var6 < 0.0F) {
         var6 = 0.0F;
      }

      if (var5 > 0.0F) {
         var3.method_22907(class_7833.field_40714.rotationDegrees(class_3532.method_15374(var5) * var5 * var6 / 10.0F * (float)var1.method_54296()));
      }

      float var7 = var1.method_7547(var2);
      if (!class_3532.method_15347(var7, 0.0F)) {
         var3.method_22907(f4003.setAngleAxis(var1.method_7547(var2) * C1074.f4552, 1.0F, 0.0F, 1.0F));
      }

      Pair var8 = var4.mio$getTexturesAndModels().get(var1.method_47885());
      class_4595 var9 = (class_4595)var8.getSecond();
      var3.method_22905(-1.0F, -1.0F, 1.0F);
      var3.method_22907(class_7833.field_40716.rotationDegrees((float)C1074.f4547));
      var9.method_2819(var1, var2, 0.0F, -0.1F, 0.0F, 0.0F);

      for (class_630 var11 : var9.method_22960()) {
         C0297.m2458(new C0550(var3, C0595.f4921), var11);
      }

      var3.method_22909();
   }
}
