package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class C0408 extends C1266 {
   public static final C1258 multitask = C0933.f1409.m2696(C1258.class);
   public final C0015<C0409> f2236;
   public final C0015<Integer> f2237;
   public final C0015<Float> f2238;
   public final C0015<Boolean> f2239;
   public final C0083 f2240;
   public float f2241;
   public final List<Long> f2242;
   public static int f2243 = w.a<"B">(741751448230166046L, 257832362129977838L);

   public C0408() {
      super("AutoClicker", "Spams attack as you hold down the attack button.", C1045.f3172);
      w.a<"B">(this, 242859112966675773L);
      this.f2240 = new C0083();
      this.f2241 = w.a<"B">((f2243 | 966407) + ~(f2243 & 966407) + 1 ^ 1565213798, 349057757755238323L);
      this.f2242 = new ArrayList<>();
   }

   @Override
   public String getInfo() {
      return w.a<"B">(w.a<"Û">(this.f2242, 260708190417501501L), 140572902764040146L);
   }

   @C1027
   public void m0926(C1357 var1) {
      w.a<"Û">(
         this.f2242,
         (Predicate<Long>)var0 -> (boolean)(w.a<"B">(223409559795593705L) - w.a<"Û">(var0, 151184307344636838L)
                  >= (((long)f2243 | 342196L) + ~((long)f2243 & 342196L) + 1L ^ 1656799293L)
               ? (f2243 | 473692) + ~(f2243 & 473692) + 1 ^ 1656930620
               : (f2243 | 961412) + ~(f2243 & 961412) + 1 ^ 1657491685),
         372804948295703628L
      );
      long var2 = (((long)f2243 | 652317L) + ~((long)f2243 & 652317L) + 1L ^ 1657539732L)
         / (long)w.a<"Û">((Integer)w.a<"Û">(this.f2237, 174312564406604366L), 260981171345819427L);
      if (!w.a<"Û">(this.f2238, 335309852205562156L)) {
         var2 = (long)((float)var2 * this.f2241);
      }

      if (w.a<"Û">(this.f2240, var2, 309642602085515378L)) {
         w.a<"Û">(this, 274284141494502372L);
         w.a<"Û">(this.f2242, w.a<"B">(w.a<"B">(223409559795593705L), 279131300036783447L), 276802003864609490L);
         w.a<"Û">(this.f2240, 387780412884547639L);
         this.f2241 = w.a<"B">(
            w.a<"B">((f2243 | 602660) + ~(f2243 & 602660) + 1 ^ 1565313349, 349057757755238323L),
            w.a<"Û">((Float)w.a<"Û">(this.f2238, 174312564406604366L), 149784643039979208L),
            270595929839834230L
         );
      }
   }

   public boolean m0927(class_1297 var1) {
      if (w.a<"Û">(this, 314537768572362865L)
         && w.a<"Û">((Boolean)w.a<"Û">(this.f2239, 174312564406604366L), 354697271520518137L)
         && var1 instanceof class_1657 var2
         && w.a<"Û">(C0933.f1417, var2, 241036547861815495L)) {
         return (boolean)((f2243 | 219528) + ~(f2243 & 219528) + 1 ^ 1657185000);
      }

      return (boolean)((f2243 | 900498) + ~(f2243 & 900498) + 1 ^ 1657292531);
   }

   public void m0928() {
      if (!w.a<"Û">(multitask, 314537768572362865L)
         || !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 367966343301975358L)
            && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 == null) {
         w.a<"B">(w.a<"Û">((C0409)w.a<"Û">(this.f2236, 174312564406604366L), 263855137237747191L).field_1655, 203486823357774136L);
      } else {
         w.a<"Û">((C0409)w.a<"Û">(this.f2236, 174312564406604366L), 275604052721263151L);
      }
   }

   public static String UTdBPIsXJI6au725uDhMGJAb8rwdW2xhsyBzGyZBEwEC8RbR2GCxa2GExoRpMP4V4Jz94EFg4IXxKHOoSwuKixufeTZwrt0ttLta(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
