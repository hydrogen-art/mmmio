package me.mioclient;

public class C0147 extends C1180 {
}
