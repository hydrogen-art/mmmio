package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1701;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2535;
import net.minecraft.class_2661;

public class C0174 extends C1266 {
   public static final C0404 illegaldisconnect = C0933.f1409.m2696(C0404.class);
   public static C0204 autoreconnect = C0933.f1409.m2696(C0204.class);
   public final C0015<Integer> f3337;
   public final C0015<Float> f3338;
   public final C0015<Boolean> f3339;
   public final C0015<Boolean> f3340;
   public final C0015<Boolean> f3341;
   public final C0015<Boolean> f3342;
   public final C0015<Boolean> f3343;
   public final C0015<Boolean> f3344;
   public final C0015<Boolean> f3345;
   public final C0015<Integer> f3346;
   public final C0015<Boolean> f3347;
   public final C0015<Integer> f3348;
   public final C0015<Boolean> f3349;
   public final C0015<Boolean> f3350;
   public final C0015<Float> f3351;
   public Runnable f3352;
   public final C0083 f3353;
   public static int f3354 = w.a<"B">(6667208046688353566L, 257832362129977838L);

   public C0174() {
      super("AutoLog", "Logs you out so you don't have to fight anyone.", C1045.f3172);
      w.a<"B">(this, 242859112966675773L);
      this.f3353 = new C0083();
   }

   @Override
   public void onEnable() {
      this.f3352 = null;
   }

   @Override
   public String getInfo() {
      return w.a<"Û">(new DecimalFormat("0.0"), w.a<"Û">(this.f3337, 174312564406604366L), 319442275750276066L);
   }

   @C1027
   public void m3420(C0612 var1) {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 216539022803564207L)
            && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 292497114066973519L)) {
            if (!w.a<"Û">((Boolean)w.a<"Û">(this.f3340, 174312564406604366L), 354697271520518137L)
               || w.a<"B">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 130756052256592378L)
               )
             {
               if (w.a<"Û">((Boolean)w.a<"Û">(this.f3347, 174312564406604366L), 354697271520518137L) && w.a<"Û">(this, 212552450171520959L)) {
                  w.a<"Û">(this, "Your elytra durability is too low!", 310048870364577593L);
               } else if (w.a<"Û">((Boolean)w.a<"Û">(this.f3350, 174312564406604366L), 354697271520518137L)
                  && w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L
                     )
                     < (double)w.a<"Û">((Float)w.a<"Û">(this.f3351, 174312564406604366L), 149784643039979208L)) {
                  w.a<"Û">(
                     this,
                     new C1002().m2591(w.a<"B">(w.a<"Û">(this.f3351, 174312564406604366L), 174997918119584642L)).m2593("You are below Y level \u0001"),
                     310048870364577593L
                  );
               } else if (!(
                  (float)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6012
                        / w.a<"B">((f3354 | 624903) + ~(f3354 & 624903) + 1 ^ -1276126407, 349057757755238323L)
                     < w.a<"Û">((Float)w.a<"Û">(this.f3338, 174312564406604366L), 149784643039979208L)
               )) {
                  if (w.a<"Û">((Boolean)w.a<"Û">(this.f3342, 174312564406604366L), 354697271520518137L)) {
                     Iterator var2 = w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 188438576288929642L
                        ),
                        341496865259068134L
                     );

                     while (w.a<"Û">(var2, 333900474771661065L)) {
                        class_1657 var3 = (class_1657)w.a<"Û">(var2, 192468336863492695L);
                        if (!w.a<"Û">(C0933.f1417, w.a<"Û">(w.a<"Û">(var3, 148578202377381513L), 286788181028845103L), 225253295937045434L)
                           && var3 != m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724) {
                           w.a<"Û">(
                              this,
                              new C1002()
                                 .m2591(w.a<"Û">(w.a<"Û">(var3, 148578202377381513L), 286788181028845103L))
                                 .m2593("\u0001 has entered your render distance!"),
                              310048870364577593L
                           );
                        }
                     }
                  }

                  if (!w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                           class_1701.class,
                           w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 261249985676109960L
                              ),
                              w.a<"B">(((long)f3354 | 751945L) + ~((long)f3354 & 751945L) + 1L ^ -4616189618284582025L, 317139102743630955L),
                              w.a<"B">(((long)f3354 | 880667L) + ~((long)f3354 & 880667L) + 1L ^ -4616189618284715483L, 317139102743630955L),
                              w.a<"B">(((long)f3354 | 481373L) + ~((long)f3354 & 481373L) + 1L ^ -4616189618285376925L, 317139102743630955L),
                              172678400209048579L
                           ),
                           class_1701::method_7578,
                           132523282209579994L
                        ),
                        284469716622774448L
                     )
                     && w.a<"Û">((Boolean)w.a<"Û">(this.f3344, 174312564406604366L), 354697271520518137L)) {
                     w.a<"Û">(this, "You are at risk of getting blown up by a TNT minecart!", 310048870364577593L);
                  }

                  if (w.a<"Û">((Boolean)w.a<"Û">(this.f3343, 174312564406604366L), 354697271520518137L)) {
                     w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L
                        ),
                        (Consumer<class_1297>)var1x -> {
                           if (var1x instanceof class_1511
                              && w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                    var1x,
                                    116638973756329245L
                                 )
                                 <= w.a<"B">(((long)f3354 | 323262L) + ~((long)f3354 & 323262L) + 1L ^ -4638707616422118272L, 317139102743630955L)) {
                              double var2x = (double)w.a<"B">(
                                 w.a<"Û">(var1x, 360959056130751432L),
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 w.a<"Û">(
                                    m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                    261249985676109960L
                                 ),
                                 w.a<"B">(((long)f3354 | 389227L) + ~((long)f3354 & 389227L) + 1L ^ -4618441418098892203L, 317139102743630955L),
                                 (boolean)((f3354 | 772137) + ~(f3354 & 772137) + 1 ^ -229795306),
                                 null,
                                 null,
                                 288791306669618563L
                              );
                              if (var2x >= (double)w.a<"B">(346651574723755238L)) {
                                 w.a<"Û">(this, "You are at risk of getting blown up by an end crystal!", 310048870364577593L);
                              }
                           }
                        },
                        299394416706935363L
                     );
                  }

                  int var5 = (int)w.a<"B">(346651574723755238L);
                  if (!w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 307964813036810127L
                     )
                     && var5 != 0) {
                     if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 319349690398983888L)
                        || !w.a<"Û">((Boolean)w.a<"Û">(this.f3341, 174312564406604366L), 354697271520518137L)) {
                        int var6 = w.a<"Û">(
                           w.a<"Û">(
                              w.a<"Û">(
                                 w.a<"Û">(
                                    w.a<"Û">(
                                          m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                          373857742241070098L
                                       )
                                       .field_7547,
                                    254602599683321059L
                                 ),
                                 (Predicate<class_1799>)var0 -> (boolean)(w.a<"Û">(var0, 222207108884875224L) == class_1802.field_8288
                                       ? (f3354 | 159344) + ~(f3354 & 159344) + 1 ^ -230409137
                                       : (f3354 | 116582) + ~(f3354 & 116582) + 1 ^ -230189736),
                                 287370376266094532L
                              ),
                              class_1799::method_7947,
                              189770009826906455L
                           ),
                           188736301400376121L
                        );
                        if (w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 159396947398056288L
                              ),
                              222207108884875224L
                           )
                           == class_1802.field_8288) {
                           var6 += w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 159396947398056288L
                              ),
                              144154955567765793L
                           );
                        }

                        int var4 = var6 <= w.a<"Û">((Integer)w.a<"Û">(this.f3346, 174312564406604366L), 260981171345819427L)
                           ? (f3354 | 324203) + ~(f3354 & 324203) + 1 ^ -230514604
                           : (f3354 | 892856) + ~(f3354 & 892856) + 1 ^ -229913210;
                        if (!w.a<"Û">((Boolean)w.a<"Û">(this.f3345, 174312564406604366L), 354697271520518137L)) {
                           var4 = (f3354 | 90087) + ~(f3354 & 90087) + 1 ^ -230224424;
                        }

                        if (var5 <= w.a<"Û">((Integer)w.a<"Û">(this.f3337, 174312564406604366L), 260981171345819427L) && var4 != 0) {
                           w.a<"Û">(this, new C1002().m2578(var5).m2593("Your health is too low! (\u0001)."), 310048870364577593L);
                        }
                     }
                  }
               }
            }
         }
      }
   }

   @C1027
   public void m3421(C0878 var1) {
      if (w.a<"Û">(this, 205492958615326489L)) {
         this.f3352 = null;
      }

      if (this.f3352 != null && w.a<"Û">(this.f3353, ((long)f3354 | 142691L) + ~((long)f3354 & 142691L) + 1L ^ -230393215L, 309642602085515378L)) {
         w.a<"Û">(this.f3352, 324159666149362285L);
         this.f3352 = null;
      }
   }

   @C1027
   public void m3422(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2661) {
         this.f3352 = null;
      }
   }

   public boolean m3423() {
      class_1799 var1 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
         w.a<"Û">(class_1304.field_6174, 296145192384863639L),
         266240718425717133L
      );
      if (w.a<"Û">(var1, class_1802.field_8833, 282470456889867724L) && w.a<"Û">(var1, 263055534152868350L)) {
         int var2 = w.a<"B">(var1, 303034432954394330L) > (float)w.a<"Û">((Integer)w.a<"Û">(this.f3348, 174312564406604366L), 260981171345819427L)
            ? (f3354 | 998649) + ~(f3354 & 998649) + 1 ^ -230068538
            : (f3354 | 486743) + ~(f3354 & 486743) + 1 ^ -230604951;
         if (var2 != 0) {
            return (boolean)((f3354 | 898569) + ~(f3354 & 898569) + 1 ^ -229907401);
         } else {
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f3349, 174312564406604366L), 354697271520518137L)) {
               Iterator var3 = w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L)
                     .field_7547,
                  299599814954325426L
               );

               while (w.a<"Û">(var3, 333900474771661065L)) {
                  class_1799 var4 = (class_1799)w.a<"Û">(var3, 192468336863492695L);
                  if (w.a<"Û">(var4, class_1802.field_8833, 282470456889867724L)
                     && (
                        !w.a<"Û">(var4, 263055534152868350L)
                           || w.a<"B">(var4, 303034432954394330L) > (float)w.a<"Û">((Integer)w.a<"Û">(this.f3348, 174312564406604366L), 260981171345819427L)
                     )) {
                     return (boolean)((f3354 | 895920) + ~(f3354 & 895920) + 1 ^ -229901938);
                  }
               }
            }

            return (boolean)((f3354 | 551714) + ~(f3354 & 551714) + 1 ^ -229754595);
         }
      } else {
         return (boolean)((f3354 | 98088) + ~(f3354 & 98088) + 1 ^ -230216426);
      }
   }

   public void m3424(String var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f3339, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(this, 155417974908982175L);
      }

      class_2535 var2 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944, 337197838954396671L
      );
      if (var2 != null) {
         C0933.f1416.f1407 = (boolean)((f3354 | 987307) + ~(f3354 & 987307) + 1 ^ -230079852);
         w.a<"Û">(autoreconnect, 155417974908982175L);
         Runnable var3 = () -> w.a<"Û">(
               var2,
               w.a<"Û">(
                  w.a<"B">(151712998973257886L),
                  w.a<"B">(
                     new C1002()
                        .m2591(var1)
                        .m2591(w.a<"B">(class_124.field_1061, 174997918119584642L))
                        .m2591(w.a<"B">(class_124.field_1080, 174997918119584642L))
                        .m2593("\u0001[AutoLog] \u0001\u0001"),
                     273107254583785490L
                  ),
                  267862536496645581L
               ),
               165895829995046834L
            );
         int var4 = w.a<"Û">((Boolean)w.a<"Û">(illegaldisconnect.f1655, 174312564406604366L), 354697271520518137L) && w.a<"B">(110949539905229901L)
            ? (f3354 | 123380) + ~(f3354 & 123380) + 1 ^ -230181942
            : (f3354 | 328926) + ~(f3354 & 328926) + 1 ^ -230467871;
         if (w.a<"Û">(illegaldisconnect, 314537768572362865L) && var4 != 0) {
            w.a<"B">(163001575677976185L);
            if (this.f3352 == null) {
               w.a<"Û">(this.f3353, 387780412884547639L);
            }

            this.f3352 = var3;
            return;
         }

         w.a<"Û">(var3, 324159666149362285L);
      }
   }

   public static String WZV0PzXTTrO9mP7781Ai5GSWvqMEk8zky70OkwSruWs8eYqxGiIvsMcFtlOeAzhv3pkPsrkbYU2VpLMNmlHqARogQZP4rgMJ8M6H(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
