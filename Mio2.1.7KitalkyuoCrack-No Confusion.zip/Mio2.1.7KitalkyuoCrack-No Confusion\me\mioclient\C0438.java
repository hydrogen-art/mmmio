package me.mioclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_5481;
import net.minecraft.class_757;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_327.class_6415;
import org.joml.Matrix4f;

public class C0438 {
   public static final C0066 f4852 = C0066.m0745();

   public static void m3958(class_4587 var0, float var1, float var2, float var3, float var4, Color var5) {
      m3962(var0, var1, var3, var2 + var4, var3 + var4, var5);
   }

   public static void m3959(class_4587 var0, float var1, float var2, float var3, float var4, Color var5) {
      m3962(var0, var1, var2 + var4, var1 + var4, var3, var5);
   }

   public static void m3960(class_4587 var0, float var1, float var2, float var3, float var4, Color var5) {
      m3958(var0, var1, var3, var2, 1.0F, var5);
      m3959(var0, var3, var2, var4, 1.0F, var5);
      m3958(var0, var1, var3, var4, 1.0F, var5);
      m3959(var0, var1, var2, var4, 1.0F, var5);
   }

   public static void m3961(class_4587 var0, float var1, float var2, float var3, float var4, float var5, Color var6) {
      m3958(var0, var1, var3, var2, var5, var6);
      m3959(var0, var3, var2, var4, var5, var6);
      m3958(var0, var1, var3, var4, var5, var6);
      m3959(var0, var1, var2, var4, var5, var6);
   }

   public static void m3962(class_4587 var0, float var1, float var2, float var3, float var4, Color var5) {
      m3963(var0, var1, var2, var3, var4, var5.hashCode());
   }

   public static void m3963(class_4587 var0, float var1, float var2, float var3, float var4, int var5) {
      float var6 = (float)(var5 >> 24 & 0xFF) / 255.0F;
      float var7 = (float)(var5 >> 16 & 0xFF) / 255.0F;
      float var8 = (float)(var5 >> 8 & 0xFF) / 255.0F;
      float var9 = (float)(var5 & 0xFF) / 255.0F;
      if (var6 != 0.0F) {
         f4852.method_22918(var0.method_23760().method_23761(), var1, var4, 0.0F).method_22915(var7, var8, var9, var6);
         f4852.method_22918(var0.method_23760().method_23761(), var3, var4, 0.0F).method_22915(var7, var8, var9, var6);
         f4852.method_22918(var0.method_23760().method_23761(), var3, var2, 0.0F).method_22915(var7, var8, var9, var6);
         f4852.method_22918(var0.method_23760().method_23761(), var1, var2, 0.0F).method_22915(var7, var8, var9, var6);
      }
   }

   public static void m3964(Matrix4f var0, float var1, float var2, float var3, float var4, int var5, int var6, int var7, int var8) {
      float[] var9 = new float[]{(float)(var5 >> 16 & 0xFF) / 255.0F, (float)(var5 >> 8 & 0xFF) / 255.0F, (float)(var5 & 0xFF) / 255.0F};
      float[] var10 = new float[]{(float)(var6 >> 16 & 0xFF) / 255.0F, (float)(var6 >> 8 & 0xFF) / 255.0F, (float)(var6 & 0xFF) / 255.0F};
      float[] var11 = new float[]{(float)(var7 >> 16 & 0xFF) / 255.0F, (float)(var7 >> 8 & 0xFF) / 255.0F, (float)(var7 & 0xFF) / 255.0F};
      float[] var12 = new float[]{(float)(var8 >> 16 & 0xFF) / 255.0F, (float)(var8 >> 8 & 0xFF) / 255.0F, (float)(var8 & 0xFF) / 255.0F};
      f4852.method_22918(var0, var1, var2 + var4, 0.0F).method_22915(var12[0], var12[1], var12[2], 1.0F);
      f4852.method_22918(var0, var1 + var3, var2 + var4, 0.0F).method_22915(var11[0], var11[1], var11[2], 1.0F);
      f4852.method_22918(var0, var1 + var3, var2, 0.0F).method_22915(var10[0], var10[1], var10[2], 1.0F);
      f4852.method_22918(var0, var1, var2, 0.0F).method_22915(var9[0], var9[1], var9[2], 1.0F);
   }

   public static void m3965(Matrix4f var0, float var1, float var2, float var3, float var4, int... var5) {
      if (var5.length >= 2) {
         float[][] var6 = new float[var5.length][4];

         for (int var7 = 0; var7 < var5.length; var7++) {
            var6[var7] = new float[]{
               (float)(var5[var7] >> 24 & 0xFF) / 255.0F,
               (float)(var5[var7] >> 16 & 0xFF) / 255.0F,
               (float)(var5[var7] >> 8 & 0xFF) / 255.0F,
               (float)(var5[var7] & 0xFF) / 255.0F
            };
         }

         float var10 = var3 / (float)var5.length;

         for (int var8 = 1; var8 < var5.length; var8++) {
            float var9 = var8 == var5.length - 1 ? var3 : var10 * (float)var8;
            f4852.method_22918(var0, var1 + var9, var2, 0.0F).method_22915(var6[var8][1], var6[var8][2], var6[var8][3], var6[var8][0]);
            f4852.method_22918(var0, var1 + var10 * (float)(var8 - 1), var2, 0.0F)
               .method_22915(var6[var8 - 1][1], var6[var8 - 1][2], var6[var8 - 1][3], var6[var8 - 1][0]);
            f4852.method_22918(var0, var1 + var10 * (float)(var8 - 1), var2 + var4, 0.0F)
               .method_22915(var6[var8 - 1][1], var6[var8 - 1][2], var6[var8 - 1][3], var6[var8 - 1][0]);
            f4852.method_22918(var0, var1 + var9, var2 + var4, 0.0F).method_22915(var6[var8][1], var6[var8][2], var6[var8][3], var6[var8][0]);
         }
      }
   }

   public static void m3966(class_4587 var0, String var1, int var2, int var3, int var4, boolean var5) {
      class_310.method_1551()
         .field_1772
         .method_27521(
            var1, (float)var2, (float)var3, var4, var5, var0.method_23760().method_23761(), C0498.f4738.m3884().m1959(), class_6415.field_33993, 0, 15728880
         );
   }

   public static void m3967(class_4587 var0, class_5481 var1, int var2, int var3, int var4, boolean var5) {
      class_310.method_1551()
         .field_1772
         .method_22942(
            var1, (float)var2, (float)var3, var4, var5, var0.method_23760().method_23761(), C0498.f4738.m3884().m1959(), class_6415.field_33993, 0, 15728880
         );
   }

   public static void m3968() {
      m3969(true);
   }

   public static void m3969(boolean var0) {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.setShader(class_757::method_34540);
      f4852.m0752();
      RenderSystem.disableBlend();
      if (var0) {
         C0498.f4738.m3895();
      }
   }

   static {
      f4852.m0747(class_5596.field_27382, class_290.field_1576);
   }
}
