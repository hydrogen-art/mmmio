package me.mioclient;

import java.util.function.Predicate;

public class C0274 implements Predicate {
   public C0411 f3149;

   public C0274(C0411 var1) {
      this.f3149 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3149.f0691, 254992554122318132L);
   }
}
