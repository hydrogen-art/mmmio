package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2473;
import net.minecraft.class_2523;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3965;
import net.minecraft.class_5702;
import net.minecraft.class_2350.class_2353;

public class C0411 extends C1266 {
   public final C0015<C0412> f0685;
   public final C0015<Float> f0686;
   public final C0015<Integer> f0687;
   public final C0015<Boolean> f0688;
   public final C0015<Boolean> f0689;
   public final C0015<Boolean> f0690;
   public final C0015<Boolean> f0691;
   public final C0015<Float> f0692;
   public final C0015<Boolean> f0693;
   public final C0015<Boolean> f0694;
   public final C0015<Boolean> f0695;
   public final C0015<Boolean> f0696;
   public final C0015<Boolean> f0697;
   public final C0015<Boolean> f0698;
   public final C0015<Boolean> f0699;
   public final C0015<Boolean> f0700;
   public final C0083 f0701;
   public final C0083 f0702;
   public int f0703;
   public static int f0704 = w.a<"B">(3528351890954854965L, 257832362129977838L);

   public C0411() {
      super("AutoFarm", "Farms your crops for you.", C1045.f3176);
      w.a<"B">(this, 242859112966675773L);
      this.f0701 = new C0083();
      this.f0702 = new C0083();
   }

   @C1027
   public void m0331(C0153 var1) {
      Iterator var2 = w.a<"Û">(w.a<"Û">((C0412)w.a<"Û">(this.f0685, 174312564406604366L), this, 311091569058562790L), 341496865259068134L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         class_2338 var3 = (class_2338)w.a<"Û">(var2, 192468336863492695L);
         if (this.f0703 >= w.a<"Û">((Integer)w.a<"Û">(this.f0687, 174312564406604366L), 260981171345819427L)) {
            break;
         }

         w.a<"Û">(
            this,
            var3,
            w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  new class_5702(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 270398306108537951L
                     ),
                     w.a<"Û">(var3, 229561253177300454L),
                     var0 -> (boolean)((f0704 | 321942) + ~(f0704 & 321942) + 1 ^ -1168795570)
                  ),
                  384291509824812557L
               ),
               256237328539981644L
            ),
            120513406339747976L
         );
      }

      this.f0703 = (f0704 | 918228) + ~(f0704 & 918228) + 1 ^ -1168149747;
   }

   public void m0332(class_2338 var1, class_2350 var2) {
      class_2680 var3 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var1, 310987074049434965L
      );
      boolean var4 = w.a<"Û">(var3, class_2246.field_10424, 272812080270536171L);
      class_1268 var5 = w.a<"Û">(
         this, (Predicate<class_1799>)var1x -> w.a<"Û">(this, w.a<"Û">(var1x, 222207108884875224L), 240428821897142076L), 239690142813455364L
      );
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0688, 174312564406604366L), 354697271520518137L)
         && var5 != null
         && w.a<"Û">(
            this,
            var1,
            var3,
            w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, var5, 116318201500984113L
               ),
               222207108884875224L
            ),
            266117294383622514L
         )) {
         w.a<"Û">(this, var1, var5, 121183579818655520L);
      } else if (w.a<"Û">(this, w.a<"Û">(w.a<"Û">(var3, 152622786059621427L), 312810381105506273L), 240428821897142076L)) {
         boolean var6 = w.a<"Û">(this, var3, var1, 171512141244170627L);
         class_1268 var7 = w.a<"Û">(this, class_1802.field_8324, 249815184513641605L);
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f0690, 174312564406604366L), 354697271520518137L) && !var6 && var7 != null && !var4) {
            w.a<"Û">(this, var1, var7, 335040897792751984L);
         } else {
            w.a<"Û">(this, var1, var2, var6, 245186925522531629L);
         }
      }
   }

   public void m0333(class_2338 var1, class_2350 var2, boolean var3) {
      if (!(
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var1, 310987074049434965L),
            152622786059621427L
         ) instanceof class_2473
      )) {
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f0691, 174312564406604366L), 354697271520518137L)
            && w.a<"Û">(
               this.f0701, (double)w.a<"Û">((Float)w.a<"Û">(this.f0692, 174312564406604366L), 149784643039979208L), TimeUnit.SECONDS, 215737872562411156L
            )) {
            if (var3 || !w.a<"Û">((Boolean)w.a<"Û">(this.f0693, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
                  var1,
                  var2,
                  355816461603514109L
               );
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  class_1268.field_5808,
                  356560492913773202L
               );
               w.a<"Û">(this.f0702, 387780412884547639L);
               this.f0703 = this.f0703 + ((f0704 | 127067) + ~(f0704 & 127067) + 1 ^ -1169129085);
               w.a<"Û">(this.f0701, 387780412884547639L);
               if (w.a<"Û">((Boolean)w.a<"Û">(this.f0689, 174312564406604366L), 354697271520518137L)) {
                  w.a<"Û">(
                     C0933.f1412,
                     w.a<"B">(w.a<"Û">(var1, 229561253177300454L), 213766782372904553L),
                     (f0704 | 75905) + ~(f0704 & 75905) + 1 ^ -1169139368,
                     236731835237641613L
                  );
               }
            }
         }
      }
   }

   public void m0334(class_2338 var1, class_1268 var2) {
      w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
         var2,
         new class_3965(w.a<"Û">(var1, 229561253177300454L), class_2350.field_11036, var1, (boolean)((f0704 | 665942) + ~(f0704 & 665942) + 1 ^ -1168418673)),
         353197595888970100L
      );
      w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, var2, 356560492913773202L);
      w.a<"Û">(this.f0702, 387780412884547639L);
      this.f0703 = this.f0703 + ((f0704 | 583314) + ~(f0704 & 583314) + 1 ^ -1168533686);
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0689, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(
            C0933.f1412,
            w.a<"B">(w.a<"Û">(var1, 229561253177300454L), 213766782372904553L),
            (f0704 | 531178) + ~(f0704 & 531178) + 1 ^ -1168544973,
            236731835237641613L
         );
      }
   }

   public void m0335(class_2338 var1, class_1268 var2) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0689, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(
            C0933.f1412,
            w.a<"B">(w.a<"B">(var1, 146290212019169501L), 213766782372904553L),
            (f0704 | 409755) + ~(f0704 & 409755) + 1 ^ -1168690878,
            236731835237641613L
         );
      }

      w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
         var2,
         new class_3965(w.a<"B">(var1, 146290212019169501L), class_2350.field_11036, var1, (boolean)((f0704 | 765740) + ~(f0704 & 765740) + 1 ^ -1168449803)),
         353197595888970100L
      );
      w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, var2, 356560492913773202L);
      w.a<"Û">(this.f0702, 387780412884547639L);
      this.f0703 = this.f0703 + ((f0704 | 585440) + ~(f0704 & 585440) + 1 ^ -1168531656);
   }

   public boolean m0336(class_2338 var1, class_2680 var2, class_1792 var3) {
      if (var3 instanceof class_1747 var4) {
         if (w.a<"Û">(var4, 339813793232936443L) instanceof class_2302) {
            return (boolean)(w.a<"Û">(var2, class_2246.field_10362, 272812080270536171L)
                  && w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                        w.a<"Û">(var1, 286357605983762592L),
                        310987074049434965L
                     ),
                     class_2246.field_10124,
                     272812080270536171L
                  )
               ? (f0704 | 544051) + ~(f0704 & 544051) + 1 ^ -1168556821
               : (f0704 | 644096) + ~(f0704 & 644096) + 1 ^ -1168595495);
         }

         if (w.a<"Û">(var4, 339813793232936443L) instanceof class_2523) {
            if (!w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  w.a<"Û">(var1, 286357605983762592L),
                  310987074049434965L
               ),
               class_2246.field_10124,
               272812080270536171L
            )) {
               return (boolean)((f0704 | 920600) + ~(f0704 & 920600) + 1 ^ -1168147007);
            }

            if (!w.a<"Û">(var2, class_3481.field_29822, 196332704002388139L) && !w.a<"Û">(var2, class_3481.field_15466, 196332704002388139L)) {
               return (boolean)((f0704 | 362938) + ~(f0704 & 362938) + 1 ^ -1168836509);
            }

            Iterator var5 = w.a<"Û">(class_2353.field_11062, 287411357280723181L);

            while (w.a<"Û">(var5, 333900474771661065L)) {
               class_2350 var6 = (class_2350)w.a<"Û">(var5, 192468336863492695L);
               class_3610 var7 = w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  w.a<"Û">(var1, var6, 361576458954219689L),
                  178072535326928040L
               );
               var2 = w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  w.a<"Û">(var1, var6, 361576458954219689L),
                  310987074049434965L
               );
               if (w.a<"Û">(var7, class_3486.field_15517, 148800888907140770L) || w.a<"Û">(var2, class_2246.field_10110, 272812080270536171L)) {
                  return (boolean)((f0704 | 357804) + ~(f0704 & 357804) + 1 ^ -1168898956);
               }
            }
         }
      }

      return (boolean)((f0704 | 727185) + ~(f0704 & 727185) + 1 ^ -1168479928);
   }

   public boolean m0337(class_2680 var1, class_2338 var2) {
      if (w.a<"Û">(var1, 152622786059621427L) instanceof class_2473) {
         return (boolean)((f0704 | 815459) + ~(f0704 & 815459) + 1 ^ -1168310086);
      } else if (w.a<"Û">(var1, 152622786059621427L) instanceof class_2302 var3) {
         return (boolean)(w.a<"Û">(var3, var1, 250820286265886630L) == w.a<"Û">(var3, 240024272428822726L)
            ? (f0704 | 898055) + ~(f0704 & 898055) + 1 ^ -1168325153
            : (f0704 | 329782) + ~(f0704 & 329782) + 1 ^ -1168868881);
      } else {
         return (boolean)(w.a<"Û">(var1, 152622786059621427L) instanceof class_2523
            ? w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  w.a<"Û">(var2, 210046241258394501L),
                  310987074049434965L
               ),
               class_2246.field_10424,
               272812080270536171L
            )
            : (f0704 | 533650) + ~(f0704 & 533650) + 1 ^ -1168550581);
      }
   }

   public class_1268 m0338(class_1792 var1) {
      return w.a<"Û">(this, (Predicate<class_1799>)var1x -> w.a<"Û">(var1x, var1, 282470456889867724L), 239690142813455364L);
   }

   public class_1268 m0339(Predicate<class_1799> var1) {
      if (w.a<"Û">(
         var1,
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L),
         258912813308304151L
      )) {
         return class_1268.field_5808;
      } else {
         return w.a<"Û">(
               var1,
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 159396947398056288L),
               258912813308304151L
            )
            ? class_1268.field_5810
            : null;
      }
   }

   public boolean m0340(class_1792 var1) {
      if (var1 instanceof class_1747 var2 && w.a<"Û">(var2, 339813793232936443L) instanceof class_2473) {
         return w.a<"Û">((Boolean)w.a<"Û">(this.f0700, 174312564406604366L), 354697271520518137L);
      }

      return (boolean)((var1 != class_1802.field_8317 || !w.a<"Û">((Boolean)w.a<"Û">(this.f0695, 174312564406604366L), 354697271520518137L))
            && (var1 != class_1802.field_8179 || !w.a<"Û">((Boolean)w.a<"Û">(this.f0696, 174312564406604366L), 354697271520518137L))
            && (var1 != class_1802.field_8567 || !w.a<"Û">((Boolean)w.a<"Û">(this.f0697, 174312564406604366L), 354697271520518137L))
            && (var1 != class_1802.field_8309 || !w.a<"Û">((Boolean)w.a<"Û">(this.f0698, 174312564406604366L), 354697271520518137L))
            && (var1 != class_1802.field_17531 || !w.a<"Û">((Boolean)w.a<"Û">(this.f0699, 174312564406604366L), 354697271520518137L))
         ? (f0704 | 570737) + ~(f0704 & 570737) + 1 ^ -1168522072
         : (f0704 | 991290) + ~(f0704 & 991290) + 1 ^ -1168223774);
   }

   public static String sYj49UmxZhOgxwjjwyskfHcrq983lIScHJT9rYsJQhB2rmTtAYIajsRMs1jrCd9LWjM19rdTvjBXtzpcRkNBV6Nv9KROnw7yLpaR(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
