package me.mioclient;

import java.util.function.Predicate;

public class C0419 implements Predicate {
   public C0039 f4050;

   public C0419(C0039 var1) {
      this.f4050 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f4050.f5265, 254992554122318132L);
   }
}
