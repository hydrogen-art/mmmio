package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_332;
import net.minecraft.class_7922;
import net.minecraft.class_7923;

public class C0279 extends C0601 {
   public final C0015<Set<class_1299<?>>> f4588;
   public final C0015<Set<class_1792>> f4589;
   public final C0015<C0040> f4590;
   public final C0015<C0040> f4591;
   public final C0015<C0281> f4592;
   public final C0015<Boolean> f4593;
   public final C0015<Boolean> f4594;
   public final Map<String, Integer> f4595;
   public final List<C0280> f4596;
   public static int f4597 = w.a<"B">(1443603901803354356L, 257832362129977838L);

   public C0279() {
      super("EntityList");
      class_7922 var10005 = class_7923.field_41177;
      class_1299[] var10006 = new class_1299[(f4597 | 21595) + ~(f4597 & 21595) + 1 ^ 1649370453];
      var10006[(f4597 | 306266) + ~(f4597 & 306266) + 1 ^ 1649122645] = class_1299.field_6097;
      this.f4588 = w.a<"Û">(this, new C0275<>("WhiteList", var10005, var10006), 192839886211813275L);
      var10005 = class_7923.field_41178;
      class_1792[] var2 = new class_1792[(f4597 | 903988) + ~(f4597 & 903988) + 1 ^ 1648556602];
      var2[(f4597 | 755989) + ~(f4597 & 755989) + 1 ^ 1648670746] = class_1802.field_8281;
      this.f4589 = w.a<"Û">(this, new C0275<>("Items", var10005, var2), 192839886211813275L);
      this.f4590 = w.a<"Û">(this, new C0495<>("Selection", C0040.f0103), 192839886211813275L);
      this.f4591 = w.a<"Û">(this, new C0495<>("ItemSelection", C0040.f0101), 192839886211813275L);
      this.f4592 = w.a<"Û">(this, new C0495<>("Sorting", C0281.f0837), 192839886211813275L);
      this.f4593 = w.a<"Û">(
         this, new C0240("CustomNames", w.a<"B">((boolean)((f4597 | 411203) + ~(f4597 & 411203) + 1 ^ 1648981837), 320330632857389983L)), 192839886211813275L
      );
      this.f4594 = w.a<"Û">(
         this, new C0240("ColoredCount", w.a<"B">((boolean)((f4597 | 595821) + ~(f4597 & 595821) + 1 ^ 1648764515), 320330632857389983L)), 192839886211813275L
      );
      this.f4595 = new HashMap<>();
      this.f4596 = new ArrayList<>();
      w.a<"Û">(
         this.f4591,
         (Predicate<C0040>)var1x -> w.a<"Û">(
               (C0040)w.a<"Û">(this.f4590, 174312564406604366L),
               class_1299.field_6052,
               (Collection)w.a<"Û">(this.f4588, 174312564406604366L),
               257405975721056342L
            ),
         235935633196277017L
      );
      this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(new C0024(this));
   }

   @C1027
   public void m1851(C0612 var1) {
      synchronized (this.f4596) {
         w.a<"Û">(this.f4595, 288879253482200997L);
         Iterator var3 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
            191661729848227466L
         );

         while (w.a<"Û">(var3, 333900474771661065L)) {
            class_1297 var4 = (class_1297)w.a<"Û">(var3, 192468336863492695L);
            if (w.a<"Û">(
               (C0040)w.a<"Û">(this.f4590, 174312564406604366L),
               w.a<"Û">(var4, 379519689300238200L),
               (Collection)w.a<"Û">(this.f4588, 174312564406604366L),
               257405975721056342L
            )) {
               if (var4 instanceof class_1542) {
                  class_1542 var5 = (class_1542)var4;
                  if (w.a<"Û">(w.a<"Û">(var5, 295879862864005166L), 330190014994709712L)) {
                     continue;
                  }

                  class_1792 var6 = w.a<"Û">(w.a<"Û">(var5, 295879862864005166L), 222207108884875224L);
                  if (!w.a<"Û">((C0040)w.a<"Û">(this.f4591, 174312564406604366L), var6, this.f4589, 158749129574266968L)) {
                     continue;
                  }
               }

               String var10 = w.a<"Û">((Boolean)w.a<"Û">(this.f4593, 174312564406604366L), 354697271520518137L)
                  ? w.a<"Û">(w.a<"Û">(var4, 291295238331520790L), 286788181028845103L)
                  : w.a<"Û">(w.a<"Û">(w.a<"Û">(var4, 379519689300238200L), 141367179046548088L), 286788181028845103L);
               if (var4 instanceof class_1542 var11) {
                  var10 = w.a<"Û">(w.a<"Û">(w.a<"Û">(var11, 295879862864005166L), 248308138707081744L), 286788181028845103L);
               }

               int var12 = var4 instanceof class_1542 var7
                  ? w.a<"Û">(w.a<"Û">(var7, 295879862864005166L), 144154955567765793L)
                  : (f4597 | 248048) + ~(f4597 & 248048) + 1 ^ 1649211902;
               w.a<"Û">(
                  this.f4595,
                  var10,
                  (BiFunction<String, Integer, Integer>)(var1x, var2) -> var2 == null
                        ? w.a<"B">(var12, 367942141483020029L)
                        : w.a<"B">(w.a<"Û">(var2, 260981171345819427L) + var12, 367942141483020029L),
                  280205116198276366L
               );
            }
         }

         w.a<"Û">(this.f4596, 140901994866995976L);
         w.a<"Û">(
            this.f4596,
            w.a<"Û">(w.a<"Û">(w.a<"Û">(w.a<"Û">(this.f4595, 354320704134596920L), 218807454277778388L), C0280::m1395, 141209812120559377L), 325049488880240942L),
            271623032661790232L
         );
         switch (w.a<"Û">((C0281)w.a<"Û">(this.f4592, 174312564406604366L), 272278565139418512L)) {
            case 0:
               w.a<"Û">(this.f4596, w.a<"B">((Function<C0280, String>)var0 -> var0.f3447, 224107444354928270L), 369116887926758393L);
               break;
            case 1:
               w.a<"Û">(
                  this.f4596, w.a<"B">((Function<C0280, Integer>)var0 -> w.a<"B">(-var0.f3448, 367942141483020029L), 224107444354928270L), 369116887926758393L
               );
               break;
            case 2:
               w.a<"Û">(
                  this.f4596,
                  w.a<"B">(
                     (Function<C0280, Float>)var0 -> w.a<"B">(C0498.f4738.m3896(w.a<"Û">(var0, class_124.field_1068, 219892924872078724L)), 243402859552372891L),
                     224107444354928270L
                  ),
                  369116887926758393L
               );
         }
      }
   }

   @Override
   public void m0562(class_332 var1) {
      float var2 = this.m$$PpPu8DGysERuMBG0leKIFNRaKTaNSzoCfcKirIjr69JLku3Wnfarn023SAFK1QxxHfuMxDcep9htxtos8M0qbRsNrTpFakkn7.m2958((float)C0498.f4738.m3897())
         - this.m$$PpPu8DGysERuMBG0leKIFNRaKTaNSzoCfcKirIjr69JLku3Wnfarn023SAFK1QxxHfuMxDcep9htxtos8M0qbRsNrTpFakkn7.m2947();
      synchronized (this.f4596) {
         for (Iterator var4 = w.a<"Û">(this.f4596, 341496865259068134L);
            w.a<"Û">(var4, 333900474771661065L);
            var2 += (float)(
               (C0498.f4738.m3897() + ((f4597 | 115306) + ~(f4597 & 115306) + 1 ^ 1649341284))
                  * this.m$$PpPu8DGysERuMBG0leKIFNRaKTaNSzoCfcKirIjr69JLku3Wnfarn023SAFK1QxxHfuMxDcep9htxtos8M0qbRsNrTpFakkn7.m2960()
            )
         ) {
            C0280 var5 = (C0280)w.a<"Û">(var4, 192468336863492695L);
            Color var6 = this.m$$iZnnVBJ17A5YJbakVntJjvhjlzvzt8abld4g7DVpkphruizpxyO31ajNTWEZ2smIjpUa4yekh7iZ7sJESIVA0nApb5M9c0lYC(var2);
            class_124 var7 = w.a<"Û">((Boolean)w.a<"Û">(this.f4594, 174312564406604366L), 354697271520518137L) ? class_124.field_1068 : class_124.field_1070;
            String var8 = w.a<"Û">(var5, var7, 219892924872078724L);
            float var9 = C0498.f4738.m3896(var8);
            C0498.f4738
               .m3889(
                  var1,
                  var8,
                  this.m$$PpPu8DGysERuMBG0leKIFNRaKTaNSzoCfcKirIjr69JLku3Wnfarn023SAFK1QxxHfuMxDcep9htxtos8M0qbRsNrTpFakkn7.m2957(var9)
                     - this.m$$PpPu8DGysERuMBG0leKIFNRaKTaNSzoCfcKirIjr69JLku3Wnfarn023SAFK1QxxHfuMxDcep9htxtos8M0qbRsNrTpFakkn7.m2944(),
                  var2,
                  var6
               );
         }
      }
   }

   @Override
   public float[] m0563() {
      float var1 = 0.0F;
      float var2 = 0.0F;
      synchronized (this.f4596) {
         Iterator var4 = w.a<"Û">(this.f4596, 341496865259068134L);

         while (w.a<"Û">(var4, 333900474771661065L)) {
            C0280 var5 = (C0280)w.a<"Û">(var4, 192468336863492695L);
            float var6 = C0498.f4738.m3896(w.a<"Û">(var5, class_124.field_1068, 219892924872078724L));
            var1 += (float)(C0498.f4738.m3897() + ((f4597 | 724660) + ~(f4597 & 724660) + 1 ^ 1648639930));
            if (var6 > var2) {
               var2 = var6;
            }
         }
      }

      float[] var10000 = new float[(f4597 | 173752) + ~(f4597 & 173752) + 1 ^ 1649252277];
      var10000[(f4597 | 890524) + ~(f4597 & 890524) + 1 ^ 1648535443] = var2;
      var10000[(f4597 | 809148) + ~(f4597 & 809148) + 1 ^ 1648585138] = var1;
      return var10000;
   }

   public static String gCCTeTLDxMbUhNiLDqelvdrYCbLjP8cHFzgoVdqoChoGokkZAwhH2AhejDLiHhBVAj4NLVBVPaMgTc3AFzg6XJ97x4MQB9oOhsPI(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
