package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0361 implements C0196 {
   f2143("None"),
   f2144("Flat"),
   f2145("End");

   public final String f2146;

   public C0361(String var3) {
      this.f2146 = var3;
   }

   @Override
   public String getName() {
      return this.f2146;
   }

   public static String sjqJWQsc8JwJaPdqFiZsOdasySXIHTB5Ev01AKWJXhoFYfCzpRahjoSyRdOCOB5XLvasb89aD6cbrNZ66f2LqBXibcTGGjNPISyK(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
