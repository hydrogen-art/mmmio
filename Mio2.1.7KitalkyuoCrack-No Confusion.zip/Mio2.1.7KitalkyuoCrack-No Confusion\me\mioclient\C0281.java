package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0281 implements C0196 {
   f0837("Alphabet"),
   f0838("Count"),
   f0839("Length");

   public final String f0840;

   public C0281(String var3) {
      this.f0840 = var3;
   }

   @Override
   public String getName() {
      return this.f0840;
   }

   public static String F2iuQrNV79aMUNLbEzwvhbn236nPglnHfaHxjKBGV1qiaLDImzddfeXY2wxXzmwK34x7CSYvIRNtplIJSwCW3cdU9s3A1LxltzZ0(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
