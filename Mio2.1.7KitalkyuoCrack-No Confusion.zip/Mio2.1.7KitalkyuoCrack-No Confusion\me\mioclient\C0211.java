package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import me.mioclient.mixin.ducks.DuckAbstractBlock;
import me.mioclient.mixin.ducks.DuckClientPlayerEntity;
import net.minecraft.class_2244;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;

public class C0211 extends C1266 {
   public static C0345 f2803 = C0933.f1409.m2696(C0345.class);
   public static C1179 f2804 = C0933.f1409.m2696(C1179.class);
   public static C0303 f2805 = C0933.f1409.m2696(C0303.class);
   public static C0159 f2806 = C0933.f1409.m2696(C0159.class);
   public final C0015<C0212> f2807;
   public final C0015<Float> f2808;
   public final C0015<Float> f2809;
   public final C0015<Boolean> f2810;
   public final C0015<Boolean> f2811;
   public final C0015<Boolean> f2812;
   public boolean f2813;
   public boolean f2814;
   public boolean f2815;
   public boolean f2816;
   public boolean f2817;
   public boolean f2818;
   public double f2819;
   public double f2820;
   public final C0083 f2821;
   public static int f2822 = w.a<"B">(8534489438405142837L, 257832362129977838L);

   public C0211() {
      C1045 var10003 = C1045.f3175;
      String[] var10004 = new String[(f2822 | 276331) + ~(f2822 & 276331) + 1 ^ -766031389];
      var10004[(f2822 | 975008) + ~(f2822 & 975008) + 1 ^ -765616599] = "reversestep";
      super("FastFall", "Allows you to get in holes with ease!", var10003, var10004);
      w.a<"B">(this, 242859112966675773L);
      this.f2821 = new C0083();
   }

   @Override
   public void onToggle() {
      this.f2813 = (boolean)((f2822 | 577857) + ~(f2822 & 577857) + 1 ^ -765743160);
      this.f2818 = (boolean)((f2822 | 300118) + ~(f2822 & 300118) + 1 ^ -765990177);
   }

   @C1027
   public void m1114(C0591 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f2812, 174312564406604366L), 354697271520518137L) && w.a<"Û">(C0933.f1419, 149866353757505195L) && this.f2818) {
         w.a<"Û">(this, 155417974908982175L);
      } else if (w.a<"Û">(this, 156102754009519129L) && (this.f2816 || !w.a<"Û">((Boolean)w.a<"Û">(this.f2811, 174312564406604366L), 354697271520518137L))) {
         if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)) {
            if (w.a<"Û">(this.f2821, ((long)f2822 | 42901L) + ~((long)f2822 & 42901L) + 1L ^ -766256920L, 309642602085515378L)) {
               this.f2815 = (boolean)(!this.f2815
                  ? (f2822 | 923880) + ~(f2822 & 923880) + 1 ^ -765630880
                  : (f2822 | 954860) + ~(f2822 & 954860) + 1 ^ -765595803);
               w.a<"Û">(this.f2821, 387780412884547639L);
            }

            if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 214921524804283555L).field_1351
                  < 0.0
               && this.f2814
               && this.f2815) {
               w.a<"Û">(C0933.f1431, this, w.a<"B">((f2822 | 956182) + ~(f2822 & 956182) + 1 ^ -1839339105, 349057757755238323L), 371685643619254063L);
               this.f2818 = (boolean)((f2822 | 907443) + ~(f2822 & 907443) + 1 ^ -765548997);
            } else {
               w.a<"Û">(this, 293354366973813502L);
            }
         } else {
            this.f2814 = (boolean)((f2822 | 107704) + ~(f2822 & 107704) + 1 ^ -766322128);
            w.a<"Û">(C0933.f1431, this, 150212528603319406L);
            if (w.a<"Û">(C0933.f1429, 202655309853842506L) > ((f2822 | 365284) + ~(f2822 & 365284) + 1 ^ -766055314)) {
               w.a<"Û">(this.f2821, 387780412884547639L);
               this.f2815 = (boolean)((f2822 | 744376) + ~(f2822 & 744376) + 1 ^ -765975248);
            }
         }
      } else {
         w.a<"Û">(this, 293354366973813502L);
      }
   }

   @C1027
   public void m1115(C0612 var1) {
      int var2 = !w.a<"B">(239474890139367192L) && (!w.a<"Û">(f2804, 314537768572362865L) || w.a<"Û">(f2804, 141429197897467118L) == null)
         ? (f2822 | 610735) + ~(f2822 & 610735) + 1 ^ -765841626
         : (f2822 | 396913) + ~(f2822 & 396913) + 1 ^ -766152455;
      if ((this.f2816 || !w.a<"Û">((Boolean)w.a<"Û">(this.f2811, 174312564406604366L), 354697271520518137L)) && var2 != 0) {
         this.f2817 = (boolean)((f2822 | 194466) + ~(f2822 & 194466) + 1 ^ -766408405);
         if (((DuckClientPlayerEntity)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724)
               .lastOnGround()
            && w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 214921524804283555L),
                  292829928904272542L
               )
               <= 0.0
            && w.a<"Û">(this, 211865530509197791L)
            && !w.a<"Û">(this, 223645244528084494L)) {
            double var3 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L
            );
            class_238 var5 = w.a<"Û">(
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L),
                  0.0,
                  (double)(-w.a<"Û">((Float)w.a<"Û">(this.f2808, 174312564406604366L), 149784643039979208L)),
                  0.0,
                  244681124810902308L
               ),
               var3,
               182030847371476974L
            );
            if (w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  var5,
                  202307702852076291L
               )
               && !w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var5, 339917567397917213L
               )) {
               return;
            }

            Iterable var6 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               var5,
               363058483439524627L
            );
            AtomicReference var7 = new AtomicReference<>(
               w.a<"B">(
                  (double)w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 296776091267530333L
                  ),
                  165155940100814265L
               )
            );
            w.a<"Û">(
               var6,
               (Consumer<class_265>)var1x -> w.a<"Û">(
                     var7,
                     w.a<"B">(
                        w.a<"B">(
                           w.a<"Û">((Double)w.a<"Û">(var7, 196201331055827726L), 287934447355057060L),
                           w.a<"Û">(var1x, class_2351.field_11052, 248596733715571699L),
                           354112003008534934L
                        ),
                        165155940100814265L
                     ),
                     178167371445125443L
                  ),
               299394416706935363L
            );
            if (w.a<"Û">((Double)w.a<"Û">(var7, 196201331055827726L), 287934447355057060L)
               < w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L)
               )
             {
               double var8 = w.a<"Û">((Double)w.a<"Û">(var7, 196201331055827726L), 287934447355057060L);
               class_243 var10 = w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 214921524804283555L
               );
               class_2338 var11 = w.a<"B">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L),
                  var8,
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L),
                  377906593793678812L
               );
               int var12 = !w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                        w.a<"Û">(
                           var11,
                           new class_2382((int)var10.field_1352, (f2822 | 998450) + ~(f2822 & 998450) + 1 ^ 765705540, (int)var10.field_1350),
                           332515151004208459L
                        ),
                        319660430185239203L
                     )
                     && w.a<"Û">(
                        w.a<"Û">(C0933.f1416, 284526657513910806L), ((long)f2822 | 350387L) + ~((long)f2822 & 350387L) + 1L ^ -766106077L, 309642602085515378L
                     )
                     && w.a<"Û">(this.f2807, 174312564406604366L) != C0212.f0018
                  ? (f2822 | 503539) + ~(f2822 & 503539) + 1 ^ -766193542
                  : (f2822 | 829760) + ~(f2822 & 829760) + 1 ^ -765470776;
               if (w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L
                        )
                        - var8
                     > w.a<"B">(((long)f2822 | 218341L) + ~((long)f2822 & 218341L) + 1L ^ -4611686019193886100L, 317139102743630955L)
                  || var12 != 0) {
                  var8 = w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L
                     )
                     - w.a<"B">(((long)f2822 | 395470L) + ~((long)f2822 & 395470L) + 1L ^ -4611686019193539001L, 317139102743630955L);
                  this.f2817 = (boolean)((f2822 | 119920) + ~(f2822 & 119920) + 1 ^ -766334216);
                  float var13 = w.a<"Û">(this.f2807, 174312564406604366L) == C0212.f0018
                     ? w.a<"Û">((Float)w.a<"Û">(this.f2809, 174312564406604366L), 149784643039979208L)
                     : w.a<"B">((f2822 | 28318) + ~(f2822 & 28318) + 1 ^ -304934889, 349057757755238323L);
                  if (var13 != 0.0F) {
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                        w.a<"Û">(var10, class_2351.field_11052, (double)(-var13), 156744506625070247L),
                        371430761082648882L
                     );
                  }
               }

               if (var12 == 0) {
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L
                     ),
                     var8,
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L
                     ),
                     267135527332903540L
                  );
               }

               w.a<"Û">(f2806, 219424730437685481L);
               this.f2818 = (boolean)((f2822 | 226194) + ~(f2822 & 226194) + 1 ^ -766505702);
            }
         }
      }
   }

   @C1027
   public void m1116(C0650 var1) {
      this.f2819 = (double)w.a<"B">(206591968858273041L);
      this.f2820 = (double)w.a<"B">(274098019152472497L);
      this.f2816 = w.a<"Û">(
         C0933.f1419,
         w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 299721818904416994L),
            (int)this.f2820,
            166090202747874403L
         ),
         244811264617537130L
      );
      if (this.f2816 || !w.a<"Û">((Boolean)w.a<"Û">(this.f2811, 174312564406604366L), 354697271520518137L)) {
         double var2 = w.a<"B">(((long)f2822 | 328137L) + ~((long)f2822 & 328137L) + 1L ^ -4599075939125212045L, 317139102743630955L);
         int var4 = w.a<"Û">(f2804, 314537768572362865L)
               && w.a<"Û">(f2804.f1268, ((long)f2822 | 467999L) + ~((long)f2822 & 467999L) + 1L ^ -766223518L, 309642602085515378L)
               && w.a<"Û">(f2804, 141429197897467118L) != null
            ? (f2822 | 464691) + ~(f2822 & 464691) + 1 ^ -766219845
            : (f2822 | 281483) + ~(f2822 & 281483) + 1 ^ -766036734;
         if (w.a<"Û">(this, 223645244528084494L)
               && w.a<"Û">(this, 211865530509197791L)
               && w.a<"Û">(this, 386716828015543480L)
               && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)
            || this.f2817 && var4 == 0 && w.a<"Û">(this, 196560962786908916L)) {
            w.a<"B">(
               w.a<"Û">(var1, 240677964963708953L),
               w.a<"Û">(var1, 211665782282761067L) * var2,
               w.a<"Û">(var1, 142189287634836180L),
               w.a<"Û">(var1, 149300137507612725L) * var2,
               340489545772167457L
            );
         }
      }
   }

   public boolean m1117() {
      class_238 var1 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L
      );
      class_243 var2 = w.a<"Û">(var1, 376895844755266015L);
      double var3 = var1.field_1323;
      double var5 = var1.field_1321;
      double var7 = var1.field_1320;
      double var9 = var1.field_1324;
      HashMap var11 = new HashMap();
      w.a<"Û">(
         var11,
         var2,
         new class_243(
            var2.field_1352,
            var2.field_1351 - w.a<"B">(((long)f2822 | 635076L) + ~((long)f2822 & 635076L) + 1L ^ -4607182419565818291L, 317139102743630955L),
            var2.field_1350
         ),
         121875332790264405L
      );
      w.a<"Û">(
         var11,
         new class_243(var3, var2.field_1351, var5),
         new class_243(
            var3, var2.field_1351 - w.a<"B">(((long)f2822 | 37199L) + ~((long)f2822 & 37199L) + 1L ^ -4607182419566268474L, 317139102743630955L), var5
         ),
         121875332790264405L
      );
      w.a<"Û">(
         var11,
         new class_243(var7, var2.field_1351, var5),
         new class_243(
            var7, var2.field_1351 - w.a<"B">(((long)f2822 | 837144L) + ~((long)f2822 & 837144L) + 1L ^ -4607182419565496175L, 317139102743630955L), var5
         ),
         121875332790264405L
      );
      w.a<"Û">(
         var11,
         new class_243(var3, var2.field_1351, var9),
         new class_243(
            var3, var2.field_1351 - w.a<"B">(((long)f2822 | 835091L) + ~((long)f2822 & 835091L) + 1L ^ -4607182419565494118L, 317139102743630955L), var9
         ),
         121875332790264405L
      );
      w.a<"Û">(
         var11,
         new class_243(var7, var2.field_1351, var9),
         new class_243(
            var7, var2.field_1351 - w.a<"B">(((long)f2822 | 975428L) + ~((long)f2822 & 975428L) + 1L ^ -4607182419565634355L, 317139102743630955L), var9
         ),
         121875332790264405L
      );
      Iterator var12 = w.a<"Û">(w.a<"Û">(var11, 344909330910693100L), 194435811056609302L);

      while (w.a<"Û">(var12, 333900474771661065L)) {
         class_243 var13 = (class_243)w.a<"Û">(var12, 192468336863492695L);
         class_3965 var14 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
            new class_3959(
               var13,
               (class_243)w.a<"Û">(var11, var13, 299255156581412505L),
               class_3960.field_17558,
               class_242.field_1348,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
            ),
            146985274835351625L
         );
         if (var14 != null && w.a<"Û">(var14, 189274766630417875L) == class_240.field_1332) {
            return (boolean)((f2822 | 95954) + ~(f2822 & 95954) + 1 ^ -766375845);
         }
      }

      if (!w.a<"Û">(this, 196560962786908916L)) {
         return (boolean)((f2822 | 280212) + ~(f2822 & 280212) + 1 ^ -766035939);
      } else {
         class_2680 var15 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
            w.a<"B">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L),
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L)
                  - w.a<"B">(((long)f2822 | 630951L) + ~((long)f2822 & 630951L) + 1L ^ -4607182419565814226L, 317139102743630955L),
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L),
               377906593793678812L
            ),
            310987074049434965L
         );
         return (boolean)(var15 != null && w.a<"Û">(var15, 152622786059621427L) != class_2246.field_10124
            ? (f2822 | 973431) + ~(f2822 & 973431) + 1 ^ -765614850
            : (f2822 | 672610) + ~(f2822 & 672610) + 1 ^ -765903382);
      }
   }

   public boolean m1118() {
      class_243 var1 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 214921524804283555L
      );
      double var2 = var1.field_1352;
      double var4 = var1.field_1350;
      var2 = w.a<"B">(var4, 230886300607664670L) > w.a<"B">(var2, 230886300607664670L) ? 0.0 : w.a<"B">(var2, 323147739359627475L);
      var4 = w.a<"B">(var2, 230886300607664670L) > w.a<"B">(var4, 230886300607664670L) ? 0.0 : w.a<"B">(var4, 323147739359627475L);
      class_2680 var6 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
         w.a<"B">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L)
               + var2,
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L)
               - w.a<"B">(((long)f2822 | 421818L) + ~((long)f2822 & 421818L) + 1L ^ -4607182419566194381L, 317139102743630955L),
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L)
               + var4,
            377906593793678812L
         ),
         310987074049434965L
      );
      return (boolean)(var6 != null
         ? ((DuckAbstractBlock)w.a<"Û">(var6, 152622786059621427L)).isCollidable()
         : (f2822 | 317343) + ~(f2822 & 317343) + 1 ^ -766007017);
   }

   public boolean m1119() {
      if (w.a<"Û">(f2803, 314537768572362865L)
         && w.a<"Û">(f2803.f0369, 174312564406604366L) != C0347.f1912
         && w.a<"Û">(f2803.f0369, 174312564406604366L) != C0347.f1911) {
         return (boolean)((f2822 | 275716) + ~(f2822 & 275716) + 1 ^ -766030963);
      } else {
         return (boolean)(!w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 341620216578473814L
               )
               && !w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L
               )
               && !w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 273207397020522272L
               )
               && (
                  !w.a<"B">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229073305445517953L
                     )
                     || !w.a<"Û">((Boolean)w.a<"Û">(this.f2810, 174312564406604366L), 354697271520518137L)
               )
               && w.a<"Û">(
                  w.a<"Û">(C0933.f1416, 131737481540982891L), ((long)f2822 | 566782L) + ~((long)f2822 & 566782L) + 1L ^ -765732221L, 309642602085515378L
               )
               && !(
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                        w.a<"B">(
                           w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                              114479647550158442L
                           ),
                           274163478939689086L
                        ),
                        310987074049434965L
                     ),
                     152622786059621427L
                  ) instanceof class_2244
               )
            ? (f2822 | 977011) + ~(f2822 & 977011) + 1 ^ -765618437
            : (f2822 | 706935) + ~(f2822 & 706935) + 1 ^ -765872130);
      }
   }

   public boolean m1120() {
      return (boolean)(w.a<"Û">(this.f2807, 174312564406604366L) == C0212.f0019
         ? (f2822 | 913707) + ~(f2822 & 913707) + 1 ^ -765554781
         : (f2822 | 129508) + ~(f2822 & 129508) + 1 ^ -766343315);
   }

   public boolean m1121() {
      return (boolean)(w.a<"Û">(this, 211865530509197791L)
            && w.a<"Û">(this, 223645244528084494L)
            && this.f2819 != 0.0
            && this.f2820 != 0.0
            && this.f2820 <= (double)w.a<"Û">((Float)w.a<"Û">(this.f2808, 174312564406604366L), 149784643039979208L)
         ? (f2822 | 360716) + ~(f2822 & 360716) + 1 ^ -766050428
         : (f2822 | 165322) + ~(f2822 & 165322) + 1 ^ -766379197);
   }

   public void m1122() {
      if (w.a<"Û">(this, 223645244528084494L)) {
         this.f2814 = (boolean)((f2822 | 715054) + ~(f2822 & 715054) + 1 ^ -765880409);
         w.a<"Û">(C0933.f1431, this, 150212528603319406L);
      }
   }

   public static String GFAR61Yqa4vFu7EfEJzgv1Gf0RFSHoa6n1cZY248GzoNMbcghaROKx8kqjHvflCFBsDuvHCbxRP2dMsYNR2sYMmJDRmQHBYtiPeA(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
