package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2815;

public class C0172 extends C1266 {
   public static int f1657 = w.a<"B">(6354675593760992492L, 257832362129977838L);

   public C0172() {
      super("XCarry", "Lets you use crafting slots as inventory slots.", C1045.f3177);
      w.a<"Û">(this, (boolean)((f1657 | 10648) + ~(f1657 & 10648) + 1 ^ -508743188), 135570431627433065L);
   }

   @C1027
   public void m2732(C0132 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2815 var2
         && w.a<"Û">(var2, 180379644195837256L)
            == m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7498.field_7763) {
         w.a<"Û">(var1, 385440235371820560L);
      }
   }

   public static String _QW4ZIYWByCewfqcfvrt4cKlajbv1brXCaSFNyMX4srGOaKvnBRyc8JbzYRC49bdAmWVCrkJQI7Cpu5NEpzU7GDVnEqmv4K0G6Gv/* $VF was: 7QW4ZIYWByCewfqcfvrt4cKlajbv1brXCaSFNyMX4srGOaKvnBRyc8JbzYRC49bdAmWVCrkJQI7Cpu5NEpzU7GDVnEqmv4K0G6Gv*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
