package me.mioclient;

import java.awt.Color;
import java.util.Objects;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_238;

public record C0188() implements C0045 {
   public final class_1923 f5036;
   public final C0364 f5037;
   public final C0026 f5038;
   public static int f5039 = w.a<"B">(4012025271513949774L, 257832362129977838L);

   public C0188(class_1923 var1, C0364 var2, C0026 var3) {
      this.f5036 = var1;
      this.f5037 = var2;
      this.f5038 = var3;
   }

   public static C0188 m4012(class_1923 var0, C0026 var1) {
      return new C0188(var0, w.a<"B">(375727057840316412L), var1);
   }

   public boolean m4013(C0026 var1) {
      return (boolean)(var1 == this.f5038 ? (f5039 | 478059) + ~(f5039 & 478059) + 1 ^ -42552193 : (f5039 | 390434) + ~(f5039 & 390434) + 1 ^ -42726857);
   }

   public void m4014(C1355 var1, C0513 var2) {
      Color[] var3 = w.a<"Û">(this.f5038, var2, 223604769016059664L);
      if (var3 != null) {
         class_2338 var4 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L),
            311335674990834024L
         );
         int var5 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 296776091267530333L
            )
            + w.a<"Û">((Integer)w.a<"Û">(var2.f1326, 174312564406604366L), 260981171345819427L);
         if (w.a<"Û">(
            var4,
            w.a<"Û">(this.f5036, w.a<"Û">(var4, 171752333823210875L), 180313840442026216L),
            (double)(((f5039 | 697912) + ~(f5039 & 697912) + 1 ^ -42247875) * w.a<"Û">((Integer)w.a<"Û">(var2.f1325, 174312564406604366L), 260981171345819427L)),
            217636444529705754L
         )) {
            class_238 var6 = new class_238(
               (double)w.a<"Û">(this.f5036, 246289701840133598L),
               (double)var5,
               (double)w.a<"Û">(this.f5036, 255085604585515475L),
               (double)(w.a<"Û">(this.f5036, 246289701840133598L) + ((f5039 | 769362) + ~(f5039 & 769362) + 1 ^ -42319273)),
               (double)var5,
               (double)(w.a<"Û">(this.f5036, 255085604585515475L) + ((f5039 | 925212) + ~(f5039 & 925212) + 1 ^ -41950951))
            );
            if (!w.a<"B">(var6, 132682894836608805L)) {
               return;
            }

            w.a<"B">(w.a<"Û">(var1, 173269294235887931L), var6, var3[(f5039 | 51871) + ~(f5039 & 51871) + 1 ^ -42912374], 246072095578695914L);
            C0485.m3219(
               w.a<"Û">(var1, 173269294235887931L),
               var6,
               var3[(f5039 | 119178) + ~(f5039 & 119178) + 1 ^ -42979682],
               w.a<"Û">((Float)w.a<"Û">(var2.f1328, 174312564406604366L), 149784643039979208L)
            );
         }
      }
   }

   @Override
   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)((f5039 | 244878) + ~(f5039 & 244878) + 1 ^ -42843238);
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         C0188 var2 = (C0188)var1;
         return (boolean)(Objects.equals(this.f5036, var2.f5036) && this.f5038 == var2.f5038 && this.f5037 == var2.f5037
            ? (f5039 | 923129) + ~(f5039 & 923129) + 1 ^ -41948435
            : (f5039 | 593004) + ~(f5039 & 593004) + 1 ^ -42404999);
      } else {
         return (boolean)((f5039 | 496572) + ~(f5039 & 496572) + 1 ^ -42570583);
      }
   }

   @Override
   public int hashCode() {
      Object[] var10000 = new Object[(f5039 | 144934) + ~(f5039 & 144934) + 1 ^ -42743504];
      var10000[(f5039 | 767482) + ~(f5039 & 767482) + 1 ^ -42317073] = this.f5036;
      var10000[(f5039 | 874703) + ~(f5039 & 874703) + 1 ^ -42162213] = this.f5037;
      var10000[(f5039 | 941926) + ~(f5039 & 941926) + 1 ^ -41967503] = this.f5038;
      return w.a<"B">(var10000, 292132947184505832L);
   }

   public class_1923 m4015() {
      return this.f5036;
   }

   public C0364 m4016() {
      return this.f5037;
   }

   public C0026 m4017() {
      return this.f5038;
   }
}
