package me.mioclient;

public class C0523 {
}
