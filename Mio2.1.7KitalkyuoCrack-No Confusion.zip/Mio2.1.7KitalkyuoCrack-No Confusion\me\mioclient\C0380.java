package me.mioclient;

import baritone.api.IBaritone;
import baritone.api.command.IBaritoneChatControl;
import baritone.api.event.events.ChatEvent;
import baritone.api.event.events.TabCompleteEvent;
import baritone.api.event.listener.IEventBus;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.StringRange;
import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.Suggestions;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_2172;
import net.minecraft.class_2338;

public class C0380 extends C0219 {
   public static final String f3300 = "#";
   public static int f3301 = w.a<"B">(636225450683273106L, 257832362129977838L);

   public C0380() {
      super("baritone");
      String[] var10001 = new String[(f3301 | 412929) + ~(f3301 & 412929) + 1 ^ 1475749638];
      var10001[(f3301 | 138182) + ~(f3301 & 138182) + 1 ^ 1475506624] = "b";
      w.a<"Û">(this, var10001, 219242751041471617L);
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"Û">(
               w.a<"B">("command", w.a<"B">(260998554108144903L), 191188367299315725L),
               (SuggestionProvider)(var1x, var2) -> {
                  IBaritone var3 = w.a<"Û">(w.a<"B">(138748748971879289L), 164621699202994993L);
                  String var4 = "#";

                  try {
                     var4 = new C1002().m2591(w.a<"Û">(var2, 110975976514483618L)).m2591(var4).m2593("\u0001\u0001");
                  } catch (Exception var11) {
                  }

                  TabCompleteEvent var5 = new TabCompleteEvent(var4);
                  w.a<"Û">(this, (Runnable)() -> w.a<"Û">(w.a<"Û">(var3, 187335353393415947L), var5, 270915106796264439L), 170476340884631694L);
                  if (var5.completions != null && var5.completions.length != 0) {
                     String var6 = w.a<"Û">(var1x, 173789390739681368L);
                     String var7 = w.a<"Û">(
                        var6,
                        (f3301 | 181944) + ~(f3301 & 181944) + 1 ^ 1475521726,
                        w.a<"B">(
                           w.a<"Û">(var6, 120891947504160641L),
                           w.a<"Û">(var2, 184899309879601106L) + w.a<"Û">(w.a<"Û">(var2, 110975976514483618L), 120891947504160641L),
                           244670932612973720L
                        ),
                        145614115509746641L
                     );
                     StringRange var8 = w.a<"B">(
                        w.a<"Û">(var7, " ", 187593710675503495L) + ((f3301 | 121191) + ~(f3301 & 121191) + 1 ^ 1475457888),
                        w.a<"Û">(var7, 120891947504160641L),
                        305432690186719782L
                     );
                     List var9 = (List)w.a<"Û">(
                        w.a<"Û">(
                           w.a<"B">(var5.completions, 290973472845544482L),
                           (Function<String, Suggestion>)var1xx -> new Suggestion(
                                 var8,
                                 w.a<"Û">(var1xx, "#", 339063961306778534L)
                                    ? w.a<"Û">(var1xx, (f3301 | 525653) + ~(f3301 & 525653) + 1 ^ 1475899218, 262110967219539157L)
                                    : var1xx
                              ),
                           141209812120559377L
                        ),
                        w.a<"B">(237074135112251105L),
                        185878351305311015L
                     );
                     Suggestions var10 = new Suggestions(var8, var9);
                     return w.a<"B">(var10, 172813072404835053L);
                  } else {
                     return w.a<"Û">(var2, 135487642270960168L);
                  }
               },
               357832626693996259L
            ),
            (Command)var1x -> {
               IBaritone var2 = w.a<"Û">(w.a<"B">(138748748971879289L), 164621699202994993L);
               String var3 = (String)w.a<"Û">(var1x, "command", String.class, 275658406246533271L);
               if (w.a<"Û">("goto", var3, 307662238383225114L)) {
                  w.a<"Û">(
                     C0933.f1444,
                     w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L
                        ),
                        311335674990834024L
                     ),
                     373712900980242593L
                  );
                  return (f3301 | 427135) + ~(f3301 & 427135) + 1 ^ 1475800696;
               } else {
                  if (w.a<"Û">("goto ping", var3, 307662238383225114L)) {
                     class_2338 var4 = w.a<"Û">(this, 346862193067910410L);
                     if (var4 != null) {
                        w.a<"Û">(C0933.f1444, var4, 373712900980242593L);
                        return (f3301 | 240488) + ~(f3301 & 240488) + 1 ^ 1475592559;
                     }
                  } else if (w.a<"Û">("elytra ping", var3, 307662238383225114L)) {
                     class_2338 var5 = w.a<"Û">(this, 346862193067910410L);
                     if (var5 != null) {
                        w.a<"Û">(
                           C0933.f1444,
                           w.a<"Û">(
                              var5,
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 225355054653996046L
                              ),
                              322697695374850390L
                           ),
                           294197528283861825L
                        );
                        return (f3301 | 781184) + ~(f3301 & 781184) + 1 ^ 1476100487;
                     }
                  }

                  IEventBus var10000 = w.a<"Û">(var2, 187335353393415947L);
                  String var10003 = IBaritoneChatControl.FORCE_COMMAND_PREFIX;
                  w.a<"Û">(var10000, new ChatEvent(new C1002().m2591(var3).m2591(var10003).m2593("\u0001\u0001")), 240560481015100880L);
                  return (f3301 | 524235) + ~(f3301 & 524235) + 1 ^ 1475843532;
               }
            },
            368995281709124746L
         ),
         289819728773344295L
      );
   }

   public void m1363(Runnable var1) {
      String var2 = (String)w.a<"B">(368076255256835497L).prefix.value;
      w.a<"B">(368076255256835497L).prefix.value = "#";
      w.a<"Û">(var1, 324159666149362285L);
      w.a<"B">(368076255256835497L).prefix.value = var2;
   }

   public class_2338 m1364() {
      synchronized (w.a<"Û">(C0933.f1424, 228162244322414354L)) {
         Iterator var2 = w.a<"Û">(w.a<"Û">(C0933.f1424, 228162244322414354L), 341496865259068134L);

         while (w.a<"Û">(var2, 333900474771661065L)) {
            C0221 var3 = (C0221)w.a<"Û">(var2, 192468336863492695L);
            if (w.a<"Û">(var3, 232802977336792662L)
               && !w.a<"Û">(
                  w.a<"Û">(var3, 225232154800069699L),
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 325699207128272228L
                     ),
                     286788181028845103L
                  ),
                  307662238383225114L
               )) {
               float var4 = (float)w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 270398306108537951L),
                  w.a<"Û">(w.a<"Û">(var3, 387250098636931604L), 229561253177300454L),
                  180844654503832142L
               );
               if (!(var4 >= w.a<"B">((f3301 | 870554) + ~(f3301 & 870554) + 1 ^ 299966108, 349057757755238323L))) {
                  return w.a<"Û">(var3, 387250098636931604L);
               }
            }
         }

         return null;
      }
   }

   public static String QPWAYl5zg4yww2hhGmsQesSnPdhC5olJluoe1dWiMzJbh4oqu5i6FkX9KtrOqpmNNRN8R3Ilf6LYVMh1T20h5jxlhYpeCNQEbwpT(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
