package me.mioclient;

import java.util.function.Supplier;
import net.minecraft.class_2583;

public interface C0328 {
   class_2583 mio$withColor(Supplier<Integer> var1);
}
