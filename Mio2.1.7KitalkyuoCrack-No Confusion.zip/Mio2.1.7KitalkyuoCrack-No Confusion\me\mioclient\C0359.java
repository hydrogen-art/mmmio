package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.Predicate;

public class C0359 extends C1266 {
   public final C0015<C0361> f5349;
   public final C0015<Boolean> f5350;
   public final C0015<Color> f5351;
   public final C0015<Color> f5352;
   public final C0015<Boolean> f5353;
   public final C0015<Boolean> f5354;
   public final C0015<Boolean> f5355;
   public final C0015<Boolean> f5356;
   public static int f5357 = w.a<"B">(9042809221844709431L, 257832362129977838L);

   public C0359() {
      super("SkyColor", "Changes the fog color.", C1045.f3174);
      w.a<"B">(this, 242859112966675773L);
      w.a<"Û">(this, (boolean)((f5357 | 438576) + ~(f5357 & 438576) + 1 ^ 1425914638), 135570431627433065L);
      w.a<"Û">(
         this.f5351,
         (Predicate<Color>)var1 -> (boolean)(w.a<"Û">(this.f5349, 174312564406604366L) != C0361.f2145
               ? (f5357 | 887259) + ~(f5357 & 887259) + 1 ^ 1425441764
               : (f5357 | 592754) + ~(f5357 & 592754) + 1 ^ 1425146188),
         235935633196277017L
      );
      w.a<"Û">(
         this.f5352,
         (Predicate<Color>)var1 -> (boolean)(w.a<"Û">(this.f5349, 174312564406604366L) != C0361.f2145
               ? (f5357 | 180780) + ~(f5357 & 180780) + 1 ^ 1425655827
               : (f5357 | 561349) + ~(f5357 & 561349) + 1 ^ 1425251067),
         235935633196277017L
      );
      w.a<"Û">(
         this.f5350,
         (Predicate<Boolean>)var1 -> (boolean)(w.a<"Û">(this.f5349, 174312564406604366L) != C0361.f2144
                  && (
                     !w.a<"Û">((Boolean)w.a<"Û">(this.f5355, 174312564406604366L), 354697271520518137L)
                           && !w.a<"Û">((Boolean)w.a<"Û">(this.f5356, 174312564406604366L), 354697271520518137L)
                        || w.a<"Û">(this.f5349, 174312564406604366L) != C0361.f2143
                  )
               ? (f5357 | 786886) + ~(f5357 & 786886) + 1 ^ 1425476600
               : (f5357 | 920256) + ~(f5357 & 920256) + 1 ^ 1425342719),
         235935633196277017L
      );
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public boolean m4124() {
      return switch (<unrepresentable>.f1951[w.a<"Û">(w.a<"B">(375727057840316412L), 256325088668397295L)]) {
         case 1 -> w.a<"Û">((Boolean)w.a<"Û">(this.f5354, 174312564406604366L), 354697271520518137L);
         case 2 -> w.a<"Û">((Boolean)w.a<"Û">(this.f5355, 174312564406604366L), 354697271520518137L);
         default -> w.a<"Û">((Boolean)w.a<"Û">(this.f5356, 174312564406604366L), 354697271520518137L);
      };
   }

   public static String aQLIzdhQQO8EoFcPGcn2Btioox3YW1dP5JK2GFH1hOvk101kE9iehc0JUukebvlWEZeyRjuDy8vcx8O4is6kRCWJwgj231KJB945(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
