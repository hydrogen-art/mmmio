package me.mioclient;

import java.util.Iterator;

public class C0451 extends C1108 {
   public final C0083 f2933 = new C0083();
   public static int f2934 = w.a<"B">(5927640031255625863L, 257832362129977838L);

   public C0451(String var1, C1088 var2) {
      super(var1, C0272.f3583, var2);
   }

   @Override
   public void run() {
      if (w.a<"Û">(this.f2933, ((long)f2934 | 52469L) + ~((long)f2934 & 52469L) + 1L ^ -1997807294L, 309642602085515378L)) {
         w.a<"Û">(this.f2933, 387780412884547639L);
      } else {
         Iterator var1 = w.a<"Û">(
            this.m$$Pj8KnzzsTD4xKKhQb68ECP9g0nEEpfufc7jFY70HUwPGeOvVekkswMX1i2w14VV02yg6VKSM5QFhrBBDf5OkEZjmAMRXT47Mn, 341496865259068134L
         );

         while (w.a<"Û">(var1, 333900474771661065L)) {
            String var2 = (String)w.a<"Û">(var1, 192468336863492695L);
            w.a<"Û">(this, var2, 152247831893841791L);
         }

         w.a<"Û">(this.f2933, -1L, 167864214448769242L);
      }
   }
}
