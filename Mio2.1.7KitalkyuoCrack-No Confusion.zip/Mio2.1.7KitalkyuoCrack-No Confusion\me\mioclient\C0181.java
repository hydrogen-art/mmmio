package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;

public enum C0181 implements C0196 {
   f2640("None") {
      @Override
      public Color m1018(C1323 var1, float var2) {
         return w.a<"Û">(var1.f2206, 364389994709402373L)
            ? w.a<"Û">(
               var1.f2206,
               (Color)w.a<"Û">(var1.f2206, 174312564406604366L),
               (int)(var2 * (float)w.a<"Û">((Integer)w.a<"Û">(var1.f2208, 174312564406604366L), 260981171345819427L) * w.a<"B">(233392706582494107L)),
               333078734724323843L
            )
            : (Color)w.a<"Û">(var1.f2206, 174312564406604366L);
      }
   },
   f2641("Pulse") {
      @Override
      public Color m1018(C1323 var1, float var2) {
         return C0152.m3471(
            (Color)w.a<"Û">(var1.f2206, 174312564406604366L),
            (Color)w.a<"Û">(var1.f2209, 174312564406604366L),
            2000.0,
            (double)(var2 * (float)w.a<"Û">((Integer)w.a<"Û">(var1.f2208, 174312564406604366L), 260981171345819427L) * w.a<"B">(233392706582494107L))
         );
      }
   },
   f2642("Raw") {
      @Override
      public Color m1018(C1323 var1, float var2) {
         int var3 = w.a<"Û">((Integer)w.a<"Û">(var1.f2210, 174312564406604366L), 260981171345819427L);
         int var4 = w.a<"Û">((Integer)w.a<"Û">(var1.f2208, 174312564406604366L), 260981171345819427L);
         float var5 = 1.0F / (float)var4;
         int var6 = (int)(
            (float)(
                  w.a<"B">(223409559795593705L) / (long)w.a<"Û">((Integer)w.a<"Û">(var1.f2211, 174312564406604366L), 260981171345819427L) % (long)(var3 * var4)
               )
               + var2 / w.a<"B">(233392706582494107L)
         );
         int var7 = (int)w.a<"B">((double)((float)var6 * var5), 143282796194555966L);
         if (var7 < 0) {
            var7 = 0;
         }

         return w.a<"Û">((Boolean)w.a<"Û">(var1.f2212, 174312564406604366L), 354697271520518137L)
            ? C0152.m3472(
               (Color)w.a<"Û">((C0015)w.a<"Û">(var1.f2213, var7 % var3, 325739049664951543L), 174312564406604366L),
               (Color)w.a<"Û">((C0015)w.a<"Û">(var1.f2213, (var7 + 1) % var3, 325739049664951543L), 174312564406604366L),
               1.0F - ((float)var6 * var5 - (float)var7)
            )
            : (Color)w.a<"Û">((C0015)w.a<"Û">(var1.f2213, var7 % var3, 325739049664951543L), 174312564406604366L);
      }
   };

   public final String f2643;

   public C0181(String var3) {
      this.f2643 = var3;
   }

   @Override
   public String getName() {
      return this.f2643;
   }

   public abstract Color m1018(C1323 var1, float var2);

   public static float m1019() {
      return 10.0F / (float)(C0498.f4738.m3897() + 2);
   }

   public static String VNdRq3SkbDZiPEnC8nfozQ4HMOwdro5HrdGBnSWGnLFwa3A5hCWNtqOwIBnZ4uokwIoeTVcbBUkqQDXjNLUsE9ivK8zy0q86yrGd(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
