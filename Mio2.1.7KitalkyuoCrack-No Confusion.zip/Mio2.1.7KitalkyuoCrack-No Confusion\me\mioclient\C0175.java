package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import me.mioclient.mixin.ducks.DuckFireworkEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2848.class_2849;

public final class C0175 extends C1266 {
   public static final C0276 f1463 = C0933.f1409.m2696(C0276.class);
   public static final C0671 f1464 = C0933.f1409.m2696(C0671.class);
   public final C0015<Boolean> f1465;
   public final C0015<Boolean> f1466;
   public final C0015<Boolean> f1467;
   public final C0015<Float> f1468;
   public final C0015<Boolean> f1469;
   public final C0015<Boolean> f1470;
   public final C0015<Boolean> f1471;
   public final C0015<Boolean> f1472;
   public final C0015<Float> f1473;
   public final C0015<Boolean> f1474;
   public final C0015<Integer> f1475;
   public final C0015<Boolean> f1476;
   public final C0015<Float> f1477;
   public final C0015<Float> f1478;
   public final C0083 f1479;
   public boolean f1480;
   public int f1481;
   public int f1482;
   public boolean f1483;
   public boolean f1484;
   public static int f1485 = w.a<"B">(3346123639394173294L, 257832362129977838L);

   public C0175() {
      C1045 var10003 = C1045.f3175;
      String[] var10004 = new String[(f1485 | 585399) + ~(f1485 & 585399) + 1 ^ -2042235688];
      var10004[(f1485 | 748643) + ~(f1485 & 748643) + 1 ^ -2042202611] = "rockets";
      super("Fireworks", "Enhances the usage of firework rockets.", var10003, var10004);
      w.a<"B">(this, 242859112966675773L);
      this.f1479 = new C0083();
      w.a<"Û">(this.f1473, "Auto", C0508.f2371, 381268910042652120L);
   }

   @C1027
   public void m0610(C0816 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1465, 174312564406604366L), 354697271520518137L)) {
         if (w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               w.a<"Û">(var1, 313087336970921067L),
               116318201500984113L
            ),
            class_1802.field_8639,
            282470456889867724L
         )) {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               w.a<"Û">(var1, 313087336970921067L),
               114543782118481187L
            );
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               w.a<"Û">(var1, 313087336970921067L),
               356560492913773202L
            );
            w.a<"Û">(var1, 385440235371820560L);
         }
      }
   }

   @C1027
   public void m0611(C0254 var1) {
      if (w.a<"Û">(this, 355438456862731507L)) {
         if (w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_1802.field_8639,
            240990298961599048L
         )) {
            this.f1482 = (f1485 | 787308) + ~(f1485 & 787308) + 1 ^ -2042554110;
            w.a<"Û">(this, 127214991617097642L);
            this.f1481 = w.a<"Û">((Integer)w.a<"Û">(this.f1475, 174312564406604366L), 260981171345819427L);
            this.f1484 = (boolean)((f1485 | 302002) + ~(f1485 & 302002) + 1 ^ -2042002979);
         }
      }
   }

   @C1027
   public void m0612(C0591 var1) {
      if (this.f1483) {
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            (boolean)((f1485 | 582962) + ~(f1485 & 582962) + 1 ^ -2042232996),
            338213165866007469L
         );
         w.a<"B">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_2849.field_12984,
            (f1485 | 735777) + ~(f1485 & 735777) + 1 ^ -2042224561,
            157595208248618445L
         );
         this.f1483 = (boolean)((f1485 | 700546) + ~(f1485 & 700546) + 1 ^ -2042123540);
         if (!w.a<"B">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 249568915987008963L)) {
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 346962699068412296L);
         }
      }

      if (this.f1481 > 0) {
         w.a<"Û">(this, 127214991617097642L);
         this.f1481 = this.f1481 - ((f1485 | 754945) + ~(f1485 & 754945) + 1 ^ -2042192018);
         this.f1483 = (boolean)(this.f1481 == 0
            ? (f1485 | 601045) + ~(f1485 & 601045) + 1 ^ -2042351174
            : (f1485 | 173890) + ~(f1485 & 173890) + 1 ^ -2041594580);
      }

      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1469, 174312564406604366L), 354697271520518137L)
         && (w.a<"Û">(f1464, 314537768572362865L) || !w.a<"Û">((Boolean)w.a<"Û">(this.f1470, 174312564406604366L), 354697271520518137L))) {
         if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)) {
            w.a<"Û">(this.f1479, -1L, 167864214448769242L);
         }

         int var2 = w.a<"Û">(
                  this.f1479, (double)w.a<"Û">((Float)w.a<"Û">(this.f1473, 174312564406604366L), 149784643039979208L), TimeUnit.SECONDS, 215737872562411156L
               )
               && (!w.a<"Û">(f1463, 314537768572362865L) || f1463.f2263 == ((f1485 | 642667) + ~(f1485 & 642667) + 1 ^ 2042309626) || f1463.f2264 == null)
            ? (f1485 | 276617) + ~(f1485 & 276617) + 1 ^ -2042027289
            : (f1485 | 39201) + ~(f1485 & 39201) + 1 ^ -2041740466;
         if (w.a<"Û">(this, 363684429490498682L)) {
            var2 = (f1485 | 165397) + ~(f1485 & 165397) + 1 ^ -2041602950;
         }

         if (var2 == 0) {
            if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)
               )
             {
               this.f1480 = (boolean)((f1485 | 33436) + ~(f1485 & 33436) + 1 ^ -2041734926);
            }

            if (!this.f1480 || !w.a<"Û">((Boolean)w.a<"Û">(this.f1471, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(this, 350224882188364959L);
            }
         }
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = -100
   )
   public void m0613(C0650 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1476, 174312564406604366L), 354697271520518137L)
         && this.f1481 > ((f1485 | 807795) + ~(f1485 & 807795) + 1 ^ -2042541796)
         && w.a<"Û">(this, 363684429490498682L)) {
         w.a<"Û">(this, var1, 352953289520366065L);
      }

      if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)
         && w.a<"Û">((Boolean)w.a<"Û">(this.f1472, 174312564406604366L), 354697271520518137L)
         && w.a<"Û">((Boolean)w.a<"Û">(this.f1469, 174312564406604366L), 354697271520518137L)) {
         if (!w.a<"Û">(this, 363684429490498682L)) {
            w.a<"Û">(var1, new class_243(0.0, 0.0, 0.0), 326881584648207186L);
         }
      }
   }

   @C1027
   public void m0614(C0771 var1) {
      if (this.f1481 > 0
         && w.a<"Û">(var1, 139172364189134130L) != null
         && w.a<"Û">(w.a<"Û">(var1, 139172364189134130L), 164367448962417760L) != null
         && w.a<"Û">(w.a<"Û">(w.a<"Û">(w.a<"Û">(var1, 139172364189134130L), 164367448962417760L), 245453061757190100L), "item.armor.equip", 160084314699716367L)
         )
       {
         w.a<"Û">(var1, 385440235371820560L);
      }
   }

   public void m0615(C0650 var1) {
      float var2 = w.a<"B">((f1485 | 165759) + ~(f1485 & 165759) + 1 ^ 1020039038, 349057757755238323L);
      if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913.field_3904) {
         var2 = w.a<"Û">((Float)w.a<"Û">(this.f1478, 174312564406604366L), 149784643039979208L);
      } else if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913.field_3903) {
         var2 = -w.a<"Û">((Float)w.a<"Û">(this.f1478, 174312564406604366L), 149784643039979208L);
      }

      float var3 = w.a<"Û">((Float)w.a<"Û">(this.f1477, 174312564406604366L), 149784643039979208L);
      if ((double)var3 > w.a<"B">(((long)f1485 | 530551L) + ~((long)f1485 & 530551L) + 1L ^ -4609884579759875197L, 317139102743630955L)) {
         var3 = w.a<"B">(
            w.a<"B">((f1485 | 128588) + ~(f1485 & 128588) + 1 ^ -1182785297, 349057757755238323L)
               + (float)this.f1482 * w.a<"B">((f1485 | 879369) + ~(f1485 & 879369) + 1 ^ -1148404310, 349057757755238323L),
            w.a<"B">((f1485 | 225130) + ~(f1485 & 225130) + 1 ^ -1182615095, 349057757755238323L),
            var3,
            131506059371757968L
         );
         this.f1482 = this.f1482 + ((f1485 | 513707) + ~(f1485 & 513707) + 1 ^ -2041918268);
      }

      double[] var4 = w.a<"B">(var1, (double)var3, 141944367774315646L);
      class_243 var5 = new class_243(
         var4[(f1485 | 620776) + ~(f1485 & 620776) + 1 ^ -2042338682], (double)var2, var4[(f1485 | 623674) + ~(f1485 & 623674) + 1 ^ -2042323371]
      );
      w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, var5, 371430761082648882L);
      w.a<"Û">(var1, var5, 326881584648207186L);
   }

   public void m0616() {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f1469, 174312564406604366L), 354697271520518137L)
         && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)) {
         class_1268 var1 = w.a<"B">(class_1802.field_8639, 290444706100011361L);
         int var2 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
            )
            .field_7545;
         int var3 = w.a<"B">(class_1802.field_8639, 261845468269893067L);
         int var4 = w.a<"B">(class_1802.field_8639, 113439863899466963L);
         if (var1 != null) {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               var1,
               114543782118481187L
            );
            w.a<"Û">(this.f1479, 387780412884547639L);
         } else if (var3 != ((f1485 | 976622) + ~(f1485 & 976622) + 1 ^ 2042364799)) {
            int var5 = var4 == ((f1485 | 789792) + ~(f1485 & 789792) + 1 ^ 2042554545)
               ? (f1485 | 847436) + ~(f1485 & 847436) + 1 ^ -2042498013
               : (f1485 | 863065) + ~(f1485 & 863065) + 1 ^ -2042613449;
            w.a<"Û">(this, var5 != 0 ? var3 : var4, (boolean)var5, 154425217345526988L);
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               class_1268.field_5808,
               114543782118481187L
            );
            f1463.f2265 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L
            );
            w.a<"Û">(this, var5 != 0 ? var3 : var2, (boolean)var5, 154425217345526988L);
            w.a<"Û">(this.f1479, 387780412884547639L);
         }

         this.f1480 = (boolean)((f1485 | 304534) + ~(f1485 & 304534) + 1 ^ -2041987079);
      }
   }

   public void m0617(int var1, boolean var2) {
      if (var2) {
         w.a<"B">(var1, 209502932342608419L);
      } else {
         w.a<"B">(var1, 279757124141714355L);
      }
   }

   public boolean m0618() {
      if (!w.a<"Û">(this.f1479, ((long)f1485 | 965549L) + ~((long)f1485 & 965549L) + 1L ^ -2042388425L, 309642602085515378L)) {
         return (boolean)((f1485 | 285116) + ~(f1485 & 285116) + 1 ^ -2042018861);
      } else {
         Iterator var1 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
            191661729848227466L
         );

         while (w.a<"Û">(var1, 333900474771661065L)) {
            class_1297 var2 = (class_1297)w.a<"Û">(var1, 192468336863492695L);
            if (var2 instanceof DuckFireworkEntity var3
               && var3.mio$getShooter() == m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724) {
               return (boolean)((f1485 | 408194) + ~(f1485 & 408194) + 1 ^ -2041896723);
            }
         }

         return (boolean)((f1485 | 598550) + ~(f1485 & 598550) + 1 ^ -2042349448);
      }
   }

   public float m0619(boolean var1) {
      return w.a<"Û">(this, 314537768572362865L)
            && w.a<"Û">((Boolean)w.a<"Û">(this.f1466, 174312564406604366L), 354697271520518137L)
            && (var1 || w.a<"Û">((Boolean)w.a<"Û">(this.f1467, 174312564406604366L), 354697271520518137L))
            && w.a<"Û">(this, 363684429490498682L)
         ? w.a<"Û">((Float)w.a<"Û">(this.f1468, 174312564406604366L), 149784643039979208L)
         : 0.0F;
   }

   public int m0620() {
      return this.f1481;
   }

   public boolean m0621() {
      if (w.a<"B">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 249568915987008963L)) {
         return (boolean)((f1485 | 861590) + ~(f1485 & 861590) + 1 ^ -2042609672);
      } else {
         return (boolean)(w.a<"Û">(this, 314537768572362865L)
               && w.a<"Û">((Boolean)w.a<"Û">(this.f1474, 174312564406604366L), 354697271520518137L)
               && !w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L
               )
               && w.a<"B">(class_1802.field_8833, 261845468269893067L) != ((f1485 | 832703) + ~(f1485 & 832703) + 1 ^ 2042515758)
            ? (f1485 | 29325) + ~(f1485 & 29325) + 1 ^ -2041747230
            : (f1485 | 733212) + ~(f1485 & 733212) + 1 ^ -2042221966);
      }
   }

   public void m0622() {
      int var1 = w.a<"B">(class_1802.field_8833, 113439863899466963L);
      int var2 = var1 == ((f1485 | 268290) + ~(f1485 & 268290) + 1 ^ 2042035603)
         ? (f1485 | 465653) + ~(f1485 & 465653) + 1 ^ -2041970534
         : (f1485 | 880153) + ~(f1485 & 880153) + 1 ^ -2042596233;
      if (var1 == ((f1485 | 940968) + ~(f1485 & 940968) + 1 ^ 2042412601)) {
         var1 = w.a<"B">(class_1802.field_8833, 261845468269893067L);
      }

      if (var1 != ((f1485 | 21025) + ~(f1485 & 21025) + 1 ^ 2041755568)) {
         int var3 = var1;
         if (var2 != 0) {
            var1 = (f1485 | 622520) + ~(f1485 & 622520) + 1 ^ -2042337834;
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
               (f1485 | 881593) + ~(f1485 & 881593) + 1 ^ -2042598953,
               var3,
               (f1485 | 319218) + ~(f1485 & 319218) + 1 ^ -2041985892,
               class_1713.field_7791,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               270665692837061225L
            );
         }

         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            (f1485 | 615255) + ~(f1485 & 615255) + 1 ^ -2042332871,
            (f1485 | 398115) + ~(f1485 & 398115) + 1 ^ -2041902773,
            var1,
            class_1713.field_7791,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            270665692837061225L
         );
         w.a<"B">(370137111334983660L);
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 332932048095061767L);
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            (f1485 | 696064) + ~(f1485 & 696064) + 1 ^ -2042133138,
            (f1485 | 819004) + ~(f1485 & 819004) + 1 ^ -2042534572,
            var1,
            class_1713.field_7791,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            270665692837061225L
         );
         if (var2 != 0) {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
               (f1485 | 371017) + ~(f1485 & 371017) + 1 ^ -2042055897,
               var3,
               (f1485 | 3295) + ~(f1485 & 3295) + 1 ^ -2041768271,
               class_1713.field_7791,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               270665692837061225L
            );
         }
      }
   }

   public static String mkBmLwInSwPr5DyjbprlFJZH2Xzno7Q9Uon2knhMXqWj7tRnrqkytBfipigS3gXgauNrwW8vrdvcVn8oIRI5TQIxqiEWB4RDapoO(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
