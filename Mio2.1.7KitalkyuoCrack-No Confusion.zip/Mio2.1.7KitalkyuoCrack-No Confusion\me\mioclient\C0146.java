package me.mioclient;

import net.minecraft.class_243;

public final class C0146 extends C0105 {
   public static C0300 f4953 = C0933.f1409.m2696(C0300.class);
   public static int f4954 = w.a<"B">(4557724734771283078L, 257832362129977838L);

   public C0146(C0345 var1) {
      super(var1);
   }

   @Override
   public void m0455(C0650 var1) {
      if (!w.a<"Û">(this, 369407487914564677L)) {
         if (w.a<"Û">(
               (Boolean)w.a<"Û">(
                  this.m$$LAhfmHeFtSEGjfgS6DHzdS5ZBZKqbuGliycdfZy9nckSGZyLmKD7Z4vdct7yfsIqcXmjvTtoHUS5P0o9HyXX6PoycrAMIjvVv.f0373, 174312564406604366L
               ),
               354697271520518137L
            )
            && w.a<"Û">(w.a<"Û">(C0933.f1416, 131737481540982891L), ((long)f4954 | 578715L) + ~((long)f4954 & 578715L) + 1L ^ 1307422389L, 309642602085515378L)
            )
          {
            w.a<"Û">(
               C0933.f1410,
               this.m$$LAhfmHeFtSEGjfgS6DHzdS5ZBZKqbuGliycdfZy9nckSGZyLmKD7Z4vdct7yfsIqcXmjvTtoHUS5P0o9HyXX6PoycrAMIjvVv,
               w.a<"B">((f4954 | 334599) + ~(f4954 & 334599) + 1 ^ 1919630367, 349057757755238323L),
               371685643619254063L
            );
         } else {
            w.a<"Û">(
               C0933.f1410, this.m$$LAhfmHeFtSEGjfgS6DHzdS5ZBZKqbuGliycdfZy9nckSGZyLmKD7Z4vdct7yfsIqcXmjvTtoHUS5P0o9HyXX6PoycrAMIjvVv, 150212528603319406L
            );
         }

         if (!w.a<"B">(239474890139367192L)) {
            w.a<"Û">(var1, 0.0, 0.0, 341834528303342411L);
         } else {
            double var2 = w.a<"B">((boolean)((f4954 | 594637) + ~(f4954 & 594637) + 1 ^ 1307338777), 246124077639322483L);
            if (w.a<"Û">(w.a<"Û">(C0933.f1416, 131737481540982891L), ((long)f4954 | 242209L) + ~((long)f4954 & 242209L) + 1L ^ 1306970369L, 309642602085515378L)
               )
             {
               var2 = w.a<"B">(
                  var2, w.a<"B">(w.a<"Û">(var1, 211665782282761067L), w.a<"Û">(var1, 149300137507612725L), 263950649710151907L), 354112003008534934L
               );
            }

            w.a<"B">(var1, var2, 141944367774315646L);
         }
      }
   }

   @Override
   public void m1433() {
      if (!w.a<"Û">(this, 369407487914564677L)
         && w.a<"B">(239474890139367192L)
         && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_36331) {
         double[] var1 = w.a<"B">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L),
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913,
            w.a<"B">(((long)f4954 | 768633L) + ~((long)f4954 & 768633L) + 1L ^ 4607182420107509933L, 317139102743630955L),
            108620803423508722L
         );
         float var2 = (float)(
            w.a<"B">(
                  w.a<"B">(
                     var1[(f4954 | 170076) + ~(f4954 & 170076) + 1 ^ 1307042441],
                     var1[(f4954 | 681852) + ~(f4954 & 681852) + 1 ^ 1307516328],
                     370151239157781531L
                  ),
                  207871222047649314L
               )
               - (double)C1074.f4547
         );
         class_243 var3 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 214921524804283555L
         );
         float var4 = (float)w.a<"B">((double)var2, 175389272199548133L);
         float var5 = w.a<"B">((f4954 | 629348) + ~(f4954 & 629348) + 1 ^ 1939876989, 349057757755238323L);
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            var3.field_1352,
            w.a<"B">(((long)f4954 | 7684L) + ~((long)f4954 & 7684L) + 1L ^ 4600877380309679434L, 317139102743630955L) + w.a<"B">(346349225321202810L),
            var3.field_1350,
            211344564396137847L
         );
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            new class_243((double)(-w.a<"B">(var4, 155264254601911076L) * var5), 0.0, (double)(w.a<"B">(var4, 229164846296942151L) * var5)),
            271068129340873042L
         );
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            (boolean)((f4954 | 583226) + ~(f4954 & 583226) + 1 ^ 1307417839),
            343736006055686636L
         );
      }
   }

   public boolean m2003() {
      return (boolean)(!w.a<"Û">(this.m$$LAhfmHeFtSEGjfgS6DHzdS5ZBZKqbuGliycdfZy9nckSGZyLmKD7Z4vdct7yfsIqcXmjvTtoHUS5P0o9HyXX6PoycrAMIjvVv, 119633580786107485L)
            && !w.a<"Û">(this.m$$LAhfmHeFtSEGjfgS6DHzdS5ZBZKqbuGliycdfZy9nckSGZyLmKD7Z4vdct7yfsIqcXmjvTtoHUS5P0o9HyXX6PoycrAMIjvVv, 291728366122999264L)
            && !w.a<"B">(132944285386342797L)
            && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)
            && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 216539022803564207L)
            && !w.a<"Û">(f4953, 314537768572362865L)
         ? (f4954 | 162200) + ~(f4954 & 162200) + 1 ^ 1306985292
         : (f4954 | 506404) + ~(f4954 & 506404) + 1 ^ 1306706161);
   }
}
