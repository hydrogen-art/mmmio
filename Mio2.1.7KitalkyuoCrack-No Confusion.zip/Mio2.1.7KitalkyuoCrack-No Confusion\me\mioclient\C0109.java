package me.mioclient;

import net.minecraft.class_243;

public class C0109 extends C1180 {
   public double f4555;
   public double f4556;
   public double f4557;

   public C0109(double var1, double var3, double var5) {
      this.f4555 = var1;
      this.f4556 = var3;
      this.f4557 = var5;
   }

   public void m1843(class_243 var1) {
      this.f4555 = var1.field_1352;
      this.f4556 = var1.field_1351;
      this.f4557 = var1.field_1350;
   }

   public class_243 m1844() {
      return new class_243(this.f4555, this.f4556, this.f4557);
   }
}
