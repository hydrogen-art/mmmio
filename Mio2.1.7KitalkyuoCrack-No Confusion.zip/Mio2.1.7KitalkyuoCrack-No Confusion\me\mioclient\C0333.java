package me.mioclient;

import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class C0333 extends C1180 {
   public final class_437 f3987;
   public class_332 f3988;
   public float f3989;
   public float f3990;
   public Runnable f3991 = null;

   public C0333(class_437 var1) {
      this.f3987 = var1;
   }

   public class_437 m3636() {
      return this.f3987;
   }

   public class_4587 m3637() {
      return this.f3988.method_51448();
   }

   public float m3638() {
      return this.f3989;
   }

   public float m3639() {
      return this.f3990;
   }

   public class_332 m3640() {
      return this.f3988;
   }

   public void m3641(class_332 var1) {
      this.f3988 = var1;
   }

   public void setX(float var1) {
      this.f3989 = var1;
   }

   public void setY(float var1) {
      this.f3990 = var1;
   }

   public void m3642(Runnable var1) {
      this.f3991 = var1;
   }

   public void m3643() {
      if (this.f3991 != null) {
         this.f3991.run();
      }
   }
}
