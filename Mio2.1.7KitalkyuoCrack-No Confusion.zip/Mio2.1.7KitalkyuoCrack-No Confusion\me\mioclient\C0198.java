package me.mioclient;

import java.util.HashMap;
import java.util.function.Supplier;

public class C0198<E extends Enum<?>, T> {
   public final HashMap<E, T> f1222 = new HashMap<>();
   public final Supplier<E> f1223;
   public static int f1224 = w.a<"B">(439870093917005745L, 257832362129977838L);

   public C0198(Supplier<E> var1) {
      this.f1223 = var1;
   }

   public C0198(C0015<E> var1) {
      w.a<"B">(var1, 131918113315390561L);
      this.f1223 = var1::getValue;
   }

   public T m0564() {
      return (T)w.a<"Û">(this.f1222, w.a<"Û">(this.f1223, 151449370165949320L), 208914271082929313L);
   }

   public void m0565(E var1, T var2) {
      w.a<"Û">(this.f1222, var1, var2, 298749053205630862L);
   }
}
