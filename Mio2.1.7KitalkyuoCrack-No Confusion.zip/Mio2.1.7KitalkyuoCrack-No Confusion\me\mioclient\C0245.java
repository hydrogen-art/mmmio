package me.mioclient;

import java.util.function.Predicate;

public class C0245 implements Predicate {
   public C0012 f5318;

   public C0245(C0012 var1) {
      this.f5318 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f5318.f2876, 254992554122318132L);
   }
}
