package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.Predicate;
import me.mioclient.mixin.ducks.DuckPlayerMoveC2SPacket;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1810;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_1893;
import net.minecraft.class_238;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_638;
import net.minecraft.class_9362;
import net.minecraft.class_2848.class_2849;

public class C0309 extends C1266 {
   public static final C0960 f3382 = C0933.f1409.m2696(C0960.class);
   public static final C1082 f3383 = C0933.f1409.m2696(C1082.class);
   public static final C1367 f3384 = C0933.f1409.m2696(C1367.class);
   public static final C0303 f3385 = C0933.f1409.m2696(C0303.class);
   public final C0015<C0313> f3386;
   public final C0015<Float> f3387;
   public final C0015<Float> f3388;
   public final C0015<Float> f3389;
   public final C0015<Float> f3390;
   public final C0015<Boolean> f3391;
   public final C0015<Boolean> f3392;
   public final C0015<Boolean> f3393;
   public final C0015<Float> f3394;
   public final C0015<Boolean> f3395;
   public final C0015<Color> f3396;
   public final C0015<Color> f3397;
   public final C0015<Float> f3398;
   public final C0015<Boolean> f3399;
   public final C0015<C0310> f3400;
   public final C0015<C0312> f3401;
   public final C0015<C0311> f3402;
   public final C0015<Boolean> f3403;
   public final C0015<Boolean> f3404;
   public final C0015<Boolean> f3405;
   public final C0015<Boolean> f3406;
   public final C0015<Boolean> f3407;
   public final C0015<Boolean> f3408;
   public final C0015<Boolean> f3409;
   public final C0015<Boolean> f3410;
   public final C0015<Boolean> f3411;
   public final C0015<Boolean> f3412;
   public final C0015<Boolean> f3413;
   public final C0072 f3414;
   public int f3415;
   public boolean f3416;
   public boolean f3417;
   public class_1297 f3418;
   public class_1297 f3419;
   public static int f3420 = w.a<"B">(4053033382232923769L, 257832362129977838L);

   public C0309() {
      C1045 var10003 = C1045.f3172;
      String[] var10004 = new String[(f3420 | 528905) + ~(f3420 & 528905) + 1 ^ 1310235944];
      var10004[(f3420 | 122412) + ~(f3420 & 122412) + 1 ^ 1309757710] = "killaura";
      var10004[(f3420 | 885933) + ~(f3420 & 885933) + 1 ^ 1310526350] = "forcefield";
      var10004[(f3420 | 654323) + ~(f3420 & 654323) + 1 ^ 1310291155] = "ka";
      super("Aura", "Attacks entities nearby.", var10003, var10004);
      w.a<"B">(this, 242859112966675773L);
      this.f3414 = new C0072();
      this.f3415 = (f3420 | 474074) + ~(f3420 & 474074) + 1 ^ -1310176505;
      w.a<"Û">(this.f3394, "None", C0508.f2371, 381268910042652120L);
      w.a<"Û">(this.f3392, 260554171392458811L);
   }

   @Override
   public void onDisable() {
      if (w.a<"Û">(this, 205492958615326489L)) {
         this.f3415 = (f3420 | 417187) + ~(f3420 & 417187) + 1 ^ -1310118530;
      } else {
         w.a<"Û">(this, 357955329378469621L);
      }
   }

   @Override
   public void onToggle() {
      this.f3418 = null;
      w.a<"Û">(this.f3414, 0.0F, 329276899603713802L);
      w.a<"Û">(C0933.f1444, this, 298834728175715582L);
   }

   @Override
   public String getInfo() {
      return this.f3418 != null && this.f3418 instanceof class_1657 ? w.a<"Û">(w.a<"Û">(this.f3418, 291295238331520790L), 286788181028845103L) : null;
   }

   @C1027
   public void m3434(C0153 var1) {
      int var2 = this.f3418 != null && !w.a<"Û">(this.f3418, 133372882497935473L)
         ? (f3420 | 354759) + ~(f3420 & 354759) + 1 ^ 1310058212
         : (f3420 | 790997) + ~(f3420 & 790997) + 1 ^ 1310498551;
      if ((
            w.a<"Û">(
                  this,
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L
                     ),
                     222207108884875224L
                  ),
                  275154021417978881L
               )
               || w.a<"Û">(this.f3400, 174312564406604366L) != C0310.f1936
         )
         && var2 == 0) {
         if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7512
               == m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_7498
            || !w.a<"Û">(f3385, 317419592226466359L)) {
            this.f3418 = w.a<"B">(
               w.a<"Û">((Boolean)w.a<"Û">(this.f3406, 174312564406604366L), 354697271520518137L),
               w.a<"Û">((Boolean)w.a<"Û">(this.f3410, 174312564406604366L), 354697271520518137L),
               w.a<"Û">((Boolean)w.a<"Û">(this.f3408, 174312564406604366L), 354697271520518137L),
               w.a<"Û">((Boolean)w.a<"Û">(this.f3409, 174312564406604366L), 354697271520518137L),
               w.a<"Û">((Boolean)w.a<"Û">(this.f3411, 174312564406604366L), 354697271520518137L),
               w.a<"Û">((Boolean)w.a<"Û">(this.f3412, 174312564406604366L), 354697271520518137L),
               w.a<"Û">((Float)w.a<"Û">(this.f3390, 174312564406604366L), 149784643039979208L)
                  + w.a<"B">((f3420 | 253315) + ~(f3420 & 253315) + 1 ^ 1897091745, 349057757755238323L),
               w.a<"Û">((Float)w.a<"Û">(this.f3389, 174312564406604366L), 149784643039979208L)
                  + w.a<"B">((f3420 | 893807) + ~(f3420 & 893807) + 1 ^ 1897737293, 349057757755238323L),
               w.a<"Û">((Boolean)w.a<"Û">(this.f3413, 174312564406604366L), 354697271520518137L),
               w.a<"Û">((Boolean)w.a<"Û">(this.f3407, 174312564406604366L), 354697271520518137L),
               w.a<"Û">((C0313)w.a<"Û">(this.f3386, 174312564406604366L), 228923376424047370L),
               this::m3444,
               309274278493543260L
            );
            w.a<"Û">(C0933.f1444, this, 298834728175715582L);
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f3392, 174312564406604366L), 354697271520518137L) && this.f3418 != null) {
               w.a<"Û">(C0933.f1444, this, 162912410053828053L);
            }

            if (this.f3418 == null) {
               w.a<"Û">(this, 357955329378469621L);
            } else if (!w.a<"B">(171090672375251307L)
               || w.a<"Û">(this, this.f3418, 110547652596451153L)
               || w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)
               )
             {
               w.a<"Û">(this, 111055589466179942L);
               if (w.a<"Û">((Boolean)w.a<"Û">(this.f3393, 174312564406604366L), 354697271520518137L)) {
                  if (!w.a<"B">(171090672375251307L)
                     && w.a<"Û">((Float)w.a<"Û">(this.f3394, 174312564406604366L), 149784643039979208L) != 0.0F
                     && w.a<"Û">((Float)w.a<"Û">(this.f3394, 174312564406604366L), 149784643039979208L)
                           * w.a<"Û">((Float)w.a<"Û">(this.f3388, 174312564406604366L), 149784643039979208L)
                        > w.a<"Û">(this, 325184672166309076L)) {
                     return;
                  }

                  float[] var3 = w.a<"B">(w.a<"B">(this.f3418, 227058158510945889L), w.a<"Û">(C0933.f1412, 189657535592792269L), 175129603142460589L);
                  w.a<"Û">(C0933.f1412, var3, (f3420 | 760406) + ~(f3420 & 760406) + 1 ^ 1310397809, 236731835237641613L);
               }
            }
         }
      } else {
         this.f3418 = null;
      }
   }

   @C1027
   public void m3435(C0132 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2828 var2
         && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6017
            > w.a<"B">((f3420 | 578023) + ~(f3420 & 578023) + 1 ^ 240672453, 349057757755238323L)) {
         class_638 var10000 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687;
         class_238 var10001 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L
         );
         long var10004 = (long)f3420 | 594060L;
         if (!w.a<"Û">(
               var10000,
               w.a<"Û">(
                  var10001,
                  0.0,
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 214921524804283555L)
                        .field_1351
                     * w.a<"B">(var10004 + ~((long)f3420 & 594060L) + 1L ^ 4607632779801265716L, 317139102743630955L),
                  0.0,
                  244681124810902308L
               ),
               116811053208981688L
            )
            && this.f3416) {
            ((DuckPlayerMoveC2SPacket)var2)
               .setY(
                  w.a<"Û">(var2, 0.0, 295470329057738010L)
                     + w.a<"B">(((long)f3420 | 723052L) + ~((long)f3420 & 723052L) + 1L ^ 4611686019737814862L, 317139102743630955L)
               );
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L),
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L)
                  + w.a<"B">(((long)f3420 | 832748L) + ~((long)f3420 & 832748L) + 1L ^ 4613937819551546318L, 317139102743630955L),
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L),
               274939219394891130L
            );
            this.f3416 = (boolean)((f3420 | 626222) + ~(f3420 & 626222) + 1 ^ 1310261516);
         }
      }
   }

   @C1027
   public void m3436(C1358 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f3395, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(
            this.f3414,
            this.f3418 == null ? 0.0F : w.a<"B">((f3420 | 998561) + ~(f3420 & 998561) + 1 ^ 1906291587, 349057757755238323L),
            ((long)f3420 | 282098L) + ~((long)f3420 & 282098L) + 1L ^ 1309983274L,
            299144451833946012L
         );
         float var2 = w.a<"Û">(this.f3414, 130550643917971814L);
         class_238 var3 = w.a<"Û">(this, 308577404558244842L);
         if (var3 == null || var2 == 0.0F) {
            return;
         }

         Color var4 = C0152.m3473(
            (Color)w.a<"Û">(this.f3396, 174312564406604366L),
            (int)((float)w.a<"Û">((Color)w.a<"Û">(this.f3396, 174312564406604366L), 245270953955453918L) * var2)
         );
         Color var5 = C0152.m3473(
            (Color)w.a<"Û">(this.f3397, 174312564406604366L),
            (int)((float)w.a<"Û">((Color)w.a<"Û">(this.f3397, 174312564406604366L), 245270953955453918L) * var2)
         );
         w.a<"B">(w.a<"Û">(var1, 173269294235887931L), var3, var4, 246072095578695914L);
         C0485.m3219(w.a<"Û">(var1, 173269294235887931L), var3, var5, w.a<"Û">((Float)w.a<"Û">(this.f3398, 174312564406604366L), 149784643039979208L));
      }
   }

   public class_238 m3437() {
      class_238 var1 = null;
      class_1297 var2 = this.f3418;
      if (var2 == null) {
         var2 = this.f3419;
      }

      if (var2 != null) {
         var1 = w.a<"B">(var2, C0094.m1872(), 221007421302384320L);
         this.f3419 = var2;
      }

      return var1;
   }

   public void m3438() {
      if (this.f3418 != null) {
         if (w.a<"Û">(this, this.f3418, 110547652596451153L)) {
            float var1 = w.a<"Û">(
               w.a<"B">(this.f3418, 280786748544115652L) ? (Float)w.a<"Û">(this.f3389, 174312564406604366L) : (Float)w.a<"Û">(this.f3390, 174312564406604366L),
               149784643039979208L
            );
            if (!(w.a<"B">(this.f3418, 162406777113727086L) > (double)var1)) {
               int var2 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6017 <= 0.0F
                     && !w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L
                     )
                  ? (f3420 | 315108) + ~(f3420 & 315108) + 1 ^ 1309950407
                  : (f3420 | 676332) + ~(f3420 & 676332) + 1 ^ 1310383822;
               if (w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L
                  )
                  && w.a<"Û">(C0933.f1429, 202655309853842506L) <= ((f3420 | 524105) + ~(f3420 & 524105) + 1 ^ 1310158954)) {
                  var2 = (f3420 | 51857) + ~(f3420 & 51857) + 1 ^ 1309689266;
               }

               if (w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 179114946195012748L
               )) {
                  var2 = (f3420 | 742581) + ~(f3420 & 742581) + 1 ^ 1310448535;
               }

               if (w.a<"Û">(f3384, 314537768572362865L)
                  || w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 365261228406721299L
                     )
                     .field_7479
                  || w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L
                  )
                  || w.a<"B">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229073305445517953L
                  )
                  || w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114259500353953419L
                  )
                  || !(this.f3418 instanceof class_1309)
                  || var2 == 0
                  || w.a<"Û">(f3382, 314537768572362865L) && w.a<"Û">(f3382.f4380, 174312564406604366L) == C0961.f1987
                  || w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                     class_1294.field_5902,
                     176223852645644080L
                  )) {
                  int var3 = w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
                     )
                     .field_7545;
                  int var4 = w.a<"B">(
                     (Predicate<class_1799>)var0 -> (boolean)(!(w.a<"Û">(var0, 222207108884875224L) instanceof class_1743)
                              && !(w.a<"Û">(var0, 222207108884875224L) instanceof class_1829)
                           ? (f3420 | 447743) + ~(f3420 & 447743) + 1 ^ 1310088157
                           : (f3420 | 254819) + ~(f3420 & 254819) + 1 ^ 1309895744),
                     344867982687893969L
                  );
                  int var5 = w.a<"Û">(this.f3401, 174312564406604366L) == C0312.f0220 && w.a<"Û">(this, 369209844390321507L)
                     ? (f3420 | 978341) + ~(f3420 & 978341) + 1 ^ 1310614150
                     : (f3420 | 261574) + ~(f3420 & 261574) + 1 ^ 1309897444;
                  if (w.a<"Û">(this, 369209844390321507L)) {
                     if ((var5 == 0 || w.a<"Û">((Boolean)w.a<"Û">(this.f3404, 174312564406604366L), 354697271520518137L))
                        && var4 != var3
                        && w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 367966343301975358L
                        )
                        && w.a<"Û">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                              137331122518345133L
                           )
                           == class_1268.field_5808) {
                        return;
                     }

                     w.a<"B">(var4, 279757124141714355L);
                     if (var3 != var4) {
                        this.f3415 = var3;
                     }
                  }

                  boolean var6 = w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 210159634295343391L
                  );
                  if (var6) {
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
                        new class_2848(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                           class_2849.field_12985
                        ),
                        125787698683892978L
                     );
                  }

                  int var7 = w.a<"Û">(this, 216754117180023495L);
                  if (this.f3418 instanceof class_1309 var8 && !w.a<"B">(var8, 130756052256592378L)) {
                     var7 = (f3420 | 316759) + ~(f3420 & 316759) + 1 ^ -1309956726;
                  }

                  if (var7 != ((f3420 | 668866) + ~(f3420 & 668866) + 1 ^ -1310374881)) {
                     w.a<"B">(var7, 279757124141714355L);
                  }

                  w.a<"B">(this.f3418, 220670037367856860L);
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 257015636314407964L);
                  if (var6) {
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
                        new class_2848(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                           class_2849.field_12981
                        ),
                        125787698683892978L
                     );
                  }

                  f3383.f1737 = (boolean)((f3420 | 921131) + ~(f3420 & 921131) + 1 ^ 1310621961);
                  if (var7 != ((f3420 | 979272) + ~(f3420 & 979272) + 1 ^ -1310621291)) {
                     if (w.a<"Û">((Boolean)w.a<"Û">(this.f3403, 174312564406604366L), 354697271520518137L)) {
                        this.f3416 = w.a<"B">(
                           class_1893.field_50157,
                           w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                                 373857742241070098L
                              ),
                              var7,
                              386860178278302175L
                           ),
                           266852383896389005L
                        );
                     }

                     w.a<"B">(var3, 279757124141714355L);
                  }

                  if (var5 != 0 && var4 != ((f3420 | 705505) + ~(f3420 & 705505) + 1 ^ -1310346436)) {
                     w.a<"B">(var3, 279757124141714355L);
                  }
               }
            }
         }
      }
   }

   public boolean m3439(class_1297 var1) {
      if (!(this.f3418 instanceof class_1657)
         && var1 instanceof class_1309 var2
         && (double)w.a<"B">(var2, 181476777857313967L)
            <= w.a<"B">(((long)f3420 | 535673L) + ~((long)f3420 & 535673L) + 1L ^ 4607182420110254939L, 317139102743630955L)
         && w.a<"Û">(var2, 208532652696600212L) <= w.a<"B">((f3420 | 789452) + ~(f3420 & 789452) + 1 ^ 245138670, 349057757755238323L)) {
         return (boolean)((f3420 | 955789) + ~(f3420 & 955789) + 1 ^ 1310595758);
      }

      double var4 = (double)w.a<"Û">((Float)w.a<"Û">(this.f3388, 174312564406604366L), 149784643039979208L);
      return (boolean)((double)w.a<"Û">(this, 325184672166309076L) >= var4
         ? (f3420 | 42900) + ~(f3420 & 42900) + 1 ^ 1309681847
         : (f3420 | 753495) + ~(f3420 & 753495) + 1 ^ 1310453877);
   }

   public float m3440() {
      double var1 = C1074.f4550;
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f3391, 174312564406604366L), 354697271520518137L)) {
         var1 -= (double)(w.a<"B">((f3420 | 26302) + ~(f3420 & 26302) + 1 ^ 263252380, 349057757755238323L) - w.a<"Û">(C0933.f1416, 384249270720918251L));
      }

      return w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, (float)var1, 307875972928141599L
      );
   }

   public boolean m3441(class_1792 var1) {
      return (boolean)(!(var1 instanceof class_1829)
            && !(var1 instanceof class_1835)
            && !(var1 instanceof class_1743)
            && !(var1 instanceof class_9362)
            && (
               !(var1 instanceof class_1810)
                  || w.a<"B">(
                        (Predicate<class_1799>)var0 -> (boolean)(!(w.a<"Û">(var0, 222207108884875224L) instanceof class_1829)
                                 && !(w.a<"Û">(var0, 222207108884875224L) instanceof class_1743)
                              ? (f3420 | 872923) + ~(f3420 & 872923) + 1 ^ 1310580473
                              : (f3420 | 184964) + ~(f3420 & 184964) + 1 ^ 1309826471),
                        344867982687893969L
                     )
                     != ((f3420 | 920444) + ~(f3420 & 920444) + 1 ^ -1310622815)
            )
         ? (f3420 | 987976) + ~(f3420 & 987976) + 1 ^ 1310694506
         : (f3420 | 203325) + ~(f3420 & 203325) + 1 ^ 1309906206);
   }

   public void m3442() {
      if (w.a<"Û">(this, 369209844390321507L)
         && w.a<"Û">(this.f3401, 174312564406604366L) == C0312.f0219
         && this.f3415 != ((f3420 | 871618) + ~(f3420 & 871618) + 1 ^ -1310573537)) {
         w.a<"B">(this.f3415, 279757124141714355L);
         this.f3415 = (f3420 | 429023) + ~(f3420 & 429023) + 1 ^ -1310065918;
      }
   }

   public int m3443() {
      if (w.a<"Û">(this.f3401, 174312564406604366L) == C0312.f0220 && w.a<"Û">(this, 369209844390321507L)) {
         return (f3420 | 201975) + ~(f3420 & 201975) + 1 ^ -1309907926;
      } else {
         int var1 = w.a<"B">(
            (Predicate<class_1799>)var1x -> (boolean)(w.a<"Û">(var1x, class_1802.field_49814, 282470456889867724L)
                     && w.a<"Û">((C0311)w.a<"Û">(this.f3402, 174312564406604366L), var1x, 212590154118959804L)
                  ? (f3420 | 902318) + ~(f3420 & 902318) + 1 ^ 1310542733
                  : (f3420 | 290562) + ~(f3420 & 290562) + 1 ^ 1309990944),
            344867982687893969L
         );
         return w.a<"Û">(this.f3402, 174312564406604366L) == C0311.f2831
               && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6017
                  > w.a<"B">((f3420 | 46455) + ~(f3420 & 46455) + 1 ^ 240138837, 349057757755238323L)
               && var1 == ((f3420 | 723737) + ~(f3420 & 723737) + 1 ^ -1310426172)
            ? w.a<"B">((Predicate<class_1799>)var0 -> w.a<"Û">(var0, class_1802.field_49814, 282470456889867724L), 344867982687893969L)
            : var1;
      }
   }

   public boolean m3444(class_1297 var1) {
      float[] var2 = w.a<"B">(var1, 227058158510945889L);
      float var3 = w.a<"B">(
         var2[(f3420 | 318477) + ~(f3420 & 318477) + 1 ^ 1309954863],
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L),
         123679565561004181L
      );
      float var4 = w.a<"B">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 218194352988080011L)
            - var2[(f3420 | 597797) + ~(f3420 & 597797) + 1 ^ 1310298118],
         159606413758159910L
      );
      return (boolean)(var3 <= w.a<"Û">((Float)w.a<"Û">(this.f3387, 174312564406604366L), 149784643039979208L)
            && var4 <= w.a<"Û">((Float)w.a<"Û">(this.f3387, 174312564406604366L), 149784643039979208L)
         ? (f3420 | 536876) + ~(f3420 & 536876) + 1 ^ 1310244367
         : (f3420 | 605310) + ~(f3420 & 605310) + 1 ^ 1310307164);
   }

   public boolean m3445() {
      return (boolean)(w.a<"Û">(this.f3400, 174312564406604366L) == C0310.f1937
         ? (f3420 | 665177) + ~(f3420 & 665177) + 1 ^ 1310370170
         : (f3420 | 931577) + ~(f3420 & 931577) + 1 ^ 1310636507);
   }

   public static String BgOUpDiGmgVbgOiPdCzeZtceATmgFQNXyxtaGb4CFxhoNDLalYNPxqkRD75l8OuNqNuZIIUv3eJFJrm70TI8IxBdfeRZzPpyCon9(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
