package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0494 implements C0196 {
   f1863("Cancel"),
   f1864("Shift");

   public final String f1865;

   public C0494(String var3) {
      this.f1865 = var3;
   }

   @Override
   public String getName() {
      return this.f1865;
   }

   public static String o8gG4Srtx1nLtDVq8tQNMeSJ1vWirmF5c95lOWdKjWl3v0LGNsCjVQJonjtbkood7WMsRO6kmFDIz2ud736R4YxIuI7PsPzlEfGD(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
