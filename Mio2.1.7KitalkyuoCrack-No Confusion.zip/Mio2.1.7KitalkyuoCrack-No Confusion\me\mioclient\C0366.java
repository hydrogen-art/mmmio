package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import me.mioclient.mixin.ducks.DuckAbstractBlock;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2813;
import net.minecraft.class_3965;
import net.minecraft.class_5134;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2848.class_2849;

public class C0366 extends C1266 {
   public static C0303 f3237 = C0933.f1409.m2696(C0303.class);
   public final C0015<C0040> f3238;
   public final C0015<Set<class_2248>> f3239;
   public final C0015<C0383> f3240;
   public final C0015<Integer> f3241;
   public final C0015<Integer> f3242;
   public final C0015<Boolean> f3243;
   public final C0015<Boolean> f3244;
   public final C0015<Boolean> f3245;
   public final C0015<Boolean> f3246;
   public final C0015<Boolean> f3247;
   public final C0015<Boolean> f3248;
   public final C0015<Boolean> f3249;
   public final C0015<Boolean> f3250;
   public final C0015<Boolean> f3251;
   public final C0015<Float> f3252;
   public final C0015<Color> f3253;
   public final C0015<Color> f3254;
   public final C0015<Boolean> f3255;
   public final C0015<Float> f3256;
   public final C0083 f3257;
   public final C0083 f3258;
   public final C0083 f3259;
   public final C0083 f3260;
   public final C0083 f3261;
   public C0545 f3262;
   public float[] f3263;
   public int f3264;
   public int f3265;
   public double f3266;
   public float f3267;
   public static int f3268 = w.a<"B">(591952001857261039L, 257832362129977838L);

   public C0366() {
      super("Scaffold", "Speedbridges for you automatically.", C1045.f3176);
      w.a<"B">(this, 242859112966675773L);
      this.f3257 = new C0083();
      this.f3258 = new C0083();
      this.f3259 = new C0083();
      this.f3260 = new C0083();
      this.f3261 = new C0083();
      this.f3265 = (f3268 | 289674) + ~(f3268 & 289674) + 1 ^ 1756126760;
      this.f3267 = w.a<"B">((f3268 | 78303) + ~(f3268 & 78303) + 1 ^ 685177730, 349057757755238323L);
      w.a<"Û">(
         C0933.f1430,
         new C0122(
            this,
            this.f3253,
            this.f3254,
            this.f3252,
            this.f3256,
            () -> w.a<"B">((boolean)((f3268 | 42169) + ~(f3268 & 42169) + 1 ^ -1755877660), 320330632857389983L),
            this.f3255,
            (f3268 | 575136) + ~(f3268 & 575136) + 1 ^ -1755378369
         ),
         215636623669649177L
      );
   }

   @Override
   public void onToggle() {
      w.a<"Û">(this.f3257, 387780412884547639L);
      w.a<"Û">(this.f3258, 387780412884547639L);
      this.f3262 = null;
      this.f3263 = null;
      this.f3264 = (f3268 | 61293) + ~(f3268 & 61293) + 1 ^ -1755896528;
      this.f3265 = (f3268 | 626360) + ~(f3268 & 626360) + 1 ^ 1755429658;
   }

   @Override
   public void onEnable() {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         this.f3266 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L
         );
      }
   }

   @C1027
   public void m1342(C0153 var1) {
      if (this.f3267 > 0.0F) {
         w.a<"Û">(this, this.f3267, 212716907172098013L);
         this.f3267 = w.a<"B">((f3268 | 745704) + ~(f3268 & 745704) + 1 ^ 685550261, 349057757755238323L);
      }

      if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 134119629880483189L)) {
         if (w.a<"Û">(this.f3260, ((long)f3268 | 449250L) + ~((long)f3268 & 449250L) + 1L ^ -1756295027L, 309642602085515378L)
            || !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)
            || !w.a<"Û">((Boolean)w.a<"Û">(f3237.f2502, 174312564406604366L), 354697271520518137L)) {
            if (!w.a<"B">(239474890139367192L)
               || m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_5976) {
               this.f3266 = w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L
               );
            }

            w.a<"Û">(this, 147894258766926349L);
            this.f3262 = w.a<"Û">(this, 112911084153323047L);
            int var2 = this.f3265 != ((f3268 | 359933) + ~(f3268 & 359933) + 1 ^ 1756186719)
                  && !w.a<"Û">(
                     w.a<"Û">(
                        w.a<"Û">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
                        ),
                        this.f3265,
                        386860178278302175L
                     ),
                     330190014994709712L
                  )
               ? (f3268 | 607415) + ~(f3268 & 607415) + 1 ^ -1755410710
               : (f3268 | 403048) + ~(f3268 & 403048) + 1 ^ -1756238796;
            if (w.a<"Û">(this.f3240, 174312564406604366L) == C0383.f4383
               && w.a<"Û">(
                     this,
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L
                     ),
                     157355693488054101L
                  )
                  == 0) {
               var2 = (f3268 | 462572) + ~(f3268 & 462572) + 1 ^ -1756314448;
            }

            if (var2 != 0) {
               this.f3262 = null;
            } else {
               w.a<"Û">(this, this.f3262, 226396922898542503L);
               if (!w.a<"B">(326994201598620857L) && this.f3262 != null) {
                  w.a<"Û">(this, w.a<"Û">(this, C0025.f3814, 229716136645307662L), 199114498866914686L);
               }

               if (this.f3263 != null) {
                  w.a<"Û">(C0933.f1412, this.f3263, (f3268 | 740649) + ~(f3268 & 740649) + 1 ^ -1755543695, 236731835237641613L);
               }

               if (w.a<"Û">(this.f3258, ((long)f3268 | 231710L) + ~((long)f3268 & 231710L) + 1L ^ -1756085577L, 309642602085515378L)
                  || w.a<"B">(171090672375251307L)) {
                  this.f3263 = null;
               }

               w.a<"Û">(this, 361692562758274142L);
               if (this.f3262 != null
                  && w.a<"Û">(this.f3259, (long)w.a<"Û">((Integer)w.a<"Û">(this.f3241, 174312564406604366L), 260981171345819427L), 309642602085515378L)) {
                  if (!w.a<"Û">(this, w.a<"Û">(this.f3262, 237456811241023827L), this.f3265, 366391463637340388L)) {
                     return;
                  }

                  w.a<"Û">(
                     (C0383)w.a<"Û">(this.f3240, 174312564406604366L),
                     this.f3265,
                     (Runnable)() -> {
                        if (w.a<"Û">((Boolean)w.a<"Û">(this.f3251, 174312564406604366L), 354697271520518137L)) {
                           w.a<"Û">(C0933.f1430, this, w.a<"Û">(this.f3262, 237456811241023827L), 283167244224626822L);
                        }

                        C1282 var1x = w.a<"B">(this.f3262, (boolean)((f3268 | 449720) + ~(f3268 & 449720) + 1 ^ -1756293404), 140213278516212981L);
                        class_243 var2x = w.a<"Û">(var1x, 288099495399349948L);
                        if (w.a<"Û">(var1x, 167356443507828609L) == class_2350.field_11033) {
                           var2x = w.a<"Û">(
                              var2x,
                              class_2351.field_11052,
                              (double)w.a<"Û">(w.a<"Û">(this.f3262, 237456811241023827L), 171752333823210875L),
                              156744506625070247L
                           );
                        } else {
                           double var10002;
                           if (w.a<"Û">(w.a<"Û">(var1x, 112014855873244199L), 125999939138686596L)) {
                              var10002 = C1074.f4550;
                           } else {
                              long var10003 = (long)f3268 | 350321L;
                              var10002 = w.a<"Û">(w.a<"Û">(var1x, 112014855873244199L), 153037909352617834L).field_1325
                                 - w.a<"B">(var10003 + ~((long)f3268 & 350321L) + 1L ^ -4576918228890253737L, 317139102743630955L);
                           }

                           var2x = w.a<"Û">(var2x, 0.0, var10002, 0.0, 215037093685651073L);
                        }

                        boolean var3 = w.a<"Û">(C0933.f1416, 380957205957342880L);
                        w.a<"B">(
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                           class_2849.field_12979,
                           (f3268 | 154315) + ~(f3268 & 154315) + 1 ^ -1756000106,
                           157595208248618445L
                        );
                        w.a<"B">(
                           w.a<"Û">(this.f3262, 237456811241023827L),
                           var2x,
                           w.a<"Û">(var1x, 167356443507828609L),
                           w.a<"Û">((Boolean)w.a<"Û">(this.f3245, 174312564406604366L), 354697271520518137L),
                           class_1268.field_5808,
                           342747827846445618L
                        );
                        if (!var3) {
                           w.a<"B">(
                              m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                              class_2849.field_12984,
                              (f3268 | 43874) + ~(f3268 & 43874) + 1 ^ -1755881153,
                              157595208248618445L
                           );
                        }

                        if (w.a<"B">(326994201598620857L)) {
                           w.a<"Û">(this, w.a<"Û">(this, w.a<"Û">(C0025.f3815, var1x, var2x, 180469386549942388L), 229716136645307662L), 199114498866914686L);
                        }

                        w.a<"Û">(this.f3259, 387780412884547639L);
                        w.a<"Û">(this.f3258, 387780412884547639L);
                        w.a<"Û">(this.f3257, 387780412884547639L);
                     },
                     126799636931199059L
                  );
               }

               if (w.a<"Û">(this.f3257, ((long)f3268 | 686543L) + ~((long)f3268 & 686543L) + 1L ^ -1755467004L, 309642602085515378L)) {
                  w.a<"Û">(this.f3257, 387780412884547639L);
                  this.f3262 = null;
               }
            }
         }
      }
   }

   @C1027
   public void m1343(C0618 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f3244, 174312564406604366L), 354697271520518137L)
         && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 134119629880483189L)) {
         w.a<"Û">(var1, 385440235371820560L);
      }
   }

   @C1027
   public void m1344(C0650 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f3244, 174312564406604366L), 354697271520518137L)
         && w.a<"B">(171090672375251307L)
         && w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)
         && !w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 134119629880483189L)) {
         class_238 var2 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L),
            w.a<"Û">(var1, 211665782282761067L),
            0.0,
            w.a<"Û">(var1, 149300137507612725L),
            240768051853680291L
         );
         boolean var3 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 341620216578473814L
         );
         if (w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
            w.a<"Û">(var2, 0.0, w.a<"B">(-4616189618054758400L, 317139102743630955L), 0.0, 244681124810902308L),
            116811053208981688L
         )) {
            if (!var3) {
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  (boolean)((f3268 | 907305) + ~(f3268 & 907305) + 1 ^ -1755704715),
                  338213165866007469L
               );
            }

            w.a<"Û">(var1, 0.0, 0.0, 341834528303342411L);
         } else if (!var3) {
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               (boolean)((f3268 | 728568) + ~(f3268 & 728568) + 1 ^ -1755523163),
               338213165866007469L
            );
         }
      }
   }

   @C1027
   public void m1345(C0132 var1) {
      if (!w.a<"Û">(var1, 228050418011231981L)) {
         if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2813) {
            w.a<"Û">(this.f3260, 387780412884547639L);
         }
      }
   }

   public void m1346() {
      int var1 = (int)w.a<"B">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L),
         143282796194555966L
      );
      if (this.f3264 != var1 || w.a<"B">(171090672375251307L)) {
         this.f3264 = var1;
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f3243, 174312564406604366L), 354697271520518137L)
            && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913.field_3904
            && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6250 == 0.0F
            && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_6212 == 0.0F) {
            if (w.a<"B">(171090672375251307L)) {
               if (w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L
               )) {
                  this.f3267 = w.a<"Û">(this, 188455788407007460L);
                  w.a<"Û">(this, w.a<"B">((f3268 | 914104) + ~(f3268 & 914104) + 1 ^ -1444527252, 349057757755238323L), 212716907172098013L);
               }
            } else if (this.f3262 != null) {
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
                  0.0,
                  w.a<"B">(((long)f3268 | 511749L) + ~((long)f3268 & 511749L) + 1L ^ -4601237667738286727L, 317139102743630955L),
                  0.0,
                  211344564396137847L
               );
            }
         }
      }
   }

   public void m1347(C0545 var1) {
      if (var1 != null) {
         if (w.a<"Û">((Boolean)w.a<"Û">(this.f3250, 174312564406604366L), 354697271520518137L)
            && w.a<"Û">(this.f3261, (long)w.a<"Û">(C0933.f1437, 171300772395263258L), 309642602085515378L)) {
            class_1297 var2 = w.a<"B">(w.a<"Û">(var1, 237456811241023827L), w.a<"Û">(C0933.f1437, 260832460033760053L), 259879800301833065L);
            if (var2 != null) {
               float[] var3 = w.a<"B">(var2, 227058158510945889L);
               w.a<"Û">(this, var3, 199114498866914686L);
               w.a<"Û">(this.f3261, 387780412884547639L);
            }
         }
      }
   }

   public void m1348(float[] var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f3248, 174312564406604366L), 354697271520518137L)) {
         if (w.a<"B">(326994201598620857L)) {
            w.a<"Û">(C0933.f1412, var1, (f3268 | 647889) + ~(f3268 & 647889) + 1 ^ -1755436922, 382136293665917794L);
            w.a<"B">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L),
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L),
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L),
               var1[(f3268 | 813132) + ~(f3268 & 813132) + 1 ^ -1755602415],
               var1[(f3268 | 952297) + ~(f3268 & 952297) + 1 ^ -1755755083],
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L),
               109075415780320931L
            );
         } else {
            this.f3263 = var1;
         }
      }
   }

   public void m1349() {
      if (w.a<"Û">(
            this,
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 229019767109027877L),
            157355693488054101L
         )
         > 0) {
         this.f3265 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
            )
            .field_7545;
      } else {
         int var1 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
            )
            .field_7545;
         int var2 = w.a<"Û">(
            this,
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
               var1,
               386860178278302175L
            ),
            157355693488054101L
         );

         for (int var3 = (f3268 | 391817) + ~(f3268 & 391817) + 1 ^ -1756221228; var3 < ((f3268 | 480564) + ~(f3268 & 480564) + 1 ^ -1756324000); var3++) {
            int var4 = w.a<"Û">(
               this,
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
                  var3,
                  386860178278302175L
               ),
               157355693488054101L
            );
            if (var4 > var2) {
               var1 = var3;
               var2 = var4;
            }
         }

         if (var2 == 0) {
            this.f3265 = (f3268 | 907186) + ~(f3268 & 907186) + 1 ^ 1755701776;
         } else {
            this.f3265 = var1;
         }
      }
   }

   public int m1350(class_1799 var1) {
      if (w.a<"Û">(var1, 222207108884875224L) instanceof class_1747 var2
         && w.a<"Û">(
            (C0040)w.a<"Û">(this.f3238, 174312564406604366L),
            w.a<"Û">(var2, 339813793232936443L),
            (Collection)w.a<"Û">(this.f3239, 174312564406604366L),
            257405975721056342L
         )
         && ((DuckAbstractBlock)w.a<"Û">(var2, 339813793232936443L)).isCollidable()
         && w.a<"Û">(this, var2, 296543727934434172L)) {
         return w.a<"B">(
               w.a<"Û">(
                  w.a<"Û">(w.a<"Û">(var2, 339813793232936443L), 371018036170469473L),
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  class_2338.field_10980,
                  127692959363775057L
               ),
               356347219109562032L
            )
            ? (f3268 | 829258) + ~(f3268 & 829258) + 1 ^ -1755615979
            : (f3268 | 428397) + ~(f3268 & 428397) + 1 ^ -1756282063;
      }

      return (f3268 | 11100) + ~(f3268 & 11100) + 1 ^ -1755848447;
   }

   public boolean m1351(class_1747 var1) {
      int var2 = w.a<"B">(274098019152472497L);
      return (boolean)(w.a<"Û">(var1, 339813793232936443L) instanceof class_2346 && var2 > ((f3268 | 210091) + ~(f3268 & 210091) + 1 ^ -1756037385)
         ? (f3268 | 666834) + ~(f3268 & 666834) + 1 ^ -1755453809
         : (f3268 | 361641) + ~(f3268 & 361641) + 1 ^ -1756213515);
   }

   public float[] m1352(C0025 var1) {
      if (var1 == C0025.f3814) {
         C1282 var2 = w.a<"B">(this.f3262, (boolean)((f3268 | 340548) + ~(f3268 & 340548) + 1 ^ -1756170215), 140213278516212981L);
         class_243 var6 = w.a<"Û">(var2, 288099495399349948L);
         double var7;
         if (w.a<"Û">(w.a<"Û">(var2, 112014855873244199L), 125999939138686596L)) {
            var7 = C1074.f4550;
         } else {
            long var8 = (long)f3268 | 125998L;
            var7 = w.a<"Û">(w.a<"Û">(var2, 112014855873244199L), 153037909352617834L).field_1325
               - w.a<"B">(var8 + ~((long)f3268 & 125998L) + 1L ^ -4576918228890537464L, 317139102743630955L);
         }

         float[] var3 = w.a<"B">(w.a<"Û">(var6, 0.0, var7, 0.0, 215037093685651073L), 213766782372904553L);
         if (w.a<"B">(239474890139367192L)) {
            double[] var4 = w.a<"B">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L),
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913,
               w.a<"B">(((long)f3268 | 859379L) + ~((long)f3268 & 859379L) + 1L ^ -4607182420555671890L, 317139102743630955L),
               108620803423508722L
            );
            float var5 = (float)(
               w.a<"B">(
                     w.a<"B">(
                        var4[(f3268 | 328586) + ~(f3268 & 328586) + 1 ^ -1756182058],
                        var4[(f3268 | 138806) + ~(f3268 & 138806) + 1 ^ -1755982741],
                        370151239157781531L
                     ),
                     207871222047649314L
                  )
                  - w.a<"B">(((long)f3268 | 801543L) + ~((long)f3268 & 801543L) + 1L ^ -4643457508179185318L, 317139102743630955L)
            );
            if (w.a<"B">(var5, var3[(f3268 | 999630) + ~(f3268 & 999630) + 1 ^ -1755805037], 123679565561004181L)
               < w.a<"B">((f3268 | 814157) + ~(f3268 & 814157) + 1 ^ -718559728, 349057757755238323L)) {
               var3[(f3268 | 769089) + ~(f3268 & 769089) + 1 ^ -1755548132] = var5;
            }
         }

         w.a<"Û">(this.f3258, 387780412884547639L);
         return var3;
      } else {
         class_243 var10000 = var1.f3817;
         double var10002;
         if (w.a<"Û">(w.a<"Û">(var1.f3816, 112014855873244199L), 125999939138686596L)) {
            var10002 = C1074.f4550;
         } else {
            long var10003 = (long)f3268 | 165650L;
            var10002 = w.a<"Û">(w.a<"Û">(var1.f3816, 112014855873244199L), 153037909352617834L).field_1325
               - w.a<"B">(var10003 + ~((long)f3268 & 165650L) + 1L ^ -4576918228890330828L, 317139102743630955L);
         }

         return w.a<"B">(w.a<"Û">(var10000, 0.0, var10002, 0.0, 215037093685651073L), 213766782372904553L);
      }
   }

   public C0545 m1353() {
      class_2338 var1 = null;
      class_243 var2 = w.a<"B">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L),
         351265736671775343L
      );
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f3247, 174312564406604366L), 354697271520518137L)) {
         var2 = w.a<"Û">(var2, class_2351.field_11052, this.f3266, 156744506625070247L);
      }

      boolean var3 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 179114946195012748L
         )
         ? w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 312103791313807134L).field_36331
         : m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_36331;
      if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 179114946195012748L)) {
         var2 = w.a<"B">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 312103791313807134L),
               225708705569795011L
            ),
            351265736671775343L
         );
      }

      double var4 = w.a<"Û">(this, (float)w.a<"Û">(var2, 292829928904272542L), 118880383050025545L);

      for (int var6 = (f3268 | 406998) + ~(f3268 & 406998) + 1 ^ -1756233845;
         var6 < w.a<"Û">((Integer)w.a<"Û">(this.f3242, 174312564406604366L), 260981171345819427L) + ((f3268 | 468754) + ~(f3268 & 468754) + 1 ^ -1756304050)
            && (
               w.a<"B">(239474890139367192L)
                     && w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L
                     )
                  || var6 <= 0
            );
         var6++
      ) {
         var1 = w.a<"Û">(
            w.a<"B">(w.a<"Û">(var2, class_2351.field_11052, var4, 156744506625070247L), 274163478939689086L),
            w.a<"B">(371504870337745156L),
            var6,
            216997267188579272L
         );
         if (!var3
            && !w.a<"Û">((Boolean)w.a<"Û">(this.f3247, 174312564406604366L), 354697271520518137L)
            && !w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var1, 310987074049434965L
               ),
               289106033197017315L
            )) {
            var1 = w.a<"Û">(var1, 286357605983762592L);
         }

         if (w.a<"Û">(this, var1, this.f3265, 366391463637340388L)) {
            break;
         }

         var1 = null;
      }

      if (var1 == null) {
         return null;
      } else {
         class_2350 var12 = w.a<"B">(var1, w.a<"Û">((Boolean)w.a<"Û">(this.f3246, 174312564406604366L), 354697271520518137L), 310756169772890262L);
         if (var12 != null) {
            return new C0545(var1, var12);
         } else {
            for (int var7 = (f3268 | 486494) + ~(f3268 & 486494) + 1 ^ -1756322302; var7 < ((f3268 | 87795) + ~(f3268 & 87795) + 1 ^ -1755931475); var7++) {
               class_2350[] var8 = w.a<"B">(179161450352945543L);
               int var9 = var8.length;

               for (int var10 = (f3268 | 421744) + ~(f3268 & 421744) + 1 ^ -1756256979; var10 < var9; var10++) {
                  class_2350 var11 = var8[var10];
                  if (var11 != class_2350.field_11036) {
                     var12 = w.a<"B">(
                        w.a<"Û">(var1, var11, var7, 216997267188579272L),
                        w.a<"Û">((Boolean)w.a<"Û">(this.f3246, 174312564406604366L), 354697271520518137L),
                        310756169772890262L
                     );
                     if (var12 != null) {
                        return new C0545(w.a<"Û">(var1, var11, 361576458954219689L), var12);
                     }
                  }
               }
            }

            return null;
         }
      }
   }

   public double m1354(float var1) {
      class_238 var2 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L
      );
      boolean var3 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L
      );
      if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 179114946195012748L)) {
         var2 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 312103791313807134L),
            225708705569795011L
         );
         var3 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 312103791313807134L),
            365938579659973637L
         );
      }

      double var4 = var2.field_1323;
      double var6 = var2.field_1321;
      double var8 = var2.field_1320;
      double var10 = var2.field_1324;
      ArrayList var12 = new ArrayList();
      w.a<"Û">(var12, w.a<"Û">(w.a<"B">(var2, 351265736671775343L), class_2351.field_11052, (double)var1, 156744506625070247L), 276802003864609490L);
      if (var3) {
         w.a<"Û">(
            var12,
            w.a<"B">(
               new class_243(var4, (double)var1, var6),
               new class_243(var8, (double)var1, var6),
               new class_243(var4, (double)var1, var10),
               new class_243(var8, (double)var1, var10),
               319034520487861803L
            ),
            271623032661790232L
         );
      }

      double var13 = w.a<"B">(-4571373524106608640L, 317139102743630955L);
      Iterator var15 = w.a<"Û">(var12, 341496865259068134L);

      while (w.a<"Û">(var15, 333900474771661065L)) {
         class_243 var16 = (class_243)w.a<"Û">(var15, 192468336863492695L);
         C0884 var17 = w.a<"Û">(
            w.a<"Û">(
               new C0885(var16, w.a<"Û">(var16, 0.0, w.a<"B">(-4616189618054758400L, 317139102743630955L), 0.0, 215037093685651073L)),
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 179114946195012748L)
                  ? w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 312103791313807134L
                  )
                  : m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               287508913512678813L
            ),
            227384346927815494L
         );
         class_3965 var18 = w.a<"B">(var17, 284997627127993255L);
         double var19 = w.a<"Û">(var18, 189274766630417875L) == class_240.field_1333
            ? w.a<"Û">(var16, 292829928904272542L)
               - w.a<"B">(((long)f3268 | 651021L) + ~((long)f3268 & 651021L) + 1L ^ -4607182420555455152L, 317139102743630955L)
            : w.a<"Û">(w.a<"Û">(var18, 378186176745654896L), 292829928904272542L)
               - w.a<"B">(((long)f3268 | 137456L) + ~((long)f3268 & 137456L) + 1L ^ -4576918228783738195L, 317139102743630955L);
         var13 = w.a<"B">(var13, var19, 354112003008534934L);
      }

      return var13;
   }

   public boolean m1355(class_2338 var1, int var2) {
      class_1799 var3 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L),
         var2 == ((f3268 | 44230) + ~(f3268 & 44230) + 1 ^ 1755879780)
            ? w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545
            : var2,
         386860178278302175L
      );
      return w.a<"Û">(var3, 222207108884875224L) instanceof class_1747 var4
         ? w.a<"B">(
            var1,
            w.a<"Û">(var4, 339813793232936443L),
            (boolean)((f3268 | 956105) + ~(f3268 & 956105) + 1 ^ -1755751275),
            w.a<"Û">((Boolean)w.a<"Û">(this.f3250, 174312564406604366L), 354697271520518137L),
            138195683728284013L
         )
         : w.a<"B">(
            var1,
            (boolean)((f3268 | 96960) + ~(f3268 & 96960) + 1 ^ -1755926372),
            w.a<"Û">((Boolean)w.a<"Û">(this.f3250, 174312564406604366L), 354697271520518137L),
            295003381032774252L
         );
   }

   public float m1356() {
      return (float)w.a<"Û">(
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_5134.field_23728,
            362921755500736432L
         ),
         282216017406627031L
      );
   }

   public void m1357(float var1) {
      w.a<"Û">(
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_5134.field_23728,
            362921755500736432L
         ),
         (double)var1,
         159793083125634076L
      );
   }

   public static String q4pqi9cmuRAin6FUVEmcksFNSzIuBg7lg2pAzxE4h41lSMEzGhs4UiTNWi3f9yP9GIp9WzU4j75lzXB0Vlbr2EWVgWy59K7q2bcE(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
