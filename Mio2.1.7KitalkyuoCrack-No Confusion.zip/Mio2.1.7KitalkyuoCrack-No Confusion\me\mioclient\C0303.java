package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2645;
import net.minecraft.class_2846;
import net.minecraft.class_465;
import net.minecraft.class_2846.class_2847;

public class C0303 extends C0232 {
   public static final C0551 velocity = C0933.f1409.m2696(C0551.class);
   public static final float f2499 = (float)(
      w.a<"B">(
               w.a<"B">(((long)C0303.f2508 | 609657L) + ~((long)C0303.f2508 & 609657L) + 1L ^ 4596373781105706125L, 317139102743630955L),
               w.a<"B">(((long)C0303.f2508 | 78893L) + ~((long)C0303.f2508 & 78893L) + 1L ^ 4613937819544583641L, 317139102743630955L),
               293138351106450517L
            )
            * w.a<"B">(((long)C0303.f2508 | 711481L) + ~((long)C0303.f2508 & 711481L) + 1L ^ 4620693218986169037L, 317139102743630955L)
            * w.a<"B">(((long)C0303.f2508 | 388374L) + ~((long)C0303.f2508 & 388374L) + 1L ^ 4594572341107103697L, 317139102743630955L)
         - w.a<"B">(((long)C0303.f2508 | 893186L) + ~((long)C0303.f2508 & 893186L) + 1L ^ 4562254508050923786L, 317139102743630955L)
   );
   public final C0015<Boolean> f2500;
   public final C0015<Float> f2501;
   public final C0015<Boolean> f2502;
   public final C0015<C1349> f2503;
   public final C0015<C0444> f2504;
   public final C1019 f2505;
   public boolean f2506;
   public boolean f2507;
   public static int f2508 = w.a<"B">(6567374652715921686L, 257832362129977838L);

   public C0303() {
      super("AntiCheat", "Manages the client's behavior on different anti-cheats.", C1045.f3178);
      w.a<"B">(this, 242859112966675773L);
      this.f2505 = new C1019(this);
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   @C1027
   public void m0976(C0591 var1) {
      w.a<"Û">(this.f2505, (boolean)((f2508 | 785560) + ~(f2508 & 785560) + 1 ^ 1304114540), 317664912905293143L);
   }

   @C1027
   public void m0977(C1095 var1) {
      this.f2507 = (boolean)(w.a<"Û">(var1, 336212328865671254L) == C0277.f4214
         ? (f2508 | 494390) + ~(f2508 & 494390) + 1 ^ 1303855811
         : (f2508 | 933646) + ~(f2508 & 933646) + 1 ^ 1304360698);
      if (w.a<"Û">(var1, 336212328865671254L) == C0277.f4214 && w.a<"Û">((Boolean)w.a<"Û">(this.f2502, 174312564406604366L), 354697271520518137L)) {
         if (w.a<"Û">(this, 317419592226466359L)
            && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 instanceof class_465
            && !w.a<"Û">(this.f2505, 289072432747109763L)) {
            return;
         }

         if (w.a<"B">(121594624341608201L)) {
            return;
         }

         if (w.a<"Û">(velocity, 314537768572362865L) && w.a<"Û">(velocity, 219957562990897698L) instanceof C1217 var2 && w.a<"Û">(var2, 251404721893373853L)) {
            return;
         }

         float var4 = f2499
            * w.a<"B">((f2508 | 710881) + ~(f2508 & 710881) + 1 ^ 230297877, 349057757755238323L)
            * (float)(this.f2506 ? (f2508 | 158632) + ~(f2508 & 158632) + 1 ^ -1303552605 : (f2508 | 968046) + ~(f2508 & 968046) + 1 ^ 1304300699);
         this.f2506 = (boolean)(!this.f2506 ? (f2508 | 206994) + ~(f2508 & 206994) + 1 ^ 1303634279 : (f2508 | 342407) + ~(f2508 & 342407) + 1 ^ 1303769203);
         w.a<"Û">(
            var1, w.a<"B">(w.a<"Û">(var1, 369040957432539465L) + var4, (float)(-C1074.f4547), (float)C1074.f4547, 131506059371757968L), 140051362125175423L
         );
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = 999
   )
   public void m0978(C0132 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2846 var2
         && w.a<"Û">(this, 317419592226466359L)
         && w.a<"Û">(var2, 330938709892691986L) == class_2847.field_12968) {
         w.a<"B">(class_2847.field_12973, w.a<"Û">(var2, 285359998060394220L), w.a<"Û">(var2, 373003849294135548L), 282456429933142666L);
      }
   }

   @C1027
   public void m0979(C0133 var1) {
      if (w.a<"Û">(this, 317419592226466359L)) {
         if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2645 var2 && w.a<"Û">(var2, 328918175624615165L) == 0) {
            w.a<"Û">(var1, 385440235371820560L);
         }
      }
   }

   public float m0980() {
      return w.a<"Û">((Float)w.a<"Û">(this.f2501, 174312564406604366L), 149784643039979208L);
   }

   public boolean m0981() {
      return w.a<"Û">((Boolean)w.a<"Û">(this.f2500, 174312564406604366L), 354697271520518137L);
   }

   public C1019 m0982() {
      return this.f2505;
   }

   public static String yvjLftDJJy5evocgkRFVKvVLZnkch8oKHMO5It1RxQcZeXtX5kAGdesZsucb04TxdThit1xM2gAzcRtvdsjVdVcnre3xQizWucrN(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
