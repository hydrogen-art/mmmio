package me.mioclient;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_276;
import net.minecraft.class_310;
import org.lwjgl.opengl.GL30;

public class C0439 extends class_276 {
   public static final int f0417 = 2;
   public static final int f0418 = GL30.glGetInteger(36183);
   public static final Map<Integer, C0439> f0419 = new HashMap<>();
   public static final List<C0439> f0420 = new ArrayList<>();
   public final int f0421;
   public int f0422;
   public int f0423;
   public boolean f0424;

   public C0439(int var1) {
      super(true);
      int var2 = Math.clamp((long)var1, 2, f0418);
      if ((var2 & var2 - 1) != 0) {
         throw new IllegalArgumentException(String.valueOf(var2));
      } else {
         this.f0421 = var2;
         this.method_1236(1.0F, 1.0F, 1.0F, 0.0F);
      }
   }

   public static boolean m2280() {
      return !f0420.isEmpty();
   }

   public static C0439 m2281(int var0) {
      return f0419.computeIfAbsent(var0, var1 -> new C0439(var0));
   }

   public static void m2282(int var0, Runnable var1) {
      m2283(var0, class_310.method_1551().method_1522(), var1);
   }

   public static void m2283(int var0, class_276 var1, Runnable var2) {
      RenderSystem.assertOnRenderThreadOrInit();
      C0439 var3 = m2281(var0);
      var3.method_1234(var1.field_1482, var1.field_1481, true);
      GlStateManager._glBindFramebuffer(36008, var1.field_1476);
      GlStateManager._glBindFramebuffer(36009, var3.field_1476);
      GlStateManager._glBlitFrameBuffer(0, 0, var3.field_1482, var3.field_1481, 0, 0, var3.field_1482, var3.field_1481, 16384, 9729);
      var3.method_1235(true);
      var2.run();
      var3.method_1240();
      GlStateManager._glBindFramebuffer(36008, var3.field_1476);
      GlStateManager._glBindFramebuffer(36009, var1.field_1476);
      GlStateManager._glBlitFrameBuffer(0, 0, var3.field_1482, var3.field_1481, 0, 0, var3.field_1482, var3.field_1481, 16384, 9729);
      var3.method_1230(true);
      var1.method_1235(false);
   }

   public void method_1234(int var1, int var2, boolean var3) {
      if (this.field_1482 != var1 || this.field_1481 != var2) {
         super.method_1234(var1, var2, var3);
      }
   }

   public void method_1231(int var1, int var2, boolean var3) {
      RenderSystem.assertOnRenderThreadOrInit();
      int var4 = RenderSystem.maxSupportedTextureSize();
      if (var1 > 0 && var1 <= var4 && var2 > 0 && var2 <= var4) {
         this.field_1480 = var1;
         this.field_1477 = var2;
         this.field_1482 = var1;
         this.field_1481 = var2;
         this.field_1476 = GlStateManager.glGenFramebuffers();
         GlStateManager._glBindFramebuffer(36160, this.field_1476);
         this.f0422 = GlStateManager.glGenRenderbuffers();
         GlStateManager._glBindRenderbuffer(36161, this.f0422);
         GL30.glRenderbufferStorageMultisample(36161, this.f0421, 32856, var1, var2);
         GlStateManager._glBindRenderbuffer(36161, 0);
         this.f0423 = GlStateManager.glGenRenderbuffers();
         GlStateManager._glBindRenderbuffer(36161, this.f0423);
         GL30.glRenderbufferStorageMultisample(36161, this.f0421, 6402, var1, var2);
         GlStateManager._glBindRenderbuffer(36161, 0);
         GL30.glFramebufferRenderbuffer(36160, 36064, 36161, this.f0422);
         GL30.glFramebufferRenderbuffer(36160, 36096, 36161, this.f0423);
         this.field_1475 = class_310.method_1551().method_1522().method_30277();
         this.field_1474 = class_310.method_1551().method_1522().method_30278();
         this.method_1239();
         this.method_1230(var3);
         this.method_1242();
      } else {
         throw new IllegalArgumentException("%d x %d (Out of bounds).".formatted(var1, var2));
      }
   }

   public void method_1238() {
      RenderSystem.assertOnRenderThreadOrInit();
      this.method_1242();
      this.method_1240();
      if (this.field_1476 > -1) {
         GlStateManager._glBindFramebuffer(36160, 0);
         GlStateManager._glDeleteFramebuffers(this.field_1476);
         this.field_1476 = -1;
      }

      if (this.f0422 > -1) {
         GlStateManager._glDeleteRenderbuffers(this.f0422);
         this.f0422 = -1;
      }

      if (this.f0423 > -1) {
         GlStateManager._glDeleteRenderbuffers(this.f0423);
         this.f0423 = -1;
      }

      this.field_1475 = -1;
      this.field_1474 = -1;
      this.field_1482 = -1;
      this.field_1481 = -1;
   }

   public void method_1235(boolean var1) {
      super.method_1235(var1);
      if (!this.f0424) {
         f0420.add(this);
         this.f0424 = true;
      }
   }

   public void method_1240() {
      super.method_1240();
      if (this.f0424) {
         this.f0424 = false;
         f0420.remove(this);
      }
   }

   public static String r4H549ixpdqDL0VXaujviiOtAS4JKfs6PEUYiIHPDHgIOpatThvxo4OJwlWtA4WuMqB3o4uk0AUMPLY2xOkZFOe5k6XJGN7sNP7Y(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
