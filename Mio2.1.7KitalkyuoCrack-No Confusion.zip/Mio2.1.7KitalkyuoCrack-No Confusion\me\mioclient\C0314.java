package me.mioclient;

public abstract sealed class C0314 extends C1180 permits C0315, C0316 {
}
