package me.mioclient;

import java.awt.Color;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_4587;

public interface C0386 extends C0045 {
   C0818 f0268 = C0933.f1409.m2696(C0818.class);
   Color f0269 = new Color(0, 0, 0, 0);

   default void m2226(C0304 var1, class_1297 var2, class_4587 var3) {
      Color[] var4 = w.a<"Û">(this, var1, 114633939362447540L);
      if (w.a<"Û">((Boolean)w.a<"Û">(var1.f2577, 174312564406604366L), 354697271520518137L)) {
         float var5 = w.a<"Û">(var1, var2, 289880824373668596L);
         var4 = new Color[]{
            C0152.m3473(var4[0], (int)(var5 * (float)w.a<"Û">(var4[0], 245270953955453918L))),
            C0152.m3473(var4[1], (int)(var5 * (float)w.a<"Û">(var4[1], 245270953955453918L)))
         };
      }

      C0297.m2453(var4[0], var4[1]);
      if (w.a<"Û">((Boolean)w.a<"Û">(var1.f2602, 174312564406604366L), 354697271520518137L) && var2 instanceof class_1657 var6) {
         if (w.a<"Û">(C0933.f1417, var6, 241036547861815495L)) {
            w.a<"Û">(this, var1, var4, (Color)w.a<"Û">(f0268.f5252, 174312564406604366L), 285183199389426338L);
         }

         if (w.a<"Û">(C0933.f1417, var6, 331571300069254198L)) {
            w.a<"Û">(this, var1, var4, (Color)w.a<"Û">(f0268.f5253, 174312564406604366L), 285183199389426338L);
         }
      }

      C0297.m2454(w.a<"Û">((Boolean)w.a<"Û">(var1.f2580, 174312564406604366L), 354697271520518137L));
      if (var2 instanceof class_1657 var7 && w.a<"Û">(var1, 269488381686658669L)) {
         var7.field_42108.field_42111 = 0.0F;
         var7.field_42108.field_42110 = 0.0F;
         var7.field_42108.field_42109 = 0.0F;
      }

      C0297.m2456(var3, var2);
   }

   default void m2227(C0304 var1, Color[] var2, Color var3) {
      C0297.m2453(C0152.m3473(var3, w.a<"Û">(var2[0], 245270953955453918L)), C0152.m3473(var3, w.a<"Û">(var2[1], 245270953955453918L)));
   }

   default Color[] m2228(C0304 var1) {
      return new Color[]{(Color)w.a<"Û">(var1.f2604, 174312564406604366L), (Color)w.a<"Û">(var1.f2603, 174312564406604366L)};
   }

   default boolean m2229() {
      return false;
   }
}
