package me.mioclient;

import java.util.Iterator;
import java.util.List;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_1893;

public final class C0400 {
   public static final List<C0402> f4207 = w.a<"B">(
      new C0402(class_1893.field_9111, (C0400.f4213 | 758412) + ~(C0400.f4213 & 758412) + 1 ^ 511045538),
      new C0402(class_1893.field_9119, (C0400.f4213 | 551959) + ~(C0400.f4213 & 551959) + 1 ^ 511054142),
      new C0402(class_1893.field_9101, (C0400.f4213 | 450845) + ~(C0400.f4213 & 450845) + 1 ^ 511220790),
      187679336490942256L
   );
   public static final List<C0402> f4208 = w.a<"B">(
      new C0402(class_1893.field_9111, (C0400.f4213 | 797753) + ~(C0400.f4213 & 797753) + 1 ^ 510808343),
      new C0402(class_1893.field_9119, (C0400.f4213 | 642394) + ~(C0400.f4213 & 642394) + 1 ^ 511160435),
      new C0402(class_1893.field_9101, (C0400.f4213 | 544486) + ~(C0400.f4213 & 544486) + 1 ^ 511062989),
      187679336490942256L
   );
   public static final List<C0402> f4209 = w.a<"B">(
      new C0402(class_1893.field_9107, (C0400.f4213 | 375645) + ~(C0400.f4213 & 375645) + 1 ^ 511428211),
      new C0402(class_1893.field_9119, (C0400.f4213 | 79935) + ~(C0400.f4213 & 79935) + 1 ^ 511657238),
      new C0402(class_1893.field_9101, (C0400.f4213 | 789156) + ~(C0400.f4213 & 789156) + 1 ^ 510818191),
      187679336490942256L
   );
   public static final List<C0402> f4210 = w.a<"B">(
      new C0402(class_1893.field_9111, (C0400.f4213 | 345477) + ~(C0400.f4213 & 345477) + 1 ^ 511391915),
      new C0402(class_1893.field_9119, (C0400.f4213 | 147927) + ~(C0400.f4213 & 147927) + 1 ^ 511458558),
      new C0402(class_1893.field_9101, (C0400.f4213 | 737983) + ~(C0400.f4213 & 737983) + 1 ^ 511000468),
      new C0402(class_1893.field_9129, (C0400.f4213 | 325258) + ~(C0400.f4213 & 325258) + 1 ^ 511347620),
      319034520487861803L
   );
   public static final List<C0402> f4211 = w.a<"B">(
      new C0402(class_1893.field_9119, (C0400.f4213 | 365443) + ~(C0400.f4213 & 365443) + 1 ^ 511438506),
      new C0402(class_1893.field_9101, (C0400.f4213 | 491001) + ~(C0400.f4213 & 491001) + 1 ^ 511246546),
      330593338300798873L
   );
   public static final List<C0402> f4212 = w.a<"B">(
      new C0402(class_1893.field_9118, (C0400.f4213 | 787556) + ~(C0400.f4213 & 787556) + 1 ^ 510818635),
      new C0402(class_1893.field_9124, (C0400.f4213 | 396050) + ~(C0400.f4213 & 396050) + 1 ^ 511211066),
      new C0402(class_1893.field_9121, (C0400.f4213 | 121934) + ~(C0400.f4213 & 121934) + 1 ^ 511680870),
      new C0402(class_1893.field_9115, (C0400.f4213 | 954289) + ~(C0400.f4213 & 954289) + 1 ^ 510718616),
      new C0402(class_1893.field_9119, (C0400.f4213 | 189283) + ~(C0400.f4213 & 189283) + 1 ^ 511483466),
      new C0402(class_1893.field_9101, (C0400.f4213 | 628579) + ~(C0400.f4213 & 628579) + 1 ^ 511175240),
      376653535090113969L
   );
   public static int f4213 = w.a<"B">(5493901527547631410L, 257832362129977838L);

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public static boolean m1717(class_1799 var0) {
      if (w.a<"Û">(var0, 222207108884875224L) instanceof class_1738 var1) {
         return (boolean)(switch (<unrepresentable>.f1705[w.a<"Û">(w.a<"Û">(var1, 337650081844373857L), 316902857602188317L)]) {
            case 1, 2 -> (f4213 | 366582) + ~(f4213 & 366582) + 1 ^ 511437532;
            case 3 -> w.a<"B">(var0, f4210, 363116970891604518L);
            case 4 -> w.a<"B">(var0, f4209, 363116970891604518L);
            case 5 -> w.a<"B">(var0, f4208, 363116970891604518L);
            case 6 -> w.a<"B">(var0, f4207, 363116970891604518L);
            case 7 -> (f4213 | 671256) + ~(f4213 & 671256) + 1 ^ 510935858;
            default -> throw new MatchException(null, null);
         });
      } else if (w.a<"Û">(var0, 222207108884875224L) instanceof class_1829) {
         return w.a<"B">(var0, f4212, 363116970891604518L);
      } else {
         return (boolean)(w.a<"Û">(var0, class_1802.field_8833, 282470456889867724L)
            ? w.a<"B">(var0, f4211, 363116970891604518L)
            : (f4213 | 328) + ~(f4213 & 328) + 1 ^ 511605858);
      }
   }

   public static boolean m1718(class_1799 var0, Iterable<C0402> var1) {
      Iterator var2 = w.a<"Û">(var1, 191661729848227466L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         C0402 var3 = (C0402)w.a<"Û">(var2, 192468336863492695L);
         if (w.a<"B">(w.a<"Û">(var3, 158274432081472062L), var0, 311653725715531217L) != w.a<"Û">(var3, 375275909074739042L)) {
            return (boolean)((f4213 | 878600) + ~(f4213 & 878600) + 1 ^ 510858530);
         }
      }

      return (boolean)((f4213 | 212871) + ~(f4213 & 212871) + 1 ^ 511525548);
   }
}
