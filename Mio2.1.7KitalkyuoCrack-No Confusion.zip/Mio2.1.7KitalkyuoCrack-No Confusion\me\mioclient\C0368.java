package me.mioclient;

import net.minecraft.class_2338;
import net.minecraft.class_2350;

public final class C0368 extends C1180 {
   public final class_2338 f3476;
   public final class_2350 f3477;

   public C0368(class_2338 var1, class_2350 var2) {
      this.f3476 = var1;
      this.f3477 = var2;
   }

   public class_2338 m1430() {
      return this.f3476;
   }

   public class_2350 m1431() {
      return this.f3477;
   }
}
