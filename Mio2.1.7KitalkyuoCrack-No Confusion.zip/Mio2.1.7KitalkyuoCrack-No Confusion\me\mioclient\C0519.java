package me.mioclient;

import java.util.function.Predicate;

public class C0519 implements Predicate {
   public C1061 f0392;

   public C0519(C1061 var1) {
      this.f0392 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return false;
   }
}
