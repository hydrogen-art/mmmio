package me.mioclient;

import java.util.Iterator;
import net.minecraft.class_1294;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_744;

public class C0215 implements C0045 {
   public static float f0562 = w.a<"B">((C0215.f0564 | 214270) + ~(C0215.f0564 & 214270) + 1 ^ 612264807, 349057757755238323L);
   public static float f0563 = f0562 * w.a<"B">((C0215.f0564 | 264130) + ~(C0215.f0564 & 264130) + 1 ^ 614923370, 349057757755238323L);
   public static int f0564 = w.a<"B">(8668856249208573696L, 257832362129977838L);

   public static double[] m0304(C0650 var0, double var1) {
      if (w.a<"B">(239474890139367192L)) {
         double[] var3 = w.a<"B">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               C0094.m1872(),
               111737428835766792L
            ),
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913,
            var1,
            108620803423508722L
         );
         w.a<"Û">(
            var0, var3[(f0564 | 779723) + ~(f0564 & 779723) + 1 ^ 451269294], var3[(f0564 | 870891) + ~(f0564 & 870891) + 1 ^ 451116687], 341834528303342411L
         );
         return var3;
      } else {
         w.a<"Û">(var0, 0.0, 0.0, 341834528303342411L);
         double[] var10000 = new double[(f0564 | 853203) + ~(f0564 & 853203) + 1 ^ 451097524];
         var10000[(f0564 | 386088) + ~(f0564 & 386088) + 1 ^ 451662669] = 0.0;
         var10000[(f0564 | 341227) + ~(f0564 & 341227) + 1 ^ 451609487] = 0.0;
         return var10000;
      }
   }

   public static double[] m0305(float var0, class_744 var1, double var2) {
      float var4 = var1.field_3905;
      float var5 = var1.field_3907;
      float var6 = var0;
      if (var4 != 0.0F) {
         if (var5 > 0.0F) {
            var6 = var0 + (float)(var4 > 0.0F ? -C1074.f4546 : C1074.f4546);
         } else if (var5 < 0.0F) {
            var6 = var0 + (float)(var4 > 0.0F ? C1074.f4546 : -C1074.f4546);
         }

         var5 = 0.0F;
         if (var4 > 0.0F) {
            var4 = w.a<"B">((f0564 | 418283) + ~(f0564 & 418283) + 1 ^ 627594894, 349057757755238323L);
         } else if (var4 < 0.0F) {
            var4 = w.a<"B">((f0564 | 63303) + ~(f0564 & 63303) + 1 ^ -1519468510, 349057757755238323L);
         }
      }

      double var7 = (double)var4 * var2 * -w.a<"B">(w.a<"B">((double)var6, 175389272199548133L), 230683255727203842L)
         + (double)var5 * var2 * w.a<"B">(w.a<"B">((double)var6, 175389272199548133L), 266524427586034326L);
      double var9 = (double)var4 * var2 * w.a<"B">(w.a<"B">((double)var6, 175389272199548133L), 266524427586034326L)
         - (double)var5 * var2 * -w.a<"B">(w.a<"B">((double)var6, 175389272199548133L), 230683255727203842L);
      double[] var10000 = new double[(f0564 | 561080) + ~(f0564 & 561080) + 1 ^ 451328223];
      var10000[(f0564 | 655076) + ~(f0564 & 655076) + 1 ^ 451398017] = var7;
      var10000[(f0564 | 442612) + ~(f0564 & 442612) + 1 ^ 451475344] = var9;
      return var10000;
   }

   public static double m0306(double var0, double var2, double var4, long var6) {
      if (var2 >= var0) {
         return var0;
      } else {
         double var8 = w.a<"B">(
            (double)(w.a<"B">(223409559795593705L) - var6)
               / (var4 * w.a<"B">(((long)f0564 | 365881L) + ~((long)f0564 & 365881L) + 1L ^ 4652007309292839516L, 317139102743630955L)),
            0.0,
            w.a<"B">(((long)f0564 | 484520L) + ~((long)f0564 & 484520L) + 1L ^ 4607182419251516365L, 317139102743630955L),
            318037245528159060L
         );
         double var10 = var2 + (var0 - var2) * var8;
         return w.a<"B">(var10, var0, 199488685501753436L);
      }
   }

   public static boolean m0307(class_1657 var0) {
      if (var0 == null) {
         return (boolean)((f0564 | 992942) + ~(f0564 & 992942) + 1 ^ 450957771);
      } else {
         return (boolean)(var0.field_6250 == 0.0F && var0.field_6212 == 0.0F
            ? (f0564 | 52338) + ~(f0564 & 52338) + 1 ^ 451869463
            : (f0564 | 570085) + ~(f0564 & 570085) + 1 ^ 451315073);
      }
   }

   public static boolean m0308() {
      return w.a<"B">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 282320709208602225L);
   }

   public static double m0309(boolean var0) {
      return w.a<"B">(var0, (double)f0562, 328551394550687600L);
   }

   public static double m0310(boolean var0, double var1) {
      double var3 = var1;
      if (w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
         class_1294.field_5904,
         176223852645644080L
      )) {
         int var5 = w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               class_1294.field_5904,
               169566341115889972L
            ),
            148721469287305317L
         );
         var3 = var1
            * (
               w.a<"B">(((long)f0564 | 813273L) + ~((long)f0564 & 813273L) + 1L ^ 4607182419251060668L, 317139102743630955L)
                  + w.a<"B">(((long)f0564 | 155709L) + ~((long)f0564 & 155709L) + 1L ^ 4596373779322883778L, 317139102743630955L)
                     * (double)(var5 + ((f0564 | 652844) + ~(f0564 & 652844) + 1 ^ 451395912))
            );
      }

      if (var0
         && w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_1294.field_5909,
            176223852645644080L
         )) {
         int var6 = w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               class_1294.field_5909,
               169566341115889972L
            ),
            148721469287305317L
         );
         var3 /= w.a<"B">(((long)f0564 | 909834L) + ~((long)f0564 & 909834L) + 1L ^ 4607182419251156335L, 317139102743630955L)
            + w.a<"B">(((long)f0564 | 341127L) + ~((long)f0564 & 341127L) + 1L ^ 4596373779322673784L, 317139102743630955L)
               * (double)(var6 + ((f0564 | 219511) + ~(f0564 & 219511) + 1 ^ 451767827));
      }

      return var3;
   }

   public static double m0311() {
      double var0 = 0.0;
      if (w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
         class_1294.field_5913,
         176223852645644080L
      )) {
         int var2 = w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               class_1294.field_5913,
               169566341115889972L
            ),
            148721469287305317L
         );
         var0 += (double)(var2 + ((f0564 | 794075) + ~(f0564 & 794075) + 1 ^ 451029695))
            * w.a<"B">(((long)f0564 | 200443L) + ~((long)f0564 & 200443L) + 1L ^ 4591870179695435780L, 317139102743630955L);
      }

      return var0;
   }

   public static double m0312(double var0) {
      int var2 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L)
            && m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_5976
         ? (f0564 | 691034) + ~(f0564 & 691034) + 1 ^ 451198014
         : (f0564 | 52014) + ~(f0564 & 52014) + 1 ^ 451869771;
      if (var2 == 0) {
         return 0.0;
      } else {
         double var3 = w.a<"B">(-4616189618054758400L, 317139102743630955L);
         class_238 var5 = w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L),
               0.0,
               w.a<"B">(((long)f0564 | 566732L) + ~((long)f0564 & 566732L) + 1L ^ 4587366580068748083L, 317139102743630955L),
               0.0,
               240768051853680291L
            ),
            w.a<"B">(((long)f0564 | 976927L) + ~((long)f0564 & 976927L) + 1L ^ 4587366580068370144L, 317139102743630955L),
            130605157384247280L
         );
         var5 = w.a<"Û">(var5, var5.field_1325 + var0, 182030847371476974L);
         Iterator var6 = w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
               var5,
               176158938395654034L
            ),
            191661729848227466L
         );

         while (w.a<"Û">(var6, 333900474771661065L)) {
            class_265 var7 = (class_265)w.a<"Û">(var6, 192468336863492695L);
            Iterator var8 = w.a<"Û">(w.a<"Û">(var7, 353497208615209733L), 341496865259068134L);

            while (w.a<"Û">(var8, 333900474771661065L)) {
               class_238 var9 = (class_238)w.a<"Û">(var8, 192468336863492695L);
               if (var9.field_1325 > var3) {
                  var3 = var9.field_1325;
               }
            }
         }

         var3 -= w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L);
         return var3 > 0.0 && var3 <= var0 ? var3 : 0.0;
      }
   }

   public static boolean m0313(class_1657 var0, class_243 var1) {
      class_243 var2 = w.a<"Û">(var0, 251973325887060219L);
      if (w.a<"B">(var0, 282320709208602225L)) {
         class_243 var3 = w.a<"Û">(
            w.a<"Û">(var0, 359920018220808632L),
            w.a<"Û">(var2, 366754089402394978L) * w.a<"B">(((long)f0564 | 406725L) + ~((long)f0564 & 406725L) + 1L ^ 4666723172918756256L, 317139102743630955L),
            0.0,
            w.a<"Û">(var2, 317360164092454553L) * w.a<"B">(((long)f0564 | 816548L) + ~((long)f0564 & 816548L) + 1L ^ 4666723172918379201L, 317139102743630955L),
            215037093685651073L
         );
         class_243 var4 = w.a<"Û">(
            w.a<"Û">(var0, 359920018220808632L),
            w.a<"Û">(var2, 366754089402394978L) * w.a<"B">(-4556648864387432448L, 317139102743630955L),
            0.0,
            w.a<"Û">(var2, 317360164092454553L) * w.a<"B">(-4556648864387432448L, 317139102743630955L),
            215037093685651073L
         );
         return (boolean)(w.a<"Û">(var3, var1, 271768320413122837L) < w.a<"Û">(var4, var1, 271768320413122837L)
            ? (f0564 | 767108) + ~(f0564 & 767108) + 1 ^ 451249120
            : (f0564 | 573211) + ~(f0564 & 573211) + 1 ^ 451315838);
      } else {
         return (boolean)((f0564 | 3990) + ~(f0564 & 3990) + 1 ^ 451819763);
      }
   }

   public static boolean m0314(class_243 var0) {
      return w.a<"B">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, var0, 272159985293103090L
      );
   }

   public static float m0315() {
      if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L)) {
         double[] var3 = w.a<"B">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L),
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913,
            w.a<"B">(((long)f0564 | 917865L) + ~((long)f0564 & 917865L) + 1L ^ 4607182419250918924L, 317139102743630955L),
            108620803423508722L
         );
         return (float)(
            w.a<"B">(
                  w.a<"B">(
                     var3[(f0564 | 830136) + ~(f0564 & 830136) + 1 ^ 451059164],
                     var3[(f0564 | 356282) + ~(f0564 & 356282) + 1 ^ 451631327],
                     370151239157781531L
                  ),
                  207871222047649314L
               )
               - (double)C1074.f4547
         );
      } else {
         float var0 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 152871992642526281L
         );
         class_744 var1 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3913;
         int var2 = var1.field_3910 != var1.field_3909
            ? (f0564 | 716671) + ~(f0564 & 716671) + 1 ^ 451205147
            : (f0564 | 564452) + ~(f0564 & 564452) + 1 ^ 451324801;
         if (var1.field_3909) {
            var0 += w.a<"B">((f0564 | 189858) + ~(f0564 & 189858) + 1 ^ 1507381959, 349057757755238323L);
         }

         if (var1.field_3906 && var2 == 0) {
            var0 += (float)(
               C1074.f4547 * (var1.field_3909 ? (f0564 | 299681) + ~(f0564 & 299681) + 1 ^ -451585477 : (f0564 | 899763) + ~(f0564 & 899763) + 1 ^ 451120599)
            );
         }

         if (var1.field_3908 && var2 == 0) {
            var0 -= (float)(
               C1074.f4547 * (var1.field_3909 ? (f0564 | 956097) + ~(f0564 & 956097) + 1 ^ -450929061 : (f0564 | 960337) + ~(f0564 & 960337) + 1 ^ 450924597)
            );
         }

         return var0;
      }
   }
}
