package me.mioclient;

import java.awt.Color;
import java.util.Objects;

public record C0122() {
   public final C0502 f0949;
   public final C0617<Color> f0950;
   public final C0617<Color> f0951;
   public final C0617<Float> f0952;
   public final C0617<Float> f0953;
   public final C0617<Boolean> f0954;
   public final C0617<Boolean> f0955;
   public final int f0956;
   public static int f0957 = w.a<"B">(403108407715274617L, 257832362129977838L);

   public C0122(C0502 var1, C0617<Color> var2, C0617<Color> var3, C0617<Float> var4, C0617<Float> var5, C0617<Boolean> var6, C0617<Boolean> var7, int var8) {
      this.f0949 = var1;
      this.f0950 = var2;
      this.f0951 = var3;
      this.f0952 = var4;
      this.f0953 = var5;
      this.f0954 = var6;
      this.f0955 = var7;
      this.f0956 = var8;
   }

   public Color m0441() {
      return (Color)w.a<"Û">(this.f0950, 165538822832276514L);
   }

   public Color m0442() {
      return (Color)w.a<"Û">(this.f0951, 165538822832276514L);
   }

   public float m0443() {
      return w.a<"Û">((Float)w.a<"Û">(this.f0952, 165538822832276514L), 149784643039979208L);
   }

   public float m0444() {
      return w.a<"Û">((Boolean)w.a<"Û">(this.f0955, 165538822832276514L), 354697271520518137L)
         ? w.a<"Û">((Float)w.a<"Û">(this.f0953, 165538822832276514L), 149784643039979208L) * (float)this.f0956
         : 0.0F;
   }

   public boolean m0445() {
      return w.a<"Û">((Boolean)w.a<"Û">(this.f0954, 165538822832276514L), 354697271520518137L);
   }

   public boolean m0446() {
      return w.a<"Û">((Boolean)w.a<"Û">(this.f0955, 165538822832276514L), 354697271520518137L);
   }

   @Override
   public boolean equals(Object var1) {
      if (this == var1) {
         return (boolean)((f0957 | 193719) + ~(f0957 & 193719) + 1 ^ -685093585);
      } else if (var1 != null && this.getClass() == var1.getClass()) {
         C0122 var2 = (C0122)var1;
         return Objects.equals(this.f0949, var2.f0949);
      } else {
         return (boolean)((f0957 | 626781) + ~(f0957 & 626781) + 1 ^ -685692476);
      }
   }

   @Override
   public int hashCode() {
      Object[] var10000 = new Object[(f0957 | 279822) + ~(f0957 & 279822) + 1 ^ -684917610];
      var10000[(f0957 | 940880) + ~(f0957 & 940880) + 1 ^ -685317431] = this.f0949;
      return w.a<"B">(var10000, 292132947184505832L);
   }

   public C0502 m0447() {
      return this.f0949;
   }

   public C0617<Color> m0448() {
      return this.f0950;
   }

   public C0617<Color> m0449() {
      return this.f0951;
   }

   public C0617<Float> m0450() {
      return this.f0952;
   }

   public C0617<Float> m0451() {
      return this.f0953;
   }

   public C0617<Boolean> m0452() {
      return this.f0954;
   }

   public C0617<Boolean> m0453() {
      return this.f0955;
   }

   public int m0454() {
      return this.f0956;
   }
}
