package me.mioclient;

import net.minecraft.class_2561;

public interface C0196 {
   String getName();

   default C0196 m0741(String var1) {
      return () -> var1;
   }

   default class_2561 m0742() {
      return w.a<"B">(w.a<"Û">(this, 352801181599163784L), 228465064790135899L);
   }

   static boolean m0743(Object var0) {
      return var0 instanceof C0196;
   }
}
