package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1959.class_1963;

public enum C0457 implements C0196 {
   f1236("Clear", class_1963.field_9384),
   f1237("Snow", class_1963.field_9383),
   f1238("Rain", class_1963.field_9382),
   f1239("Dusty", class_1963.field_9384);

   public final String f1240;
   public final class_1963 f1241;

   public C0457(String var3, class_1963 var4) {
      this.f1240 = var3;
      this.f1241 = var4;
   }

   @Override
   public String getName() {
      return this.f1240;
   }

   public class_1963 m2572() {
      return this.f1241;
   }

   public static String rDJaVikOO28Y4FUMM4MaoPx3byMEcOXaTWIxqdsAumtwXcyrKhGnfY3CVUd9jpcYeAbYPRY2nwoMQ5pOZcFbgkyT4OWudonj2vV6(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
