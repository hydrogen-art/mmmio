package me.mioclient;

import baritone.api.IBaritone;
import baritone.api.pathing.goals.GoalXZ;
import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2172;
import net.minecraft.class_243;

public class C0250 extends C0219 {
   public static int f3200 = w.a<"B">(1431017744679770065L, 257832362129977838L);

   public C0250() {
      super("walk");
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"Û">(
               w.a<"B">("name", w.a<"B">(147271288244807063L), 191188367299315725L),
               (SuggestionProvider)(var0, var1x) -> w.a<"B">(var0, var1x, w.a<"B">(236891368760475340L), 182432673308705042L),
               357832626693996259L
            ),
            (Command)var0 -> {
               class_243 var1x = w.a<"B">(var0, 374789206573028538L);
               if (var1x == null) {
                  return (f3200 | 536337) + ~(f3200 & 536337) + 1 ^ 674861780;
               } else {
                  IBaritone var2 = w.a<"Û">(w.a<"B">(138748748971879289L), 164621699202994993L);
                  GoalXZ var3 = new GoalXZ((int)w.a<"Û">(var1x, 366754089402394978L), (int)w.a<"Û">(var1x, 317360164092454553L));
                  w.a<"Û">(w.a<"Û">(var2, 214050004715517817L), var3, 343191871106212258L);
                  return (f3200 | 677644) + ~(f3200 & 677644) + 1 ^ 675015368;
               }
            },
            368995281709124746L
         ),
         289819728773344295L
      );
   }

   public static String qjnvU9tDgFwwfvQOd3EhMRJGv9Hx8lw5byqVxllgdAB1cmPZKn8wZ4XrXA8i45oPaVQRn5IXuvw0cbzmVks3lcw8EQ6pzK2wJa7g(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
