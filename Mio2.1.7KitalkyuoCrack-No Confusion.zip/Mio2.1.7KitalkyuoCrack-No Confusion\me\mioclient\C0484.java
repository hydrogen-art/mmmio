package me.mioclient;

import java.util.function.Predicate;

public class C0484 implements Predicate {
   public C1051 f3236;

   public C0484(C1051 var1) {
      this.f3236 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f3236.f0312, 254992554122318132L) && w.a<"Û">((Boolean)w.a<"Û">(this.f3236.f0317, 174312564406604366L), 354697271520518137L);
   }
}
