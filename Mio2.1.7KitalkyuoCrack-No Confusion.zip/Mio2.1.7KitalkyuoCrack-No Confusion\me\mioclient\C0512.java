package me.mioclient;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;

public class C0512<T> implements ArgumentType<Collection<T>> {
   public final ArgumentType<T> f4566;
   public static int f4567 = w.a<"B">(1452661669043328313L, 257832362129977838L);

   public C0512(ArgumentType<T> var1) {
      this.f4566 = var1;
   }

   public Collection<T> parse(StringReader var1) {
      String var2 = w.a<"Û">(var1, 375896365896432422L);
      w.a<"Û">(var1, w.a<"Û">(var1, 185662703704259241L), 171934355112443263L);
      String[] var3 = w.a<"Û">(var2, " ", 369825978071233340L);
      ArrayList var4 = new ArrayList();
      String[] var5 = var3;
      int var6 = var3.length;

      for (int var7 = (f4567 | 524661) + ~(f4567 & 524661) + 1 ^ -1921597507; var7 < var6; var7++) {
         String var8 = var5[var7];
         w.a<"Û">(var4, w.a<"Û">(this.f4566, new StringReader(var8), 183711798673691400L), 276802003864609490L);
      }

      return var4;
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> var1, SuggestionsBuilder var2) {
      String[] var3 = w.a<"Û">(w.a<"Û">(var2, 110975976514483618L), " ", 369825978071233340L);
      int var4 = w.a<"Û">(var2, 184899309879601106L)
         + w.a<"Û">(w.a<"Û">(var2, 110975976514483618L), 120891947504160641L)
         - w.a<"Û">(var3[var3.length - ((f4567 | 671135) + ~(f4567 & 671135) + 1 ^ -1921744042)], 120891947504160641L);
      return w.a<"Û">(this.f4566, var1, new SuggestionsBuilder(w.a<"Û">(var2, 286871211146376987L), var4), 318283616997728196L);
   }
}
