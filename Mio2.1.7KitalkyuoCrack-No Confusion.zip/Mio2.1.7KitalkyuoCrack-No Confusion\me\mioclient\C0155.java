package me.mioclient;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ScheduledFuture;

public class C0155 extends SimpleChannelInboundHandler<C0636> {
   public final CopyOnWriteArrayList<ScheduledFuture<?>> f2024 = new CopyOnWriteArrayList<>();
   public static int f2025 = w.a<"B">(6107812767373516781L, 257832362129977838L);

   public void m2835(ChannelHandlerContext var1, C0636 var2) {
      w.a<"Û">(var2, var1, 110387922695531375L);
      w.a<"Û">(var1, 238196870287038229L);
   }

   public void exceptionCaught(ChannelHandlerContext var1, Throwable var2) {
      w.a<"Û">(var2, 186266871610698991L);
      w.a<"Û">(var1, 141843314860840105L);
      w.a<"B">(131240376211642313L);
      w.a<"B">(243972494957822593L);
      w.a<"Û">(C0933.f1424, 319304145122957091L);
      w.a<"Û">(C0933.f1424, (boolean)((f2025 | 609117) + ~(f2025 & 609117) + 1 ^ -517268341), 272036996223953733L);
   }
}
