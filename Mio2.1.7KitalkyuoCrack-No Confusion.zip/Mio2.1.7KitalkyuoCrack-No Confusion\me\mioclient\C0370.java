package me.mioclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.List;

public final class C0370 extends C1316<C1097> implements C0045, C0997 {
   public static C0022 f0382 = C0933.f1409.m2696(C0022.class);
   public static int f0383 = w.a<"B">(8827545134171924316L, 257832362129977838L);

   public C0370() {
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   @Override
   public JsonElement toJson() {
      if (!w.a<"Û">((Boolean)w.a<"Û">(f0382.f2550, 174312564406604366L), 354697271520518137L)) {
         return new JsonObject();
      } else {
         JsonArray var1 = new JsonArray();
         JsonObject var2 = new JsonObject();
         Iterator var3 = w.a<"Û">((List)w.a<"Û">(C0933.f1432, 268370374673263607L), 341496865259068134L);

         while (w.a<"Û">(var3, 333900474771661065L)) {
            C1097 var4 = (C1097)w.a<"Û">(var3, 192468336863492695L);
            w.a<"Û">(
               var1,
               w.a<"Û">(m$$WIXrwZ4s3IpmGVifSWBBELSopMnHWq0oi2qH3axWFDamTO1i9JlTspOMIa3dc9q8OPm3xsTZds5jMitIlfICDOaCPZa7qwQNW, var4, 144992806448910693L),
               293586665875438700L
            );
         }

         w.a<"Û">(var2, "stashes", var1, 130151082343781043L);
         return var2;
      }
   }

   @Override
   public void fromJson(JsonElement var1) {
      if (w.a<"Û">(var1, 266361156733738545L) && w.a<"Û">(w.a<"Û">(var1, 322749330123725882L), "stashes", 314399812765309162L)) {
         JsonArray var2 = w.a<"Û">(w.a<"Û">(var1, 322749330123725882L), "stashes", 345492744153864995L);
         Iterator var3 = w.a<"Û">(var2, 160599635136516371L);

         while (w.a<"Û">(var3, 333900474771661065L)) {
            JsonElement var4 = (JsonElement)w.a<"Û">(var3, 192468336863492695L);

            try {
               w.a<"Û">(
                  (List)this.m$$QDkcwdYSbTNdbe5p3C5ySbQG1n5FQqhuRTHWqt7x5QuBqJu8aRR1jGHbETJpDr14tCJvzHoHAl5J7jWeOwDnRwu1yTi0LxvXg,
                  (C1097)w.a<"Û">(
                     m$$WIXrwZ4s3IpmGVifSWBBELSopMnHWq0oi2qH3axWFDamTO1i9JlTspOMIa3dc9q8OPm3xsTZds5jMitIlfICDOaCPZa7qwQNW,
                     var4,
                     C1097.class,
                     150422887749779488L
                  ),
                  276802003864609490L
               );
            } catch (Exception var6) {
            }
         }
      }
   }

   @Override
   public String getConfigName() {
      return "stashfinder.json";
   }

   public static String _Ydja2399bfeKPVmng9itSj1i9ZttQ8LBYLALfSyrx5BlcvEg0PqcNTtikXdcXOppqDuEXPyvtJj0SoJaGzIBdrjUpFbJInZFTI3/* $VF was: 5Ydja2399bfeKPVmng9itSj1i9ZttQ8LBYLALfSyrx5BlcvEg0PqcNTtikXdcXOppqDuEXPyvtJj0SoJaGzIBdrjUpFbJInZFTI3*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
