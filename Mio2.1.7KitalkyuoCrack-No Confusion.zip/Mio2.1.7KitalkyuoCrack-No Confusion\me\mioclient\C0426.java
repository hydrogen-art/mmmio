package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1299;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_2604;
import net.minecraft.class_2708;
import net.minecraft.class_6373;

public class C0426 extends C1266 {
   public final Queue<class_6373> f2387;
   public boolean f2388;
   public boolean f2389;
   public class_243 f2390;
   public int f2391;
   public final C0083 f2392;
   public final C0083 f2393;
   public static int f2394 = w.a<"B">(7255302873781362222L, 257832362129977838L);

   public C0426() {
      C1045 var10002 = C1045.f3177;
      String[] var10003 = new String[(f2394 | 485707) + ~(f2394 & 485707) + 1 ^ -174285705];
      var10003[(f2394 | 213300) + ~(f2394 & 213300) + 1 ^ -174541815] = "disabler";
      super("GrimDisabler", var10002, var10003);
      this.f2387 = new ArrayDeque<>();
      this.f2392 = new C0083();
      this.f2393 = new C0083();
   }

   @Override
   public String getInfo() {
      return this.f2388 ? "+" : "-";
   }

   @Override
   public void onToggle() {
      this.f2388 = (boolean)((f2394 | 717087) + ~(f2394 & 717087) + 1 ^ -175045598);
      w.a<"Û">(this.f2393, -1L, 167864214448769242L);
   }

   @C1027
   public void m3039(C0591 var1) {
      if (this.f2388
         && this.f2390 != null
         && w.a<"B">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L),
               this.f2390,
               342075947093997425L
            )
            > w.a<"B">((f2394 | 93553) + ~(f2394 & 93553) + 1 ^ -1221683124, 349057757755238323L)) {
         this.f2388 = (boolean)((f2394 | 633701) + ~(f2394 & 633701) + 1 ^ -174956968);
      }

      if (w.a<"Û">(this.f2392, ((long)f2394 | 149118L) + ~((long)f2394 & 149118L) + 1L ^ -174515061L, 309642602085515378L)) {
         this.f2388 = (boolean)((f2394 | 283032) + ~(f2394 & 283032) + 1 ^ -174087003);
      }

      if (!this.f2388) {
         while (!w.a<"Û">(this.f2387, 296374206093673190L)) {
            class_6373 var2 = (class_6373)w.a<"Û">(this.f2387, 154912847677331014L);
            if (var2 == null) {
               break;
            }

            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
               var2,
               387022742154350736L
            );
         }
      } else {
         this.f2391 = this.f2391 - ((f2394 | 572661) + ~(f2394 & 572661) + 1 ^ -174896695);
      }

      if (w.a<"Û">(this, 147347547096426794L) && !this.f2388) {
         w.a<"Û">(this, 310610829907201345L);
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = -200
   )
   public void m3040(C0650 var1) {
      if (!this.f2388) {
         w.a<"Û">(var1, w.a<"Û">(var1, 150720566870291082L), 326881584648207186L);
         w.a<"Û">(var1, 335396843668455379L);
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 365261228406721299L).field_7479 = (boolean)((
                  f2394 | 243332
               )
               + ~(f2394 & 243332)
               + 1
            ^ -174570567);
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 365261228406721299L).field_7478 = (boolean)((
                  f2394 | 244406
               )
               + ~(f2394 & 244406)
               + 1
            ^ -174567541);
      }
   }

   @C1027
   public void m3041(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_6373 var2 && this.f2388 && this.f2391 <= 0) {
         w.a<"Û">(this.f2387, var2, 276905752407976510L);
         w.a<"Û">(var1, 385440235371820560L);
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2708) {
         if (!this.f2388 || this.f2391 > 0) {
            return;
         }

         this.f2388 = (boolean)((f2394 | 393907) + ~(f2394 & 393907) + 1 ^ -174196850);
         this.f2390 = null;
         this.f2389 = (boolean)((f2394 | 830396) + ~(f2394 & 830396) + 1 ^ -174629247);
      }

      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2604 var4
         && this.f2389
         && w.a<"Û">(
               this.f2390, w.a<"Û">(var4, 180182980834797487L), w.a<"Û">(var4, 350612975000976430L), w.a<"Û">(var4, 193879592482149874L), 145073102115949444L
            )
            < w.a<"B">(((long)f2394 | 830381L) + ~((long)f2394 & 830381L) + 1L ^ -4625196817484128624L, 317139102743630955L)
         && w.a<"Û">(var4, 353809255235785168L) == class_1299.field_6133) {
         this.f2391 = (f2394 | 296945) + ~(f2394 & 296945) + 1 ^ -174099770;
         this.f2388 = (boolean)((f2394 | 649806) + ~(f2394 & 649806) + 1 ^ -174973070);
         this.f2389 = (boolean)((f2394 | 60674) + ~(f2394 & 60674) + 1 ^ -174385089);
         w.a<"Û">(this.f2392, 387780412884547639L);
      }
   }

   public boolean m3042() {
      if (!w.a<"Û">(this.f2393, ((long)f2394 | 782346L) + ~((long)f2394 & 782346L) + 1L ^ -175110433L, 309642602085515378L)) {
         return (boolean)((f2394 | 734252) + ~(f2394 & 734252) + 1 ^ -175062767);
      } else {
         return (boolean)(w.a<"B">(class_1802.field_8639, 261845468269893067L) != ((f2394 | 26480) + ~(f2394 & 26480) + 1 ^ 174353842)
               && w.a<"Û">(this, 198715220601828119L) != ((f2394 | 34778) + ~(f2394 & 34778) + 1 ^ 174361880)
               && !w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 120447883516886953L
               )
            ? (f2394 | 427198) + ~(f2394 & 427198) + 1 ^ -174231166
            : (f2394 | 760735) + ~(f2394 & 760735) + 1 ^ -175083870);
      }
   }

   public void m3043() {
      int var1 = w.a<"Û">(this, 198715220601828119L);
      w.a<"B">(w.a<"B">(var1, 117367628897531893L), (f2394 | 184883) + ~(f2394 & 184883) + 1 ^ -174512376, 238771771368340878L);
      w.a<"B">(370137111334983660L);
      w.a<"Û">(this, 308731259530997687L);
      w.a<"Û">(this.f2393, 387780412884547639L);
      this.f2390 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L
      );
      this.f2389 = (boolean)((f2394 | 140586) + ~(f2394 & 140586) + 1 ^ -174469098);
      w.a<"B">(w.a<"B">(var1, 117367628897531893L), (f2394 | 627432) + ~(f2394 & 627432) + 1 ^ -174954541, 238771771368340878L);
   }

   public int m3044() {
      return w.a<"B">(
         (Predicate<class_1799>)var0 -> (boolean)(w.a<"Û">(var0, class_1802.field_8833, 282470456889867724L)
                  && w.a<"Û">(var0, 166785356836111273L) - w.a<"Û">(var0, 329096039767898799L) > ((f2394 | 758082) + ~(f2394 & 758082) + 1 ^ -175086466)
               ? (f2394 | 343705) + ~(f2394 & 343705) + 1 ^ -174142555
               : (f2394 | 192651) + ~(f2394 & 192651) + 1 ^ -174520906),
         (boolean)((f2394 | 798453) + ~(f2394 & 798453) + 1 ^ -174597176),
         155900307420311747L
      );
   }

   public void m3045() {
      class_1268 var1 = w.a<"B">(class_1802.field_8639, 290444706100011361L);
      int var2 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545;
      int var3 = w.a<"B">(class_1802.field_8639, 261845468269893067L);
      int var4 = w.a<"B">(class_1802.field_8639, 113439863899466963L);
      if (var1 != null) {
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            var1,
            114543782118481187L
         );
      } else if (var3 != ((f2394 | 596417) + ~(f2394 & 596417) + 1 ^ 174920451)) {
         int var5 = var4 == ((f2394 | 390451) + ~(f2394 & 390451) + 1 ^ 174194673)
            ? (f2394 | 876983) + ~(f2394 & 876983) + 1 ^ -174680949
            : (f2394 | 853220) + ~(f2394 & 853220) + 1 ^ -174657063;
         w.a<"Û">(this, var5 != 0 ? var3 : var4, (boolean)var5, 378688220947802543L);
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            var5 != 0 ? class_1268.field_5810 : class_1268.field_5808,
            114543782118481187L
         );
         w.a<"Û">(this, var5 != 0 ? var3 : var2, (boolean)var5, 378688220947802543L);
      }
   }

   public void m3046(int var1, boolean var2) {
      if (var2) {
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            (f2394 | 798103) + ~(f2394 & 798103) + 1 ^ -174597974,
            var1,
            (f2394 | 748973) + ~(f2394 & 748973) + 1 ^ -175073096,
            class_1713.field_7791,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            270665692837061225L
         );
      } else {
         w.a<"B">(var1, 279757124141714355L);
      }
   }

   public static String _zyEp0AdTKU5xZlXA3c5BmaRhnRwX6apw0OoQAkqNjFKE7tYTN6tT6mIONJXu1HqlAgtMCLRqcMpVSwPNvvgQzadPobxGXuSZOYk/* $VF was: 0zyEp0AdTKU5xZlXA3c5BmaRhnRwX6apw0OoQAkqNjFKE7tYTN6tT6mIONJXu1HqlAgtMCLRqcMpVSwPNvvgQzadPobxGXuSZOYk*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
