package me.mioclient;

import java.util.function.Predicate;

public class C0331 implements Predicate {
   public C0879 f0561;

   public C0331(C0879 var1) {
      this.f0561 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0561.f3774, 254992554122318132L);
   }
}
