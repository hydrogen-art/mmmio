package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0364 implements C0196 {
   f1226("overworld", "Overworld"),
   f1227("the_nether", "Nether"),
   f1228("the_end", "End");

   public final String f1229;
   public final String f1230;

   public C0364(String var3, String var4) {
      this.f1229 = var3;
      this.f1230 = var4;
   }

   public boolean m2564() {
      return this == f1226;
   }

   public boolean m2565() {
      return this == f1227;
   }

   public boolean m2566() {
      return this == f1228;
   }

   public String m2567() {
      return this.f1230;
   }

   @Override
   public String getName() {
      return this.f1229;
   }

   public static String _f2wc2rNZCYwYqQMSEDUuYzThWV6wQvMaSAJKHcio1JZF5pf2ziD1qlXoF7QC3eA6YD2lmIsgxlsCQr6rbA4akvMMykkdxGVWP7j/* $VF was: 7f2wc2rNZCYwYqQMSEDUuYzThWV6wQvMaSAJKHcio1JZF5pf2ziD1qlXoF7QC3eA6YD2lmIsgxlsCQr6rbA4akvMMykkdxGVWP7j*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
