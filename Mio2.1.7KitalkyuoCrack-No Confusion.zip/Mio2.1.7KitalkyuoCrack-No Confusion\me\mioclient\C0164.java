package me.mioclient;

import com.mojang.authlib.GameProfile;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import me.mioclient.mixin.ducks.DuckLivingEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1664;
import net.minecraft.class_243;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_745;
import net.minecraft.class_8685;

public class C0164 extends class_745 {
   public final Set<class_1664> f1700 = new HashSet<>();
   public class_8685 f1701;
   public boolean f1702;
   public class_243 f1703;
   public static int f1704 = w.a<"B">(5706590910491297799L, 257832362129977838L);

   public C0164(class_638 var1) {
      super(var1, new GameProfile(UUID.randomUUID(), ""));
   }

   public void method_6007() {
   }

   public void m0721(class_1657 var1) {
      this.f1703 = new class_243(w.a<"Û">(var1, 232702264516987563L), w.a<"Û">(var1, 113514750778988419L), w.a<"Û">(var1, 203672616216990522L));
      super.method_5878(var1);
      w.a<"Û">(this, var1, 361937407034084327L);
      this.field_5982 = w.a<"Û">(var1, 330860038479874348L);
      w.a<"Û">(this, w.a<"Û">(var1, 330860038479874348L), 133202107604643322L);
      this.field_6004 = w.a<"Û">(var1, 254745727559094121L);
      w.a<"Û">(this, w.a<"Û">(var1, 254745727559094121L), 288540847422612874L);
      this.field_6283 = var1.field_6283;
      this.field_6220 = var1.field_6283;
      this.field_6241 = var1.field_6241;
      this.field_6259 = var1.field_6241;
      this.field_42108.field_42110 = var1.field_42108.field_42110;
      this.field_42108.field_42109 = var1.field_42108.field_42110;
      this.field_42108.field_42111 = var1.field_42108.field_42111;
      this.field_6213 = (f1704 | 209478) + ~(f1704 & 209478) + 1 ^ -1610654268;
      this.field_42906 = new class_243(0.0, 0.0, 0.0);
      w.a<"Û">(this, 0.0, 0.0, 0.0, 277062859492086706L);
      w.a<"Û">(this, w.a<"Û">(var1, 213144736476427845L), 247609076342620248L);
      w.a<"Û">(this, w.a<"Û">(var1, 354532350977589571L), 150339423563025319L);
      if (var1 instanceof class_742 var2) {
         this.f1701 = w.a<"Û">(var2, 173155350842553820L);
         class_1664[] var3 = w.a<"B">(245766347670166649L);
         int var4 = var3.length;

         for (int var5 = (f1704 | 571635) + ~(f1704 & 571635) + 1 ^ -1611344015; var5 < var4; var5++) {
            class_1664 var6 = var3[var5];
            if (var6 != class_1664.field_7559 && w.a<"Û">(var2, var6, 273407461625466431L)) {
               w.a<"Û">(this.f1700, var6, 309270453639690490L);
            }
         }
      }

      for (int var7 = (f1704 | 193940) + ~(f1704 & 193940) + 1 ^ -1610704362; var7 < w.a<"Û">(w.a<"Û">(this, 116713616076026342L), 338465858754043645L); var7++) {
         w.a<"Û">(
            w.a<"Û">(this, 116713616076026342L),
            var7,
            w.a<"Û">(w.a<"Û">(w.a<"Û">(var1, 128194116942239918L), var7, 386860178278302175L), 130512395089112511L),
            228631044764945951L
         );
      }

      w.a<"Û">(this, class_1268.field_5808, w.a<"Û">(w.a<"Û">(var1, 264704449765867577L), 130512395089112511L), 122450374346155396L);
      w.a<"Û">(this, class_1268.field_5810, w.a<"Û">(w.a<"Û">(var1, 337505956433277341L), 130512395089112511L), 122450374346155396L);
      w.a<"Û">(this, 116713616076026342L).field_7545 = w.a<"Û">(var1, 128194116942239918L).field_7545;
      ((DuckLivingEntity)this).mio$setLeaningPitch(((DuckLivingEntity)var1).mio$getLeaningPitch());
      ((DuckLivingEntity)this).mio$setLastLeaningPitch(((DuckLivingEntity)var1).mio$getLastLeaningPitch());
   }

   public void method_5814(double var1, double var3, double var5) {
      super.method_5814(var1, var3, var5);
      this.field_6038 = var1;
      this.field_5971 = var3;
      this.field_5989 = var5;
   }

   public class_243 m0722() {
      return this.f1703;
   }

   public class_8685 method_52814() {
      return this.f1701 != null ? this.f1701 : super.method_52814();
   }

   public boolean method_7348(class_1664 var1) {
      return w.a<"Û">(this.f1700, var1, 338145669613544495L);
   }

   public boolean m0723() {
      return this.f1702;
   }

   public void m0724(boolean var1) {
      this.f1702 = var1;
   }
}
