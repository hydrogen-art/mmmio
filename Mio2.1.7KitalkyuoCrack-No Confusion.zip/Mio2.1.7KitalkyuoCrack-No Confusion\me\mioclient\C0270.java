package me.mioclient;

import java.util.function.Predicate;

public class C0270 implements Predicate {
   public C0846 f0301;

   public C0270(C0846 var1) {
      this.f0301 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0301.f5202, 174312564406604366L) == C1204.f4315 && w.a<"Û">(this.f0301.f5201, 254992554122318132L);
   }
}
