package me.mioclient;

public abstract class C0378 implements C0045 {
   public final C0551 f0982;
   public static int f0983 = w.a<"B">(1255487334928471652L, 257832362129977838L);

   public C0378(C0551 var1) {
      this.f0982 = var1;
   }

   public abstract void m0465(C0133 var1);

   public void m0466(C0132 var1) {
   }

   public void m0467() {
   }

   public void m0468(C1006 var1) {
   }

   public void m0469(C1095 var1) {
   }

   public void m0470(C0816 var1) {
   }

   public void onDisable() {
   }
}
