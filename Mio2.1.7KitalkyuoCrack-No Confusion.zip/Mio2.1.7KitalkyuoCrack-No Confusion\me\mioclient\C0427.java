package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2318;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2665;
import net.minecraft.class_2680;
import net.minecraft.class_2350.class_2353;

public class C0427 extends C1266 {
   public final C0015<Float> f2744;
   public final C0015<Integer> f2745;
   public final C0015<Boolean> f2746;
   public final C0015<Boolean> f2747;
   public final C0015<Boolean> f2748;
   public final C0015<Boolean> f2749;
   public final C0015<Boolean> f2750;
   public final C0015<Boolean> f2751;
   public final C0015<Boolean> f2752;
   public final C0015<Boolean> f2753;
   public final C0015<Boolean> f2754;
   public final C0015<Boolean> f2755;
   public final C0015<Color> f2756;
   public final C0015<Color> f2757;
   public final C0015<Float> f2758;
   public final C0015<Boolean> f2759;
   public final C0015<Float> f2760;
   public final C0083 f2761;
   public class_1657 f2762;
   public boolean f2763;
   public class_2338 f2764;
   public boolean f2765;
   public final C1201 f2766;
   public final C0766 f2767;
   public static int f2768 = w.a<"B">(4777064516209343444L, 257832362129977838L);

   public C0427() {
      super("Pusher", "Pushes your enemies out of their holes.", C1045.f3172);
      w.a<"B">(this, 242859112966675773L);
      this.f2761 = new C0083();
      this.f2766 = new C1201();
      this.f2767 = new C0766(this);
      w.a<"Û">(
         C0933.f1430,
         new C0122(
            this,
            this.f2756,
            this.f2757,
            this.f2758,
            this.f2760,
            () -> w.a<"B">((boolean)((f2768 | 986034) + ~(f2768 & 986034) + 1 ^ -1382338132), 320330632857389983L),
            this.f2759,
            (f2768 | 461725) + ~(f2768 & 461725) + 1 ^ -1382862784
         ),
         215636623669649177L
      );
   }

   @Override
   public void onEnable() {
      this.f2765 = (boolean)((f2768 | 291248) + ~(f2768 & 291248) + 1 ^ -1383052369);
   }

   @Override
   public String getInfo() {
      return this.f2762 != null ? w.a<"Û">(w.a<"Û">(this.f2762, 138826997201410603L), 211085733983653208L) : super.getInfo();
   }

   @C1027
   public void m1095(C0153 var1) {
      if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 300193738958224619L)) {
         if (!this.f2765) {
            w.a<"Û">(
               C0933.f1433,
               (Runnable)() -> w.a<"B">(
                     w.a<"B">("Pusher doesn't work in singleplayer.", 228465064790135899L),
                     w.a<"B">((f2768 | 306087) + ~(f2768 & 306087) + 1 ^ 1383034438, 289296048454852994L),
                     C0639.f3880,
                     211469761772001922L
                  ),
               (f2768 | 839497) + ~(f2768 & 839497) + 1 ^ -1382484649,
               122889728173745617L
            );
            this.f2765 = (boolean)((f2768 | 659766) + ~(f2768 & 659766) + 1 ^ -1382143192);
         }
      } else if (!w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 367966343301975358L)
         || w.a<"Û">((Boolean)w.a<"Û">(this.f2749, 174312564406604366L), 354697271520518137L)) {
         this.f2762 = w.a<"Û">(this.f2767, 291084581452871205L);
         if (this.f2762 != null) {
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f2750, 174312564406604366L), 354697271520518137L)) {
               boolean var2 = w.a<"Û">(
                  w.a<"B">(w.a<"Û">(this.f2762, 224997102751365724L), 172114470161424426L),
                  (Predicate<class_2338>)var0 -> (boolean)(!w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                                 var0,
                                 310987074049434965L
                              ),
                              class_2246.field_10379,
                              272812080270536171L
                           )
                           && !w.a<"Û">(
                              w.a<"Û">(
                                 m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                                 var0,
                                 310987074049434965L
                              ),
                              class_2246.field_10560,
                              272812080270536171L
                           )
                        ? (f2768 | 976368) + ~(f2768 & 976368) + 1 ^ -1382359057
                        : (f2768 | 636576) + ~(f2768 & 636576) + 1 ^ -1382183746),
                  342868315342270588L
               );
               if (var2) {
                  w.a<"Û">(this, 155417974908982175L);
                  return;
               }
            }

            if (w.a<"Û">(this.f2761, (long)w.a<"Û">((Integer)w.a<"Û">(this.f2745, 174312564406604366L), 260981171345819427L), 309642602085515378L)) {
               this.f2763 = (boolean)((f2768 | 410308) + ~(f2768 & 410308) + 1 ^ -1382909733);
               w.a<"Û">(this.f2761, 387780412884547639L);
               w.a<"Û">(this, 315460895367475723L);
               w.a<"Û">(this, 196660424457685583L);
            }
         }
      }
   }

   public void m1096() {
      int var1 = w.a<"B">(class_1802.field_8793, 113439863899466963L);
      int var2 = (f2768 | 106833) + ~(f2768 & 106833) + 1 ^ -1382704306;
      if (var1 == ((f2768 | 91669) + ~(f2768 & 91669) + 1 ^ 1382720501)) {
         var1 = w.a<"B">(class_1802.field_8530, 113439863899466963L);
         var2 = (f2768 | 134666) + ~(f2768 & 134666) + 1 ^ -1382665196;
      }

      int var3 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545;
      if (var1 != ((f2768 | 309247) + ~(f2768 & 309247) + 1 ^ 1383035423)) {
         C0428 var4 = null;
         Iterator var5 = w.a<"Û">(class_2353.field_11062, 287411357280723181L);

         while (w.a<"Û">(var5, 333900474771661065L)) {
            class_2350 var6 = (class_2350)w.a<"Û">(var5, 192468336863492695L);
            class_2338 var7 = w.a<"Û">(w.a<"Û">(w.a<"Û">(this.f2762, 193992736062884021L), 286357605983762592L), var6, 361576458954219689L);
            if (w.a<"B">(var7, 178847294037167480L) instanceof class_2665 && !w.a<"Û">(this, this.f2762, var7, var6, 326094056185566831L)) {
               var4 = w.a<"Û">(this, (boolean)var2, var7, 145548644464996787L);
            }
         }

         if (var4 != null) {
            this.f2763 = (boolean)((f2768 | 349959) + ~(f2768 & 349959) + 1 ^ -1382978279);
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f2747, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(
                  C0933.f1412,
                  w.a<"B">(w.a<"Û">(w.a<"Û">(var4, 146353067407379815L), 229561253177300454L), w.a<"Û">(var4, 366888171225920269L), 130733282910283802L),
                  (f2768 | 332376) + ~(f2768 & 332376) + 1 ^ -1382995533,
                  236731835237641613L
               );
            }

            w.a<"B">(var1, 279757124141714355L);
            w.a<"B">(
               w.a<"Û">(var4, 146353067407379815L),
               w.a<"Û">(var4, 366888171225920269L),
               (boolean)((f2768 | 639520) + ~(f2768 & 639520) + 1 ^ -1382156225),
               class_1268.field_5808,
               360863021140479360L
            );
            w.a<"B">(class_1268.field_5808, 183891258734353801L);
            w.a<"B">(var3, 279757124141714355L);
            if (w.a<"Û">((Boolean)w.a<"Û">(this.f2755, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(C0933.f1430, this, w.a<"Û">(var4, 146353067407379815L), 283167244224626822L);
            }
         }
      }
   }

   public void m1097() {
      if (!this.f2763) {
         class_1792[] var10000 = new class_1792[(f2768 | 770001) + ~(f2768 & 770001) + 1 ^ -1382054452];
         var10000[(f2768 | 60261) + ~(f2768 & 60261) + 1 ^ -1382755974] = class_1802.field_8249;
         var10000[(f2768 | 233263) + ~(f2768 & 233263) + 1 ^ -1382566607] = class_1802.field_8105;
         int var1 = w.a<"B">(var10000, 316378340591725282L);
         int var2 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
            )
            .field_7545;
         if (var1 != ((f2768 | 308755) + ~(f2768 & 308755) + 1 ^ 1383035891)) {
            C0429 var3 = null;
            Iterator var4 = w.a<"Û">(class_2353.field_11062, 287411357280723181L);

            while (w.a<"Û">(var4, 333900474771661065L)) {
               class_2350 var5 = (class_2350)w.a<"Û">(var4, 192468336863492695L);
               class_2338 var6 = w.a<"Û">(w.a<"Û">(w.a<"Û">(this.f2762, 193992736062884021L), 286357605983762592L), var5, 361576458954219689L);
               if (!w.a<"Û">(this, this.f2762, var6, var5, 326094056185566831L)) {
                  if (w.a<"Û">(this, var6, 188622972845718771L) == w.a<"Û">(var5, 368417885573126044L)) {
                     var3 = null;
                     break;
                  }

                  if (w.a<"B">(var6, (boolean)((f2768 | 854342) + ~(f2768 & 854342) + 1 ^ -1382468776), 242496856158723858L)) {
                     C0429 var7 = w.a<"Û">(this, var6, w.a<"Û">(var5, 368417885573126044L), 242313287637729145L);
                     if (var7 != null) {
                        var3 = var7;
                     }
                  }
               }
            }

            if (var3 != null) {
               this.f2764 = w.a<"Û">(var3, 299678030495623552L);
               w.a<"Û">(
                  C0933.f1412,
                  w.a<"B">(w.a<"Û">(var3, 341513762118356899L), 213766782372904553L),
                  (f2768 | 378071) + ~(f2768 & 378071) + 1 ^ -1382940868,
                  236731835237641613L
               );
               w.a<"B">(var1, 279757124141714355L);
               w.a<"B">(
                  w.a<"Û">(var3, 299678030495623552L),
                  w.a<"Û">(var3, 162773094367151541L),
                  (boolean)((f2768 | 667052) + ~(f2768 & 667052) + 1 ^ -1382148173),
                  class_1268.field_5808,
                  360863021140479360L
               );
               w.a<"B">(class_1268.field_5808, 183891258734353801L);
               w.a<"B">(var2, 279757124141714355L);
               if (w.a<"Û">((Boolean)w.a<"Û">(this.f2755, 174312564406604366L), 354697271520518137L)) {
                  w.a<"Û">(C0933.f1430, this, w.a<"Û">(var3, 299678030495623552L), 283167244224626822L);
               }
            }
         }
      }
   }

   public C0428 m1098(boolean var1, class_2338 var2) {
      C0428 var3 = null;
      class_2350[] var4 = w.a<"B">(179161450352945543L);
      int var5 = var4.length;

      for (int var6 = (f2768 | 956323) + ~(f2768 & 956323) + 1 ^ -1382371908; var6 < var5; var6++) {
         class_2350 var7 = var4[var6];
         class_2338 var8 = w.a<"Û">(var2, var7, 361576458954219689L);
         if (w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var8, 310987074049434965L),
            class_2246.field_10002,
            272812080270536171L
         )) {
            return null;
         }

         if (w.a<"B">(var8, (boolean)((f2768 | 875642) + ~(f2768 & 875642) + 1 ^ -1382455708), 242496856158723858L)) {
            class_2350 var9 = w.a<"Û">(this, var1, var8, w.a<"Û">(var7, 368417885573126044L), 227156672077774253L);
            if (var9 != null) {
               var3 = new C0428(var9, var8);
            }
         }
      }

      return var3;
   }

   public class_2350 m1099(boolean var1, class_2338 var2, class_2350 var3) {
      if (!var1) {
         return w.a<"B">(var2, w.a<"Û">((Boolean)w.a<"Û">(this.f2746, 174312564406604366L), 354697271520518137L), 310756169772890262L);
      } else {
         class_2350[] var4 = w.a<"B">(179161450352945543L);
         int var5 = var4.length;

         for (int var6 = (f2768 | 241858) + ~(f2768 & 241858) + 1 ^ -1382577443; var6 < var5; var6++) {
            class_2350 var7 = var4[var6];
            class_2338 var8 = w.a<"Û">(var2, var7, 361576458954219689L);
            if (var3 != var7
               && w.a<"Û">(C0933.f1436, var8, 223898872679019570L)
               && (
                  !w.a<"Û">((Boolean)w.a<"Û">(this.f2746, 174312564406604366L), 354697271520518137L)
                     || w.a<"Û">(w.a<"B">(var8, 239126559569481376L), w.a<"Û">(var7, 368417885573126044L), 144617673607550225L)
               )) {
               return var7;
            }
         }

         return null;
      }
   }

   public C0429 m1100(class_2338 var1, class_2350 var2) {
      class_2350[] var3 = w.a<"B">(179161450352945543L);
      int var4 = var3.length;

      for (int var5 = (f2768 | 641580) + ~(f2768 & 641580) + 1 ^ -1382158285; var5 < var4; var5++) {
         class_2350 var6 = var3[var5];
         class_2338 var7 = w.a<"Û">(var1, var6, 361576458954219689L);
         if (w.a<"Û">(C0933.f1436, var7, 223898872679019570L)
            && (
               !w.a<"Û">((Boolean)w.a<"Û">(this.f2746, 174312564406604366L), 354697271520518137L)
                  || w.a<"Û">(w.a<"B">(var7, 239126559569481376L), w.a<"Û">(var6, 368417885573126044L), 144617673607550225L)
            )
            && (
               !w.a<"Û">((Boolean)w.a<"Û">(this.f2748, 174312564406604366L), 354697271520518137L)
                  || w.a<"B">(w.a<"Û">(C0139.f4247, var7, 166568231611948727L), 364240166945318996L)
            )) {
            if (!w.a<"Û">((Boolean)w.a<"Û">(this.f2747, 174312564406604366L), 354697271520518137L)) {
               class_243 var11 = w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 270398306108537951L),
                  w.a<"Û">(var2, 368417885573126044L),
                  w.a<"B">(((long)f2768 | 458524L) + ~((long)f2768 & 458524L) + 1L ^ -4607182420182907645L, 317139102743630955L),
                  126432286205995483L
               );
               return new C0429(var6, var1, var11);
            }

            Iterator var8 = w.a<"Û">(w.a<"Û">(C0139.f4247, var7, w.a<"Û">(var6, 368417885573126044L), 223969579123159715L), 341496865259068134L);

            while (w.a<"Û">(var8, 333900474771661065L)) {
               class_243 var9 = (class_243)w.a<"Û">(var8, 192468336863492695L);
               class_2350 var10 = w.a<"Û">(this.f2766, w.a<"B">(var9, 213766782372904553L), 197735023389184696L);
               if (var10 == w.a<"Û">(var2, 368417885573126044L)) {
                  return new C0429(var6, var1, var9);
               }
            }
         }
      }

      return null;
   }

   public boolean m1101(class_1309 var1, class_2338 var2, class_2350 var3) {
      if (w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 270398306108537951L),
            w.a<"Û">(var2, 229561253177300454L),
            180844654503832142L
         )
         > (double)w.a<"Û">(this, 159587736270965470L)) {
         return (boolean)((f2768 | 941108) + ~(f2768 & 941108) + 1 ^ -1382390230);
      } else {
         class_2338 var4 = w.a<"Û">(var2, w.a<"Û">(var3, 368417885573126044L), (f2768 | 981890) + ~(f2768 & 981890) + 1 ^ -1382366817, 216997267188579272L);
         int var5 = (f2768 | 943961) + ~(f2768 & 943961) + 1 ^ -1382392506;
         Iterator var6 = w.a<"Û">(w.a<"B">(var1, 192000415531997755L), 341496865259068134L);

         while (w.a<"Û">(var6, 333900474771661065L)) {
            class_2338 var7 = (class_2338)w.a<"Û">(var6, 192468336863492695L);
            if (w.a<"Û">(C0933.f1436, var7, 223898872679019570L)) {
               var5++;
            }
         }

         boolean var8 = w.a<"Û">(
            w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
               w.a<"Û">(var4, 210046241258394501L),
               310987074049434965L
            ),
            289106033197017315L
         );
         if (var5 > ((f2768 | 600693) + ~(f2768 & 600693) + 1 ^ -1382215576) && var8) {
            return (boolean)((f2768 | 11425) + ~(f2768 & 11425) + 1 ^ -1382803777);
         } else {
            return (boolean)(!w.a<"Û">(
                  w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var4, 310987074049434965L
                  ),
                  289106033197017315L
               )
               ? (f2768 | 442597) + ~(f2768 & 442597) + 1 ^ -1382876421
               : (f2768 | 926558) + ~(f2768 & 926558) + 1 ^ -1382409919);
         }
      }
   }

   public class_2350 m1102(class_2338 var1) {
      class_2680 var2 = w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var1, 310987074049434965L
      );
      return w.a<"Û">(var2, 152622786059621427L) instanceof class_2665 ? (class_2350)w.a<"Û">(var2, class_2318.field_10927, 241837761123994827L) : null;
   }

   public float m1103() {
      return w.a<"Û">((Float)w.a<"Û">(this.f2744, 174312564406604366L), 149784643039979208L);
   }

   public static String wQD18jUAhkPwlrg4o8v5NltBFXmPbwlwqsMp9ikQXYKL1l2q2QmVQZAl5CwvRDJCDsfvrO1PvnqmO2vsZOtW68mjafSXOgeTaCfk(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
