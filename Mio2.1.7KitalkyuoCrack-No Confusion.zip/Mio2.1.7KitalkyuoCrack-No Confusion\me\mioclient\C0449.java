package me.mioclient;

import java.util.function.Predicate;

public class C0449 implements Predicate {
   public C0113 f1508;

   public C0449(C0113 var1) {
      this.f1508 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1508.f1045, 254992554122318132L);
   }
}
