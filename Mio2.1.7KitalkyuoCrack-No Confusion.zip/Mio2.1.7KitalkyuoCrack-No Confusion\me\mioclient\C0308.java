package me.mioclient;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.nio.file.Path;
import java.util.Iterator;

public final class C0308 implements C0045 {
   public static int f3134 = w.a<"B">(8718532181387743982L, 257832362129977838L);

   public static void run() {
      Path var0 = w.a<"Û">(C1165.f0524, "friends.json", 208803259736780592L);
      Path var1 = w.a<"Û">(C1165.f0524, "socials.json", 208803259736780592L);
      if (w.a<"Û">(w.a<"Û">(var0, 318068064568792515L), 317839649527142638L) && !w.a<"Û">(w.a<"Û">(var1, 318068064568792515L), 317839649527142638L)) {
         String var2 = w.a<"B">(var0, 306889852767246998L);
         JsonObject var3 = w.a<"Û">(w.a<"B">(var2, 360179252972467592L), 322749330123725882L);
         Iterator var4 = w.a<"Û">(w.a<"Û">(var3, "friends", 345492744153864995L), 160599635136516371L);

         while (w.a<"Û">(var4, 333900474771661065L)) {
            JsonElement var5 = (JsonElement)w.a<"Û">(var4, 192468336863492695L);
            w.a<"Û">(C0933.f1417, w.a<"Û">(var5, 327479800495025542L), 268852395399414033L);
         }

         w.a<"B">(
            var1,
            w.a<"Û">(
               m$$WIXrwZ4s3IpmGVifSWBBELSopMnHWq0oi2qH3axWFDamTO1i9JlTspOMIa3dc9q8OPm3xsTZds5jMitIlfICDOaCPZa7qwQNW,
               w.a<"Û">(C0933.f1417, 333781410613905431L),
               284023674023782997L
            ),
            217352846448097781L
         );
         w.a<"Û">(w.a<"Û">(var0, 318068064568792515L), 125361176297416345L);
      }
   }
}
