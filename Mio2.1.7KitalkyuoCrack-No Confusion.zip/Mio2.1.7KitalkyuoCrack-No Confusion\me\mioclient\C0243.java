package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import org.lwjgl.glfw.GLFW;

public class C0243 extends C0293<String> {
   public final C0083 f2095 = new C0083();
   public boolean f2096;
   public String f2097;
   public int f2098;
   public static int f2099 = -2083198012;

   public C0243(C1244 var1, C1008 var2, C0015<?> var3) {
      super(var1, var2, var3);
      this.f2096 = (boolean)((f2099 | 567850) + ~(f2099 & 567850) + 1 ^ -2082717202);
      this.f2098 = (f2099 | 967904) + ~(f2099 & 967904) + 1 ^ -2082853084;
   }

   @Override
   public void m0003(double var1, double var3, int var5) {
      if (this.m$$STDt5JeVOLvpsDsEaqvKooezG4fl5lgQQRrGRKi1BSQx5RCTZiGpiNl9MhmPuA122tO5m0lfbSnyOh6ELiKUca8nxNN9fcD8V()) {
         this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO = (boolean)((f2099 | 156426)
               + ~(f2099 & 156426)
               + 1
            ^ -2083092274);
      } else {
         super.m0003(var1, var3, var5);
         if (this.m$$KS06f9f0NeLXQssz988RwWxLCd732LAhBiLrzA6AumbpOGfb45EuzpXjfSeTD0OkSNHYLtbwg5PkbT1fpFz6nDh4Qmr4NR48O(var1, var3) && var5 == 0) {
            this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO = (boolean)(!this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO
               ? (f2099 | 593521) + ~(f2099 & 593521) + 1 ^ -2082609740
               : (f2099 | 596631) + ~(f2099 & 596631) + 1 ^ -2082606765);
            if (this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO) {
               if (this.m$$sfKkICL5CwlIsogPs033QpNC9kkbNjOxClSGi2k3yBxhEgcawfo3v5R8rBLIMRozNNvOtrN2gIpv9XeUSunW7YXNzID7drO0e().m3733() != null
                  && this.m$$sfKkICL5CwlIsogPs033QpNC9kkbNjOxClSGi2k3yBxhEgcawfo3v5R8rBLIMRozNNvOtrN2gIpv9XeUSunW7YXNzID7drO0e().m3733() != this) {
                  this.m$$sfKkICL5CwlIsogPs033QpNC9kkbNjOxClSGi2k3yBxhEgcawfo3v5R8rBLIMRozNNvOtrN2gIpv9XeUSunW7YXNzID7drO0e().m3733().f4577 = (boolean)((
                           f2099 | 996509
                        )
                        + ~(f2099 & 996509)
                        + 1
                     ^ -2082742439);
               }

               this.m$$sfKkICL5CwlIsogPs033QpNC9kkbNjOxClSGi2k3yBxhEgcawfo3v5R8rBLIMRozNNvOtrN2gIpv9XeUSunW7YXNzID7drO0e().m3734(this);
            } else if (this.m$$sfKkICL5CwlIsogPs033QpNC9kkbNjOxClSGi2k3yBxhEgcawfo3v5R8rBLIMRozNNvOtrN2gIpv9XeUSunW7YXNzID7drO0e().m3733() == this) {
               this.m$$sfKkICL5CwlIsogPs033QpNC9kkbNjOxClSGi2k3yBxhEgcawfo3v5R8rBLIMRozNNvOtrN2gIpv9XeUSunW7YXNzID7drO0e().m3734(null);
            }

            this.f2097 = (String)this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getValue();
            if (this.f2097 != null && !this.f2097.isEmpty()) {
               this.f2098 = this.f2097.length();
            }
         }
      }
   }

   public void m2854(class_332 var1, class_4587 var2, double var3, double var5) {
      if (this.m$$STDt5JeVOLvpsDsEaqvKooezG4fl5lgQQRrGRKi1BSQx5RCTZiGpiNl9MhmPuA122tO5m0lfbSnyOh6ELiKUca8nxNN9fcD8V()) {
         if (this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO
            && this.m$$sfKkICL5CwlIsogPs033QpNC9kkbNjOxClSGi2k3yBxhEgcawfo3v5R8rBLIMRozNNvOtrN2gIpv9XeUSunW7YXNzID7drO0e().m3733() == this) {
            this.m$$sfKkICL5CwlIsogPs033QpNC9kkbNjOxClSGi2k3yBxhEgcawfo3v5R8rBLIMRozNNvOtrN2gIpv9XeUSunW7YXNzID7drO0e().m3734(null);
         }

         this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO = (boolean)((f2099 | 331016)
               + ~(f2099 & 331016)
               + 1
            ^ -2083395892);
      } else {
         super.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(var1, var2, var3, var5);
         if (this.m$$Cyfyk5OMQSnlg0Q0ageBpOGLRjg1rgovHKt6FL6P1atToUuY0RXlw1MESRBF7pV5ASO7ZCRHy1JeA1EIR9q5GwA1SnbjOF5EH) {
            C1214.f0644 = C0371.f0345;
         }

         C0438.m3962(
            var2,
            (float)(
               this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                  + this.m$$NS6TKVieR7Xlj1stwELtzhosiSSdbbqnOWlolJ0xXC4zrfT8Xy1aT9eDfPClVRYR4rkRGXRycEszCfpQdjHBpGXBWCmEzMF7H()
            ),
            (float)(
                  this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                     + this.m$$hlCUpAMCB8w0fikXDazwCNyOBsPOGWgAm2lmO5tu7dGyqkbhliec158gzgZe9bnF3DuoOxLmXH5dfCU0wQDHsWXD8knX2Gis1
               )
               + Float.intBitsToFloat((f2099 | 448683) + ~(f2099 & 448683) + 1 ^ -1127074961),
            (float)(
               this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                  + this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.m0240()
                  - ((f2099 | 476548) + ~(f2099 & 476548) + 1 ^ -2083279295)
            ),
            (float)(
                  this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                     + this.m$$hlCUpAMCB8w0fikXDazwCNyOBsPOGWgAm2lmO5tu7dGyqkbhliec158gzgZe9bnF3DuoOxLmXH5dfCU0wQDHsWXD8knX2Gis1
                     + this.m$$xdvvw3zUfaxk5zyR1LuOyULP1ncsBH0Jp7Rg4gVMI1b0GhMBLMGdWDzO5FqEI2nDnNORyLVYlZg5A0VP0jSXwr08L1rXIE9mU()
               )
               - Float.intBitsToFloat((f2099 | 346818) + ~(f2099 & 346818) + 1 ^ -1127112442),
            this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3779.getValue()
         );
         if (this.f2097 != null) {
            this.f2098 = class_3532.method_15340(this.f2098, (f2099 | 4558) + ~(f2099 & 4558) + 1 ^ -2083194358, this.f2097.length());
         }

         if (this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO) {
            var2.method_22903();
            String var7 = this.m2857();
            float var8 = C0498.f4738
               .m3896(new C1002().m2591(this.f2097.substring((f2099 | 276704) + ~(f2099 & 276704) + 1 ^ -2083466460, this.f2098)).m2593("\u0001_"));
            if (var8
               > (float)(
                  this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().m0240()
                     - this.m$$NS6TKVieR7Xlj1stwELtzhosiSSdbbqnOWlolJ0xXC4zrfT8Xy1aT9eDfPClVRYR4rkRGXRycEszCfpQdjHBpGXBWCmEzMF7H()
                        * ((f2099 | 415197) + ~(f2099 & 415197) + 1 ^ -2083340773)
               )) {
               var2.method_46416(
                  (float)(
                        this.m$$F2VfRczxZgfSe3elTQhPXeEksLehCkyfAuyqtTiWZTRt0Js08hZqVR8N3vuoeqziiTFXxmCcxA9OCdO6VEZ1GrXbj54aT0ytc().m0240()
                           - this.m$$NS6TKVieR7Xlj1stwELtzhosiSSdbbqnOWlolJ0xXC4zrfT8Xy1aT9eDfPClVRYR4rkRGXRycEszCfpQdjHBpGXBWCmEzMF7H()
                              * ((f2099 | 309698) + ~(f2099 & 309698) + 1 ^ -2083499516)
                     )
                     - var8,
                  0.0F,
                  0.0F
               );
            }

            if (!this.f2097.isEmpty()) {
               C0498.f4738
                  .m3889(
                     var1,
                     this.f2097,
                     (float)(
                        this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                           + ((f2099 | 383874) + ~(f2099 & 383874) + 1 ^ -2083442622)
                     ),
                     (float)this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                        + this.m$$Q6v7Z8vHWixFGmnIwtPT9IRjbEDcp4pbIBg72K4rvMLMAvr4NRM7tkUiW5GGFIwz5ErOctZd5wyLot9rbgaFeWhVicVZ9yVxZ()
                        - this.m$$F4zako7ZnM6Q4oBXFdOvlGhEdnVEGYRWpCXVM3b498QSheE2JxUfvz3PeTnhcFs37rb30sKqxM30g1NRLsO51EuMfjqHIZr01()
                        + (float)this.m$$hlCUpAMCB8w0fikXDazwCNyOBsPOGWgAm2lmO5tu7dGyqkbhliec158gzgZe9bnF3DuoOxLmXH5dfCU0wQDHsWXD8knX2Gis1,
                     this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3776.getValue()
                  );
            }

            if (!var7.isBlank()) {
               C0498.f4738
                  .m3889(
                     var1,
                     var7,
                     (float)(
                           this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                              + ((f2099 | 711523) + ~(f2099 & 711523) + 1 ^ -2082590557)
                        )
                        + C0498.f4738.m3896(this.f2097.substring((f2099 | 227302) + ~(f2099 & 227302) + 1 ^ -2083021790, this.f2098)),
                     (float)this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                        + this.m$$Q6v7Z8vHWixFGmnIwtPT9IRjbEDcp4pbIBg72K4rvMLMAvr4NRM7tkUiW5GGFIwz5ErOctZd5wyLot9rbgaFeWhVicVZ9yVxZ()
                        - this.m$$F4zako7ZnM6Q4oBXFdOvlGhEdnVEGYRWpCXVM3b498QSheE2JxUfvz3PeTnhcFs37rb30sKqxM30g1NRLsO51EuMfjqHIZr01()
                        + (float)this.m$$hlCUpAMCB8w0fikXDazwCNyOBsPOGWgAm2lmO5tu7dGyqkbhliec158gzgZe9bnF3DuoOxLmXH5dfCU0wQDHsWXD8knX2Gis1,
                     this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3776.getValue()
                  );
            }

            var2.method_22909();
         } else {
            String var9 = new C1002()
               .m2591((String)this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getValue())
               .m2591(this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getName())
               .m2593("\u0001: \u0001");
            this.m$$H4ZB5VRjXea6ADgAn7oqhkF1jdY2RLRFdAhjRxioAK3g7dPU84hlRjGs8rjdVIiyq3olBiqej55jhKcEKsFLMteWctvBZwGDg(
               var2,
               var9,
               () -> C0498.f4738
                     .m3889(
                        var1,
                        new C1002()
                           .m2591((String)this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getValue())
                           .m2591(this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.getName())
                           .m2593("\u0001: \u0001"),
                        (float)(
                           this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
                              + ((f2099 | 838252) + ~(f2099 & 838252) + 1 ^ -2082987604)
                        ),
                        (float)this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
                           + this.m$$Q6v7Z8vHWixFGmnIwtPT9IRjbEDcp4pbIBg72K4rvMLMAvr4NRM7tkUiW5GGFIwz5ErOctZd5wyLot9rbgaFeWhVicVZ9yVxZ()
                           - this.m$$F4zako7ZnM6Q4oBXFdOvlGhEdnVEGYRWpCXVM3b498QSheE2JxUfvz3PeTnhcFs37rb30sKqxM30g1NRLsO51EuMfjqHIZr01()
                           + (float)this.m$$hlCUpAMCB8w0fikXDazwCNyOBsPOGWgAm2lmO5tu7dGyqkbhliec158gzgZe9bnF3DuoOxLmXH5dfCU0wQDHsWXD8knX2Gis1,
                        this.m$$RMYwRgyl7vvgm1H2lo9ktTEAKiIDvTunbc3az4N3Oaj484okgkcjCPFt1Y13NM7WuhGQlRXRy1LG34HAHpl3bQqOTw5JlDdEu().f3776.getValue()
                     )
            );
         }
      }
   }

   public void m2855(int var1) {
      if (!this.m$$STDt5JeVOLvpsDsEaqvKooezG4fl5lgQQRrGRKi1BSQx5RCTZiGpiNl9MhmPuA122tO5m0lfbSnyOh6ELiKUca8nxNN9fcD8V()) {
         if (this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO) {
            C0933.m2652().m$$7QWhPyjVBRfqVyU4WWL6xElrdYPfVLeVIqfgFytt3G6T0McudbmIYVtMO0ljqR2koeSOHm7L7jGs6keQpgagLh7kzcdr0D3B5();
            switch (var1) {
               case 86:
                  if (GLFW.glfwGetKey(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4490(),
                        (f2099 | 664549) + ~(f2099 & 664549) + 1 ^ -2082551436
                     )
                     == ((f2099 | 589637) + ~(f2099 & 589637) + 1 ^ -2082728832)) {
                     this.f2097 = new StringBuilder(this.f2097)
                        .insert(
                           this.f2098,
                           m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1774.method_1460()
                        )
                        .toString();
                  }
                  break;
               case 256:
                  this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO = (boolean)((f2099 | 758152)
                        + ~(f2099 & 758152)
                        + 1
                     ^ -2082506164);
                  break;
               case 257:
                  this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO = (boolean)((f2099 | 238889)
                        + ~(f2099 & 238889)
                        + 1
                     ^ -2083041555);
                  this.m$$lcsK03SA5Uzf6wbRbQ3Gyei3NLvWgLlLpsuyxu7J47EMHW3DQr1eadbZKYZ9X1WwYOys2RS5VtAUQtmcQIirvqXan3F1K71WH.m2603(this.f2097);
                  this.f2098 = this.f2097.length();
                  break;
               case 259:
                  if (this.f2097.length() == 0 || this.f2098 == 0) {
                     return;
                  }

                  int var2 = this.f2098 - ((f2099 | 624042) + ~(f2099 & 624042) + 1 ^ -2082640273);
                  if (this.f2098 == this.f2097.length()) {
                     this.f2097 = this.f2097
                        .substring(
                           (f2099 | 114456) + ~(f2099 & 114456) + 1 ^ -2083171108,
                           this.f2097.length() - ((f2099 | 441088) + ~(f2099 & 441088) + 1 ^ -2083368763)
                        );
                  } else if (var2 >= 0 && var2 <= this.f2097.length()) {
                     this.f2097 = new StringBuilder(this.f2097).deleteCharAt(var2).toString();
                  }

                  this.f2098 = this.f2098 - ((f2099 | 868940) + ~(f2099 & 868940) + 1 ^ -2082887287);
                  break;
               case 262:
                  if (this.f2098 < this.f2097.length()) {
                     this.f2098 = this.f2098 + ((f2099 | 180329) + ~(f2099 & 180329) + 1 ^ -2083116116);
                  }
                  break;
               case 263:
                  if (this.f2098 > 0) {
                     this.f2098 = this.f2098 - ((f2099 | 793681) + ~(f2099 & 793681) + 1 ^ -2082932844);
                  }
            }
         }
      }
   }

   public void m2856(char var1) {
      if (!this.m$$STDt5JeVOLvpsDsEaqvKooezG4fl5lgQQRrGRKi1BSQx5RCTZiGpiNl9MhmPuA122tO5m0lfbSnyOh6ELiKUca8nxNN9fcD8V()) {
         if (this.m$$en7dw3SSbEtpzPoDTevWYS9QYbRYTgaQIqrUuV2TB1QfMIBlMMissIRLUbPFd5nuixm0kNp4zesjwhaf3DyLmS0VUj1LEWBcO) {
            this.f2097 = new StringBuilder(this.f2097).insert(this.f2098, var1).toString();
            this.f2098 = this.f2098 + ((f2099 | 39405) + ~(f2099 & 39405) + 1 ^ -2083229144);
         }
      }
   }

   public String m2857() {
      if (this.f2095.m1675(((long)f2099 | 157478L) + ~((long)f2099 & 157478L) + 1L ^ -2083091178L)) {
         this.f2096 = (boolean)(!this.f2096 ? (f2099 | 640484) + ~(f2099 & 640484) + 1 ^ -2082656735 : (f2099 | 934433) + ~(f2099 & 934433) + 1 ^ -2082821659);
         this.f2095.reset();
      }

      return this.f2096 ? "_" : "";
   }

   static {
      long var10000 = 1175701314972293489L;
   }

   public static String H09F2F8XKOGaRO1bp3VzPT0pExR8Wlb6ZCVFSaaQiYY8I7nt4xS6W7m0ObwQBeZrNugkykAIuGQSlzgXrGKGLi74XVenMKzoB7Jp(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
