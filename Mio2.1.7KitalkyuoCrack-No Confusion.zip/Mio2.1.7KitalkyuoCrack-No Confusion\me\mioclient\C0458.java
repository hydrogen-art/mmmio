package me.mioclient;

import java.util.Iterator;
import net.minecraft.class_1297;
import net.minecraft.class_1690;
import net.minecraft.class_2246;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2627;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2627.class_2628;

public class C0458 extends C0105 {
   public static C0303 f2034 = C0933.f1409.m2696(C0303.class);
   public class_238 f2035;
   public static int f2036 = w.a<"B">(6865742255956801613L, 257832362129977838L);

   public C0458(C0345 var1) {
      super(var1);
   }

   @Override
   public void m0455(C0650 var1) {
      if (this.f2035 != null) {
         if (w.a<"B">(239474890139367192L)) {
            int var2 = (f2036 | 408516) + ~(f2036 & 408516) + 1 ^ 414612985;
            Iterator var3 = w.a<"Û">(w.a<"B">(307461254337034737L), 341496865259068134L);

            while (w.a<"Û">(var3, 333900474771661065L)) {
               class_2586 var4 = (class_2586)w.a<"Û">(var3, 192468336863492695L);
               if (var4 instanceof class_2627) {
                  class_2627 var5 = (class_2627)var4;
                  if (w.a<"Û">(
                        w.a<"Û">(
                           this.f2035,
                           w.a<"B">(((long)f2036 | 505486L) + ~((long)f2036 & 505486L) + 1L ^ 4602678819587354803L, 317139102743630955L),
                           130605157384247280L
                        ),
                        w.a<"Û">(
                           w.a<"Û">(var5, w.a<"Û">(class_2246.field_10603, 371018036170469473L), 316007582841547451L),
                           w.a<"Û">(var4, 269630716540245963L),
                           252103202185457587L
                        ),
                        133676266014519719L
                     )
                     && w.a<"Û">(var5, 203080976091795888L) != class_2628.field_12065) {
                     var2 += w.a<"Û">(f2034, 317419592226466359L)
                        ? (f2036 | 257129) + ~(f2036 & 257129) + 1 ^ 414427732
                        : (f2036 | 7342) + ~(f2036 & 7342) + 1 ^ 414210711;
                  }
               }
            }

            float var6 = w.a<"Û">(f2034, 317419592226466359L) ? 0.0F : w.a<"B">((f2036 | 614882) + ~(f2036 & 614882) + 1 ^ 658057183, 349057757755238323L);
            Iterator var7 = w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
               191661729848227466L
            );

            while (w.a<"Û">(var7, 333900474771661065L)) {
               class_1297 var10 = (class_1297)w.a<"Û">(var7, 192468336863492695L);
               if (!(var10 instanceof C0804)
                  && var10 != m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724
                  && w.a<"Û">(var10, 314577643944602543L)
                  && w.a<"Û">(w.a<"Û">(var10, 225708705569795011L), w.a<"Û">(this.f2035, (double)var6, 130605157384247280L), 133676266014519719L)) {
                  if (var10 instanceof class_1690) {
                     var2 += 4;
                  }

                  var2++;
               }
            }

            if (var2 != 0) {
               class_243 var8 = w.a<"Û">(w.a<"Û">(var1, 240677964963708953L), 255657378358618113L);
               class_243 var9 = w.a<"Û">(var8, class_2351.field_11052, 0.0, 156744506625070247L);
               w.a<"Û">(
                  var1,
                  w.a<"Û">(
                     w.a<"Û">(var1, 240677964963708953L),
                     w.a<"Û">(
                        var9,
                        w.a<"B">(((long)f2036 | 363254L) + ~((long)f2036 & 363254L) + 1L ^ 4590429028579268784L, 317139102743630955L) * (double)var2,
                        310215828564446757L
                     ),
                     300445064978294627L
                  ),
                  326881584648207186L
               );
            }
         }
      }
   }

   @Override
   public void m0456(C1095 var1) {
      if (w.a<"Û">(var1, 336212328865671254L) == C0277.f4215) {
         this.f2035 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 261249985676109960L
         );
      }
   }
}
