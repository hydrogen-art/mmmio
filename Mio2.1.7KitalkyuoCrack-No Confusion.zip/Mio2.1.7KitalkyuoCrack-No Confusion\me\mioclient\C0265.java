package me.mioclient;

import java.util.function.Predicate;

public class C0265 implements Predicate {
   public C0309 f1275;

   public C0265(C0309 var1) {
      this.f1275 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(C0933.f1444, 295997551300011996L);
   }
}
