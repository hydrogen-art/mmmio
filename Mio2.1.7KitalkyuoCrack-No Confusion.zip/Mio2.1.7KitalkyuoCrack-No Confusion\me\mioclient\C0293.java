package me.mioclient;

import net.minecraft.class_4587;

public abstract class C0293<T> extends C0684 {
   public final C1008 f4572;
   public final C0015<T> f4573;
   public final C0072 f4574 = new C0072();
   public boolean f4575;
   public long f4576;
   public boolean f4577;
   public static int f4578 = -12411204;

   public C0293(C1244 var1, C0015<T> var2) {
      this(var1, () -> (boolean)((f4578 | 743082) + ~(f4578 & 743082) + 1 ^ -11941866), var2);
   }

   public C0293(C1244 var1, C1008 var2, C0015<T> var3) {
      super(var1, (f4578 | 507968) + ~(f4578 & 507968) + 1 ^ -12230916);
      this.f4572 = var2;
      this.f4573 = var3;
   }

   public int m0172() {
      return !this.f4573.m3411()
         ? (f4578 | 767156) + ~(f4578 & 767156) + 1 ^ -11982328
         : this.m$$4pV0XlRIp4cDUyskylgOmPZTmM1Cm1Gb3t6qmsm9WaHYQRZKVwi9AWUFUSK0Q6Q4SAfIUacgGminfDDGkwXZhAbLvD3aANrPL();
   }

   public C1008 m3837() {
      return this.f4572;
   }

   public C0015<T> m3838() {
      return this.f4573;
   }

   public boolean m3839() {
      int var1 = this.f4573.m3411() && !this.f4572.isClosed()
         ? (f4578 | 786414) + ~(f4578 & 786414) + 1 ^ -11968174
         : (f4578 | 2258) + ~(f4578 & 2258) + 1 ^ -12413329;
      if (var1 != 0) {
         this.f4573.f3315 = (boolean)((f4578 | 258053) + ~(f4578 & 258053) + 1 ^ -12489031);
      }

      return (boolean)var1;
   }

   public void m3840(class_4587 var1, String var2, Runnable var3) {
      var1.method_22903();
      this.m3841(C0498.f4738.m3896(var2));
      float var4 = -this.f4574.m0795();
      int var5 = var4 != 0.0F && !(this instanceof C0220)
         ? (f4578 | 455836) + ~(f4578 & 455836) + 1 ^ -12293599
         : (f4578 | 343889) + ~(f4578 & 343889) + 1 ^ -12082707;
      if (var5 != 0) {
         C0914 var6 = (C0914)this.f4572;
         C0438.m3968();
         C0089.m1009(
            this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getX()
               + this.m$$NS6TKVieR7Xlj1stwELtzhosiSSdbbqnOWlolJ0xXC4zrfT8Xy1aT9eDfPClVRYR4rkRGXRycEszCfpQdjHBpGXBWCmEzMF7H(),
            this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.getY()
               + var6.m$$1naCvMBH12oymvzHXaMb44zjA3kXs0E6bMAD4z1nJUpyI8qXT8hRKQ76Bf2ybbpbmIOkLNIBOnIiSRElzQQTzuMlOGHxKHQvu(),
            this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.m0240()
               - this.m$$NS6TKVieR7Xlj1stwELtzhosiSSdbbqnOWlolJ0xXC4zrfT8Xy1aT9eDfPClVRYR4rkRGXRycEszCfpQdjHBpGXBWCmEzMF7H(),
            var6.m2432()
         );
      }

      var1.method_46416(var4, 0.0F, 0.0F);
      var3.run();
      if (var5 != 0) {
         C0438.m3968();
         C0089.m1010();
      }

      var1.method_22909();
   }

   public void m3841(float var1) {
      if (var1
         <= (float)(
            this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.m0240()
               - ((f4578 | 972580) + ~(f4578 & 972580) + 1 ^ -11777636)
         )) {
         this.f4574.m0794(0.0F);
      } else {
         if (this.m$$Cyfyk5OMQSnlg0Q0ageBpOGLRjg1rgovHKt6FL6P1atToUuY0RXlw1MESRBF7pV5ASO7ZCRHy1JeA1EIR9q5GwA1SnbjOF5EH) {
            if (!this.f4575) {
               this.f4576 = System.currentTimeMillis();
            }

            if (System.currentTimeMillis() > this.f4576 + (((long)f4578 | 205448L) + ~((long)f4578 & 205448L) + 1L ^ -12468518L)) {
               this.f4574
                  .m0792(
                     var1
                        - (float)(
                           this.m$$WdQySQFfK5inj4ZJGVO6i5WS7jlaOT0fUXzeE72Sw9Wmijq6vyjlGV1NVssQ5YaIBkwJ733gAhF7vRR3FxyvTRYFBXWiENTbT.m0240()
                              - ((f4578 | 872468) + ~(f4578 & 872468) + 1 ^ -11546964)
                        ),
                     ((long)f4578 | 454557L) + ~((long)f4578 & 454557L) + 1L ^ -12291883L
                  );
            }
         } else {
            this.f4574.m0792(0.0F, ((long)f4578 | 939175L) + ~((long)f4578 & 939175L) + 1L ^ -11744273L);
         }

         this.f4575 = this.m$$Cyfyk5OMQSnlg0Q0ageBpOGLRjg1rgovHKt6FL6P1atToUuY0RXlw1MESRBF7pV5ASO7ZCRHy1JeA1EIR9q5GwA1SnbjOF5EH;
      }
   }

   @Override
   public void m0003(double var1, double var3, int var5) {
      if (!this.m3839()) {
         super.m0003(var1, var3, var5);
      }
   }

   public C1163 m3842() {
      return C0933.m2652();
   }

   static {
      long var10000 = 6005768173315686600L;
   }
}
