package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;

public enum C0383 implements C0045, C0196 {
   f4383("None"),
   f4384("Normal") {
      @Override
      public void m1767(int var1, Runnable var2) {
         w.a<"B">(var1, 279757124141714355L);
         w.a<"Û">(var2, 324159666149362285L);
      }
   },
   f4385("Silent") {
      @Override
      public void m1767(int var1, Runnable var2) {
         int var3 = w.a<"Û">(
               m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L
            )
            .field_7545;
         w.a<"B">(var1, 279757124141714355L);
         w.a<"Û">(var2, 324159666149362285L);
         w.a<"B">(var3, 279757124141714355L);
      }
   };

   public final String f4386;

   public C0383(String var3) {
      this.f4386 = var3;
   }

   @Override
   public String getName() {
      return this.f4386;
   }

   public void m1767(int var1, Runnable var2) {
      if (w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545
         == var1) {
         w.a<"Û">(var2, 324159666149362285L);
      }
   }

   public static String kcld5BBRefpMwjt1q00RJc0KA58N5PAB1RzuaFRGBWDKRFPO0XntZv2bsq2hTpNRPXp8sGXFp9zOK9iAp8P8iE5BO2E7ywRCcrmE(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
