package me.mioclient;

import java.util.function.Predicate;

public class C0142 implements Predicate {
   public C0931 f0186;

   public C0142(C0931 var1) {
      this.f0186 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0186.f2424, 254992554122318132L);
   }
}
