package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.List;
import net.minecraft.class_2338;

enum C0412 implements C0196 {
   f0457("Crosshair") {
      @Override
      public List<class_2338> m2297(C0411 var1) {
         return w.a<"B">(w.a<"B">(w.a<"Û">(C0045.f2103.field_1765, 152935392184286408L), 274163478939689086L), 201810025483049824L);
      }
   },
   f0458("Sphere") {
      @Override
      public List<class_2338> m2297(C0411 var1) {
         return w.a<"B">(
            w.a<"Û">(C0045.f2103.field_1724, 114479647550158442L),
            w.a<"Û">((Float)w.a<"Û">(var1.f0686, 174312564406604366L), 149784643039979208L),
            true,
            297851292504232202L
         );
      }
   };

   public final String f0459;

   public C0412(String var3) {
      this.f0459 = var3;
   }

   @Override
   public String getName() {
      return this.f0459;
   }

   public abstract List<class_2338> m2297(C0411 var1);

   public static String l5wKk7WqVSKrm4QxN194Y2lHxXttIhV8VMP1dL8FVwN2GKdJqf4GmMrsVTy9K8WaaXIsf8BIMmxEnm2n7fLIxCkLCSegXLEmieFJ(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
