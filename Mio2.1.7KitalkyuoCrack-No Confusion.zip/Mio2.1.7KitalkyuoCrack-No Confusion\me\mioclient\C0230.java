package me.mioclient;

import java.util.function.Predicate;

public class C0230 implements Predicate {
   public C0018 f0780;

   public C0230(C0018 var1) {
      this.f0780 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0780.f4095, 174312564406604366L) == C0020.f0357;
   }
}
