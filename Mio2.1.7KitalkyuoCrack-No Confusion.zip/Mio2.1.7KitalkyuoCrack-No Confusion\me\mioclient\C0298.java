package me.mioclient;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.function.Predicate;

public abstract class C0298<T> extends C0015<Set<T>> {
   public T f4850;
   public static int f4851 = w.a<"B">(2626623696804985890L, 257832362129977838L);

   @SafeVarargs
   public C0298(String var1, T... var2) {
      super(var1, new ObjectOpenHashSet());
      w.a<"Û">((Set)w.a<"Û">(this, 231406999951969558L), w.a<"B">(var2, 229368493351775837L), 182818729096028278L);
      w.a<"Û">((Set)w.a<"Û">(this, 174312564406604366L), w.a<"B">(var2, 229368493351775837L), 182818729096028278L);
   }

   @SafeVarargs
   public C0298(String var1, Predicate<Set<T>> var2, T... var3) {
      super(var1, new ObjectOpenHashSet(), var2);
      w.a<"Û">((Set)w.a<"Û">(this, 231406999951969558L), w.a<"B">(var3, 229368493351775837L), 182818729096028278L);
      w.a<"Û">((Set)w.a<"Û">(this, 174312564406604366L), w.a<"B">(var3, 229368493351775837L), 182818729096028278L);
   }

   public abstract T m0855(String var1);

   public abstract String m0854(T var1);

   public abstract Collection<T> m0853();

   public Set<String> m3949() {
      ObjectOpenHashSet var1 = new ObjectOpenHashSet();
      Iterator var2 = w.a<"Û">((Set)w.a<"Û">(this, 174312564406604366L), 194435811056609302L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         Object var3 = w.a<"Û">(var2, 192468336863492695L);
         w.a<"Û">(var1, w.a<"Û">(this, var3, 370718506324770253L), 309270453639690490L);
      }

      return var1;
   }

   @Override
   public void m0645(String var1) {
      Object var2 = w.a<"Û">(this, var1, 317259606439523897L);
      if (var2 == null) {
         throw new IllegalArgumentException();
      } else {
         if (w.a<"Û">(this, var2, 115874567935130091L)) {
            w.a<"Û">(this, var2, 349616046991813941L);
         } else {
            w.a<"Û">(this, var2, 164039534772424779L);
         }
      }
   }

   public Collection<String> m3950() {
      HashSet var1 = new HashSet();
      Iterator var2 = w.a<"Û">(w.a<"Û">(this, 334415201058939559L), 277715502174036685L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         Object var3 = w.a<"Û">(var2, 192468336863492695L);
         w.a<"Û">(var1, w.a<"Û">(this, var3, 370718506324770253L), 309270453639690490L);
      }

      return var1;
   }

   public void m3951(T var1) {
      if (var1 != null) {
         w.a<"Û">((Set)w.a<"Û">(this, 174312564406604366L), var1, 309270453639690490L);
         this.f4850 = (T)var1;
         if (this.m$$hEvN2fRYnhg0W6PnTKGDdyepD6SNxBMYOiaFucVZPXbi5iuQgNdM9KEfzkWQrzbyoTXViLRJqeS1gS0hm2yiAPsfVXYEUOZ6o != null) {
            w.a<"Û">(this.m$$hEvN2fRYnhg0W6PnTKGDdyepD6SNxBMYOiaFucVZPXbi5iuQgNdM9KEfzkWQrzbyoTXViLRJqeS1gS0hm2yiAPsfVXYEUOZ6o, 324159666149362285L);
         }
      }
   }

   public void m3952(String var1) {
      if (var1 != null) {
         w.a<"Û">(this, w.a<"Û">(this, var1, 317259606439523897L), 164039534772424779L);
      }
   }

   public void m3953(T var1) {
      if (var1 != null) {
         w.a<"Û">((Set)w.a<"Û">(this, 174312564406604366L), var1, 124697318442522382L);
         this.f4850 = (T)var1;
         if (this.m$$hEvN2fRYnhg0W6PnTKGDdyepD6SNxBMYOiaFucVZPXbi5iuQgNdM9KEfzkWQrzbyoTXViLRJqeS1gS0hm2yiAPsfVXYEUOZ6o != null) {
            w.a<"Û">(this.m$$hEvN2fRYnhg0W6PnTKGDdyepD6SNxBMYOiaFucVZPXbi5iuQgNdM9KEfzkWQrzbyoTXViLRJqeS1gS0hm2yiAPsfVXYEUOZ6o, 324159666149362285L);
         }
      }
   }

   public void m3954(String var1) {
      if (var1 != null) {
         w.a<"Û">(this, w.a<"Û">(this, var1, 317259606439523897L), 349616046991813941L);
      }
   }

   public boolean m3955(T var1) {
      return (boolean)(var1 == null
         ? (f4851 | 81689) + ~(f4851 & 81689) + 1 ^ -1340402077
         : w.a<"Û">((Set)w.a<"Û">(this, 174312564406604366L), var1, 338145669613544495L));
   }

   public boolean m3956(String var1) {
      return (boolean)(var1 == null
         ? (f4851 | 8348) + ~(f4851 & 8348) + 1 ^ -1340470810
         : w.a<"Û">(this, w.a<"Û">(this, var1, 317259606439523897L), 115874567935130091L));
   }

   public T m3957() {
      return this.f4850;
   }

   @Override
   public JsonElement toJson() {
      JsonArray var1 = new JsonArray();
      Iterator var2 = w.a<"Û">((Set)w.a<"Û">(this, 174312564406604366L), 194435811056609302L);

      while (w.a<"Û">(var2, 333900474771661065L)) {
         Object var3 = w.a<"Û">(var2, 192468336863492695L);
         w.a<"Û">(var1, w.a<"Û">(this, var3, 370718506324770253L), 342149247544151917L);
      }

      return var1;
   }
}
