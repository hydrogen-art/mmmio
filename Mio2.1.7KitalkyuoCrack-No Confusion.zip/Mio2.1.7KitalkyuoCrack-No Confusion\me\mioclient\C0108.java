package me.mioclient;

import java.util.function.Predicate;

public class C0108 implements Predicate {
   public C0309 f1022;

   public C0108(C0309 var1) {
      this.f1022 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f1022.f3402, 140659502048675535L)
         && (w.a<"Û">(this.f1022.f3402, 174312564406604366L) == C0311.f2830 || w.a<"Û">(this.f1022.f3402, 174312564406604366L) == C0311.f2831);
   }
}
