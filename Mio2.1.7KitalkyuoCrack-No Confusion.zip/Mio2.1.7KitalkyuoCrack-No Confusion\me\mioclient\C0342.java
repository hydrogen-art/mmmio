package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_2172;

public final class C0342 extends C0219 {
   public static int f0024 = w.a<"B">(4173099496275459766L, 257832362129977838L);

   public C0342() {
      super("coords");
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         (LiteralArgumentBuilder)w.a<"Û">(var1, w.a<"Û">(w.a<"B">("name", new C0403(), 191188367299315725L), (Command)var1x -> {
            w.a<"Û">(this, (String)w.a<"Û">(var1x, "name", String.class, 275658406246533271L), w.a<"Û">(this, 383627927520721795L), 223755885391062176L);
            return (f0024 | 125041) + ~(f0024 & 125041) + 1 ^ 897595352;
         }, 368995281709124746L), 289819728773344295L),
         (Command)var1x -> {
            try {
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1774,
                  w.a<"Û">(this, 383627927520721795L),
                  194738086810821242L
               );
               w.a<"B">(
                  w.a<"B">("Your position has been copied to the clipboard.", 228465064790135899L),
                  w.a<"B">((f0024 | 941384) + ~(f0024 & 941384) + 1 ^ -898597601, 289296048454852994L),
                  241936116971186271L
               );
            } catch (Exception var3) {
            }

            return (f0024 | 526833) + ~(f0024 & 526833) + 1 ^ 898225752;
         },
         286944572020109927L
      );
   }

   public String m2152() {
      return m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724 == null
         ? ""
         : new C1002()
            .m2578(
               (int)w.a<"B">(
                  w.a<"B">(329795338200638383L) * w.a<"B">(((long)f0024 | 268998L) + ~((long)f0024 & 268998L) + 1L ^ 4666723173365302638L, 317139102743630955L),
                  143282796194555966L
               )
            )
            .m2591(w.a<"Û">(w.a<"B">(375727057840316412L), 149171774907305862L))
            .m2578(
               (int)w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 310441135103619165L
               )
            )
            .m2578(
               (int)w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 358934561846661819L
               )
            )
            .m2578(
               (int)w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 268094392877253824L
               )
            )
            .m2593("X: \u0001, Y: \u0001, Z: \u0001 in The \u0001 [\u0001]");
   }

   public void m2153(String var1, String var2) {
      String var3 = new C1002().m2591(var2).m2591(var1).m2593("w \u0001 \u0001");
      w.a<"Û">(
         m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944, var3, 125463245891162392L
      );
   }

   public static String y5EUTCUMC7NUBUMqKK8E3kBaFEQycoo2lZr1qNIEw4jIVUgYhHsyNhKzB0BRXjOpCepF7d8bQPcVvIMA4jDj9iDQMXhhSSjbJyZ8(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
