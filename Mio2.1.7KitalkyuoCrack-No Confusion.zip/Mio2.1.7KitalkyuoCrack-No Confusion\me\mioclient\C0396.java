package me.mioclient;

import java.awt.Color;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1684;
import net.minecraft.class_1944;
import net.minecraft.class_1972;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2767;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3562;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4618;
import net.minecraft.class_757;
import net.minecraft.class_9801;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;

public class C0396 extends C1266 {
   public static C0818 f0129 = C0933.f1409.m2696(C0818.class);
   public final C0015<Boolean> f0130;
   public final C0015<Boolean> f0131;
   public final C0015<Boolean> f0132;
   public final C0015<Boolean> f0133;
   public final C0015<Color> f0134;
   public final C0015<Color> f0135;
   public final C0015<Boolean> f0136;
   public final C0015<Color> f0137;
   public final C0015<Color> f0138;
   public final C0015<Boolean> f0139;
   public final C0015<Color> f0140;
   public final C0015<Color> f0141;
   public final C0015<Boolean> f0142;
   public final C0015<Color> f0143;
   public final C0015<Color> f0144;
   public final C0015<Boolean> f0145;
   public final C0015<C0069> f0146;
   public final C0015<Integer> f0147;
   public final C0015<Boolean> f0148;
   public final C0015<Color> f0149;
   public final C0015<Color> f0150;
   public final C0015<Float> f0151;
   public final C0015<Color> f0152;
   public final C0015<Color> f0153;
   public final C0015<Boolean> f0154;
   public final C0015<Color> f0155;
   public final C0015<Color> f0156;
   public final C0015<Boolean> f0157;
   public final C0015<Color> f0158;
   public final C0015<Boolean> f0159;
   public final C0015<Boolean> f0160;
   public final C0015<Boolean> f0161;
   public final C0015<Boolean> f0162;
   public final C0015<Boolean> f0163;
   public final C0015<Boolean> f0164;
   public final C0015<Boolean> f0165;
   public final C0015<Boolean> f0166;
   public final C0015<Boolean> f0167;
   public final C0015<Boolean> f0168;
   public final C0015<Float> f0169;
   public boolean f0170;
   public final C0416 f0171;
   public final Map<class_243, Long> f0172;
   public static int f0173 = w.a<"B">(1139045607477028526L, 257832362129977838L);

   public C0396() {
      super("ESP", "Highlights entities through walls.", C1045.f3174);
      w.a<"B">(this, 242859112966675773L);
      this.f0171 = new C0416(this);
      this.f0172 = w.a<"B">(new HashMap(), 297409492390560467L);
      w.a<"Û">(this.f0140, "AnimalsFill", 275243698516531804L);
      w.a<"Û">(this.f0141, "AnimalsOutline", 275243698516531804L);
      w.a<"Û">(this.f0134, "HostilesFill", 275243698516531804L);
      w.a<"Û">(this.f0135, "HostilesOutline", 275243698516531804L);
      w.a<"Û">(this.f0137, "PlayersFill", 275243698516531804L);
      w.a<"Û">(this.f0138, "PlayersOutline", 275243698516531804L);
      w.a<"Û">(this.f0152, "ItemsFill", 275243698516531804L);
      w.a<"Û">(this.f0153, "ItemsOutline", 275243698516531804L);
      w.a<"Û">(this.f0155, "ExpFill", 275243698516531804L);
      w.a<"Û">(this.f0156, "ExpOutline", 275243698516531804L);
      w.a<"Û">(this.f0146, "ItemsMode", 275243698516531804L);
      w.a<"Û">(this.f0147, "ItemRange", 275243698516531804L);
      w.a<"Û">(this, (boolean)((f0173 | 427490) + ~(f0173 & 427490) + 1 ^ 684001277), 135570431627433065L);
   }

   @C1027
   public void m0135(C1357 var1) {
      if (w.a<"Û">((Boolean)w.a<"Û">(this.f0132, 174312564406604366L), 354697271520518137L)) {
         w.a<"Û">(this, var1, 177493029375793320L);
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = -99999999
   )
   public void m0136(C1358 var1) {
      if (!w.a<"Û">(this, 205492958615326489L) && w.a<"Û">(this.f0171, 347380632721872488L)) {
         C0479.m2763(C0789.f1297, (boolean)((f0173 | 585598) + ~(f0173 & 585598) + 1 ^ 684420449));
         w.a<"Û">(w.a<"Û">(var1, 173269294235887931L), 156066167197700274L);
         this.f0170 = (boolean)((f0173 | 349556) + ~(f0173 & 349556) + 1 ^ 684119914);
         class_243 var2 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L),
            133466035608991790L
         );
         class_4618 var3 = C0789.f1297.m$$D2Azy1oMT0A9jULp75MJoT61sp1MSsq9TNzibl81TE1bLOjJ6WC0WyS94jT7AMeMoAtZH1XStxf9lKcSFYgefROiGy2Gn5psH;
         w.a<"B">(289559736568000957L);
         Iterator var4 = w.a<"Û">(w.a<"Û">(C0933.f1436, 256388424110503341L), 341496865259068134L);

         while (w.a<"Û">(var4, 333900474771661065L)) {
            class_2586 var5 = (class_2586)w.a<"Û">(var4, 192468336863492695L);
            if (w.a<"Û">(this.f0171, var5, 154541638095150934L)) {
               double var6 = (double)w.a<"Û">(w.a<"Û">(var5, 269630716540245963L), 188922896808372924L) - var2.field_1352;
               double var8 = (double)w.a<"Û">(w.a<"Û">(var5, 269630716540245963L), 171752333823210875L) - var2.field_1351;
               double var10 = (double)w.a<"Û">(w.a<"Û">(var5, 269630716540245963L), 278942455661123424L) - var2.field_1350;
               w.a<"Û">(w.a<"Û">(var1, 173269294235887931L), 156066167197700274L);
               w.a<"Û">(w.a<"Û">(var1, 173269294235887931L), var6, var8, var10, 174621271965583782L);
               Color var12 = C0485.m3222(
                  w.a<"Û">(this.f0171, var5, 313726186317941394L), w.a<"Û">((C0951)w.a<"Û">(f0129.f5255, 174312564406604366L), 385901224552774438L)
               );
               w.a<"Û">(
                  var3,
                  w.a<"Û">(var12, 239609820066095028L),
                  w.a<"Û">(var12, 340797987757289690L),
                  w.a<"Û">(var12, 212499208735578764L),
                  (f0173 | 245199) + ~(f0173 & 245199) + 1 ^ 683687727,
                  377547092110746105L
               );
               if (w.a<"Û">(
                     w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 326596604491102240L),
                     var5,
                     282726857989670792L
                  )
                  == null) {
                  class_4588 var13 = w.a<"Û">(var3, w.a<"B">(149651061447081944L), 385605884993482035L);
                  w.a<"Û">(
                     w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 340895941395067711L),
                     w.a<"Û">(var5, 139116205665532266L),
                     w.a<"Û">(var5, 269630716540245963L),
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                     w.a<"Û">(var1, 173269294235887931L),
                     var13,
                     (boolean)((f0173 | 972444) + ~(f0173 & 972444) + 1 ^ 684545155),
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 130424656984797105L
                     ),
                     217736028170697617L
                  );
               } else {
                  w.a<"Û">(
                     w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 326596604491102240L),
                     var5,
                     w.a<"Û">(var1, 332657398031159950L),
                     w.a<"Û">(var1, 173269294235887931L),
                     var3,
                     321424940787069813L
                  );
               }

               w.a<"Û">(w.a<"Û">(var1, 173269294235887931L), 250771500943331132L);
            }
         }

         w.a<"B">(131668795728369880L);
         w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 307206842868879895L),
               224491904139370894L
            ),
            170217939166473161L
         );
         this.f0170 = (boolean)((f0173 | 386635) + ~(f0173 & 386635) + 1 ^ 684090452);
         w.a<"Û">(w.a<"Û">(var1, 173269294235887931L), 250771500943331132L);
         C0479.m2764((boolean)((f0173 | 907810) + ~(f0173 & 907810) + 1 ^ 684611645));
      }
   }

   @C1027(
      m$$yQoOQz1st0lNQj86PDesOHtgsYLfurTAHSCXM6U4bh1f4TBvo6fLnfZOfETVK2e8rfKZwJawOCAF49XxX6pnKBXEI6PsrW7AJ = -200
   )
   public void m0137(C1358 var1) {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         ArrayList var2 = new ArrayList();
         Iterator var3 = w.a<"Û">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 156655948167432853L),
            191661729848227466L
         );

         while (w.a<"Û">(var3, 333900474771661065L)) {
            class_1297 var4 = (class_1297)w.a<"Û">(var3, 192468336863492695L);
            w.a<"Û">(var2, var4, 276802003864609490L);
         }

         w.a<"Û">(
            var2, w.a<"B">((Function<class_1297, Integer>)var0 -> w.a<"B">(-var0.field_6012, 367942141483020029L), 224107444354928270L), 369116887926758393L
         );
         ArrayList var13 = new ArrayList();
         Iterator var14 = w.a<"Û">(var2, 341496865259068134L);

         while (w.a<"Û">(var14, 333900474771661065L)) {
            class_1297 var5 = (class_1297)w.a<"Û">(var14, 192468336863492695L);
            if (w.a<"Û">(this.f0171, var5, 215422513884795291L)) {
               w.a<"B">(
                  w.a<"Û">(var1, 173269294235887931L),
                  w.a<"B">(var5, w.a<"Û">(var1, 332657398031159950L), 221007421302384320L),
                  w.a<"Û">(this.f0171, var5, (boolean)((f0173 | 61029) + ~(f0173 & 61029) + 1 ^ 683895931), 116481088746453646L),
                  246072095578695914L
               );
               C0485.m3219(
                  w.a<"Û">(var1, 173269294235887931L),
                  w.a<"B">(var5, w.a<"Û">(var1, 332657398031159950L), 221007421302384320L),
                  w.a<"Û">(this.f0171, var5, (boolean)((f0173 | 978211) + ~(f0173 & 978211) + 1 ^ 684551996), 116481088746453646L),
                  w.a<"Û">((Float)w.a<"Û">(this.f0169, 174312564406604366L), 149784643039979208L)
               );
            }

            if (var5 instanceof class_1542 var6
               && w.a<"Û">((Boolean)w.a<"Û">(this.f0145, 174312564406604366L), 354697271520518137L)
               && (w.a<"Û">(this.f0146, 174312564406604366L) == C0069.f3533 || w.a<"Û">(this.f0146, 174312564406604366L) == C0069.f3532)) {
               class_243 var7 = w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L),
                  133466035608991790L
               );
               if (var5 instanceof class_1542
                  && w.a<"Û">(w.a<"Û">(var5, 360959056130751432L), var7, 180844654503832142L)
                     > (double)w.a<"Û">((Integer)w.a<"Û">(this.f0147, 174312564406604366L), 260981171345819427L)) {
                  continue;
               }

               if (!w.a<"Û">((Boolean)w.a<"Û">(this.f0148, 174312564406604366L), 354697271520518137L)) {
                  String var20 = w.a<"Û">(w.a<"Û">(w.a<"Û">(var6, 295879862864005166L), 248308138707081744L), 286788181028845103L);
                  if (w.a<"Û">(w.a<"Û">(var6, 295879862864005166L), 144154955567765793L) > ((f0173 | 841436) + ~(f0173 & 841436) + 1 ^ 684676290)) {
                     var20 = new C1002().m2578(w.a<"Û">(w.a<"Û">(var6, 295879862864005166L), 144154955567765793L)).m2591(var20).m2593("\u0001 x\u0001");
                  }

                  w.a<"Û">(
                     this.f0171,
                     var1,
                     var20,
                     w.a<"Û">(
                        w.a<"Û">(var6, w.a<"Û">(var1, 332657398031159950L), 277651458933060293L),
                        0.0,
                        w.a<"B">(((long)f0173 | 113105L) + ~((long)f0173 & 113105L) + 1L ^ 4603579539996687310L, 317139102743630955L),
                        0.0,
                        215037093685651073L
                     ),
                     w.a<"Û">((Float)w.a<"Û">(this.f0151, 174312564406604366L), 149784643039979208L),
                     (Color)w.a<"Û">(this.f0149, 174312564406604366L),
                     (Color)w.a<"Û">(this.f0150, 174312564406604366L),
                     304827208929793997L
                  );
                  continue;
               }

               int var8 = (f0173 | 960236) + ~(f0173 & 960236) + 1 ^ 684532979;
               Iterator var9 = w.a<"Û">(var13, 341496865259068134L);

               while (w.a<"Û">(var9, 333900474771661065L)) {
                  C1164 var10 = (C1164)w.a<"Û">(var9, 192468336863492695L);
                  if (w.a<"Û">(var10, var6, 216657018359163554L)) {
                     var8 = (f0173 | 65553) + ~(f0173 & 65553) + 1 ^ 683835919;
                  }
               }

               if (var8 == 0) {
                  w.a<"Û">(var13, new C1164(var6), 276802003864609490L);
               }
            }

            String var17 = w.a<"Û">(this.f0171, var5, 321817647257036523L);
            if (var17 != null) {
               class_243 var19 = w.a<"Û">(
                  w.a<"Û">(var5, w.a<"Û">(var1, 332657398031159950L), 367406608602808081L),
                  0.0,
                  w.a<"B">(((long)f0173 | 288563L) + ~((long)f0173 & 288563L) + 1L ^ 4596373780093107382L, 317139102743630955L),
                  0.0,
                  215037093685651073L
               );
               if (!(var5 instanceof class_1684)) {
                  var19 = w.a<"Û">(
                     var19,
                     0.0,
                     w.a<"B">(((long)f0173 | 466919L) + ~((long)f0173 & 466919L) + 1L ^ 4608533499078005045L, 317139102743630955L),
                     0.0,
                     215037093685651073L
                  );
               }

               w.a<"Û">(
                  this.f0171,
                  var1,
                  var17,
                  var19,
                  w.a<"B">((f0173 | 62061) + ~(f0173 & 62061) + 1 ^ 390295666, 349057757755238323L),
                  Color.white,
                  null,
                  304827208929793997L
               );
            }
         }

         if (w.a<"Û">((Boolean)w.a<"Û">(this.f0148, 174312564406604366L), 354697271520518137L)) {
            w.a<"Û">(this, var1, var13, 375562788372688085L);
         }

         if (w.a<"Û">((Boolean)w.a<"Û">(this.f0157, 174312564406604366L), 354697271520518137L)) {
            synchronized (this.f0172) {
               Iterator var16 = w.a<"Û">(w.a<"Û">(this.f0172, 354320704134596920L), 194435811056609302L);

               while (w.a<"Û">(var16, 333900474771661065L)) {
                  Entry var18 = (Entry)w.a<"Û">(var16, 192468336863492695L);
                  w.a<"Û">(
                     this.f0171,
                     var1,
                     "Player teleport",
                     (class_243)w.a<"Û">(var18, 141740301999341859L),
                     w.a<"B">((f0173 | 543451) + ~(f0173 & 543451) + 1 ^ 390842564, 349057757755238323L),
                     (Color)w.a<"Û">(this.f0158, 174312564406604366L),
                     null,
                     304827208929793997L
                  );
               }
            }
         }
      }
   }

   public void m0138(C1355 var1, List<C1164> var2) {
      Iterator var3 = w.a<"Û">(var2, 341496865259068134L);

      while (w.a<"Û">(var3, 333900474771661065L)) {
         C1164 var4 = (C1164)w.a<"Û">(var3, 192468336863492695L);
         if (!w.a<"Û">((Boolean)w.a<"Û">(this.f0148, 174312564406604366L), 354697271520518137L)) {
            break;
         }

         class_243 var5 = w.a<"Û">(w.a<"Û">(var4, 316837445083143402L), 376895844755266015L);
         double var6 = w.a<"B">(
            w.a<"Û">(
               w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L),
               133466035608991790L
            ),
            var5,
            (double)w.a<"Û">((Float)w.a<"Û">(this.f0151, 174312564406604366L), 149784643039979208L),
            241370723479498950L
         );
         float var8 = (float)C0498.f4738.m3897();
         float var9 = 0.0F;
         if (w.a<"Û">(w.a<"Û">(var4, 115916273675207786L), 165622882639398740L) == ((f0173 | 811947) + ~(f0173 & 811947) + 1 ^ 684712373)) {
            w.a<"Û">(
               this,
               w.a<"Û">(var1, 173269294235887931L),
               var4,
               var6,
               (float)w.a<"Û">(w.a<"Û">(var4, 115916273675207786L), 165622882639398740L) * var8,
               132578939831133729L
            );
         } else {
            w.a<"Û">(this, w.a<"Û">(var1, 173269294235887931L), var4, var6, var8, 132578939831133729L);
            w.a<"Û">(
               this,
               w.a<"Û">(var1, 173269294235887931L),
               var4,
               var6,
               (float)(w.a<"Û">(w.a<"Û">(var4, 115916273675207786L), 165622882639398740L) - ((f0173 | 732155) + ~(f0173 & 732155) + 1 ^ 684239333)) * -var8
                  - w.a<"B">((f0173 | 947300) + ~(f0173 & 947300) + 1 ^ 1758328443, 349057757755238323L),
               132578939831133729L
            );
         }

         for (Iterator var10 = w.a<"Û">(w.a<"Û">(w.a<"Û">(var4, 115916273675207786L), 354320704134596920L), 194435811056609302L);
            w.a<"Û">(var10, 333900474771661065L);
            var9 -= var8
         ) {
            Entry var11 = (Entry)w.a<"Û">(var10, 192468336863492695L);
            String var12 = w.a<"B">(
               (String)w.a<"Û">(var11, 141740301999341859L), w.a<"Û">((Integer)w.a<"Û">(var11, 196870340575900401L), 260981171345819427L), 350395665025710831L
            );
            float var13 = -C0498.f4738.m3896(var12) / w.a<"B">((f0173 | 293429) + ~(f0173 & 293429) + 1 ^ 1757935658, 349057757755238323L);
            C0094.f4640
               .m1908(
                  w.a<"Û">(var1, 271310623277980550L),
                  var12,
                  var5,
                  0.0F,
                  0.0F,
                  var13,
                  var9,
                  var6,
                  (Color)w.a<"Û">(this.f0149, 174312564406604366L),
                  (boolean)((f0173 | 296044) + ~(f0173 & 296044) + 1 ^ 684131954)
               );
         }
      }
   }

   @C1027
   public void m0139(C0133 var1) {
      if (w.a<"Û">(var1, 127302489982333990L) instanceof class_2767 var2
         && ((class_3414)w.a<"Û">(w.a<"Û">(var2, 208767045855889048L), 138403591895517822L)).equals(class_3417.field_14890)) {
         w.a<"Û">(
            this.f0172,
            new class_243(w.a<"Û">(var2, 222983231982374842L), w.a<"Û">(var2, 348286204089281200L), w.a<"Û">(var2, 187858728783913294L)),
            w.a<"B">(w.a<"B">(223409559795593705L), 279131300036783447L),
            121875332790264405L
         );
      }
   }

   @C1027
   public void m0140(C0612 var1) {
      w.a<"Û">(
         w.a<"Û">(this.f0172, 354320704134596920L),
         (Predicate<Entry>)var0 -> (boolean)(w.a<"B">(223409559795593705L) - w.a<"Û">((Long)w.a<"Û">(var0, 196870340575900401L), 151184307344636838L)
                  > (((long)f0173 | 73306L) + ~((long)f0173 & 73306L) + 1L ^ 683839977L)
               ? (f0173 | 334153) + ~(f0173 & 334153) + 1 ^ 684104535
               : (f0173 | 268406) + ~(f0173 & 268406) + 1 ^ 684169833),
         271448142827029127L
      );
   }

   public void m0141(class_4587 var1, C1164 var2, double var3, float var5) {
      C0094.f4640
         .m1904(
            var1,
            w.a<"Û">(w.a<"Û">(var2, 316837445083143402L), 376895844755266015L),
            0.0F,
            0.0F,
            w.a<"Û">(var2, 350069332441463175L) + w.a<"B">((f0173 | 148133) + ~(f0173 & 148133) + 1 ^ 390185146, 349057757755238323L),
            var5,
            var3,
            (Color)w.a<"Û">(this.f0150, 174312564406604366L)
         );
   }

   public void m0142(C1355 var1) {
      float var2 = w.a<"B">((f0173 | 563679) + ~(f0173 & 563679) + 1 ^ 394992576, 349057757755238323L);
      class_243 var3 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 186577611421056948L).field_4686,
         133466035608991790L
      );
      class_4587 var4 = w.a<"Û">(var1, 173269294235887931L);
      class_287 var5 = w.a<"Û">(w.a<"B">(117631142345936934L), class_5596.field_29344, class_290.field_1576, 293291749269511555L);
      w.a<"B">(class_757::method_34540, 355523013159401593L);
      w.a<"B">(207660790260164364L);
      w.a<"B">(156169517863121162L);
      class_3562 var6 = w.a<"Û">(
         w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, 208462956635472618L),
         class_1944.field_9282,
         243840860144199787L
      );
      Iterator var7 = w.a<"Û">(
         w.a<"B">(
            w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 270398306108537951L),
            w.a<"B">((f0173 | 519047) + ~(f0173 & 519047) + 1 ^ 1770285464, 349057757755238323L),
            (boolean)((f0173 | 533903) + ~(f0173 & 533903) + 1 ^ 684435345),
            297851292504232202L
         ),
         341496865259068134L
      );

      while (w.a<"Û">(var7, 333900474771661065L)) {
         class_2338 var8 = (class_2338)w.a<"Û">(var7, 192468336863492695L);
         class_2680 var9 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var8, 310987074049434965L
         );
         if (w.a<"B">(w.a<"Û">(var8, 286357605983762592L), 264833804936079815L)
            && w.a<"Û">(var6, w.a<"Û">(var8, 286357605983762592L), 189803345072008230L) <= ((f0173 | 311068) + ~(f0173 & 311068) + 1 ^ 684145924)) {
            boolean var10 = w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687, var8, 216902558256272755L
               ),
               class_1972.field_9462,
               250885418540268378L
            );
            if (w.a<"Û">(
                  var9,
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1687,
                  var8,
                  class_1299.field_6051,
                  231801670413942018L
               )
               && !var10) {
               double var11 = w.a<"Û">(
                  w.a<"Û">(
                     w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1773, 202182323384413167L
                     ),
                     133466035608991790L
                  ),
                  w.a<"Û">(var8, 229561253177300454L),
                  180844654503832142L
               );
               float var13 = w.a<"B">((f0173 | 890096) + ~(f0173 & 890096) + 1 ^ 390993647, 349057757755238323L)
                  - (float)w.a<"B">(
                     (var11 - w.a<"B">(((long)f0173 | 396727L) + ~((long)f0173 & 396727L) + 1L ^ 4620693218366164904L, 317139102743630955L))
                        / w.a<"B">(((long)f0173 | 97303L) + ~((long)f0173 & 97303L) + 1L ^ 4611686019111255560L, 317139102743630955L),
                     0.0,
                     w.a<"B">(((long)f0173 | 847735L) + ~((long)f0173 & 847735L) + 1L ^ 4607182419484700008L, 317139102743630955L),
                     318037245528159060L
                  );
               int var14 = w.a<"Û">(Color.red, 301840407077149108L);
               if (var11 >= w.a<"B">(((long)f0173 | 379293L) + ~((long)f0173 & 379293L) + 1L ^ 4620693218366212994L, 317139102743630955L)) {
                  var14 = C0152.m3476(Color.red, var13);
               }

               w.a<"Û">(var4, 156066167197700274L);
               w.a<"Û">(
                  var4,
                  (double)w.a<"Û">(var8, 188922896808372924L) - var3.field_1352,
                  (double)w.a<"Û">(var8, 171752333823210875L)
                     - var3.field_1351
                     + w.a<"B">(((long)f0173 | 290493L) + ~((long)f0173 & 290493L) + 1L ^ 4607272491475883248L, 317139102743630955L),
                  (double)w.a<"Û">(var8, 278942455661123424L) - var3.field_1350,
                  174621271965583782L
               );
               Matrix4f var15 = w.a<"Û">(w.a<"Û">(var4, 155205621859767568L), 293784142242903534L);
               w.a<"Û">(
                  w.a<"Û">(
                     var5,
                     var15,
                     w.a<"B">((f0173 | 544020) + ~(f0173 & 544020) + 1 ^ 390844171, 349057757755238323L) - var2,
                     0.0F,
                     w.a<"B">((f0173 | 858396) + ~(f0173 & 858396) + 1 ^ 391027459, 349057757755238323L) - var2,
                     108420448448548129L
                  ),
                  var14,
                  114768872614806543L
               );
               w.a<"Û">(w.a<"Û">(var5, var15, var2, 0.0F, var2, 108420448448548129L), var14, 114768872614806543L);
               w.a<"Û">(
                  w.a<"Û">(
                     var5, var15, var2, 0.0F, w.a<"B">((f0173 | 182794) + ~(f0173 & 182794) + 1 ^ 390154261, 349057757755238323L) - var2, 108420448448548129L
                  ),
                  var14,
                  114768872614806543L
               );
               w.a<"Û">(
                  w.a<"Û">(
                     var5, var15, w.a<"B">((f0173 | 49078) + ~(f0173 & 49078) + 1 ^ 390282665, 349057757755238323L) - var2, 0.0F, var2, 108420448448548129L
                  ),
                  var14,
                  114768872614806543L
               );
               w.a<"Û">(var4, 250771500943331132L);
            }
         }
      }

      class_9801 var16 = w.a<"Û">(var5, 304607024546637614L);
      if (var16 != null) {
         w.a<"B">(var16, 256434752630151661L);
         w.a<"B">(312684551270353896L);
         w.a<"B">(108985695518258885L);
      }
   }

   public boolean m0143() {
      return this.f0170;
   }

   public static String JUY8i6Qm0Zy65J1lM65Gpuhydz9vr9go3XQCpp1HXXnrgeoplTEvt5ymOKkHMnRctx4nU2dKoP2TdW3toDTxZX7GddpWeFjQXosO(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
