package me.mioclient;

import java.util.function.Predicate;

public class C0263 implements Predicate {
   public C0736 f0124;

   public C0263(C0736 var1) {
      this.f0124 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0124.f1205, 254992554122318132L);
   }
}
