package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.BiFunction;

public enum C0272 implements C0196 {
   f3581("simple", C1167::new),
   f3582("queue", C0660::new),
   f3583("double_tap", C0451::new),
   f3584("hold", C0223::new);

   public final String f3585;
   public final BiFunction<String, C1088, C1108> f3586;

   public C0272(String var3, BiFunction<String, C1088, C1108> var4) {
      this.f3585 = var3;
      this.f3586 = var4;
   }

   public static C0272 m3502(String var0) {
      for (C0272 var4 : w.a<"B">(267977742958501838L)) {
         if (w.a<"Û">(w.a<"Û">(var4, 219013701888136000L), var0, 307662238383225114L)) {
            return var4;
         }
      }

      return null;
   }

   @Override
   public String getName() {
      return this.f3585;
   }

   public C1108 m3503(String var1, C1088 var2) {
      return (C1108)w.a<"Û">(this.f3586, var1, var2, 305225622969580745L);
   }

   public static String aZqv2zmU1ILSl81tAO09dUP6iq672tRgAOyTR40DHAm1zRJ9TyuJIXnXr5Vc4SvZUgP2rYbrDs9yUNadpPNdH5JWAnW48cdmPazm(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
