package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import java.util.function.Predicate;
import net.minecraft.class_1799;
import net.minecraft.class_1893;

public enum C0311 implements C0196 {
   f2828("None", var0 -> false),
   f2829("Breach", var0 -> w.a<"B">(class_1893.field_50158, var0, 266852383896389005L)),
   f2830("Density", var0 -> w.a<"B">(class_1893.field_50157, var0, 266852383896389005L) && C0045.f2103.field_1724.field_6017 > 3.0F),
   f2831(
      "Smart",
      var0 -> !(C0045.f2103.field_1724.field_6017 > 3.0F) && w.a<"Û">(C0933.f1429, 202655309853842506L) > 1
            ? w.a<"B">(class_1893.field_50158, var0, 266852383896389005L)
            : w.a<"B">(class_1893.field_50157, var0, 266852383896389005L)
   );

   public final Predicate<class_1799> f2832;
   public final String f2833;

   public C0311(String var3, Predicate<class_1799> var4) {
      this.f2832 = var4;
      this.f2833 = var3;
   }

   @Override
   public String getName() {
      return this.f2833;
   }

   public boolean m3197(class_1799 var1) {
      return w.a<"Û">(this.f2832, var1, 258912813308304151L);
   }

   public static String d6kGxTzRz29l18FjsuoAr4BQONdr6I6rXdAW66q74oi9SAypyGViy6ICHfhqXPl3pMR2YxweYlYcFlaDcZR9QThSdXiCsAjtz0KO(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
