package me.mioclient;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import net.minecraft.class_640;

public class C0403 implements ArgumentType<String>, C0045 {
   public static final List<String> f4311 = w.a<"B">("cat", "fit", "asphyxia1337", 187679336490942256L);
   public static int f4312 = w.a<"B">(3769626173179049451L, 257832362129977838L);

   public String parse(StringReader var1) {
      return w.a<"Û">(var1, 269296760635713865L);
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> var1, SuggestionsBuilder var2) {
      return w.a<"B">(
         w.a<"Û">(
            w.a<"Û">(
               w.a<"Û">(
                  m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724.field_3944,
                  375973895142890397L
               ),
               366567241942811964L
            ),
            (Function<class_640, String>)var0 -> w.a<"Û">(w.a<"Û">(var0, 340696059510910540L), 211085733983653208L),
            141209812120559377L
         ),
         var2,
         379722968704725371L
      );
   }

   public Collection<String> getExamples() {
      return f4311;
   }

   public static String _O1jI1HEUAYdaJmVN2ICwkqc5mS7uSbDev16oip9KwyZesT5SirVwwjCFXIjo7HbHPjZiTqOoNoOkAe46ucMYGQBWnSeF8P1ikxp/* $VF was: 8O1jI1HEUAYdaJmVN2ICwkqc5mS7uSbDev16oip9KwyZesT5SirVwwjCFXIjo7HbHPjZiTqOoNoOkAe46ucMYGQBWnSeF8P1ikxp*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
