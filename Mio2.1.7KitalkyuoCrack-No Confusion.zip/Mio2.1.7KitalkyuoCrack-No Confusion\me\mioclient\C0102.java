package me.mioclient;

public class C0102 {
   public static C0102 f1917 = new C0102();
   public static int f1918 = w.a<"B">(1954734397275051547L, 257832362129977838L);

   public C0102() {
      this.init();
   }

   public static C0102 m0812() {
      if (f1917 == null) {
         f1917 = new C0102();
      }

      return f1917;
   }

   public void init() {
      w.a<"B">(177551669559526975L);
   }
}
