package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1297;

public class C0389 extends C0344 {
   public static C0396 f2731 = C0933.f1409.m2696(C0396.class);
   public static int f2732 = -1981041519;

   public C0389() {
      this.m$$KhWP9qaEyk4Hpf2s6QAMxOObFwGNhRe4O85tW7lF7YC66NpK19NKJO2PsEofzYs8I922737IwETboj8jk8TQNWamDuqdBrJoZ("outline");
   }

   public boolean m3171() {
      return (boolean)(f2731.isToggled() && f2731.f0171.m4110()
         ? (f2732 | 51765) + ~(f2732 & 51765) + 1 ^ -1981055323
         : (f2732 | 305556) + ~(f2732 & 305556) + 1 ^ -1980818171);
   }

   public boolean m3172(class_1297 var1) {
      return (boolean)((f2732 | 426368) + ~(f2732 & 426368) + 1 ^ -1980943087);
   }

   public void m3173() {
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2507("u_Texture", (f2732 | 939479) + ~(f2732 & 939479) + 1 ^ -1981423290);
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2507("u_Width", (f2732 | 744568) + ~(f2732 & 744568) + 1 ^ -1981749013);
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2506("u_FastLines", (boolean)((f2732 | 378094) + ~(f2732 & 378094) + 1 ^ -1980862338));
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2508("u_GlowMultiplier", Double.longBitsToDouble(((long)f2732 | 848761L) + ~((long)f2732 & 848761L) + 1L ^ -4607182420781348888L));
   }

   static {
      long var10000 = 1494610961549681914L;
   }

   public static String IkcrvY564s9NiMvSEYGfe8iYuj2Mkubml6Xc4I5mCpI71IAiJsCOupXrAEo4pRhsGnb4HtlsOQr3WUmbHXCdT2cuTCGry32tFQCj(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
