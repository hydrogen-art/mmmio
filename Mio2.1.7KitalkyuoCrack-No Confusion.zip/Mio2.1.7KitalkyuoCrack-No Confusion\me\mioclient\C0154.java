package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.context.StringRange;
import com.mojang.brigadier.suggestion.Suggestion;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_124;
import net.minecraft.class_2172;

public final class C0154 extends C0219 {
   public boolean f2519;
   public String f2520;
   public C0272 f2521;
   public static int f2522 = w.a<"B">(1939260851318668706L, 257832362129977838L);

   public C0154() {
      super("macro");
      w.a<"Û">(m$$LhN3aMIG1xamNF5W0O3OUPIULy6Ir9ugEHvJJzLsIpXpAVh9kz1bVeXg8pqjWXv3Kig87cb7XjRXScjx9zcM5skilv9gXmiQ8, this, 157496676404787811L);
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         (LiteralArgumentBuilder)w.a<"Û">(
            (LiteralArgumentBuilder)w.a<"Û">(
               (LiteralArgumentBuilder)w.a<"Û">(
                  var1,
                  w.a<"Û">(
                     this,
                     "delete",
                     (Consumer<RequiredArgumentBuilder>)var0 -> w.a<"Û">(
                           var0,
                           (Command)var0x -> {
                              C1108 var1x = (C1108)w.a<"Û">(var0x, "macro", C1108.class, 275658406246533271L);
                              w.a<"Û">(C0933.f1421, var1x, 360390325788885525L);
                              w.a<"B">(
                                 w.a<"Û">(
                                    w.a<"B">(C0498.m3882(w.a<"Û">(var1x, 248211090350577353L)), 228465064790135899L), " has been deleted", 194629304146735395L
                                 ),
                                 w.a<"B">((f2522 | 751601) + ~(f2522 & 751601) + 1 ^ -135328654, 289296048454852994L),
                                 241936116971186271L
                              );
                              return (f2522 | 409081) + ~(f2522 & 409081) + 1 ^ 136165764;
                           },
                           368995281709124746L
                        ),
                     225991566948401738L
                  ),
                  289819728773344295L
               ),
               w.a<"Û">(this, "commands", this::m3100, 225991566948401738L),
               289819728773344295L
            ),
            w.a<"Û">(
               w.a<"B">("new", 233839479830701924L),
               w.a<"Û">(
                  w.a<"B">("name", w.a<"B">(192168525870671914L), 191188367299315725L),
                  w.a<"Û">(
                     (RequiredArgumentBuilder)w.a<"Û">(
                        w.a<"B">("type", new C0417<>(C0272.class, "Macro"), 191188367299315725L),
                        w.a<"Û">(
                           (RequiredArgumentBuilder)w.a<"Û">(
                              w.a<"B">("key", new C1076(), 191188367299315725L),
                              w.a<"Û">(
                                 w.a<"Û">(this, 220456120578082707L),
                                 (Command)var0 -> {
                                    String var1x = (String)w.a<"Û">(var0, "name", String.class, 275658406246533271L);
                                    String var2 = (String)w.a<"Û">(var0, "command", String.class, 275658406246533271L);
                                    C0272 var3 = (C0272)w.a<"Û">(var0, "type", C0272.class, 275658406246533271L);
                                    C1088 var4 = (C1088)w.a<"Û">(var0, "key", C1088.class, 275658406246533271L);
                                    C1108 var5 = w.a<"Û">(var3, var1x, var4, 386228792603437303L);
                                    w.a<"Û">(w.a<"Û">(var5, 139888435356199070L), var2, 276802003864609490L);
                                    w.a<"Û">(C0933.f1421, var5, 133315123936993858L);
                                    w.a<"B">(
                                       w.a<"Û">(
                                          w.a<"Û">(w.a<"B">("Macro ", 228465064790135899L), w.a<"Û">(var5, 288062603600083063L), 267862536496645581L),
                                          " has been created",
                                          194629304146735395L
                                       ),
                                       w.a<"B">((f2522 | 883504) + ~(f2522 & 883504) + 1 ^ -135724877, 289296048454852994L),
                                       241936116971186271L
                                    );
                                    return (f2522 | 135105) + ~(f2522 & 135105) + 1 ^ 135891900;
                                 },
                                 368995281709124746L
                              ),
                              364326416200407929L
                           ),
                           (Command)var0 -> {
                              String var1x = (String)w.a<"Û">(var0, "name", String.class, 275658406246533271L);
                              C0272 var2 = (C0272)w.a<"Û">(var0, "type", C0272.class, 275658406246533271L);
                              C1088 var3 = (C1088)w.a<"Û">(var0, "key", C1088.class, 275658406246533271L);
                              C1108 var4 = w.a<"Û">(var2, var1x, var3, 386228792603437303L);
                              w.a<"Û">(C0933.f1421, var4, 133315123936993858L);
                              w.a<"B">(
                                 w.a<"Û">(
                                    w.a<"Û">(w.a<"B">("Macro ", 228465064790135899L), w.a<"Û">(var4, 288062603600083063L), 267862536496645581L),
                                    " has been created",
                                    194629304146735395L
                                 ),
                                 w.a<"B">((f2522 | 69135) + ~(f2522 & 69135) + 1 ^ -135957108, 289296048454852994L),
                                 241936116971186271L
                              );
                              return (f2522 | 971101) + ~(f2522 & 971101) + 1 ^ 135615776;
                           },
                           368995281709124746L
                        ),
                        364326416200407929L
                     ),
                     (Command)var1x -> {
                        this.f2520 = (String)w.a<"Û">(var1x, "name", String.class, 275658406246533271L);
                        this.f2521 = (C0272)w.a<"Û">(var1x, "type", C0272.class, 275658406246533271L);
                        this.f2519 = (boolean)((f2522 | 253279) + ~(f2522 & 253279) + 1 ^ 135813410);
                        w.a<"B">(
                           w.a<"B">("Press a key", 228465064790135899L),
                           w.a<"B">((f2522 | 265810) + ~(f2522 & 265810) + 1 ^ -136284719, 289296048454852994L),
                           241936116971186271L
                        );
                        return (f2522 | 554675) + ~(f2522 & 554675) + 1 ^ 135525070;
                     },
                     368995281709124746L
                  ),
                  364326416200407929L
               ),
               289819728773344295L
            ),
            289819728773344295L
         ),
         w.a<"Û">(
            w.a<"B">("list", 233839479830701924L),
            (Command)var0 -> {
               int var1x = (f2522 | 340912) + ~(f2522 & 340912) + 1 ^ 136230860;
               w.a<"B">(
                  w.a<"B">("Macro list:", 228465064790135899L),
                  w.a<"B">((f2522 | 505221) + ~(f2522 & 505221) + 1 ^ -136065530, 289296048454852994L),
                  241936116971186271L
               );

               for (Iterator var2 = w.a<"Û">((List)w.a<"Û">(C0933.f1421, 268370374673263607L), 341496865259068134L);
                  w.a<"Û">(var2, 333900474771661065L);
                  var1x++
               ) {
                  C1108 var3 = (C1108)w.a<"Û">(var2, 192468336863492695L);
                  Object[] var10001 = new Object[(f2522 | 497374) + ~(f2522 & 497374) + 1 ^ 136057504];
                  var10001[(f2522 | 219430) + ~(f2522 & 219430) + 1 ^ 135847258] = w.a<"Û">(var3, 248211090350577353L);
                  var10001[(f2522 | 168836) + ~(f2522 & 168836) + 1 ^ 135862265] = w.a<"Û">(w.a<"Û">(var3, 224269605174763979L), 338391653860412648L);
                  String var4 = w.a<"Û">("%s (%s)", var10001, 259257223839993282L);
                  w.a<"B">(w.a<"B">(var4, 228465064790135899L), w.a<"B">(var1x, 289296048454852994L), 241936116971186271L);
               }

               return (f2522 | 571714) + ~(f2522 & 571714) + 1 ^ 135478590;
            },
            286944572020109927L
         ),
         289819728773344295L
      );
   }

   public void m3100(RequiredArgumentBuilder<class_2172, C1108> var1) {
      w.a<"Û">(
         (RequiredArgumentBuilder)w.a<"Û">(
            (RequiredArgumentBuilder)w.a<"Û">(
               (RequiredArgumentBuilder)w.a<"Û">(
                  (RequiredArgumentBuilder)w.a<"Û">(
                     var1,
                     w.a<"Û">(
                        w.a<"B">("add", 233839479830701924L),
                        w.a<"Û">(
                           w.a<"Û">(this, 220456120578082707L),
                           (Command)var0 -> {
                              C1108 var1x = (C1108)w.a<"Û">(var0, "macro", C1108.class, 275658406246533271L);
                              String var2 = (String)w.a<"Û">(var0, "command", String.class, 275658406246533271L);
                              if (w.a<"Û">(var1x, 346748715815929151L) == C0272.f3584
                                 && w.a<"Û">(w.a<"Û">(var1x, 139888435356199070L), 260708190417501501L)
                                    >= ((f2522 | 833826) + ~(f2522 & 833826) + 1 ^ 135740764)) {
                                 String var3 = new C1002()
                                    .m2591(w.a<"B">(class_124.field_1061, 174997918119584642L))
                                    .m2593("\u0001You've reached the command limit of Hold Macro");
                                 w.a<"B">(
                                    w.a<"B">(var3, 228465064790135899L),
                                    w.a<"B">((f2522 | 141679) + ~(f2522 & 141679) + 1 ^ -135900436, 289296048454852994L),
                                    241936116971186271L
                                 );
                                 return (f2522 | 598489) + ~(f2522 & 598489) + 1 ^ 135439780;
                              } else {
                                 w.a<"Û">(w.a<"Û">(var1x, 139888435356199070L), var2, 276802003864609490L);
                                 return (f2522 | 249734) + ~(f2522 & 249734) + 1 ^ 135810043;
                              }
                           },
                           368995281709124746L
                        ),
                        289819728773344295L
                     ),
                     364326416200407929L
                  ),
                  w.a<"Û">(
                     w.a<"B">("remove", 233839479830701924L),
                     w.a<"Û">(
                        w.a<"B">("index", w.a<"B">((f2522 | 123960) + ~(f2522 & 123960) + 1 ^ 135946309, 317030227485612947L), 191188367299315725L),
                        (Command)var1x -> {
                           C1108 var2 = (C1108)w.a<"Û">(var1x, "macro", C1108.class, 275658406246533271L);
                           int var3 = w.a<"Û">((Integer)w.a<"Û">(var1x, "index", Integer.class, 275658406246533271L), 260981171345819427L)
                              - ((f2522 | 877455) + ~(f2522 & 877455) + 1 ^ 135718898);
                           if (var3 < w.a<"Û">(w.a<"Û">(var2, 139888435356199070L), 260708190417501501L)
                              && var3 >= 0
                              && !w.a<"Û">(w.a<"Û">(var2, 139888435356199070L), 284469716622774448L)) {
                              w.a<"Û">(w.a<"Û">(var2, 139888435356199070L), var3, 233199921993690777L);
                              return (f2522 | 791791) + ~(f2522 & 791791) + 1 ^ 135762066;
                           } else {
                              String var4 = new C1002()
                                 .m2591(w.a<"Û">(this, var2, 271215450837835251L))
                                 .m2591(w.a<"B">(class_124.field_1068, 174997918119584642L))
                                 .m2591(w.a<"B">(class_124.field_1061, 174997918119584642L))
                                 .m2593("\u0001Invalid index\u0001\n\u0001");
                              w.a<"B">(
                                 w.a<"B">(var4, 228465064790135899L),
                                 w.a<"B">((f2522 | 557600) + ~(f2522 & 557600) + 1 ^ -135464541, 289296048454852994L),
                                 241936116971186271L
                              );
                              return (f2522 | 937541) + ~(f2522 & 937541) + 1 ^ 135645752;
                           }
                        },
                        368995281709124746L
                     ),
                     289819728773344295L
                  ),
                  364326416200407929L
               ),
               w.a<"Û">(w.a<"B">("clear", 233839479830701924L), (Command)var0 -> {
                  C1108 var1x = (C1108)w.a<"Û">(var0, "macro", C1108.class, 275658406246533271L);
                  w.a<"Û">(w.a<"Û">(var1x, 139888435356199070L), 140901994866995976L);
                  return (f2522 | 42238) + ~(f2522 & 42238) + 1 ^ 135995523;
               }, 286944572020109927L),
               364326416200407929L
            ),
            w.a<"Û">(
               w.a<"B">("edit", 233839479830701924L),
               w.a<"Û">(
                  w.a<"B">("index", w.a<"B">((f2522 | 152208) + ~(f2522 & 152208) + 1 ^ 135911149, 317030227485612947L), 191188367299315725L),
                  w.a<"Û">(
                     w.a<"Û">(this, 220456120578082707L),
                     (Command)var1x -> {
                        C1108 var2 = (C1108)w.a<"Û">(var1x, "macro", C1108.class, 275658406246533271L);
                        String var3 = (String)w.a<"Û">(var1x, "command", String.class, 275658406246533271L);
                        int var4 = w.a<"Û">((Integer)w.a<"Û">(var1x, "index", Integer.class, 275658406246533271L), 260981171345819427L)
                           - ((f2522 | 533287) + ~(f2522 & 533287) + 1 ^ 135505754);
                        if (var4 > w.a<"Û">(w.a<"Û">(var2, 139888435356199070L), 260708190417501501L)) {
                           String var5 = new C1002()
                              .m2591(w.a<"Û">(this, var2, 271215450837835251L))
                              .m2591(w.a<"B">(class_124.field_1068, 174997918119584642L))
                              .m2591(w.a<"B">(class_124.field_1061, 174997918119584642L))
                              .m2593("\u0001Invalid index\u0001\n\u0001");
                           w.a<"B">(
                              w.a<"B">(var5, 228465064790135899L),
                              w.a<"B">((f2522 | 957236) + ~(f2522 & 957236) + 1 ^ -135601993, 289296048454852994L),
                              241936116971186271L
                           );
                           return (f2522 | 919778) + ~(f2522 & 919778) + 1 ^ 135629983;
                        } else {
                           w.a<"Û">(w.a<"Û">(var2, 139888435356199070L), var4, var3, 302586962337252721L);
                           return (f2522 | 940497) + ~(f2522 & 940497) + 1 ^ 135650732;
                        }
                     },
                     368995281709124746L
                  ),
                  364326416200407929L
               ),
               289819728773344295L
            ),
            364326416200407929L
         ),
         (Command)var1x -> {
            C1108 var2 = (C1108)w.a<"Û">(var1x, "macro", C1108.class, 275658406246533271L);
            w.a<"B">(
               w.a<"B">(w.a<"Û">(this, var2, 271215450837835251L), 228465064790135899L),
               w.a<"B">((f2522 | 251869) + ~(f2522 & 251869) + 1 ^ -135812002, 289296048454852994L),
               241936116971186271L
            );
            return (f2522 | 580722) + ~(f2522 & 580722) + 1 ^ 135485455;
         },
         368995281709124746L
      );
   }

   public LiteralArgumentBuilder<class_2172> m3101(String var1, Consumer<RequiredArgumentBuilder<class_2172, C1108>> var2) {
      RequiredArgumentBuilder var3 = w.a<"B">("macro", new C0946(), 191188367299315725L);
      w.a<"Û">(var2, var3, 228534592884339334L);
      return (LiteralArgumentBuilder<class_2172>)w.a<"Û">(w.a<"B">(var1, 233839479830701924L), var3, 289819728773344295L);
   }

   public String m3102(C1108 var1) {
      StringBuffer var2 = new StringBuffer(new C1002().m2591(w.a<"Û">(var1, 248211090350577353L)).m2593("\u0001's command list: \n"));

      for (int var3 = (f2522 | 290430) + ~(f2522 & 290430) + 1 ^ 136309250; var3 < w.a<"Û">(w.a<"Û">(var1, 139888435356199070L), 260708190417501501L); var3++) {
         w.a<"Û">(var2, var3 + ((f2522 | 586417) + ~(f2522 & 586417) + 1 ^ 135493324), 201041500241575312L);
         w.a<"Û">(var2, ". ", 269908260629125909L);
         w.a<"Û">(var2, (String)w.a<"Û">(w.a<"Û">(var1, 139888435356199070L), var3, 325739049664951543L), 269908260629125909L);
         if (var3 != w.a<"Û">(w.a<"Û">(var1, 139888435356199070L), 260708190417501501L) - ((f2522 | 447401) + ~(f2522 & 447401) + 1 ^ 136140756)) {
            w.a<"Û">(var2, "\n", 269908260629125909L);
         }
      }

      return w.a<"Û">(var2, 211705417090297841L);
   }

   public RequiredArgumentBuilder<class_2172, String> m3103() {
      return w.a<"Û">(w.a<"B">("command", w.a<"B">(260998554108144903L), 191188367299315725L), this::m3104, 357832626693996259L);
   }

   public CompletableFuture<Suggestions> m3104(CommandContext<class_2172> var1, SuggestionsBuilder var2) {
      try {
         int var3 = w.a<"Û">(var2, 184899309879601106L);
         int var4 = (f2522 | 815403) + ~(f2522 & 815403) + 1 ^ 135787863;
         StringBuilder var5 = new StringBuilder();
         char[] var6 = w.a<"Û">(w.a<"Û">(var2, 110975976514483618L), 319560355189818562L);
         int var7 = var6.length;

         for (int var8 = (f2522 | 549580) + ~(f2522 & 549580) + 1 ^ 135521968; var8 < var7; var8++) {
            char var9 = var6[var8];
            var4++;
            if (var9 != w.a<"B">(334223681541342407L)
               && (var4 != ((f2522 | 994749) + ~(f2522 & 994749) + 1 ^ 135571904) || var9 != ((f2522 | 783034) + ~(f2522 & 783034) + 1 ^ 135296742))) {
               w.a<"Û">(var5, var9, 184577035858545201L);
            } else {
               var3 += var4;
               var4 = (f2522 | 52140) + ~(f2522 & 52140) + 1 ^ 136007632;
               w.a<"Û">(var5, (f2522 | 503331) + ~(f2522 & 503331) + 1 ^ 136063583, 187752500035504599L);
            }
         }

         var7 = var3;
         return w.a<"Û">(
            w.a<"Û">(C1001.f1489, w.a<"Û">(C1001.f1489, w.a<"Û">(var5, 167209770867625114L), null, 322470830194872479L), var4, 350667475442152866L),
            (Function<Suggestions, Suggestions>)var1x -> {
               StringRange var2x = w.a<"Û">(var1x, 135684656669921751L);
               var2x = new StringRange(w.a<"Û">(var2x, 302978517270901155L) + var7, w.a<"Û">(var2x, 213431375956711925L) + var7);
               List var3x = w.a<"Û">(
                  w.a<"Û">(
                     w.a<"Û">(w.a<"Û">(var1x, 315800637343310160L), 110814793610710346L),
                     (Function<Suggestion, Suggestion>)var1xx -> {
                        StringRange var2xx = new StringRange(
                           w.a<"Û">(w.a<"Û">(var1xx, 322945232843208719L), 302978517270901155L) + var7,
                           w.a<"Û">(w.a<"Û">(var1xx, 322945232843208719L), 213431375956711925L) + var7
                        );
                        return new Suggestion(var2xx, w.a<"Û">(var1xx, 342333320318574688L), w.a<"Û">(var1xx, 376511437373500541L));
                     },
                     141209812120559377L
                  ),
                  325049488880240942L
               );
               return new Suggestions(var2x, var3x);
            },
            191939036527835099L
         );
      } catch (Exception var10) {
         return w.a<"Û">(var2, 135487642270960168L);
      }
   }

   @C1027
   public void m3105(C0291 var1) {
      if (this.f2519 && this.f2521 != null && this.f2520 != null) {
         C1108 var2 = w.a<"Û">(
            this.f2521, this.f2520, new C1088(w.a<"Û">(var1, 300186008967279549L), C1089.f1243, w.a<"Û">(var1, 344615257042914433L)), 386228792603437303L
         );
         w.a<"Û">(C0933.f1421, var2, 133315123936993858L);
         w.a<"B">(
            w.a<"Û">(
               w.a<"Û">(w.a<"B">("Macro ", 228465064790135899L), w.a<"Û">(var2, 288062603600083063L), 267862536496645581L),
               " has been created",
               194629304146735395L
            ),
            w.a<"B">((f2522 | 409747) + ~(f2522 & 409747) + 1 ^ -136168688, 289296048454852994L),
            241936116971186271L
         );
         this.f2519 = (boolean)((f2522 | 961027) + ~(f2522 & 961027) + 1 ^ 135605887);
      }
   }

   public static String _eYywvlgkVrzv3Ve6HWn2jATOrtGNSWRbY0IKwEZofk22qdmiyJsK8qnui9qpxiym7CpXZKtM8JnZZyYPRXul4EML3xzqgXcxBKd/* $VF was: 0eYywvlgkVrzv3Ve6HWn2jATOrtGNSWRbY0IKwEZofk22qdmiyJsK8qnui9qpxiym7CpXZKtM8JnZZyYPRXul4EML3xzqgXcxBKd*/(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
