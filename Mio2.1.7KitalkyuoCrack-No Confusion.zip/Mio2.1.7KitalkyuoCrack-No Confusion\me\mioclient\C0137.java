package me.mioclient;

import com.mojang.blaze3d.platform.GlStateManager;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1297;
import net.minecraft.class_2960;

public class C0137 extends C0344 {
   public static final class_2960 f1579 = class_2960.method_60655("mio-mount", "textures/overlay.png");
   public static C0018 f1580 = C0933.f1409.m2696(C0018.class);
   public static int f1581 = -485578361;

   public C0137() {
      this.m$$KhWP9qaEyk4Hpf2s6QAMxOObFwGNhRe4O85tW7lF7YC66NpK19NKJO2PsEofzYs8I922737IwETboj8jk8TQNWamDuqdBrJoZ("solid");
   }

   public boolean m0666() {
      return (boolean)(f1580.isToggled() && f1580.f4095.getValue() == C0020.f0356
         ? (f1581 | 237012) + ~(f1581 & 237012) + 1 ^ -485673902
         : (f1581 | 796359) + ~(f1581 & 796359) + 1 ^ -486371520);
   }

   public boolean m0667(class_1297 var1) {
      return (boolean)(f1580 != null && var1 != null ? f1580.m3714(var1) : (f1581 | 258712) + ~(f1581 & 258712) + 1 ^ -485663969);
   }

   public void m0668() {
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2507("u_Texture", (f1581 | 978594) + ~(f1581 & 978594) + 1 ^ -486521051);
      int var1 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_1531()
         .method_4619(f1579)
         .method_4624();
      GlStateManager._activeTexture((f1581 | 282945) + ~(f1581 & 282945) + 1 ^ -485852153);
      GlStateManager._bindTexture(var1);
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq.m2506("u_Image", f1580.f4107.getValue());
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2507("u_Overlay", (f1581 | 847945) + ~(f1581 & 847945) + 1 ^ -486385201);
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq.m2508("u_OverlayAlpha", (double)f1580.m3713());
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2507("u_Width", f1580.m3716() ? (f1581 | 234503) + ~(f1581 & 234503) + 1 ^ -485671552 : f1580.f4097.getValue());
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2506(
            "u_FastLines",
            (boolean)(!f1580.f4098.getValue() && !C0789.f1300
               ? (f1581 | 788853) + ~(f1581 & 788853) + 1 ^ -486366990
               : (f1581 | 413085) + ~(f1581 & 413085) + 1 ^ -485956581)
         );
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2507("u_ShapeMode", (f1581 | 873682) + ~(f1581 & 873682) + 1 ^ -486277801);
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2508("u_GlowMultiplier", (double)f1580.f4099.getValue().floatValue());
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2510("u_FillColor", f1580.m3715() ? C0152.f3460 : f1580.m3712(f1580.f4114.getValue()));
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq.m2510("u_OutlineColor", f1580.f4116.getValue());
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2507("u_Dots", f1580.f4110.getValue().ordinal());
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq.m2507("u_DotsRadius", f1580.f4111.getValue());
      this.m$$V6AVWEzf5YnS3nyDKHfIPoaHqQJcAOVv2YkjXxlj2z5UctHzODWM54xeqEkPrPJDoY9uL3PX8O7pSO5uhSwrukBKHQG4vQAQq
         .m2508("u_DotsAlpha", (double)f1580.f4112.getValue().floatValue());
   }

   static {
      long var10000 = 3470432151496802087L;
   }

   public static String J85kSPulw7pZAy1l43RdUKTqCn7S0pcwWKPYhKk6GDjLUSVgeZXgPm7dxsLbUc6kgYWcQSf5I3AQAUiXpWkCUwCm4mqXrPjlb5NR(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
