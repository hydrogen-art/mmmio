package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_3966;

public class C0138 extends C1266 {
   public static final C0175 f3363 = C0933.f1409.m2696(C0175.class);
   public static final C0276 f3364 = C0933.f1409.m2696(C0276.class);
   public static C0671 elytrafly = C0933.f1409.m2696(C0671.class);
   public final C0015<Boolean> f3365;
   public final C0015<Boolean> f3366;
   public final C0015<Boolean> f3367;
   public boolean f3368;
   public static int f3369 = w.a<"B">(6962754795625205072L, 257832362129977838L);

   public C0138() {
      super("MiddleClick", "Middle click actions.", C1045.f3173);
      w.a<"B">(this, 242859112966675773L);
      w.a<"Û">(this, (boolean)((f3369 | 972337) + ~(f3369 & 972337) + 1 ^ -1539868864), 135570431627433065L);
   }

   @C1027
   public void m1384(C0591 var1) {
      if (m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1755 == null) {
         if (w.a<"B">(
                  w.a<"Û">(
                     w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
                     357688778031378998L
                  ),
                  (f3369 | 699190) + ~(f3369 & 699190) + 1 ^ -1540158907,
                  310841729015824326L
               )
               == ((f3369 | 213314) + ~(f3369 & 213314) + 1 ^ -1539645390)
            && !this.f3368) {
            this.f3368 = (boolean)((f3369 | 144717) + ~(f3369 & 144717) + 1 ^ -1539599299);
            class_239 var2 = m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1765;
            int var3 = !w.a<"Û">(
                     m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 323052896470161075L
                  )
                  && !w.a<"Û">(f3363, 355438456862731507L)
                  && !w.a<"Û">(elytrafly, 373177857405034913L)
               ? (f3369 | 633850) + ~(f3369 & 633850) + 1 ^ -1540355445
               : (f3369 | 122047) + ~(f3369 & 122047) + 1 ^ -1539801649;
            if (var3 != 0 && w.a<"Û">((Boolean)w.a<"Û">(this.f3366, 174312564406604366L), 354697271520518137L)) {
               w.a<"Û">(this, 266720978383310175L);
            } else if (var2 instanceof class_3966 var4
               && w.a<"Û">(var4, 120740545413154530L) instanceof class_1657 var5
               && w.a<"Û">((Boolean)w.a<"Û">(this.f3365, 174312564406604366L), 354697271520518137L)) {
               if (w.a<"Û">(C0933.f1417, w.a<"Û">(w.a<"Û">(var5, 138826997201410603L), 211085733983653208L), 225253295937045434L)) {
                  w.a<"Û">(C0933.f1417, w.a<"Û">(w.a<"Û">(var5, 138826997201410603L), 211085733983653208L), 193741371501337623L);
               } else {
                  w.a<"Û">(C0933.f1417, w.a<"Û">(w.a<"Û">(var5, 138826997201410603L), 211085733983653208L), 268852395399414033L);
               }
            }
         } else if (w.a<"B">(
               w.a<"Û">(
                  w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 165739045880072086L),
                  357688778031378998L
               ),
               (f3369 | 720490) + ~(f3369 & 720490) + 1 ^ -1540137191,
               310841729015824326L
            )
            == 0) {
            this.f3368 = (boolean)((f3369 | 289268) + ~(f3369 & 289268) + 1 ^ -1539454843);
         }
      }
   }

   public void m1385() {
      class_1268 var1 = w.a<"B">(class_1802.field_8639, 290444706100011361L);
      int var2 = w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 373857742241070098L).field_7545;
      int var3 = w.a<"B">(class_1802.field_8639, 261845468269893067L);
      int var4 = w.a<"B">(class_1802.field_8639, 113439863899466963L);
      if (var1 != null) {
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            var1,
            114543782118481187L
         );
      } else if (var3 != ((f3369 | 663700) + ~(f3369 & 663700) + 1 ^ 1540128282)) {
         int var5 = var4 != ((f3369 | 72377) + ~(f3369 & 72377) + 1 ^ 1539785783)
               && !w.a<"Û">((Boolean)w.a<"Û">(this.f3367, 174312564406604366L), 354697271520518137L)
            ? (f3369 | 230396) + ~(f3369 & 230396) + 1 ^ -1539693939
            : (f3369 | 367921) + ~(f3369 & 367921) + 1 ^ -1539556287;
         w.a<"Û">(this, var4, var3, (boolean)var5, 349241608230365075L);
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1761,
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_1268.field_5808,
            114543782118481187L
         );
         f3364.f2265 = w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724, 114479647550158442L
         );
         w.a<"Û">(this, var2, var3, (boolean)var5, 349241608230365075L);
      }
   }

   public void m1386(int var1, int var2, boolean var3) {
      if (var3) {
         w.a<"B">(var2, 209502932342608419L);
      } else {
         w.a<"B">(var1, 279757124141714355L);
      }
   }

   public static String bP5MFo52mxjOrJR7Wvhum3NPSjiIYOdKwvDwFIOXvlKi4iYR8fPWkAYhvHbcu8YotWAy1LuxXdyiiJpCn0r2QpU1z6PMen0wxyhZ(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
