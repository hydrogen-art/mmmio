package me.mioclient;

import com.mojang.blaze3d.systems.RenderSystem;
import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4587;

public class C0294 implements C0045, C0448 {
   public static C1323 hud = C0933.f1409.m2696(C1323.class);
   public final C0296<C1092> f0425 = new C0296<>();
   public final C0860 f0426;
   public static int f0427 = -1696017131;

   public C0294(C0860 var1) {
      this.f0426 = var1;
   }

   @Override
   public void m0001(class_332 var1, class_4587 var2, double var3, double var5) {
      for (int var7 = (f0427 | 83700) + ~(f0427 & 83700) + 1 ^ -1695968287; var7 < this.f0425.size(); var7++) {
         C1092 var8 = this.f0425.get(var7);
         var8.m2943();
         int var9 = !var8.m2956() && !(var8.m2964() > 0.0F)
            ? (f0427 | 126530) + ~(f0427 & 126530) + 1 ^ -1695990953
            : (f0427 | 347354) + ~(f0427 & 347354) + 1 ^ -1695704626;
         float[] var10 = var8.m1073();
         if (var9 == 0) {
            float[] var10000 = new float[(f0427 | 201576) + ~(f0427 & 201576) + 1 ^ -1695824257];
            var10000[(f0427 | 955988) + ~(f0427 & 955988) + 1 ^ -1696185535] = 0.0F;
            var10000[(f0427 | 312512) + ~(f0427 & 312512) + 1 ^ -1695804972] = 0.0F;
            var10 = var10000;
         }

         var8.m2953(var10);
         if (this.f0426 != C0860.f2181) {
            var8.m2946(
               this.m2288(var10[(f0427 | 537078) + ~(f0427 & 537078) + 1 ^ -1696537373], this.f0426),
               (boolean)((f0427 | 64551) + ~(f0427 & 64551) + 1 ^ -1696061133)
            );
            if (var7 == 0) {
               var8.m2949(
                  this.m2289(var10[(f0427 | 254664) + ~(f0427 & 254664) + 1 ^ -1695860772], this.f0426),
                  (boolean)((f0427 | 375596) + ~(f0427 & 375596) + 1 ^ -1695715784)
               );
            } else if (this.f0426 == C0860.f2178 || this.f0426 == C0860.f2179) {
               var8.m2949(
                  this.f0425.get(var7 - ((f0427 | 502915) + ~(f0427 & 502915) + 1 ^ -1695581801)).m2947()
                     - var10[(f0427 | 185569) + ~(f0427 & 185569) + 1 ^ -1695940107],
                  (boolean)((f0427 | 758348) + ~(f0427 & 758348) + 1 ^ -1696381096)
               );
            }
         }

         if (var9 != 0) {
            RenderSystem.setShaderColor(
               Float.intBitsToFloat((f0427 | 413166) + ~(f0427 & 413166) + 1 ^ -1519478533),
               Float.intBitsToFloat((f0427 | 165346) + ~(f0427 & 165346) + 1 ^ -1519759113),
               Float.intBitsToFloat((f0427 | 881910) + ~(f0427 & 881910) + 1 ^ -1520066077),
               var8.m2964()
            );
            var8.m0001(var1, var2, var3, var5);
            RenderSystem.setShaderColor(
               Float.intBitsToFloat((f0427 | 403717) + ~(f0427 & 403717) + 1 ^ -1519453168),
               Float.intBitsToFloat((f0427 | 590491) + ~(f0427 & 590491) + 1 ^ -1520314482),
               Float.intBitsToFloat((f0427 | 977789) + ~(f0427 & 977789) + 1 ^ -1520026008),
               Float.intBitsToFloat((f0427 | 85956) + ~(f0427 & 85956) + 1 ^ -1519805743)
            );
         }

         if (var7 < this.f0425.size() - ((f0427 | 852463) + ~(f0427 & 852463) + 1 ^ -1696213765)
            && this.f0426 != C0860.f2181
            && this.m2287(this.f0426) == ((f0427 | 982877) + ~(f0427 & 982877) + 1 ^ -1696191927)) {
            this.f0425
               .get(var7 + ((f0427 | 276058) + ~(f0427 & 276058) + 1 ^ -1695751346))
               .m2949(
                  var8.m2947() + var10[(f0427 | 675090) + ~(f0427 & 675090) + 1 ^ -1696425978],
                  (boolean)((f0427 | 941210) + ~(f0427 & 941210) + 1 ^ -1696167538)
               );
         }
      }
   }

   public C0860 m2285() {
      return this.f0426;
   }

   public C0296<C1092> m2286() {
      return this.f0425;
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public int m2287(C0860 var1) {
      return switch (<unrepresentable>.f1958[var1.ordinal()]) {
         case 1, 2, 3, 4 -> (f0427 | 484077) + ~(f0427 & 484077) + 1 ^ -1695565831;
         case 5, 6 -> (f0427 | 953307) + ~(f0427 & 953307) + 1 ^ 1696178481;
         default -> throw new MatchException(null, null);
      };
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public float m2288(float var1, C0860 var2) {
      return switch (<unrepresentable>.f1958[var2.ordinal()]) {
         case 1, 5 -> (float)hud.m2899();
         case 2, 6 -> (float)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4486()
         - var1
         - (float)hud.m2899();
         case 3 -> (float)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4486()
            / Float.intBitsToFloat((f0427 | 965339) + ~(f0427 & 965339) + 1 ^ -622432306)
         - var1 / Float.intBitsToFloat((f0427 | 688551) + ~(f0427 & 688551) + 1 ^ -622701390);
         case 4 -> throw new IllegalArgumentException("dumb");
         default -> throw new MatchException(null, null);
      };
   }

   // $VF: Unable to simplify switch on enum
   // Please report this to the Vineflower issue tracker, at https://github.com/Vineflower/vineflower/issues with a copy of the class file (if you have the rights to distribute it!)
   public float m2289(float var1, C0860 var2) {
      return switch (<unrepresentable>.f1958[var2.ordinal()]) {
         case 1, 3 -> (float)hud.m2900();
         case 2 -> hud.m2897() + (float)hud.m2900();
         case 4 -> throw new IllegalArgumentException("dumb");
         case 5, 6 -> (float)m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.method_22683().method_4502()
         - var1
         - this.m2290();
         default -> throw new MatchException(null, null);
      };
   }

   public float m2290() {
      return class_3532.method_15363((float)hud.m2900() + hud.m2896(), 0.0F, Float.intBitsToFloat((f0427 | 215699) + ~(f0427 & 215699) + 1 ^ -611606650));
   }

   static {
      long var10000 = 4406238957589145858L;
   }

   public static String LDFcxzJRQr5n8qPUQsdb9y4hBXmTa2GrLkN0fKrgZskr3f9Q6OpDbG13CN7Vnw2OvRyOq8MFl2LmFZjoIeaquvvoDOqSIyM7WcxX(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
