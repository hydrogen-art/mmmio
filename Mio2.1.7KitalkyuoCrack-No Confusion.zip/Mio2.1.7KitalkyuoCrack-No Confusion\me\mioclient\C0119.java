package me.mioclient;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.lang.invoke.MethodHandles.Lookup;
import me.mioclient.mixin.ducks.DuckSession;
import net.minecraft.class_2172;
import net.minecraft.class_442;
import net.minecraft.class_500;
import net.minecraft.class_642;

public final class C0119 extends C0219 {
   public static int f4565 = w.a<"B">(1480517901212571238L, 257832362129977838L);

   public C0119() {
      super("session");
   }

   @Override
   public void exec(LiteralArgumentBuilder<class_2172> var1) {
      w.a<"Û">(
         var1,
         w.a<"Û">(
            w.a<"B">("name", w.a<"B">(147271288244807063L), 191188367299315725L),
            (Command)var0 -> {
               String var1x = (String)w.a<"Û">(var0, "name", String.class, 275658406246533271L);
               if (w.a<"Û">(var1x, 120891947504160641L) > ((f4565 | 889035) + ~(f4565 & 889035) + 1 ^ -1412249079)) {
                  return (f4565 | 228313) + ~(f4565 & 228313) + 1 ^ -1411636981;
               } else {
                  if (w.a<"Û">(
                        w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 231206531387546689L),
                        131347417028836246L
                     )
                     != null) {
                     w.a<"Û">(
                        w.a<"Û">(
                           w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 231206531387546689L),
                           337197838954396671L
                        ),
                        w.a<"B">("", 273107254583785490L),
                        165895829995046834L
                     );
                     class_642 var2 = w.a<"Û">(
                        w.a<"Û">(m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 231206531387546689L),
                        131347417028836246L
                     );
                     w.a<"B">(
                        new class_500(new class_442()),
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff,
                        w.a<"B">(var2.field_3761, 172279064031210494L),
                        var2,
                        (boolean)((f4565 | 934033) + ~(f4565 & 934033) + 1 ^ -1412359614),
                        null,
                        179439395438931282L
                     );
                  }

                  ((DuckSession)w.a<"Û">(
                        m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff, 332480351334421754L
                     ))
                     .setUsername(var1x);
                  w.a<"B">(
                     w.a<"B">(new C1002().m2591(var1x).m2593("Session's name has been set to \u0001."), 228465064790135899L),
                     w.a<"B">((f4565 | 629688) + ~(f4565 & 629688) + 1 ^ 1411989141, 289296048454852994L),
                     241936116971186271L
                  );
                  return (f4565 | 11705) + ~(f4565 & 11705) + 1 ^ -1411418262;
               }
            },
            368995281709124746L
         ),
         289819728773344295L
      );
   }

   public static String G5Pj85vqT176oDt2kJgcYQt4rFNrsIQV7ck0fHAC9L7OBkJroqF5MVmdtdOYNQEJalPdilPKnjMVZYQVWB90Fd8pJrRg6BjZ3aaC(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
