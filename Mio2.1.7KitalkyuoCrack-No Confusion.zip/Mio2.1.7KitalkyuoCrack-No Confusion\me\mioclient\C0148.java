package me.mioclient;

import java.lang.invoke.MethodHandles.Lookup;
import net.minecraft.class_5134;

public class C0148 extends C1266 {
   public static final float f3034 = w.a<"B">((C0148.f3037 | 92651) + ~(C0148.f3037 & 92651) + 1 ^ -1042830200, 349057757755238323L);
   public final C0015<Float> f3035;
   public final C0015<Boolean> f3036;
   public static int f3037 = w.a<"B">(8234635190927118292L, 257832362129977838L);

   public C0148() {
      super("HighJump", "Makes you jump higher.", C1045.f3175);
      w.a<"B">(this, 242859112966675773L);
   }

   @Override
   public void onDisable() {
      if (!w.a<"Û">(this, 205492958615326489L)) {
         w.a<"Û">(this, 245053489916645080L);
      }
   }

   @C1027
   public void m1213(C0612 var1) {
      if (!w.a<"Û">((Boolean)w.a<"Û">(this.f3036, 174312564406604366L), 354697271520518137L) && w.a<"B">(239474890139367192L)) {
         w.a<"Û">(this, 245053489916645080L);
      } else {
         w.a<"Û">(this, w.a<"Û">((Float)w.a<"Û">(this.f3035, 174312564406604366L), 149784643039979208L), 143993051702971054L);
      }
   }

   public void reset() {
      w.a<"Û">(this, w.a<"B">((f3037 | 671235) + ~(f3037 & 671235) + 1 ^ -1042482336, 349057757755238323L), 143993051702971054L);
   }

   public void m1214(float var1) {
      w.a<"Û">(
         w.a<"Û">(
            m$$Ui76c5BZRSBpPm0DfeVTRlI7WOQRBMv4Y8TvsOKW24HodABbko9fwnPvSiOuXrlYsaF3dKAbJpJAVbaSAbJty0rklFwmhBjff.field_1724,
            class_5134.field_23728,
            362921755500736432L
         ),
         (double)var1,
         159793083125634076L
      );
   }

   public static String hSIWMqkuPhqbjtlQn38MPAuvXqf7zZ7KDaHS2Z69uhVM94Ftq725h22kPBEOeEvWk9pDxUCSNnVKYnhNCS1ger8KA78JTTUs7llO(
      Lookup var0, String var1, Class var2, int var3
   ) {
      return C0095.7IgZv9bBL5GpyGTf0kFTQpZX9VWJwgZFTFXlfKJ1x9FHDv9zDA7Ntr6wDp1wDNWSCHg8DYCpducbijJx2MEnobhlOb9ksiHrPH7r(var3);
   }
}
