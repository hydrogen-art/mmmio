package me.mioclient;

import java.util.function.Predicate;

public class C0506 implements Predicate {
   public C0686 f2329;

   public C0506(C0686 var1) {
      this.f2329 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f2329.f2621, 254992554122318132L);
   }
}
