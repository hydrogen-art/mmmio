package me.mioclient;

import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;

record C0465() {
   public final long f3223;
   public final class_238 f3224;
   public final C0364 f3225;
   public final int f3226;
   public final int f3227;
   public final class_243 f3228;
   public final C0164 f3229;
   public final String f3230;
   public static int f3231 = w.a<"B">(5602645305286573722L, 257832362129977838L);

   public C0465(long var1, class_238 var3, C0364 var4, int var5, int var6, class_243 var7, C0164 var8, String var9) {
      this.f3223 = var1;
      this.f3224 = var3;
      this.f3225 = var4;
      this.f3226 = var5;
      this.f3227 = var6;
      this.f3228 = var7;
      this.f3229 = var8;
      this.f3230 = var9;
   }

   public static C0465 m3355(class_1657 var0, String var1) {
      C0164 var2 = new C0164(C0045.f2103.field_1687);
      w.a<"Û">(var2, var0, 224394324517681089L);
      var2.field_6235 = var2.field_6213 = (f3231 | 140380) + ~(f3231 & 140380) + 1 ^ 1938024579;
      long var3 = w.a<"B">(223409559795593705L);
      class_238 var5 = w.a<"Û">(var0, 224997102751365724L);
      C0364 var6 = w.a<"B">(375727057840316412L);
      int var7 = w.a<"B">(w.a<"B">(var0, 181476777857313967L), 292355722995856317L);
      int var8 = w.a<"Û">(C0933.f1427, var0, 193163454500097853L);
      class_243 var9 = w.a<"Û">(var0, 359920018220808632L);
      return new C0465(var3, var5, var6, var7, var8, var9, var2, var1);
   }

   public long m3356() {
      return this.f3223;
   }

   public class_238 m3357() {
      return this.f3224;
   }

   public C0364 m3358() {
      return this.f3225;
   }

   public int m3359() {
      return this.f3226;
   }

   public int m3360() {
      return this.f3227;
   }

   public class_243 m3361() {
      return this.f3228;
   }

   public C0164 m3362() {
      return this.f3229;
   }

   public String m3363() {
      return this.f3230;
   }
}
