package me.mioclient;

import java.util.function.Predicate;

public class C0252 implements Predicate {
   public C1220 f0895;

   public C0252(C1220 var1) {
      this.f0895 = var1;
      super();
   }

   @Override
   public boolean test(Object var1) {
      return w.a<"Û">(this.f0895.f1541, 174312564406604366L) != C1221.f4252;
   }
}
